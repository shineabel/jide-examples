/**
 * The package contains basic ComponentUI implementation for most of the JIDE components.
 */
package com.jidesoft.plaf.basic;