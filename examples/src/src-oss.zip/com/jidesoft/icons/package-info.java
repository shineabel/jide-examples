/**
 * The package contains classes related to icons for JIDE Common Layer.
 */
package com.jidesoft.icons;