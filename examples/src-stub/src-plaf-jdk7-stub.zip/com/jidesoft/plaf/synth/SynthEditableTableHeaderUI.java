package com.jidesoft.plaf.synth;


/**
 *  UI class for EditableTableHeader for Synth L&F.
 */
public class SynthEditableTableHeaderUI extends SynthSortableTableHeaderUI {

	public SynthEditableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
