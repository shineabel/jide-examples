package com.jidesoft.plaf.synth;


/**
 *  UI class for GroupTableHeader for Synth L&F.
 * 
 *  @since 3.1.0
 */
public class SynthGroupTableHeaderUI extends SynthAutoFilterTableHeaderUI {

	public SynthGroupTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
