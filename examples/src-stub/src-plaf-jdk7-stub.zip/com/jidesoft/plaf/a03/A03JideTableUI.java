package com.jidesoft.plaf.a03;


/**
 *  The TableUI based on BasicTableUI. It's almost the same as BasicTableUI except the methods paintCell() and
 *  paintGrid() methods are protected so that subclasses can override those methods.
 */
public class A03JideTableUI extends A03TableUI {

	protected TableUIDelegate _delegate;

	public A03JideTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	public void installDefaults() {
	}

	public void uninstallDefaults() {
	}

	protected TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void paintGrid(java.awt.Graphics g, int rMin, int rMax, int cMin, int cMax) {
	}

	protected void paintDraggedArea(java.awt.Graphics g, int rMin, int rMax, javax.swing.table.TableColumn draggedColumn, int distance) {
	}

	protected void paintCell(java.awt.Graphics g, java.awt.Rectangle cellRect, int row, int column) {
	}
}
