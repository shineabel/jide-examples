package com.jidesoft.plaf.a03;


/**
 *  A Basic L&F implementation of <code>GroupListUI</code>.
 */
public class A03GroupListUI extends A03ListUI {

	/**
	 *  Local cache of bounds of all headers
	 */
	protected java.util.Map _headerBounds;

	public A03GroupListUI() {
	}

	public static void loadActionMap(LazyActionMap map) {
	}

	/**
	 *  Uninitializes <code>this.list</code> by calling <code>uninstallListeners()</code>,
	 *  <code>uninstallKeyboardActions()</code>, and <code>uninstallDefaults()</code> in order.  Sets this.list to null.
	 * 
	 *  @see #uninstallListeners
	 *  @see #uninstallKeyboardActions
	 *  @see #uninstallDefaults
	 */
	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	/**
	 *  Initialize JList properties, e.g. font, foreground, and background, and add the CellRendererPane.  The font,
	 *  foreground, and background properties are only set if their current value is either null or a UIResource, other
	 *  properties are set if the current value is null.
	 * 
	 *  @see #uninstallDefaults
	 *  @see #installUI
	 */
	@java.lang.Override
	protected void installDefaults() {
	}

	/**
	 *  Set the JList properties that haven't been explicitly overridden to null.  A property is considered overridden if
	 *  its current value is not a UIResource.
	 * 
	 *  @see #installDefaults
	 *  @see #uninstallUI
	 */
	@java.lang.Override
	protected void uninstallDefaults() {
	}

	/**
	 *  Create and install the listeners for the JList, its model, and its selectionModel.  This method is called at
	 *  installUI() time.
	 * 
	 *  @see #installUI
	 *  @see #uninstallListeners
	 */
	@java.lang.Override
	protected void installListeners() {
	}

	/**
	 *  Remove the listeners for the JList, its model, and its selectionModel.  All of the listener fields, are reset to
	 *  null here.  This method is called at uninstallUI() time, it should be kept in sync with installListeners.
	 * 
	 *  @see #uninstallUI
	 *  @see #installListeners
	 */
	@java.lang.Override
	public void uninstallListeners() {
	}

	/**
	 *  Paint the rows that intersect the Graphics objects clipRect.  This method calls paintCell as necessary.
	 *  Subclasses may want to override these methods.
	 * 
	 *  @see #paintCell
	 */
	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void originalPaintCell(java.awt.Graphics g, int row, java.awt.Rectangle rowBounds, javax.swing.ListCellRenderer cellRenderer, javax.swing.ListModel dataModel, javax.swing.ListSelectionModel selModel, int leadIndex) {
	}

	@java.lang.Override
	protected void paintCell(java.awt.Graphics g, int row, java.awt.Rectangle rowBounds, javax.swing.ListCellRenderer cellRenderer, javax.swing.ListModel dataModel, javax.swing.ListSelectionModel selModel, int leadIndex) {
	}

	/**
	 *  The preferredSize of the list depends upon the layout orientation. <table summary="Describes the preferred size
	 *  for each layout orientation"> <tr><th>Layout Orientation</th><th>Preferred Size</th></tr> <tr> <td>JList.VERTICAL
	 *  <td>The preferredSize of the list is total height of the rows and the maximum width of the cells.  If
	 *  JList.fixedCellHeight is specified then the total height of the rows is just (cellVerticalMargins +
	 *  fixedCellHeight) * model.getSize() where rowVerticalMargins is the space we allocate for drawing the yellow focus
	 *  outline. Similarly if fixedCellWidth is specified then we just use that. </td> <tr> <td>JList.VERTICAL_WRAP
	 *  <td>If the visible row count is greater than zero, the preferredHeight is the maximum cell height *
	 *  visibleRowCount. If the visible row count is &lt;= 0, the preferred height is either the current height of the
	 *  list, or the maximum cell height, whichever is bigger. The preferred width is than the maximum cell width *
	 *  number of columns needed. Where the number of columns needs is list.height / max cell height. Max cell height is
	 *  either the fixed cell height, or is determined by iterating through all the cells to find the maximum height from
	 *  the ListCellRenderer. <tr> <td>JList.HORIZONTAL_WRAP <td>If the visible row count is greater than zero, the
	 *  preferredHeight is the maximum cell height * adjustedRowCount.  Where visibleRowCount is used to determine the
	 *  number of columns. Because this lays out horizontally the number of rows is then determined from the column
	 *  count.  For example, lets say you have a model with 10 items and the visible row count is 8. The number of
	 *  columns needed to display this is 2, but you no longer need 8 rows to display this, you only need 5, thus the
	 *  adjustedRowCount is 5. <p>If the visible row count is &lt;= 0, the preferred height is dictated by the number of
	 *  columns, which will be as many as can fit in the width of the <code>JList</code> (width / max cell width), with
	 *  at least one column.  The preferred height then becomes the model size / number of columns * maximum cell height.
	 *  Max cell height is either the fixed cell height, or is determined by iterating through all the cells to find the
	 *  maximum height from the ListCellRenderer. </table> The above specifies the raw preferred width and height. The
	 *  resulting preferred width is the above width + insets.left + insets.right and the resulting preferred height is
	 *  the above height + insets.top + insets.bottom. Where the <code>Insets</code> are determined from
	 *  <code>list.getInsets()</code>.
	 * 
	 *  @param c The JList component.
	 *  @return The total size of the list.
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	/**
	 *  Returns a new instance of BasicGroupListUI.  BasicGroupListUI delegates are allocated one per JList.
	 * 
	 *  @return A new ListUI implementation for the Windows look and feel.
	 */
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent list) {
	}

	/**
	 *  Convert a point in <code>JList</code> coordinates to the closest index of the cell at that location. To determine
	 *  if the cell actually contains the specified location use a combination of this method and
	 *  <code>getCellBounds</code>.  Returns -1 if the model is empty.
	 * 
	 *  @return The index of the cell at location, or -1.
	 */
	@java.lang.Override
	public int locationToIndex(javax.swing.JList list, java.awt.Point location) {
	}

	public int locationToRow(javax.swing.JList list, java.awt.Point location) {
	}

	/**
	 *  @return The origin of the index'th cell, null if index is invalid.
	 */
	@java.lang.Override
	public java.awt.Point indexToLocation(javax.swing.JList list, int index) {
	}

	@java.lang.Override
	public java.awt.Rectangle getCellBounds(javax.swing.JList list, int index1, int index2) {
	}

	/**
	 *  Gets the bounds of the specified model index, returning the resulting bounds, or null if <code>index</code> is
	 *  not valid.
	 *  <p/>
	 *  If the index >= 0, it returns the bounds of index'th element If the index &lt;= 2, it returns the bounds of one
	 *  group's header
	 */
	public java.awt.Rectangle getCellBounds(javax.swing.JList list, int index) {
	}

	public int getRowCount() {
	}

	public int getColumnCount(int row) {
	}

	/**
	 *  If updateLayoutStateNeeded is non zero, call updateLayoutState() and reset updateLayoutStateNeeded.  This method
	 *  should be called by methods before doing any computation based on the geometry of the list. For example it's the
	 *  first call in paint() and getPreferredSize().
	 * 
	 *  @see #updateLayoutState
	 */
	@java.lang.Override
	protected void maybeUpdateLayoutState() {
	}

	/**
	 *  Recompute the value of cellHeight or cellHeights based and cellWidth, based on the current font and the current
	 *  values of fixedCellWidth, fixedCellHeight, and prototypeCellValue.
	 * 
	 *  @see #maybeUpdateLayoutState
	 */
	@java.lang.Override
	@java.lang.SuppressWarnings("unchecked")
	protected void updateLayoutState() {
	}

	protected void updateGroupLayoutState(int fixedCellWidth, int fixedCellHeight) {
	}

	/**
	 *  Invoked when the list is laid out horizontally to determine how many columns to create.
	 *  <p/>
	 *  This updates the <code>rowsPerColumn</code>, <code>columnCount</code>, <code>preferredHeight</code> and
	 *  potentially <code>cellHeight</code> instance variables.
	 */
	protected void updateCellLayoutState(int fixedCellWidth, int fixedCellHeight) {
	}

	/**
	 *  Registers the keyboard bindings on the <code>JList</code> that the <code>BasicListUI</code> is associated with.
	 *  This method is called at installUI() time.
	 * 
	 *  @see #installUI
	 */
	@java.lang.Override
	protected void installKeyboardActions() {
	}

	/**
	 *  Unregisters keyboard actions installed from <code>installKeyboardActions</code>. This method is called at
	 *  uninstallUI() time - subclasses should ensure that all of the keyboard actions registered at installUI time are
	 *  removed here.
	 * 
	 *  @see #installUI
	 */
	@java.lang.Override
	protected void uninstallKeyboardActions() {
	}

	/**
	 *  The ListSelectionListener that's added to the JLists selection model at installUI time, and whenever the
	 *  JList.selectionModel property changes.  When the selection changes we repaint the affected rows.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	public class ListSelectionHandler {


		public A03GroupListUI.ListSelectionHandler() {
		}

		@java.lang.Override
		public void valueChanged(javax.swing.event.ListSelectionEvent e) {
		}
	}

	/**
	 *  The PropertyChangeListener that's added to the JList at installUI time.  When the value of a JList property that
	 *  affects layout changes, we set a bit in updateLayoutStateNeeded. If the JLists model changes we additionally
	 *  remove our listeners from the old model.  Likewise for the JList selectionModel.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	public class PropertyChangeHandler {


		public A03GroupListUI.PropertyChangeHandler() {
		}

		@java.lang.Override
		public void propertyChange(java.beans.PropertyChangeEvent e) {
		}
	}
}
