package com.jidesoft.plaf.a03;


public class A03Customizer {

	public A03Customizer() {
	}

	@java.lang.Override
	public void customize(javax.swing.UIDefaults defaults) {
	}
}
