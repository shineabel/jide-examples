package com.jidesoft.plaf.a03;


public class A03NavigableTableUI extends A03JideTableUI {

	public A03NavigableTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}
}
