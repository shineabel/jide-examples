package com.jidesoft.plaf.tonic;


/**
 *  UI class for SortableTableHeader for Synth L&F.
 * 
 *  @since 3.1.0
 */
public class TonicSortableTableHeaderUI extends TonicCellStyleTableHeaderUI {

	public TonicSortableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	/**
	 *  Creates the default UI delegate instance to paint the header.
	 * 
	 *  @return the default UI delegate instance
	 */
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
