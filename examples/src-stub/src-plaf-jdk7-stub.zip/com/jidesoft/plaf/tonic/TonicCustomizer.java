package com.jidesoft.plaf.tonic;


public class TonicCustomizer {

	public TonicCustomizer() {
	}

	@java.lang.Override
	public void customize(javax.swing.UIDefaults defaults) {
	}
}
