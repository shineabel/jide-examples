package com.jidesoft.plaf.synthetica;


public class SyntheticaPopupBorder implements javax.swing.border.Border {

	public SyntheticaPopupBorder() {
	}

	public java.awt.Insets getBorderInsets(java.awt.Component c) {
	}

	public boolean isBorderOpaque() {
	}

	public void paintBorder(java.awt.Component c, java.awt.Graphics g, int x, int y, int w, int h) {
	}
}
