package com.jidesoft.plaf.substance;


public class SubstanceCellStyleTableHeaderUIDelegate extends BasicCellStyleTableHeaderUIDelegate {

	public SubstanceCellStyleTableHeaderUIDelegate(javax.swing.table.JTableHeader header, javax.swing.CellRendererPane rendererPane) {
	}

	@java.lang.Override
	protected void customizePaint(java.awt.Graphics g, javax.swing.table.TableColumn column, java.awt.Rectangle cellRect) {
	}
}
