package com.jidesoft.plaf.substance;


public class SubstanceJideSplitButtonUI extends BasicJideSplitButtonUI {

	/**
	 *  Tracker for visual state transitions.
	 */
	protected ButtonVisualStateTracker substanceVisualStateTracker;

	protected javax.swing.AbstractButton button;

	public SubstanceJideSplitButtonUI(javax.swing.AbstractButton button) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	@java.lang.Override
	protected void uninstallListeners() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public boolean isInside(java.awt.event.MouseEvent me) {
	}

	@java.lang.Override
	public StateTransitionTracker getTransitionTracker() {
	}
}
