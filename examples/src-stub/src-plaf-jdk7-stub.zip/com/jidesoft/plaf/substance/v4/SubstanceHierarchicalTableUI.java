package com.jidesoft.plaf.substance.v4;


public class SubstanceHierarchicalTableUI extends SubstanceCellSpanTableUI {

	public SubstanceHierarchicalTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	protected void paintGrid(java.awt.Graphics g, int rMin, int rMax, int cMin, int cMax) {
	}

	@java.lang.Override
	protected void paintCell(java.awt.Graphics g, java.awt.Rectangle cellRect, int row, int column) {
	}
}
