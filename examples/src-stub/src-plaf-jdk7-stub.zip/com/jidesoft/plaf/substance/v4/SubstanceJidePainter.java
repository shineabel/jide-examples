package com.jidesoft.plaf.substance.v4;


public class SubstanceJidePainter extends XertoPainter {

	public SubstanceJidePainter() {
	}

	public static ThemePainter getInstance() {
	}

	@java.lang.Override
	public void paintButtonBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	/**
	 *  Retrieves background image for the specified button in button pair (such as scrollbar arrows, for example).
	 * 
	 *  @param button            Button.
	 *  @param painter           Gradient painter.
	 *  @param width             Button width.
	 *  @param height            Button height.
	 *  @param side              Button orientation.
	 *  @param toIgnoreOpenSides If <code>true</code>, the open side setting (controlled by the {@link
	 *                           SubstanceLookAndFeel#BUTTON_OPEN_SIDE_PROPERTY} is ignored.
	 *  @return Button background image.
	 */
	public static java.awt.image.BufferedImage getPairwiseBackground(javax.swing.AbstractButton button, SubstanceGradientPainter painter, int width, int height, SubstanceConstants.Side side, boolean toIgnoreOpenSides) {
	}

	@java.lang.Override
	public void paintDockableFrameTitlePane(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePaneTitlePaneBackgroundEmphasized(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePaneTitlePaneBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int s) {
	}
}
