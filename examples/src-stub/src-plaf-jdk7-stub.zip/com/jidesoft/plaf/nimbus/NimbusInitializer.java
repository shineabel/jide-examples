package com.jidesoft.plaf.nimbus;


public class NimbusInitializer {

	public NimbusInitializer() {
	}

	public void initialize(javax.swing.UIDefaults defaults) {
	}
}
