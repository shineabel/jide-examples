package com.jidesoft.plaf.plastic;


public class PlasticExComboBoxUI extends PlasticComboBoxUI {

	protected ExComboBox _comboBox;

	public PlasticExComboBoxUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected javax.swing.JButton createArrowButton() {
	}

	@java.lang.Override
	protected javax.swing.plaf.basic.ComboPopup createPopup() {
	}

	@java.lang.Override
	protected javax.swing.ListCellRenderer createRenderer() {
	}

	@java.lang.Override
	protected javax.swing.ComboBoxEditor createEditor() {
	}

	public PopupPanel getPopupPanel() {
	}

	@java.lang.Override
	protected void selectNextPossibleValue() {
	}

	@java.lang.Override
	public void configureEditor() {
	}

	@java.lang.Override
	protected java.awt.event.FocusListener createFocusListener() {
	}
}
