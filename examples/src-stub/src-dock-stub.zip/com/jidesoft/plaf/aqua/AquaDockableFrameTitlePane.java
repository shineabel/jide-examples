package com.jidesoft.plaf.aqua;


/**
 *  Aqua L&f implementation of title bar for DockableFrame
 */
public class AquaDockableFrameTitlePane extends com.jidesoft.plaf.basic.BasicDockableFrameTitlePane {

	public AquaDockableFrameTitlePane(com.jidesoft.docking.DockableFrame f) {
	}

	@java.lang.Override
	protected java.awt.Dimension getMaximumButtonSize() {
	}

	@java.lang.Override
	protected void installDefaults() {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	@java.lang.Override
	protected void changeButtonType(javax.swing.AbstractButton button, int type) {
	}

	@java.lang.Override
	protected void paintTitleBackground(java.awt.Graphics g) {
	}

	@java.lang.Override
	protected void createComponents() {
	}

	protected void updateButtonVisibilities() {
	}

	protected boolean anyRollovers() {
	}

	@java.lang.Override
	protected java.awt.LayoutManager createLayout() {
	}

	@java.lang.Override
	protected boolean dockableFrameHasFocus() {
	}

	protected class ButtonChangeListener {


		public void stateChanged(javax.swing.event.ChangeEvent changeevent) {
		}
	}

	public class AquaTitlePaneLayout {


		public AquaDockableFrameTitlePane.AquaTitlePaneLayout() {
		}

		public void addLayoutComponent(String name, java.awt.Component c) {
		}

		public void removeLayoutComponent(java.awt.Component c) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container c) {
		}

		public java.awt.Dimension minimumLayoutSize(java.awt.Container c) {
		}

		public void layoutContainer(java.awt.Container c) {
		}
	}

	public class AquaCloseButton {


		public AquaDockableFrameTitlePane.AquaCloseButton() {
		}

		/**
		 *  Resets the UI property to a value from the current look and feel.
		 * 
		 *  @see JComponent#updateUI
		 */
		@java.lang.Override
		public void updateUI() {
		}

		@java.lang.Override
		public java.awt.Dimension getPreferredSize() {
		}

		@java.lang.Override
		public java.awt.Dimension getMinimumSize() {
		}

		@java.lang.Override
		public java.awt.Dimension getMaximumSize() {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}

		@java.lang.Override
		public boolean isOpaque() {
		}
	}
}
