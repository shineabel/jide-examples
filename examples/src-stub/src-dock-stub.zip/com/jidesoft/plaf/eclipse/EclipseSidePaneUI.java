package com.jidesoft.plaf.eclipse;


/**
 *  JideSidePane UI implementation
 */
public class EclipseSidePaneUI extends com.jidesoft.plaf.basic.BasicSidePaneUI {

	public EclipseSidePaneUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected void drawEastPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics, int indexOfButton) {
	}

	protected void drawWestPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics, int indexOfButton) {
	}

	protected void drawNorthPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics, int indexOfButton) {
	}

	protected void drawSouthPane(java.awt.Graphics g, javax.swing.JComponent c, java.awt.FontMetrics metrics, int indexOfButton) {
	}
}
