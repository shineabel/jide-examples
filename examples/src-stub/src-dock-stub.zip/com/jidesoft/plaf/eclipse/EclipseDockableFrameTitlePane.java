package com.jidesoft.plaf.eclipse;


/**
 *  Basic L&f implementation of title bar for DockableFrame
 */
public class EclipseDockableFrameTitlePane extends com.jidesoft.plaf.basic.BasicDockableFrameTitlePane {

	public EclipseDockableFrameTitlePane(com.jidesoft.docking.DockableFrame f) {
	}

	@java.lang.Override
	protected javax.swing.AbstractButton createTitleBarButton() {
	}

	@java.lang.Override
	protected void changeButtonType(javax.swing.AbstractButton button, int type) {
	}

	@java.lang.Override
	protected java.awt.Dimension getMaximumButtonSize() {
	}

	@java.lang.Override
	protected void paintGripper(java.awt.Graphics g) {
	}
}
