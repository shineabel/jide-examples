package com.jidesoft.plaf.xerto;


/**
 *  JideSidePane UI implementation
 */
public class XertoSidePaneUI extends com.jidesoft.plaf.basic.BasicSidePaneUI {

	public XertoSidePaneUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected java.awt.Color[] getGradientColors(SidePaneItem item) {
	}

	@java.lang.Override
	protected boolean isRoundedCorner() {
	}
}
