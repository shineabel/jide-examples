/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  <code>ContainerContainer</code> extends <code>JideSplitPane</code>. It is used by Docking Framework.
 */
@java.lang.SuppressWarnings("serial")
public class ContainerContainer extends JideSplitPane implements java.awt.event.ContainerListener, Dockable, java.beans.PropertyChangeListener {

	/**
	 *  Creates a default <code>ContainerContainer<code> with the docking manager.
	 * 
	 *  @param dockingManager
	 */
	public ContainerContainer(DockingManager dockingManager) {
	}

	/**
	 *  Creates a default <code>ContainerContainer<code> with the docking manager and the orientation.
	 * 
	 *  @param dockingManager
	 *  @param newOrientation
	 */
	public ContainerContainer(DockingManager dockingManager, int newOrientation) {
	}

	/**
	 *  Overrides add method so that if a workspace is added, automatically use <code>VARY</code> as the contraint to
	 *  <code>JideFlowLayout</code>.
	 * 
	 *  @param comp component to be added
	 */
	@java.lang.Override
	public void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	@java.lang.Override
	protected JideSplitPaneDivider createSplitPaneDivider() {
	}

	/**
	 *  Gets the docking manager.
	 * 
	 *  @return the docking manager
	 */
	public DockingManager getDockingManager() {
	}

	@java.lang.Override
	protected void startDragging(JideSplitPaneDivider divider) {
	}

	/**
	 *  Sets the docking manager.
	 * 
	 *  @param dockingManager
	 */
	public void setDockingManager(DockingManager dockingManager) {
	}

	/**
	 *  If there is no compnent in it or if the only component is another ContainerContainer, then this
	 *  ContainerContainer is not needed. This method will remove it automatically.
	 */
	public void hideItselfIfEmpty() {
	}

	/**
	 *  Gets the dock ID.
	 * 
	 *  @return the dock ID
	 */
	public int getDockID() {
	}

	/**
	 *  Sets the dock ID.
	 * 
	 *  @param id
	 */
	public void setDockID(int id) {
	}

	/**
	 *  Resets dock ID.
	 */
	public void resetDockID() {
	}

	/**
	 *  We override this to track additions and do the postponed proportion setting.
	 */
	@java.lang.Override
	public void componentAdded(java.awt.event.ContainerEvent e) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	@java.lang.Override
	protected void finishDraggingTo(JideSplitPaneDivider divider, int location) {
	}
}
