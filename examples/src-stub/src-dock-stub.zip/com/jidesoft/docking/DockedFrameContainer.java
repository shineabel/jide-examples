/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Container that holds all other dockable components except side panes.
 */
@java.lang.SuppressWarnings("serial")
public class DockedFrameContainer extends javax.swing.JPanel {

	public DockedFrameContainer() {
	}

	/**
	 *  Gets the container that contains the maximized dockable frame.
	 * 
	 *  @return the container that contains the maximized dockable frame.
	 */
	public javax.swing.JPanel getMaximizeContainer() {
	}

	/**
	 *  Gets the container that contains the non-maximized dockable frames.
	 * 
	 *  @return the container that contains the non-maximized dockable frames.
	 */
	public javax.swing.JPanel getNormalContainer() {
	}

	/**
	 *  Shows the container that contains the non-maximized dockable frames.
	 */
	public void showNormalContainer() {
	}

	/**
	 *  Shows the container that contains the maximized dockable frames.
	 */
	public void showMaximizeContainer() {
	}

	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}
}
