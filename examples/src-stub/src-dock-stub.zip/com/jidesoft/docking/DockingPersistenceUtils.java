/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  The docking persistence utility class to save/load docking layout to/from XML format stream or file.
 */
public class DockingPersistenceUtils {

	public DockingPersistenceUtils() {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param fileName the file name
	 * 
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockingManager manager, String fileName) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 * 
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockingManager manager, String fileName, String encoding) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 * 
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockingManager manager, String fileName, String encoding, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager the docking manager
	 *  @param out     the output stream
	 * 
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockingManager manager, java.io.OutputStream out) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 * 
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockingManager manager, java.io.OutputStream out, String encoding) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 * 
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockingManager manager, java.io.OutputStream out, String encoding, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Save the docking manager to a Document.
	 *  <p/>
	 *  Please be noted that you have to invoke this method inside EDT.
	 * 
	 *  @param manager  the docking manager
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 * 
	 *  @return the XML document.
	 * 
	 *  @throws ParserConfigurationException if there is any parser configuration issue.
	 */
	public static org.w3c.dom.Document save(DefaultDockingManager manager, PersistenceUtilsCallback.Save callback) {
	}

	public static boolean load(DefaultDockingManager manager, java.io.InputStream in) {
	}

	public static boolean load(DefaultDockingManager manager, java.io.InputStream in, PersistenceUtilsCallback.Load callback) {
	}

	public static boolean load(DefaultDockingManager manager, String fileName) {
	}

	public static boolean load(DefaultDockingManager manager, String fileName, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Loads the docking manager from the document.
	 * 
	 *  @param manager  the DefaultDockingManager
	 *  @param document the document to be loaded
	 *  @param callback the load callback to customize reading
	 * 
	 *  @return true if load successfully. Otherwise false.
	 */
	public static boolean load(DefaultDockingManager manager, org.w3c.dom.Document document, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Compare two documents to check if the saved layout are the same.
	 * 
	 *  @param document1 the layout in document1
	 *  @param document2 the layout in document2
	 * 
	 *  @return true if these two layout files are the same. Otherwise false.
	 */
	public static boolean compare(org.w3c.dom.Document document1, org.w3c.dom.Document document2) {
	}

	/**
	 *  Compare two documents to check if the saved layout are the same.
	 *  <p/>
	 *  If there are two or more docking mangers' layout in a same document, layoutName is used to distinguish those
	 *  different docking managers.
	 * 
	 *  @param document1   the layout in document1
	 *  @param layoutName1 the layout name in document1
	 *  @param document2   the layout in document2
	 *  @param layoutName2 the layout name in document2
	 * 
	 *  @return true if these two layout files are the same. Otherwise false.
	 */
	public static boolean compare(org.w3c.dom.Document document1, String layoutName1, org.w3c.dom.Document document2, String layoutName2) {
	}
}
