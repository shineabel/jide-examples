/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Container to hold DockableFrame when they are floating. This implementation is based on  {@link Dialog}.
 */
@java.lang.SuppressWarnings("serial")
public class DialogFloatingContainer extends ResizableDialog implements FloatingContainer {

	public DialogFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, java.awt.Frame owner) {
	}

	public DialogFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, java.awt.Frame owner, String title) {
	}

	public DialogFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, java.awt.Frame owner, String title, boolean modal) {
	}

	public DialogFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, java.awt.Dialog owner) {
	}

	public DialogFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, java.awt.Dialog owner, String title) {
	}

	public DialogFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, java.awt.Dialog owner, String title, boolean modal) {
	}

	protected void initListeners() {
	}

	protected void initKeyBindings() {
	}

	protected void doHideFloatingFrame() {
	}

	public java.awt.Component getRoutingComponent() {
	}

	public boolean hasTitleBar() {
	}

	@java.lang.Override
	public java.awt.Rectangle getInitialBounds(java.awt.Rectangle savedBounds) {
	}

	public void updateUndecorated() {
	}

	public void updateBorders() {
	}

	public DockingManager getDockingManager() {
	}

	public java.awt.Component asComponent() {
	}

	public void hideItselfIfEmpty() {
	}

	/**
	 *  Gets the dock ID.
	 * 
	 *  @return dock ID
	 */
	public int getDockID() {
	}

	/**
	 *  Sets the dock ID.
	 * 
	 *  @param id new ID
	 */
	public void setDockID(int id) {
	}

	/**
	 *  Resets dock ID.
	 */
	public void resetDockID() {
	}

	/**
	 *  Overridden to ask the embedded dockableFrame for its most recently focused subcomponent. When the
	 *  floatingContainer is activated, its content has been docked in another container; so the floatingContainer does
	 *  not have a saved mostRecentFocusOwner.
	 * 
	 *  @return the subcomponent
	 */
	@java.lang.Override
	public java.awt.Component getMostRecentFocusOwner() {
	}

	public void updateTitle() {
	}

	@java.lang.Override
	public void setResizable(boolean resizable) {
	}

	@java.lang.Override
	protected void beginResizing() {
	}

	protected class CloseFloatingDockableFrameAction {


		public DialogFloatingContainer.CloseFloatingDockableFrameAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}
	}
}
