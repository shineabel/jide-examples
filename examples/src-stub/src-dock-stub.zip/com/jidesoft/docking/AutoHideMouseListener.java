/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  MouseListener for <code>AutohideContainer</code>. It will call corresponding methods in <code>DockingManager</code>
 * 
 *  @see AutoHideContainer
 */
public class AutoHideMouseListener extends java.awt.event.MouseAdapter implements javax.swing.event.MouseInputListener {

	protected final DockableFrame _frame;

	protected final int _side;

	protected final DockingManager _dockingManager;

	/**
	 *  Constructor.
	 * 
	 *  @param dockingManager the docking manager
	 *  @param frame          the dockable frame
	 *  @param side           the autohide side in the docking manager
	 */
	public AutoHideMouseListener(DockingManager dockingManager, DockableFrame frame, int side) {
	}

	@java.lang.Override
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	/**
	 *  When mouse clicks, start showing frame timer immediately (delay is 0).
	 * 
	 *  @param e the mouse event
	 */
	@java.lang.Override
	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	/**
	 *  When mouse enters, start showing frame timer later (delay is 300) so that mouse quickly hover the button won't
	 *  have any effect.
	 * 
	 *  @param e the mouse event
	 */
	@java.lang.Override
	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	/**
	 *  When mouse exits, stop timer.
	 * 
	 *  @param e the mouse event
	 */
	@java.lang.Override
	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}
}
