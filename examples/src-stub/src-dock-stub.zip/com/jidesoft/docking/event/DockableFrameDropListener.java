/**
 *  The package contains events and listeners for JIDE Docking Framework product.
 */
package com.jidesoft.docking.event;


/**
 *  A listener that listens to any possible docking actions during drag-n-drop of a dockable frame.
 *  You can use this listener to prevent a dockable frame being docked to a certain target
 *  by return false in the isDockingAllowed method. The isDockingAllowed is called every time before
 *  it displays a rectangle outline to indicate the docking position.
 */
public interface DockableFrameDropListener extends java.util.EventListener {

	/**
	 *  Checks if the source dockable frame can be docked on the target component at the specified side.
	 * 
	 *  @param source the dockable frame to be docked.
	 *  @param target the target component that will accept the docked dockable frame.
	 *                The target component can be a DockableFrame, a Workspace, a DockedFrameContainer or a ContainerContainerDivider.
	 *  @param side   one of the values DOCK_SIDE_... as defined in DockContext. If the target is an instance of ContainerContainerDivider, the side will be -1.
	 *  @return true or false. If true, the docking is allowed. Otherwise it's not allowed to be docked.
	 */
	public boolean isDockingAllowed(com.jidesoft.docking.DockableFrame source, java.awt.Component target, int side);
}
