/**
 *  The package contains events and listeners for JIDE Docking Framework product.
 */
package com.jidesoft.docking.event;


/**
 *  The listener interface for receiving dockable frame events.
 */
public interface DockableFrameListener extends java.util.EventListener {

	/**
	 *  Invoked when a <code>DockableFrame</code> has been added to DockingManager.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameAdded(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has been removed from DockingManager.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameRemoved(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has been set visible.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameShown(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has been set invisible.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameHidden(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has change from other state to docking state.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameDocked(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has change from other state to autohide state.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameFloating(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has change from other state to autohide showing state.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameAutohidden(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has change from other state to floating state.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameAutohideShowing(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has became activated.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameActivated(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has became deactivated.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameDeactivated(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has became visible in the tabbed pane.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameTabShown(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has became invisible in the tabbed pane.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameTabHidden(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has became maximized.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameMaximized(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has restored from maximized state.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameRestored(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> was dragged between DockingManager's.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameTransferred(DockableFrameEvent e);

	/**
	 *  Invoked when a <code>DockableFrame</code> has been moved without changing is dock mode.
	 * 
	 *  @param e DockableFrameEvent
	 */
	public void dockableFrameMoved(DockableFrameEvent e);
}
