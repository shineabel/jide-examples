/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Default implementation of <code>DockingManager</code>. It is also the main interface that user needs to access to get
 *  the features of dockable frames.
 *  <p/>
 *  Basically it maintains a list of <code>DockableFrame</code>s and allows user to interactive with them.
 */
@java.lang.SuppressWarnings("serial")
public class DefaultDockingManager extends AbstractLayoutPersistence implements DockingManager {

	protected java.beans.PropertyChangeListener _focusPropertyChangeListener;

	public java.awt.event.ComponentAdapter _componentListener;

	/**
	 *  Creates a DefaultDockingManager. DockingManager must work with a RootPaneContainer and a container for the
	 *  content for Docking Framework. Once RootPaneContainer is initialized, user can call <code>getWorkspace()</code>
	 *  to get the workspace area, then add a <code>JDesktopPane</code> (for MDI) or a <code>DocumentPane</code> (for
	 *  TDI, part of JIDE Components) to it.,
	 * 
	 *  @param rootPaneContainer the top level container which is usually a JFrame, JWindow, JDialog or JApplet. Please
	 *                           note, if you don't have a rootPaneContainer when creating the DefaultDockingManager, you
	 *                           can pass in null. We will find out the rootPaneContainer on fly when the
	 *                           contentContainer is added to a rootPaneContainer.
	 *  @param contentContainer  an area inside the root pane container. It should be an empty container. It should also
	 *                           be added to the component hierarchy tree when this constructor is called.
	 */
	public DefaultDockingManager(javax.swing.RootPaneContainer rootPaneContainer, java.awt.Container contentContainer) {
	}

	public void switchRootPaneContainer(javax.swing.RootPaneContainer rootContainer) {
	}

	public void setFloatingFramesVisible(boolean show) {
	}

	/**
	 *  Is the specified window is a modal dialog.
	 * 
	 *  @param window the window to check
	 *  @return true if the window is a modal dialog.
	 */
	protected boolean isModalDialog(java.awt.Window window) {
	}

	/**
	 *  Is the specified window one of our floatingFrames?
	 * 
	 *  @param window the specified window to check
	 *  @return Is it?
	 */
	protected boolean isOwnedFloatingFrame(java.awt.Window window) {
	}

	/**
	 *  Is the specified window's ancestor is root pane container?
	 * 
	 *  @param window the specified window to check
	 *  @return Is it?
	 */
	protected boolean isOwnedWindow(java.awt.Window window) {
	}

	/**
	 *  Notification from one of our floatingFrame windows that it has been deactivated. If the opposite window is not
	 *  this or owned by this, then hide all floating windows.
	 * 
	 *  @param event the window event
	 */
	protected void internalFloatingFrameDeactivated(java.awt.event.WindowEvent event) {
	}

	/**
	 *  Notification from one of our floatingFrame windows that it has been activated. If it is offscreen, move it back
	 *  on.
	 *  <p/>
	 *  HACK!
	 *  <p/>
	 *  There is a bug that prevents setVisible() from working properly in a specific situation. If there is a
	 *  floatingContainer, a menu is open, and a menu is then selected in a different, window, a race condition occurs
	 *  where the two windows repeatedly activate and deactivate opposite each other.
	 *  <p/>
	 *  Until that bug can be resolved, a floatingContainer is hidden by moving it far offscreen.
	 * 
	 *  @param windowEvent the window event
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void internalFloatingFrameActivated(java.awt.event.WindowEvent windowEvent) {
	}

	public FloatingContainer findFloatingComponentAt(int x, int y) {
	}

	@java.lang.Deprecated
	public boolean isAutoActivateFocusOwner() {
	}

	@java.lang.Deprecated
	public void setAutoActivateFocusOwner(boolean autoActivateFocusOwner) {
	}

	public boolean handleEvent(java.awt.AWTEvent event) {
	}

	/**
	 *  Check if Docking should switch focus because of the AWTEvent.
	 *  <p/>
	 *  By default, it will return true only if the event is a left click mouse event and {@link
	 *  #shouldSwitchFocus(Object)} returns true.
	 * 
	 *  @param event the AWT event
	 *  @return true if the focus of DockableFrame should be changed. Otherwise false.
	 *  @since 3.4.1
	 */
	protected boolean shouldSwitchFocus(java.awt.AWTEvent event) {
	}

	/**
	 *  Check if Docking should switch focus if mouse clicking on the component.
	 *  <p/>
	 *  By default, it will return true if the component is not a close button. However, if you want the switch not being
	 *  changed in some cases, you could override this method. For example, if you want the focus not being changed if a
	 *  non-focusable component is clicked. You could try the following code.
	 *  <code><pre>
	 *  return super.shouldSwitchFocus(component) && (!(component instanceof JComponent) || ((JComponent)
	 *  component).isRequestFocusEnabled());
	 *  </pre></code>
	 * 
	 *  @param component the component inside the DockableFrame
	 *  @return true if the focus of DockableFrame should be changed. Otherwise false.
	 */
	protected boolean shouldSwitchFocus(Object component) {
	}

	/**
	 *  Get the source component of the event.
	 *  <p/>
	 *  By default, it will calculate the source component. However, if you want to customize some focus behavior, you
	 *  may want to override this method to return a different component.
	 *  <p/>
	 *  Please be noted that, it's kind of risky to override this method.
	 * 
	 *  @param event                the event DockingManager currently gets
	 *  @param includeFrameControls the flag indicating if frame controls should be considered
	 *  @param first                if it's the first event
	 *  @return the source component to take action.
	 */
	protected java.awt.Component getEventSource(java.awt.AWTEvent event, boolean includeFrameControls, boolean first) {
	}

	/**
	 *  Check if the this docking manager is currently focused.
	 * 
	 *  @return true if the docking manager has focus. Otherwise false.
	 *  @since 3.5.2
	 */
	protected boolean isDockingManagerFocused() {
	}

	/**
	 *  In response to an escape key event (or CTRL-tab), transfer focus to the registered escape key target.
	 * 
	 *  @param event the event
	 */
	public void internalHandleEscapeKey(java.awt.AWTEvent event) {
	}

	/**
	 *  Gets the resource string used in DefaultDockingManager. Subclass can override it to provide their own strings.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 *  @since 3.5.0
	 */
	public String getResourceString(String key) {
	}

	/**
	 *  Handle the situation that data is loaded incorrectly, either the parameter is not correct or an exception was
	 *  caught.
	 *  <p/>
	 *  By default, it will invoke {@link #resetToDefault()} to reset the layout to default. You could override this
	 *  method to run your own session.
	 */
	protected void loadDataErrorHandler() {
	}

	/**
	 *  Resets layout of frames to initial values. <br> This method is Swing thread-safe.
	 */
	public void resetToDefault() {
	}

	protected SimpleScrollPane createScrollPaneForAutoHideContainer(AutoHideContainer autoHideContainer) {
	}

	/**
	 *  Creates the <code>AutoHideContainer</code> which are the four panes on the side which contains the autohidden
	 *  dockable frames.
	 * 
	 *  @param side the side
	 *  @return the auto hide container instance.
	 */
	public AutoHideContainer createAutoHideContainer(int side) {
	}

	/**
	 *  Gets the initial split priority. Possible values are SPLIT_EAST_WEST_SOUTH_NORTH, SPLIT_SOUTH_NORTH_EAST_WEST.
	 *  The direction in front has a high priority than those after it. For example, if you initially has two frames, the
	 *  initial side of one is south and the other one is east. If you use SPLIT_EAST_WEST_SOUTH_NORTH, the east one will
	 *  cover the whole east side and the south one will cover whatever left. However if you use
	 *  SPLIT_SOUTH_NORTH_EAST_WEST, the south one will cover the whole south side and the east one will cover whatever
	 *  left.
	 * 
	 *  @return split priority.
	 */
	public int getInitSplitPriority() {
	}

	/**
	 *  Sets the initial split priority. Valid values are SPLIT_EAST_WEST_SOUTH_NORTH, SPLIT_SOUTH_NORTH_EAST_WEST,
	 *  SPLIT_EAST_SOUTH_WEST_NORTH and SPLIT_WEST_SOUTH_EAST_NORTH. All defined in DockingManager. The direction in
	 *  front has a high priority than those after it. For example, if you initially has two frames, the initial side of
	 *  one is south and the other one is east. If you use SPLIT_EAST_WEST_SOUTH_NORTH, the east one will cover the whole
	 *  east side and the south one will cover whatever left. However if you use SPLIT_SOUTH_NORTH_EAST_WEST, the south
	 *  one will cover the whole south side and the east one will cover whatever left.
	 * 
	 *  @param initSplitPriority split priority.
	 */
	public void setInitSplitPriority(int initSplitPriority) {
	}

	/**
	 *  Gets custom init split priority. This is only used when setInitPriority is set to SPLIT_CUSTOM.
	 * 
	 *  @return the custom init split priority.
	 */
	public int[] getCustomInitSplitPriority() {
	}

	/**
	 *  Sets custom init split priority. This is only used when setInitPriority is set to SPLIT_CUSTOM. The
	 *  customInitSplitPriority is an int array of four integers. The int is defined in DockContext such as
	 *  DOCK_SIDE_NORTH, DOCK_SIDE_SOUTH, DOCK_SIDE_EAST and DOCK_SIDE_WEST. Each int means it splits on that side first.
	 *  For example, setInitSplitPriority to SPLIT_EAST_WEST_SOUTH_NORTH is the same as setCustomInitSplitPriority to
	 *  {DOCK_SIDE_EAST, DOCK_SIDE_WEST, DOCK_SIDE_SOUTH, DOCK_SIDE_NORTH}. The reason we keep both ways so that for
	 *  normal users, setInitSplitPriority is good enough. But if you need a very special split priority, you can use
	 *  setCustomInitSplitPriority to fully customize it.
	 * 
	 *  @param customInitSplitPriority new init split priority
	 */
	public void setCustomInitSplitPriority(int[] customInitSplitPriority) {
	}

	/**
	 *  Gets the initial center split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_CENTER. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the center. Default is JideSplitPane.HORIZONTAL_SPLIT.
	 */
	public int getInitCenterSplit() {
	}

	/**
	 *  Sets the initial center split.
	 * 
	 *  @param initCenterSplit the initial center split
	 *  @see #getInitCenterSplit()
	 */
	public void setInitCenterSplit(int initCenterSplit) {
	}

	/**
	 *  Gets the initial east split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_EAST. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the east. Default is JideSplitPane.VERTICAL_SPLIT.
	 */
	public int getInitEastSplit() {
	}

	/**
	 *  Sets the initial east split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initEastSplit the initial east split
	 *  @see #getInitEastSplit()
	 */
	public void setInitEastSplit(int initEastSplit) {
	}

	/**
	 *  Gets the initial west split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_WEST. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the west. Default is JideSplitPane.VERTICAL_SPLIT.
	 */
	public int getInitWestSplit() {
	}

	/**
	 *  Sets the initial west split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initWestSplit initial west split
	 *  @see #getInitWestSplit()
	 */
	public void setInitWestSplit(int initWestSplit) {
	}

	/**
	 *  Gets the initial north split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_NORTH. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the north. Default is JideSplitPane.HORIZONTAL_SPLIT.
	 */
	public int getInitNorthSplit() {
	}

	/**
	 *  Sets the initial north split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initNorthSplit the initial north split
	 *  @see #getInitNorthSplit()
	 */
	public void setInitNorthSplit(int initNorthSplit) {
	}

	/**
	 *  Gets the initial south split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_SOUTH. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the south. Default is JideSplitPane.HORIZONTAL_SPLIT.
	 */
	public int getInitSouthSplit() {
	}

	/**
	 *  Sets the initial south split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initSouthSplit the flag
	 *  @see #getInitSouthSplit()
	 */
	public void setInitSouthSplit(int initSouthSplit) {
	}

	/**
	 *  Did the loadLayoutFrom(InputStream in) method load successfully from the input stream (false indicates that it
	 *  called resetToDefault to load the layout.) This method can be called immediately after the
	 *  loadLayoutFrom(InputStream in) call to determine if a specific LayoutPersistence was forced to call
	 *  resetToDefault.
	 * 
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *  load the layout.)
	 */
	public boolean isLoadDataSuccessful() {
	}

	/**
	 *  Gets the frame using key.
	 * 
	 *  @param key the frame key
	 *  @return frame which has the key
	 */
	public DockableFrame getFrame(String key) {
	}

	/**
	 *  Adds a frame to this DockingManager. <br> This method is Swing thread-safe.
	 * 
	 *  @param frame frame to be added
	 */
	public void addFrame(DockableFrame frame) {
	}

	/**
	 *  Removes all frames from this DockingManager. <br> This method is Swing thread-safe.
	 */
	public void removeAllFrames() {
	}

	/**
	 *  Removes a frame from this DockingManager. <br> This method is Swing thread-safe.
	 * 
	 *  @param key key of frame to be removed
	 */
	public void removeFrame(String key) {
	}

	/**
	 *  Removes a frame from this DockingManager. This method has an option to keep previous state. In most cases, you
	 *  don't want to keep the previous states when removing frame. That's what {@link #removeFrame(String)} does.
	 *  However if you just remove the frame and will add it back later, you can keep the state so that when the frame is
	 *  added back, it has the exact same state as before.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param key               key of frame to be removed
	 *  @param keepPreviousState the flag indicating if previous state should be kept
	 */
	public void removeFrame(String key, boolean keepPreviousState) {
	}

	/**
	 *  Sets the frame visible using the key of that frame and activate the frame. If you don't want to activate the
	 *  frame, you can call <code>showFrame(key, false)</code>. <br> This method is Swing thread-safe.
	 * 
	 *  @param key the key of frame to be shown
	 */
	public void showFrame(String key) {
	}

	/**
	 *  Sets the frame visible using the key of that frame and optionally activate the frame. <br> This method is Swing
	 *  thread-safe.
	 * 
	 *  @param key    the key of frame to be shown
	 *  @param active true to activate the frame after showing. False will only show the frame.
	 */
	public void showFrame(String key, boolean active) {
	}

	/**
	 *  Notifies the frame using the key of that frame.
	 *  <p/>
	 *  There are many cases you want to call notifyFrame rather than showFrame. A typical use case is some important
	 *  information was displayed in a dockable frame. However since user may be working on something else, you don't
	 *  want to automatically transfer the focus to that dockable frame. Instead, you just make the tab of that dockable
	 *  frame flashing to tell user that there is something in this frame.
	 *  <p/>
	 *  If a dockable frame is in docked mode and hidden behind other dockable frame in a tabbed pane. This method will
	 *  make the title of the tab flashing between red and normal color for 5 seconds, then stay red. If you click on the
	 *  tab when flashing, the flashing will stop (de-notified). If a frame is in autohide mode, the title of the tab on
	 *  the side pane will flash for 5 seconds as well. If user shows the autohide frame, the flash will go away.
	 *  <p/>
	 *  The method will not change the state of the dockable frame or change the focus from other places to the dockable
	 *  frame. So if the frame is in hidden, nothing will happen. If you wan to show a hidden frame, you need to call
	 *  showFrame explicitly before calling notifyFrame.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param key the key of frame to be notified
	 */
	public void notifyFrame(String key) {
	}

	/**
	 *  De-notifies the frame using the key of that frame. <br> This method is Swing thread-safe.
	 * 
	 *  @param key the key of frame to be de-notified
	 */
	public void denotifyFrame(String key) {
	}

	/**
	 *  Sets the frame invisible using the key of that frame. <br> This method is Swing thread-safe.<p>
	 * 
	 *  @param key the frame key
	 */
	public void hideFrame(String key) {
	}

	/**
	 *  Docks the frame on the side and at the index. <br> This method is Swing thread-safe.
	 * 
	 *  @param key   the frame to be docked
	 *  @param side  four possible sides
	 *  @param index 0 or 1
	 *  @throws IllegalArgumentException if side is not a valid value.
	 */
	public void dockFrame(String key, int side, int index) {
	}

	/**
	 *  Float the frame with specified frameName. <br> This method is Swing thread-safe.
	 * 
	 *  @param key      frame to be floated
	 *  @param bounds   the bounds of float frame
	 *  @param isSingle true if just make current frame floated, false to make all frames in the same tabbed pane
	 *                  floated
	 */
	public void floatFrame(String key, java.awt.Rectangle bounds, boolean isSingle) {
	}

	/**
	 *  Checks if the floating container should be set to visible.
	 *  <p/>
	 *  The default implementation is return getRootPaneContainerAsComponent() != null &&
	 *  getRootPaneContainerAsComponent().isVisible();
	 * 
	 *  @return true if the root pane container is visible. Otherwise false.
	 *  @since 3.4.7
	 */
	protected boolean shouldSetFloatingContainerVisible() {
	}

	/**
	 *  Creates a FloatingContainer. By default it will create a different implementation of {@link FloatingContainer}
	 *  depends on system property "docking.floatingContainerType" or the value returned from {@link
	 *  #getFloatingContainerType()}.
	 * 
	 *  @param owner the owner window
	 *  @return a FloatingContainer.
	 */
	public FloatingContainer createFloatingContainer(java.awt.Window owner) {
	}

	/**
	 *  Create FrameFloatingContainer instance.
	 * 
	 *  @param eventManager the internal event manager
	 *  @return a FrameFloatingContainer instance.
	 */
	protected FrameFloatingContainer createFrameFloatingContainer(DefaultDockingManager.InternalEventManager eventManager) {
	}

	/**
	 *  Create WindowFloatingContainer instance.
	 * 
	 *  @param eventManager the internal event manager
	 *  @param window       the owner window
	 *  @return a WindowFloatingContainer instance.
	 */
	protected WindowFloatingContainer createWindowFloatingContainer(DefaultDockingManager.InternalEventManager eventManager, java.awt.Window window) {
	}

	/**
	 *  Create DialogFloatingContainer instance.
	 * 
	 *  @param eventManager the internal event manager
	 *  @param window       the owner window
	 *  @return a DialogFloatingContainer instance.
	 */
	protected DialogFloatingContainer createDialogFloatingContainer(DefaultDockingManager.InternalEventManager eventManager, java.awt.Window window) {
	}

	/**
	 *  Stops the autohidden frame from show immediately. <br> This method is Swing thread-safe.
	 */
	public void startShowingAutohideFrameImmediately(String frame, int side) {
	}

	/**
	 *  Make the frame attached to the side bar so that it can be slided.
	 * 
	 *  @param frameKey the key of the frame
	 *  @param side     the side of the frame to show
	 *  @param delay    the delay in milliseconds
	 */
	public void startShowingAutohideFrame(String frameKey, int side, int delay) {
	}

	public void stopShowingAutohideFrame(int initDelay, boolean forceComplete) {
	}

	public void finishShowingAutohideFrame(String frame) {
	}

	/**
	 *  Stops the autohidden frame from show immediately. <br> This method is Swing thread-safe.
	 */
	public void stopShowingAutohideFrameImmediately() {
	}

	/**
	 *  Get internal event manager. This method is just for you to easy override {@link #createAutoHideContainer(int)},
	 *  {@link #createDialogFloatingContainer(com.jidesoft.docking.DefaultDockingManager.InternalEventManager,
	 *  java.awt.Window)}, {@link #createFrameFloatingContainer(com.jidesoft.docking.DefaultDockingManager.InternalEventManager)},
	 *  {@link #createWindowFloatingContainer(com.jidesoft.docking.DefaultDockingManager.InternalEventManager,
	 *  java.awt.Window)}.
	 * 
	 *  @return the internal used event manager.
	 */
	protected DefaultDockingManager.InternalEventManager getInternalEventManager() {
	}

	public int getUnknownFrameBehaviorOnLoading() {
	}

	public void setUnknownFrameBehaviorOnLoading(int unknownFrameBehaviorOnLoading) {
	}

	public boolean isXmlFormat() {
	}

	public void setXmlFormat(boolean xmlFormat) {
	}

	public int getSnapGridSize() {
	}

	public void setSnapGridSize(int snapGridSize) {
	}

	/**
	 *  Activate the frame with the key. <br> This method is Swing thread-safe.
	 * 
	 *  @param key key of frame to be activated
	 */
	public void activateFrame(String key) {
	}

	/**
	 *  This method is normally called when the user has indicated that they will begin dragging a component around. This
	 *  method should be called prior to any dragFrame() calls to allow the DockingManager to prepare any necessary
	 *  state. Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f         the DockableFrame to be dragged
	 *  @param mouseX    the mouse X where the frame is dragged to
	 *  @param mouseY    the mouse Y where the frame is dragged to
	 *  @param relativeX the relative X where the frame is dragged to
	 *  @param relativeY the relative Y where the frame is dragged to
	 *  @param single    the flag indicating only the frame itself of the entire FrameContainer will be dragged
	 */
	public void beginDraggingFrame(javax.swing.JComponent f, int mouseX, int mouseY, double relativeX, double relativeY, boolean single) {
	}

	public void pauseDragFrame() {
	}

	/**
	 *  Check if there is a dragging going on.
	 * 
	 *  @return true if dragging.
	 */
	public boolean isDragging() {
	}

	/**
	 *  Cancel the dragging. <br> This method is Swing thread-safe.
	 */
	public void cancelDragging() {
	}

	/**
	 *  The user has moved the frame. Calls to this method will be preceded by calls to beginDraggingFrame(). Normally
	 *  <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f              the dockable frame to drag
	 *  @param newX           the new X where the frame is being dragged to
	 *  @param newY           the new Y where the frame is being dragged to
	 *  @param mouseModifiers the mouse modifiers if any
	 */
	public void dragFrame(javax.swing.JComponent f, int newX, int newY, int mouseModifiers) {
	}

	/**
	 *  This method signals the end of the dragging session. Any state maintained by the DockingManager can be removed
	 *  here.  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f the component to be dragged
	 */
	public void endDraggingFrame(javax.swing.JComponent f) {
	}

	public ContainerContainer createContainerContainer() {
	}

	/**
	 *  Move the frame to the destFrame and put them into one tabbed pane. If the frameKey or destFrameKey doesn't exist,
	 *  IllegalArgumentException will be thrown. if the destFrameKey is in STATE_AUTOHIDE or STATE_AUTOHIDE_SHOWING
	 *  state, this method will do nothing but return immediately.
	 * 
	 *  @param frameKey     the key of the dockable frame to be moved
	 *  @param destFrameKey the key of the destination dockable frame
	 */
	public void moveFrame(String frameKey, String destFrameKey) {
	}

	/**
	 *  Move the frame to the destFrame's side. If the frameKey or destFrameKey doesn't exist, IllegalArgumentException
	 *  will be thrown. if the destFrameKey is in STATE_AUTOHIDE or STATE_AUTOHIDE_SHOWING state, this method will do
	 *  nothing but return immediately.
	 * 
	 *  @param frameKey     the key  of the dockable frame to be moved
	 *  @param destFrameKey the key of the destination dockable frame
	 *  @param side         dock side. Valid values are {@link DockContext#DOCK_SIDE_EAST}, {@link
	 *                      DockContext#DOCK_SIDE_WEST},{@link DockContext#DOCK_SIDE_NORTH}, {@link
	 *                      DockContext#DOCK_SIDE_SOUTH} or {@link DockContext#DOCK_SIDE_CENTER}. If side is {@link
	 *                      DockContext#DOCK_SIDE_CENTER}, it will have the same result as {@link #moveFrame(String,
	 *                      String)}.
	 */
	public void moveFrame(String frameKey, String destFrameKey, int side) {
	}

	/**
	 *  This methods is normally called when the user has indicated that they will begin resizing the frame. This method
	 *  should be called prior to any resizeFrame() calls to allow the DockingManager to prepare any necessary state.
	 *  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f         the component
	 *  @param direction the direction
	 */
	public void beginResizingFrame(javax.swing.JComponent f, int direction) {
	}

	/**
	 *  The user has resized the component. Calls to this method will be preceded by calls to beginResizingFrame().
	 *  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f         the component
	 *  @param newX      new X
	 *  @param newY      new Y
	 *  @param newWidth  new width
	 *  @param newHeight new height
	 */
	public void resizingFrame(javax.swing.JComponent f, int newX, int newY, int newWidth, int newHeight) {
	}

	/**
	 *  This method signals the end of the resize session. Any state maintained by the DockingManager can be removed
	 *  here.  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f the component
	 */
	public void endResizingFrame(javax.swing.JComponent f) {
	}

	/**
	 *  Toggle dockable attribute of the frame with the specified key.
	 * 
	 *  @param key frame key
	 */
	public void toggleDockable(String key) {
	}

	/**
	 *  Toggle auto-hide of the frame with the specified key.
	 * 
	 *  @param key frame key
	 */
	public void toggleAutohideState(String key) {
	}

	/**
	 *  Toggle auto-hide of the frame with the specified key.
	 * 
	 *  @param key    frame key
	 *  @param single the flag to toggle the entire group of the frame only
	 *  @since 3.5.17
	 */
	public void toggleAutohideState(String key, boolean single) {
	}

	/**
	 *  Autohides a frame at particular side and particular index. Index is the index of group.
	 * 
	 *  @param frameKey the key of the frame to be autohidden.
	 *  @param side     which side. It can be one of the four valid sides {@link DockContext#DOCK_SIDE_WEST}, {@link
	 *                  DockContext#DOCK_SIDE_WEST},{@link DockContext#DOCK_SIDE_NORTH} and {@link
	 *                  DockContext#DOCK_SIDE_SOUTH}.
	 *  @param index    a positive integer that indicate the position of the frame
	 *  @throws IllegalArgumentException if frameKey doesn't exist or side is not a valid side or index is less than 0.
	 */
	public void autohideFrame(String frameKey, int side, int index) {
	}

	/**
	 *  Gets the autohide container by side.
	 * 
	 *  @param side the dock side of the auto hide container
	 *  @return autohide container
	 */
	public AutoHideContainer getAutoHideContainer(int side) {
	}

	public java.util.List getOrderedFrames() {
	}

	/**
	 *  Check if the source is allowed to be activated.
	 *  <p/>
	 *  The default implementation is just to return true. However, if you popped up a modal dialog and you don't want
	 *  new dockable frames to flash the dialog, you could override this method to return false so that DockingManager
	 *  will not try to activate the frame indeed.
	 * 
	 *  @param source the component to be activated
	 *  @return true if the source is allowed to be activated. Otherwise false.
	 */
	protected boolean allowActivate(Object source) {
	}

	public javax.swing.RootPaneContainer getRootPaneContainer() {
	}

	/**
	 *  Gets the main container. Main container is the container that contains all docked window within the main frame.
	 *  It doesn't include side bars, doesn't include toolbar or menu bar.
	 * 
	 *  @return main container
	 */
	public DockedFrameContainer getDockedFrameContainer() {
	}

	/**
	 *  Creates the workspace.
	 * 
	 *  @return the workspace.
	 */
	public Workspace createWorkspace() {
	}

	public Workspace getWorkspace() {
	}

	/**
	 *  Shows or hides workspace area.
	 * 
	 *  @param showWorkspace true to show workspace and false to hide.
	 */
	public void setShowWorkspace(boolean showWorkspace) {
	}

	/**
	 *  Checks if workspace area is visible.
	 * 
	 *  @return if the workspace is visible.
	 */
	public boolean isShowWorkspace() {
	}

	protected void internalSetShowWorkspace(boolean showWorkspace) {
	}

	public void activateWorkspace() {
	}

	public boolean isWorkspaceActive() {
	}

	/**
	 *  Starts a process to add/remove frame without showing on screen immediately. Any call to loadLayoutDataXxx methods
	 *  or resetToDefault() will mark the process.
	 */
	public void beginLoadLayoutData() {
	}

	public boolean loadLayoutFrom(org.w3c.dom.Document document) {
	}

	/**
	 *  Load layout data from an InputStream that specified as <code>in</code> parameter. If any exception happens during
	 *  the read, it will call resetLayout() to use default layout.
	 *  <p/>
	 * 
	 *  @param in the InputStream where the layout data will be read from.
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *  load the layout.)
	 */
	public boolean loadLayoutFrom(java.io.InputStream in) {
	}

	/**
	 *  A method for the customer to handle newly added frames while loading layout.
	 * 
	 *  @param newlyAddedFrames the newly added frame names in array.
	 *  @since 3.5.3
	 */
	protected void handleNewlyAddedFrames(String[] newlyAddedFrames) {
	}

	public void setShowInitial(boolean value) {
	}

	public boolean isShowInitial() {
	}

	public void showInitial() {
	}

	public void requestFocusInDockingManager() {
	}

	public void saveLayoutTo(org.w3c.dom.Document document) {
	}

	/**
	 *  Save layout data to an OutputStream that specified as <code>out</code> parameter.
	 * 
	 *  @param out the OutputStream where the layout data will be written to.
	 *  @throws IOException
	 */
	public void saveLayoutTo(java.io.OutputStream out) {
	}

	public java.awt.Container getContentContainer() {
	}

	public javax.swing.JComponent getMainContainer() {
	}

	/**
	 *  This method is called for every rearragement of the dockable frames. By default, it will reset all
	 *  ContainerContainers, validate ContentContainer, DockedFrameConatiner and Workspace.
	 */
	public void resetLayout() {
	}

	public String getActiveFrameKey() {
	}

	protected void disposeFloatingContainer(FloatingContainer floatingContainer) {
	}

	/**
	 *  Updates the undecorated of the floating container to make sure there is native title bar if there are more than
	 *  one tabbed panes inside the floating container and no title bar if there is only one tabbed pane.
	 * 
	 *  @param floatingContainer the floating container.
	 *  @return the floating container that has title or or not depending on the number of tabbed panes inside it.
	 */
	protected FloatingContainer updateUndecorated(FloatingContainer floatingContainer) {
	}

	/**
	 *  Auto-hide all frames. <br> This method is Swing thread safe.
	 */
	public void autohideAll() {
	}

	public void toggleMaximizeState(String key) {
	}

	public void toggleState(String key, boolean single) {
	}

	/**
	 *  Remove it from hidden frame list.
	 * 
	 *  @param key the frame key
	 */
	public void removeFromHiddenFrames(String key) {
	}

	/**
	 *  When user presses autohide button, will it affect all tabs or just selected tab.
	 * 
	 *  @return true if it will autohide all tabs.
	 */
	public boolean isAutohideAllTabs() {
	}

	/**
	 *  When user presses autohide button, will it affect all tabs or just selected tab.
	 * 
	 *  @param autohideAllTabs true or false.
	 */
	public void setAutohideAllTabs(boolean autohideAllTabs) {
	}

	/**
	 *  When user presses close button, will it affect all tabs or just selected tab.
	 * 
	 *  @return true if it will close all tabs.
	 */
	public boolean isHideAllTabs() {
	}

	/**
	 *  Sets the option of closeAllTabs. If it's true, when user presses close it will close all tabs.
	 * 
	 *  @param hideAllTabs true or false.
	 */
	public void setHideAllTabs(boolean hideAllTabs) {
	}

	/**
	 *  When user presses toggle floating button, will it affect all tabs or just selected tab.
	 * 
	 *  @return true if it will close all tabs.
	 */
	public boolean isFloatAllTabs() {
	}

	/**
	 *  Sets the option of floatAllTabs. If it's true, when user presses toggle floating button it will float all tabs.
	 * 
	 *  @param floatAllTabs true or false.
	 */
	public void setFloatAllTabs(boolean floatAllTabs) {
	}

	/**
	 *  When user maximizes a dockable frame, will it maximize all tabs or just selected tab.
	 * 
	 *  @return true if it will close all tabs.
	 */
	public boolean isMaximizeAllTabs() {
	}

	/**
	 *  Sets the option of maximizeAllTabs.
	 * 
	 *  @param maximizeAllTabs true or false.
	 */
	public void setMaximizeAllTabs(boolean maximizeAllTabs) {
	}

	/**
	 *  Return true if floating is allowed for dockable frames.
	 * 
	 *  @return true if floating is allowed
	 */
	public boolean isFloatable() {
	}

	/**
	 *  Enable or disable floating of dockable frames.
	 * 
	 *  @param floatable the flag
	 */
	public void setFloatable(boolean floatable) {
	}

	/**
	 *  Returns true if auto-hide is allowed for dockable frames.
	 * 
	 *  @return true if auto-hide is allowed
	 */
	public boolean isAutohidable() {
	}

	/**
	 *  Enable or disable floating of dockable frames.
	 * 
	 *  @param autohidable the flag
	 */
	public void setAutohidable(boolean autohidable) {
	}

	/**
	 *  Return true if hidden is allowed for dockable frames.
	 * 
	 *  @return true if hidden is allowed
	 */
	public boolean isHidable() {
	}

	/**
	 *  Enable or disable dockable frames from being hidden.
	 * 
	 *  @param hidable the flag
	 */
	public void setHidable(boolean hidable) {
	}

	/**
	 *  If the dockable frame can be rearranged.
	 * 
	 *  @return Return true if the dockable frames can be rearranged by user.
	 */
	public boolean isRearrangable() {
	}

	/**
	 *  Enable or disable the rearrangement of dockable frames.
	 * 
	 *  @param rearrangable true if the dockable frames can be rearranged by user.
	 */
	public void setRearrangable(boolean rearrangable) {
	}

	@java.lang.Override
	public boolean isFloatingFramesResizable() {
	}

	@java.lang.Override
	public void setFloatingFramesResizable(boolean resizable) {
	}

	@java.lang.Override
	public boolean isDockedFramesResizable() {
	}

	@java.lang.Override
	public void setDockedFramesResizable(boolean resizable) {
	}

	/**
	 *  If the dockable frame can be resized.
	 * 
	 *  @return Return true if the dockable frames can be resized by user.
	 *  @deprecated replaced by {@link #isFloatingFramesResizable()} and {@link #isDockedFramesResizable()}
	 */
	@java.lang.Deprecated
	public boolean isResizable() {
	}

	/**
	 *  Enable or disable resizable property of dockable frames.
	 * 
	 *  @param resizable true if the dockable frames can be resize by user.
	 *  @deprecated replaced by {@link #setFloatingFramesResizable(boolean)} and {@link #setDockedFramesResizable(boolean)}
	 */
	@java.lang.Deprecated
	public void setResizable(boolean resizable) {
	}

	/**
	 *  Returns true if group is allowed in side bar.
	 * 
	 *  @return true or false
	 */
	public boolean isGroupAllowedOnSidePane() {
	}

	/**
	 *  If true, group is allowed in side bar.
	 * 
	 *  @param groupAllowedOnSidePane the flag
	 */
	public void setGroupAllowedOnSidePane(boolean groupAllowedOnSidePane) {
	}

	/**
	 *  Since there are several top level container in DockingManager, this method will call
	 *  <code>updateComponentTreeUI</code> to all of them to make sure everything changes after reset look and feel.
	 */
	public void updateComponentTreeUI() {
	}

	/**
	 *  Gets a collection of all dockable frames' key. You can call getDockableFrame(key) to get the actual dockable
	 *  frame.
	 *  <p/>
	 *  It is the same usage as {@link #getAllFrameNames()}. However the order of frame keys from this method is random.
	 *  {@link #getAllFrameNames()} returns the list in the order of when frame is added.
	 * 
	 *  @return the collection of all dockable frames' key.
	 */
	public java.util.Collection getAllFrames() {
	}

	/**
	 *  Gets a list of the keys of all frames. It's clone of the list maintained by the DockingManager.
	 * 
	 *  @return the list of all frames The order in the list is the order of when frame is added.
	 */
	public java.util.List getAllFrameNames() {
	}

	public String[] getAllVisibleFrameKeys() {
	}

	/**
	 *  Gets the first visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the first
	 *  one. It is the first one in the array that is returned from getAllVisibleFrameKeys method.
	 * 
	 *  @return the first visible dockable frame.
	 */
	public String getFirstFrameKey() {
	}

	/**
	 *  Gets the last visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the last
	 *  one. It is the last one in the array that is returned from getAllVisibleFrameKeys method.
	 * 
	 *  @return the last visible dockable frame.
	 */
	public String getLastFrameKey() {
	}

	/**
	 *  Gets the next visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the next
	 *  one. It is the next one in the array that is returned from getAllVisibleFrameKeys method. If the frame is the
	 *  last one, the first frame will be returned. Or if the frame is hidden, this method will return the first frame
	 *  too. So unless you have no dockable frame at all, this method will never return null.
	 * 
	 *  @return the first visible dockable frame.
	 */
	public String getNextFrame(String frame) {
	}

	/**
	 *  Gets the previous visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the
	 *  previous one. It is the next one in the array that is returned from getAllVisibleFrameKeys method. If the frame
	 *  is the first one, the last frame will be returned. Or if the frame is hidden, this method will return the last
	 *  frame too. So unless you have no dockable frame at all, this method will never return null.
	 * 
	 *  @return the last visible dockable frame.
	 */
	public String getPreviousFrame(String frame) {
	}

	/**
	 *  Determines whether the JSplitPane is set to use a continuous layout.
	 */
	public boolean isContinuousLayout() {
	}

	/**
	 *  Turn continuous layout on/off.
	 */
	public void setContinuousLayout(boolean continuousLayout) {
	}

	/**
	 *  Subclass can override it to create your own FrameContainer. Please make sure you call {@link
	 *  #customizeFrameContainer(FrameContainer)} before you return the FrameContainer you created.
	 * 
	 *  @return the FrameContainer.
	 */
	public FrameContainer createFrameContainer() {
	}

	public FrameContainer customizeFrameContainer(FrameContainer frameContainer) {
	}

	/**
	 *  Set a customizer to customize the tabbed pane where dockable frames are. <p>Here is a code example.
	 *  <p/>
	 *  <code><pre>
	 *  dockingManager.setTabbedPaneCustomizer(new DockingManager.TabbedPaneCustomizer() {
	 *      public void customize(JideTabbedPane tabbedPane) {
	 *          tabbedPane.setTabPlacement(JideTabbedPane.TOP);
	 *          tabbedPane.setHideOneTab(false);
	 *      }
	 *  });</code></pre>
	 * 
	 *  @param customizer new tabbed pane customizer
	 */
	public void setTabbedPaneCustomizer(DockingManager.TabbedPaneCustomizer customizer) {
	}

	/**
	 *  Gets initial bounds of the main frame. If init bounds is never set before, it will return the smaller one screen
	 *  size and {0, 0, 1024, 768)
	 * 
	 *  @return initial bounds
	 */
	public java.awt.Rectangle getInitBounds() {
	}

	/**
	 *  Sets the initial bounds of the main frame.
	 * 
	 *  @param initBounds the initial bounds
	 */
	public void setInitBounds(java.awt.Rectangle initBounds) {
	}

	/**
	 *  Removes dock context from the Map.
	 * 
	 *  @param key key of dockable frame
	 */
	public void removeContext(String key) {
	}

	/**
	 *  Gets initial state of the main frame. State could be the states that are specified in {@link
	 *  Frame#getExtendedState}. If user never sets init state before, it will return Frame.NORMAL if the init bounds is
	 *  less than screen size. If init bounds is larger than screen size, it will return Frame.MAXIMIZED_BOTH (under JDK
	 *  1.4 and above only) .
	 * 
	 *  @return the initial state
	 */
	public int getInitState() {
	}

	/**
	 *  Sets the initial state of the main frame. State can be the states that are specified in {@link
	 *  Frame#getExtendedState}.
	 * 
	 *  @param initState the initial state
	 *  @see Frame#setExtendedState(int)
	 *  @see Frame#getExtendedState
	 */
	public void setInitState(int initState) {
	}

	public int getSensitiveAreaSize() {
	}

	public void setSensitiveAreaSize(int sensitiveAreaSize) {
	}

	public int getOutsideSensitiveAreaSize() {
	}

	public void setOutsideSensitiveAreaSize(int sensitiveAreaSize) {
	}

	/**
	 *  Gets contour outline mode. It is HW_OUTLINE_MODE by default. However we will return an appropriate outline mode
	 *  based on the return values from SecurityUtils.isTranslucentWindowFeatureDisabled() and
	 *  isHeavyweightComponentEnabled().
	 *  <p/>
	 *  If the isTranslucentWindowFeatureDisabled is true and isHeavyweightComponentEnabled is true, we will return
	 *  FULL_OUTLINE_MODE because that's the only outline satisfied both conditions. If only
	 *  isTranslucentWindowFeatureDisabled is true, we will use TRANSPARENT_OUTLINE_MODE to replace
	 *  HW_TRANSPARENT_OUTLINE_MODE and FULL_OUTLINE_MODE to replace HW_OUTLINE_MODE and keep other modes. If
	 *  isTranslucentWindowFeatureDisabled is false but isHeavyweightComponentEnabled is true, we will use
	 *  HW_OUTLINE_MODE to replace PARTIAL_OUTLINE_MODE or MIX_OUTLINE_MODE and HW_TRANSPARENT_OUTLINE_MODE to replace
	 *  TRANSPARENT_OUTLINE_MODE. Otherwise, we will use whatever outline mode user sets.
	 * 
	 *  @return the outline mode.
	 */
	public int getOutlineMode() {
	}

	/**
	 *  Sets contour outline mode <ul> <li>PARTIAL_OUTLINE_MODE: Always uses light-weighted outline. As a result, it will
	 *  display partial outline if outside main JFrame. <li>MIX_OUTLINE_MODE: Use light-weighted outline when inside the
	 *  main JFrame and heavy-weighted outline when outside JFrame. It will be flickering free when inside the JFrame.
	 *  But when it's on the border of JFrame, it will cause some flickering. <li>FULL_OUTLINE_MODE: Always use
	 *  heavy-weight outline. As result, it will cause some flickering because of that.<li>TRANSPARENT_OUTLINE_MODE:
	 *  Always use light-weight outline using a transparent background. <li>HW_TRANSPARENT_OUTLINE_MODE: Always use
	 *  heavy-weight outline using a transparent background. <li>HW_OUTLINE_MODE: Always use heavy-weight outline using
	 *  an outline. </ul> Please note, the last two outline mode is only available on JDK6u10 and later.
	 * 
	 *  @param outlineMode the new outline mode
	 */
	public void setOutlineMode(int outlineMode) {
	}

	/**
	 *  Gets dock context of a frame specified by frameKey. If it has dock context, return the context; or else, return
	 *  null.
	 * 
	 *  @param frameKey the frame key
	 *  @return If it has dock context, return the context; or else, return null
	 */
	public DockContext getContextOf(String frameKey) {
	}

	/**
	 *  Gets the popup menu customizer.
	 * 
	 *  @return popup menu customizer
	 */
	public PopupMenuCustomizer getPopupMenuCustomizer() {
	}

	/**
	 *  Sets the popup customizer.
	 *  <p/>
	 *  The menu passed in the the customizePopupMenu already have some menu items. You can remove all of them to add
	 *  your own, or you can remove some of them. All existing menu items have a unique names. Here are the names -
	 *  "DockableFrameTitlePane.close", "DockableFrameTitlePane.close", "DockableFrameTitlePane.toggleFloating",
	 *  "DockableFrameTitlePane.toggleAutohide", "DockableFrameTitlePane.toggleMaximize",
	 *  "DockableFrameTitlePane.toggleDockable", and "DockableFrameTitlePane.hideAutohide". The names should be very
	 *  obvious to what the menu item do. There are also constants beginning with CONTEXT_MENU_xxx defined on
	 *  DockingManager. So instead of using absolute menu item index, it'd better to use the name to look up a particular
	 *  menu item.
	 * 
	 *  @param customizer the menu customizer
	 */
	public void setPopupMenuCustomizer(PopupMenuCustomizer customizer) {
	}

	public void showContextMenu(java.awt.Component source, java.awt.Point point, DockableFrame dockableFrame, boolean onTab) {
	}

	/**
	 *  Gets the escape key target component. If setEscapeKeyTargetComponent is never called, workspace will be the
	 *  escape key target component. When the ESC key is pressed in a dockable frame, this component will get focus.
	 * 
	 *  @return the escape key target component.
	 */
	public java.awt.Component getEscapeKeyTargetComponent() {
	}

	/**
	 *  Sets the escape key target component.
	 * 
	 *  @param escapeKeyTargetComponent the component
	 */
	public void setEscapeKeyTargetComponent(java.awt.Component escapeKeyTargetComponent) {
	}

	/**
	 *  Removes all used resources.
	 */
	public void dispose() {
	}

	/**
	 *  Gets the initial delay.
	 * 
	 *  @return the initial delay
	 */
	public int getInitDelay() {
	}

	/**
	 *  Sets the initial delay of autohide dockable frame when it displays.
	 * 
	 *  @param initDelay the initial delay, in ms.
	 */
	public void setInitDelay(int initDelay) {
	}

	/**
	 *  Gets the delay in each step during animation.
	 * 
	 *  @return the delay in each step
	 */
	public int getStepDelay() {
	}

	/**
	 *  Sets the delay in each step during animation, in ms. Default is 5ms.
	 * 
	 *  @param stepDelay the delay in each step
	 */
	public void setStepDelay(int stepDelay) {
	}

	/**
	 *  Gets how many steps in the animation.
	 * 
	 *  @return number of the steps
	 */
	public int getSteps() {
	}

	/**
	 *  Sets how many steps in the animation, default is 1 step. It must be greater than 0, or IllegalArgumentException
	 *  will be thrown.
	 * 
	 *  @param steps number of the steps
	 */
	public void setSteps(int steps) {
	}

	/**
	 *  Usually dragging a dockable frame and pointing to the title bar of another dockable frame will make it tab dock.
	 *  However if easyTabDock is true, pointing to any area inside the dockable frame (as long as not too close to
	 *  border) will make it tab dock.
	 * 
	 *  @return true if dragging and pointing to dockable frame will make it tab dock
	 */
	public boolean isEasyTabDock() {
	}

	/**
	 *  Sets the attribute if dragging and pointing to dockable frame will make it tab dock
	 * 
	 *  @param easyTabDock the attribute
	 */
	public void setEasyTabDock(boolean easyTabDock) {
	}

	public boolean isTabDockAllowed() {
	}

	public void setTabDockAllowed(boolean tabDockAllowed) {
	}

	public boolean isTabReorderAllowed() {
	}

	public void setTabReorderAllowed(boolean tabReorderAllowed) {
	}

	public boolean isNestedFloatingAllowed() {
	}

	public void setNestedFloatingAllowed(boolean nestedFloatingAllowed) {
	}

	public boolean isDragAllTabs() {
	}

	public void setDragAllTabs(boolean dragAllTabs) {
	}

	/**
	 *  If the gripper is visible.
	 * 
	 *  @return true if grip is visible
	 */
	public boolean isShowGripper() {
	}

	/**
	 *  Sets the visibility of the gripper. This call will call all dockable frames' setShowGripper method so that they
	 *  all have the same value.
	 * 
	 *  @param showGripper true to show grip
	 */
	public void setShowGripper(boolean showGripper) {
	}

	/**
	 *  If the gripper is visible.
	 * 
	 *  @return true if grip is visible
	 */
	public boolean isShowDividerGripper() {
	}

	/**
	 *  Sets the visibility of gripper.
	 * 
	 *  @param showDividerGripper true to show grip
	 */
	public void setShowDividerGripper(boolean showDividerGripper) {
	}

	/**
	 *  When the gripper is visible, if the drag only happens when dragging on the gripper. Default is false which means
	 *  you can drag title bar even the gripper is shown.
	 * 
	 *  @return true if grip is visible
	 */
	public boolean isDragGripperOnly() {
	}

	/**
	 *  Sets the value to allow user to drag on the gripper as well as on the title bar. This flag only has effect when
	 *  gripper is visible. If it's true, drag only happens when dragging on gripper. Otherwise, dragging on title bar
	 *  will start the drag too.
	 * 
	 *  @param dragGripperOnly true to show grip
	 */
	public void setDragGripperOnly(boolean dragGripperOnly) {
	}

	/**
	 *  If the gripper is visible.
	 * 
	 *  @return true if grip is visible
	 */
	public boolean isShowTitleBar() {
	}

	/**
	 *  Sets the visibility of the title bar. This call will call all dockable frames' setShowTitleBar method so that
	 *  they all have the same value.
	 * 
	 *  @param showTitleBar true to show grip
	 */
	public void setShowTitleBar(boolean showTitleBar) {
	}

	public void setAutohideShowingContentHidden(boolean hide) {
	}

	public boolean isAutohideShowingContentHidden() {
	}

	public boolean isSidebarRollover() {
	}

	public void setSidebarRollover(boolean sidebarRollover) {
	}

	/**
	 *  Makes the frame available.
	 *  <p/>
	 *  Usually all dockable frames are added to DockingManager when application is started. However some frames may only
	 *  be available under certain context. For example, palette window should only be available when editing a GUI form.
	 *  In this case, you can set the palette to available when GUI form is active. Or else, set it to unavailable.
	 *  <p/>
	 *  Set the frame available will restore the last state of the frame when it is set to unavailable.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param key the key of frame to be shown
	 */
	public void setFrameAvailable(String key) {
	}

	/**
	 *  Makes the frame unavailable.
	 *  <p/>
	 *  Usually all dockable frames are added to DockingManager when application is started. However some frames may only
	 *  be available under certain context. For example, palette window should only be available when editing a GUI form.
	 *  In this case, you can set the palette to available when GUI form is active. Or else, set it to unavailable.
	 *  <p/>
	 *  Set the frame unavailable will hide the frame no matter what state it is. However the state will be remembered so
	 *  that when later it was set to available, that state will be restored. When frame is unavailable, operations to
	 *  that frame such as showFrame, hideFrame, etc, will have no effect.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param key key of dockable frame
	 */
	public void setFrameUnavailable(String key) {
	}

	/**
	 *  Sets the undo limit. If you want to turn off undo function, just set it to 0. The default is 0 to be backward
	 *  compatible.
	 * 
	 *  @param undoLimit the flag
	 */
	public void setUndoLimit(int undoLimit) {
	}

	/**
	 *  Gets the undo limit.
	 * 
	 *  @return undoLimit
	 */
	public int getUndoLimit() {
	}

	public void discardAllUndoEdits() {
	}

	public void undo() {
	}

	public void redo() {
	}

	public javax.swing.undo.UndoManager getUndoManager() {
	}

	/**
	 *  Creates UndoManager.
	 * 
	 *  @return the UndoManager instance.
	 *  @since 3.4.1
	 */
	protected javax.swing.undo.UndoManager createUndoManager() {
	}

	@java.lang.Override
	public void beginCompoundEdit(boolean isUndoRedo) {
	}

	@java.lang.Override
	public void endCompoundEdit() {
	}

	public boolean isPreserveAvailableProperty() {
	}

	public void setPreserveAvailableProperty(boolean preserveAvailableProperty) {
	}

	public void addUndoableEditListener(javax.swing.event.UndoableEditListener listener) {
	}

	public void removeUndoableEditListener(javax.swing.event.UndoableEditListener listener) {
	}

	public void addUndo(String name) {
	}

	public javax.swing.undo.UndoableEditSupport getUndoableEditSupport() {
	}

	/**
	 *  Maximizes the frame. <br> This method is Swing thread-safe.
	 * 
	 *  @param key the key of frame to be maximized
	 */
	public void maximizeFrame(String key) {
	}

	public String getMaximizedFrameKey() {
	}

	/**
	 *  Restores the frame from maximized state.
	 */
	public void restoreFrame() {
	}

	/**
	 *  Gets the action when user double clicks on the title bar of a dockable frame. It could be either
	 *  DOUBLE_CLICK_TO_FLOAT (default) or DOUBLE_CLICK_TO_MAXIMIZE or DOUBLE_CLICK_NONE if you don't want to have any
	 *  action associated with double click.
	 * 
	 *  @return the action of double click on title bar.
	 */
	public int getDoubleClickAction() {
	}

	/**
	 *  Sets the action when user double clicks on the title bar of a dockable frame.
	 * 
	 *  @param doubleClickAction Either DOUBLE_CLICK_TO_FLOAT or DOUBLE_CLICK_TO_MAXIMIZE or DOUBLE_CLICK_NONE.
	 */
	public void setDoubleClickAction(int doubleClickAction) {
	}

	public boolean isAutoDocking() {
	}

	public void setAutoDocking(boolean autoDocking) {
	}

	public boolean isAutoDockingAsDefault() {
	}

	public void setAutoDockingAsDefault(boolean autoDockingAsDefault) {
	}

	public boolean isPreserveStateOnDragging() {
	}

	public void setPreserveStateOnDragging(boolean preserveStateOnDragging) {
	}

	public void removeExtraContexts() {
	}

	public java.util.Map getAllContexts() {
	}

	public boolean isHideFloatingFramesWhenDeactivate() {
	}

	public void setHideFloatingFramesWhenDeactivate(boolean hideFloatingFramesWhenDeactivate) {
	}

	/**
	 *  We can hide floating frames when we switch to a different DockingManager. Do we do the same when we switch to a
	 *  different application?
	 */
	public boolean isHideFloatingFramesOnSwitchOutOfApplication() {
	}

	/**
	 *  Turn hiding floating frames when we switch to a different application on and off.
	 */
	public void setHideFloatingFramesOnSwitchOutOfApplication(boolean newValue) {
	}

	/**
	 *  Gets the allowed dock sides. The side values are defined in DockContext. The actual value returned is a OR of all
	 *  possible dock sides. The possible dock sides are {@link DockContext#DOCK_SIDE_NORTH}, {@link
	 *  DockContext#DOCK_SIDE_SOUTH}, {@link DockContext#DOCK_SIDE_WEST}, and {@link DockContext#DOCK_SIDE_EAST}. Or you
	 *  can use combine values such as {@link DockContext#DOCK_SIDE_HORIZONTAL}, {@link DockContext#DOCK_SIDE_VERTICAL}
	 *  or {@link DockContext#DOCK_SIDE_ALL}. Please note, {@link DockContext#DOCK_SIDE_CENTER} is not a valid value# By
	 *  default, dragging a dockable frame to workspace is not allowed anyway# If you want to control it, you should use
	 *  {@link Workspace#setAcceptDockableFrame(boolean)}.
	 *  <p/>
	 *  This setting will only affect user dragging. For example, if you set the allowed dock sides to not allow north
	 *  side, user won't be able to drag a dockable frame and put it to the north side of the main window or the north
	 *  side of workspace area. However if a dockable frame's initial side is set to north, it will be put to north. So
	 *  you as developer need to consciously avoid initial dock sides which you don't allow using this setting.
	 * 
	 *  @return allowed dock sides.
	 */
	public int getAllowedDockSides() {
	}

	/**
	 *  Sets allowed dock sides.
	 * 
	 *  @param allowedDockSides allowed dock sides
	 *  @see #getAllowedDockSides()
	 */
	public void setAllowedDockSides(int allowedDockSides) {
	}

	/**
	 *  If any of the dockable frame's shouldVetoHiding() return true, this method will return true.
	 * 
	 *  @return true or false.
	 */
	public boolean shouldVetoRemovingAllFrames() {
	}

	/**
	 *  Exclusive is an attribute that controls the visibility of floating frames among different docking managers. You
	 *  could have multiple docking managers in the same applications. In some cases, you want the docking managers to be
	 *  exclusive, meaning when one docking manager is activated, the other docking managers' floating frame will be
	 *  hidden automatically. A typical use case is you have several JFrames in your application. Each JFrame is managed
	 *  by a docking manager. When one JFrame is activated, you want the floating frames of other JFrames to be hidden.
	 *  <p/>
	 *  However in other cases, you don't want to be exclusive. For example, you have a nested docking manager inside
	 *  another docking manager. <p> To consider both valid use cases, you can use this attribute to determine the
	 *  correct behavior depending on your application. The default value is false.
	 * 
	 *  @return true or false.
	 */
	public static boolean isExclusive() {
	}

	/**
	 *  Sets the exclusive attribute.
	 * 
	 *  @param exclusive the attribute
	 *  @see #isExclusive()
	 */
	public static void setExclusive(boolean exclusive) {
	}

	/**
	 *  Checks if the context menu should be shown.
	 * 
	 *  @return true if context menu will be shown. Otherwise false.
	 */
	public boolean isShowContextMenu() {
	}

	/**
	 *  Sets the flag to show context menu or not.
	 * 
	 *  @param showContextMenu the flag
	 */
	public void setShowContextMenu(boolean showContextMenu) {
	}

	public boolean isAutohideShowingInProgress() {
	}

	public String getAutohideShowingFrame() {
	}

	public DockableFrameFactory getDockableFrameFactory() {
	}

	public void setDockableFrameFactory(DockableFrameFactory dockableFrameFactory) {
	}

	public void loadInitialLayout(org.w3c.dom.Document layoutDocument) {
	}

	/**
	 *  Checks if it always use decorated dialog or frame as the floating dockable frames' container.
	 * 
	 *  @return if it use decorate dialog as floating dockable frames' container.
	 */
	public boolean isUseDecoratedFloatingContainer() {
	}

	/**
	 *  Sets to true so that it always use decorated dialog as the floating dockable frames' container. If
	 * 
	 *  @param useDecoratedFloatingContainer the flag
	 */
	public void setUseDecoratedFloatingContainer(boolean useDecoratedFloatingContainer) {
	}

	public boolean isProportionalSplits() {
	}

	public void setProportionalSplits(boolean b) {
	}

	protected void preDispatchDockableFrameEvent() {
	}

	/**
	 *  @return true if the heavyweight component is enabled.
	 */
	public boolean isHeavyweightComponentEnabled() {
	}

	/**
	 *  Enables heavyweight component. This method, if set to true, will make <ul> <li>1. The divider (when you drag) of
	 *  JideSplitPane heavyweight <li>2. Dragging outline heavyweight - basically use FULL_OUTLINE_MODE. <li>3. Popup
	 *  menu and tooltip heavyweight
	 *  <code><pre>
	 *  JPopupMenu.setDefaultLightWeightPopupEnabled(false);
	 *  ToolTipManager.sharedInstance().setLightWeightPopupEnabled(false);
	 *  </pre></code>
	 *  </ul>
	 * 
	 *  @param heavyweightComponentEnabled the flag
	 */
	public void setHeavyweightComponentEnabled(boolean heavyweightComponentEnabled) {
	}

	/**
	 *  Checks if we will use glass pane to change cursor.
	 * 
	 *  @return true or false.
	 */
	public boolean isUseGlassPaneEnabled() {
	}

	/**
	 *  Enables us to use glass pane to for cursor change purpose.
	 * 
	 *  @param useGlassPaneEnabled the flag
	 */
	public void setUseGlassPaneEnabled(boolean useGlassPaneEnabled) {
	}

	public boolean isSideDockAllowed() {
	}

	public void setSideDockAllowed(boolean sideDockAllowed) {
	}

	public boolean isWithinFrameBoundsOnDragging() {
	}

	public void setWithinFrameBoundsOnDragging(boolean withinFrameBoundsOnDragging) {
	}

	public boolean isWithinScreenBoundsOnDragging() {
	}

	public void setWithinScreenBoundsOnDragging(boolean withinScreenBoundsOnDragging) {
	}

	public boolean isCrossDraggingAllowed() {
	}

	public void setCrossDraggingAllowed(boolean crossDraggingAllowed) {
	}

	public boolean isCrossDroppingAllowed() {
	}

	public void setCrossDroppingAllowed(boolean crossDroppingAllowed) {
	}

	/**
	 *  Get all docking managers currently.
	 *  <p/>
	 *  To be thread safe, we cloned a list from the original list. Please make sure that your application will release
	 *  the memory after getting the instance. Otherwise, you will encounter memory leaking issue.
	 * 
	 *  @return docking managers list.
	 */
	public static java.util.List getAllDockingManagers() {
	}

	/**
	 *  Adds the specified listener to receive dockable frame drop events from this dockable frame.
	 * 
	 *  @param l the dockable frame listener
	 */
	public void addDockableFrameDropListener(event.DockableFrameDropListener l) {
	}

	/**
	 *  Removes the specified dockable frame listener so that it no longer receives dockable frame drop events from this
	 *  dockable frame.
	 * 
	 *  @param l the dockable frame drop listener
	 */
	public void removeDockableFrameDropListener(event.DockableFrameDropListener l) {
	}

	/**
	 *  Returns an array of all the <code>DockableFrameDropListener</code>s added to this <code>DockableFrame</code> with
	 *  <code>addDockableFrameDropListener</code>.
	 * 
	 *  @return all of the <code>DockableFrameDropListener</code>s added or an empty array if no listeners have been
	 *  added
	 *  @see #addDockableFrameDropListener(com.jidesoft.docking.event.DockableFrameDropListener)
	 */
	public event.DockableFrameDropListener[] getDockableFrameDropListeners() {
	}

	/**
	 *  Fires an dockable frame drop event.
	 */
	public boolean isDropAllowed(DockableFrame source, java.awt.Component target, int side) {
	}

	public void addDockableFrameListener(event.DockableFrameListener l) {
	}

	/**
	 *  Removes the specified dockable frame listener so that it no longer receives dockable frame events from this
	 *  dockable frame.
	 * 
	 *  @param l the dockable frame listener
	 */
	public void removeDockableFrameListener(event.DockableFrameListener l) {
	}

	/**
	 *  Returns an array of all the <code>DockableFrameListener</code>s added to this <code>DockableFrame</code> with
	 *  <code>addDockableFrameListener</code>.
	 * 
	 *  @return all of the <code>DockableFrameListener</code>s added or an empty array if no listeners have been added
	 *  @see #addDockableFrameListener
	 */
	public event.DockableFrameListener[] getDockableFrameListeners() {
	}

	/**
	 *  Checks if newly added frames should be hidden when the old layout is loaded. It's false by default.
	 * 
	 *  @return true if newly added frame is hidden. Otherwise, false.
	 */
	public boolean isHideNewlyAddedFrames() {
	}

	/**
	 *  Sets the flag to hide newly added frames when the old layout is loaded. For example, you had frame A, B and C and
	 *  saved as a layout. Now you added frame D and load the saved layout. If this flag is true, the frame D will be
	 *  hidden regardless what it's initial state is. If the flag is false, the D could be made visible if the frame's
	 *  initial state is docked or floating or autohidden.
	 * 
	 *  @param hideNewlyAddedFrames the flag
	 */
	public void setHideNewlyAddedFrames(boolean hideNewlyAddedFrames) {
	}

	/**
	 *  Gets the notification background.
	 * 
	 *  @return the notification background.
	 */
	public java.awt.Color getNotificationBackground() {
	}

	/**
	 *  Sets the notification background. The color is used to flash the tab background when notifyFrame is called.
	 * 
	 *  @param notificationBackground the notification background.
	 */
	public void setNotificationBackground(java.awt.Color notificationBackground) {
	}

	/**
	 *  Gets the notification foreground.
	 * 
	 *  @return the notification foreground.
	 */
	public java.awt.Color getNotificationForeground() {
	}

	/**
	 *  Sets the notification foreground. The color is used to flash the tab foreground when notifyFrame is called.
	 * 
	 *  @param notificationForeground the notification foreground.
	 */
	public void setNotificationForeground(java.awt.Color notificationForeground) {
	}

	/**
	 *  Gets the delay of ms between two flashes when notifyFrame is called.
	 * 
	 *  @return the delay between two flashes.
	 */
	public int getNotificationDelay() {
	}

	/**
	 *  Sets the delay between two flashes when notifyFrame is called.
	 * 
	 *  @param notificationDelay the delay.
	 */
	public void setNotificationDelay(int notificationDelay) {
	}

	/**
	 *  Gets the number of flashes when notifyFrame is called.
	 * 
	 *  @return the number of flashes when notifyFrame is called.
	 */
	public int getNotificationSteps() {
	}

	/**
	 *  Sets the number of flashes when notifyFrame is called.
	 * 
	 *  @param notificationSteps the number of flashes when notifyFrame is called. -1 means it will never stop until user
	 *                           responses to the notification.
	 */
	public void setNotificationSteps(int notificationSteps) {
	}

	public boolean isShowTitleOnOutline() {
	}

	public void setShowTitleOnOutline(boolean showTitleOnOutline) {
	}

	@java.lang.Deprecated
	public void dockFrame(DockableFrame f, int side, int index) {
	}

	@java.lang.Deprecated
	public DockableFrame getFirstFrame() {
	}

	@java.lang.Deprecated
	public DockableFrame getLastFrame() {
	}

	@java.lang.Deprecated
	public DockableFrame getNextFrame(DockableFrame f) {
	}

	@java.lang.Deprecated
	public DockableFrame getPreviousFrame(DockableFrame f) {
	}

	@java.lang.Deprecated
	public void toggleMaximizeState(DockableFrame f) {
	}

	@java.lang.Deprecated
	public void setAutohideShowingFrame(DockableFrame f) {
	}

	@java.lang.Deprecated
	public void hideActiveAutohideFrame() {
	}

	@java.lang.Deprecated
	public void startShowingAutohideFrame(DockableFrame f, int side, int delay, boolean forceFocus) {
	}

	@java.lang.Deprecated
	public void startShowingAutohideFrame(DockableFrame f, int side, int delay) {
	}

	@java.lang.Deprecated
	public javax.swing.JFrame getMainFrame() {
	}

	@java.lang.Deprecated
	public AutoHideContainer getAutoHideContaner(int side) {
	}

	@java.lang.Deprecated
	public void floatFrame(DockableFrame f, java.awt.Rectangle bounds, boolean isSingle) {
	}

	@java.lang.Deprecated
	public void autohideFrame(DockableFrame f, int side, int index) {
	}

	@java.lang.Deprecated
	public DockableFrame getActiveFrame() {
	}

	@java.lang.Deprecated
	public DockableFrame getMaximizedFrame() {
	}

	@java.lang.Deprecated
	public void toggleAutohideState(DockableFrame frame) {
	}

	@java.lang.Deprecated
	public void toggleDockable(DockableFrame frame) {
	}

	@java.lang.Deprecated
	public void toggleState(DockableFrame frame, boolean single) {
	}

	@java.lang.Deprecated
	public void doLayout() {
	}

	@java.lang.Deprecated
	public void handleEscapeKey(java.awt.AWTEvent event) {
	}

	@java.lang.Deprecated
	public void floatingFrameDeactivated(java.awt.event.WindowEvent windowEvent) {
	}

	@java.lang.Deprecated
	public void floatingFrameActivated(java.awt.event.WindowEvent windowEvent) {
	}

	@java.lang.Deprecated
	public java.awt.event.MouseListener createAutoHideMouseListener(DockableFrame frame, int side) {
	}

	@java.lang.Deprecated
	public boolean isFocusDuringLoadLayout() {
	}

	@java.lang.Deprecated
	public void setFocusDuringLayout(boolean doFocus) {
	}

	@java.lang.Deprecated
	public boolean isAllowRequestFocus() {
	}

	@java.lang.Deprecated
	public java.awt.Component getDefaultFocusComponent() {
	}

	@java.lang.Deprecated
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent) {
	}

	protected void checkFrameKey(String key, String methodName) {
	}

	public boolean isActive() {
	}

	public void setActive(boolean active) {
	}

	public DockingManagerGroup getGroup() {
	}

	public void setGroup(DockingManagerGroup group) {
	}

	public int getFloatingContainerType() {
	}

	public void setFloatingContainerType(int floatingContainerType) {
	}

	public DockingManager.FloatingContainerCustomizer getFloatingContainerCustomizer() {
	}

	public void setFloatingContainerCustomizer(DockingManager.FloatingContainerCustomizer customizer) {
	}

	/**
	 *  Get all floating frames in current layout.
	 * 
	 *  @return all floating frames in an array list.
	 */
	public java.util.List getFloatingFrames() {
	}

	@java.lang.Override
	public void setActiveMouseInputListener(javax.swing.event.MouseInputListener listener) {
	}

	@java.lang.Override
	public javax.swing.event.MouseInputListener getActiveMouseInputListener() {
	}

	protected class DefaultDockingManagerAnimationHandler {


		protected DefaultDockingManager.DefaultDockingManagerAnimationHandler() {
		}

		public void handleBeginShowing(DockableFrame frame) {
		}

		public void handleOpened(DockableFrame frame) {
		}

		public void handleShowingCancelled(DockableFrame frame) {
		}

		public void handleHidden(DockableFrame frame) {
		}
	}

	protected class DockableFrameWorkspaceHandle {


		protected Object untyped;

		protected boolean isVisible;

		protected boolean isManaged;

		protected DefaultDockingManager.DockableFrameWorkspaceHandle(Object componentHandle) {
		}

		public String getKey() {
		}

		public String getTitle() {
		}

		public javax.swing.Icon getIcon() {
		}

		public boolean isWorkspace() {
		}

		public boolean isManaged() {
		}

		public boolean isFront() {
		}

		public boolean toFront() {
		}

		public String toString() {
		}
	}

	public class MainPanel {


		public DefaultDockingManager.MainPanel() {
		}

		public DockingManager getDockingManager() {
		}

		@java.lang.Override
		public void doLayout() {
		}
	}

	protected class DockedHiddenSlidingContainer {


		protected DefaultDockingManager.DockedHiddenSlidingContainer() {
		}

		public boolean isOptimizedDrawingEnabled() {
		}

		public java.awt.FocusTraversalPolicy getFocusTraversalPolicy() {
		}
	}

	protected class InternalDockableFrameRouter {


		protected DefaultDockingManager.InternalDockableFrameRouter() {
		}

		protected void dispatchEvent(String eventType, event.DockableFrameEvent e) {
		}

		public void dockableFrameActivated(event.DockableFrameEvent e) {
		}

		public void dockableFrameAdded(event.DockableFrameEvent e) {
		}

		public void dockableFrameAutohidden(event.DockableFrameEvent e) {
		}

		public void dockableFrameAutohideShowing(event.DockableFrameEvent e) {
		}

		public void dockableFrameDeactivated(event.DockableFrameEvent e) {
		}

		public void dockableFrameDocked(event.DockableFrameEvent e) {
		}

		public void dockableFrameFloating(event.DockableFrameEvent e) {
		}

		public void dockableFrameHidden(event.DockableFrameEvent e) {
		}

		public void dockableFrameMaximized(event.DockableFrameEvent e) {
		}

		public void dockableFrameRemoved(event.DockableFrameEvent e) {
		}

		public void dockableFrameRestored(event.DockableFrameEvent e) {
		}

		public void dockableFrameShown(event.DockableFrameEvent e) {
		}

		public void dockableFrameTabHidden(event.DockableFrameEvent e) {
		}

		public void dockableFrameTabShown(event.DockableFrameEvent e) {
		}

		public void dockableFrameTransferred(event.DockableFrameEvent e) {
		}

		public void dockableFrameMoved(event.DockableFrameEvent e) {
		}
	}

	protected class MenuChangeStateListener {


		protected DefaultDockingManager.MenuChangeStateListener() {
		}

		public void stateChanged(javax.swing.event.ChangeEvent e) {
		}
	}

	protected class InternalEventManager {


		protected DefaultDockingManager.InternalEventManager() {
		}

		public javax.swing.event.MouseInputListener createAutoHideMouseInputListener(DockableFrame frame, int side) {
		}

		public void floatingFrameDeactivated(java.awt.event.WindowEvent windowEvent) {
		}

		public void floatingFrameActivated(java.awt.event.WindowEvent windowEvent) {
		}
	}
}
