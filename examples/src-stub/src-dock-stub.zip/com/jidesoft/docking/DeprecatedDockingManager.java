/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  This interface hold all methods that are implement only for backward compatibility. In the future this class and all
 *  the contain methods will not longer be supported. In most cases the functionality is supported by another function.
 *  <p/>
 *  In some cases the functions represented internal event handling and are now perform no operation.
 */
public interface DeprecatedDockingManager {

	/**
	 *  @return currently selected frame
	 * 
	 *  @deprecated use {@link #getActiveFrameKey()} instead.
	 */
	@java.lang.Deprecated
	public DockableFrame getActiveFrame();

	/**
	 *  Starts to show the autohide frame.
	 * 
	 *  @param frame
	 *  @param side
	 *  @param delay
	 *  @deprecated use {@link #startShowingAutohideFrame(String,int,int)} instead.
	 */
	@java.lang.Deprecated
	public void startShowingAutohideFrame(DockableFrame frame, int side, int delay);

	/**
	 *  Starts to show the autohide frame.
	 * 
	 *  @param frame
	 *  @param side
	 *  @param delay
	 *  @param forceFocus if delay == 0
	 *  @deprecated use {@link #startShowingAutohideFrame(String,int,int)} instead.
	 */
	@java.lang.Deprecated
	public void startShowingAutohideFrame(DockableFrame frame, int side, int delay, boolean forceFocus);

	/**
	 *  Toggle the frame's state. If it's docked, change to floating mode; if floating, change to docked mode.
	 * 
	 *  @param frame  the frame to change mode
	 *  @param single change mode for all frames in the same tabbed pane or just the frame itself.
	 *  @deprecated use {@link #toggleState(String,java.awt.Rectangle,boolean)} instead.     *
	 */
	@java.lang.Deprecated
	public void toggleState(DockableFrame frame, boolean single);

	/**
	 *  Toggle dockable attribute sof the frame with the specified key.
	 * 
	 *  @deprecated use {@link #toggleDockable(String)}. All frame accessor should use keys to prevents memory leaks
	 */
	@java.lang.Deprecated
	public void toggleDockable(DockableFrame frame);

	/**
	 *  Toggle the frame between auto-hide mode and docked mode.
	 * 
	 *  @param frame the frame to be toggled.
	 *  @deprecated use {@link #toggleAutohideState(String)}. All frame accessor should use keys to prevents memory
	 *              leaks
	 */
	@java.lang.Deprecated
	public void toggleAutohideState(DockableFrame frame);

	/**
	 *  Autohides a frame at the specified side and index. Index is the index of group.
	 * 
	 *  @param frame
	 *  @param side
	 *  @param index
	 *  @deprecated use {@link #autohideFrame(String,int,int)} instead.
	 */
	@java.lang.Deprecated
	public void autohideFrame(DockableFrame frame, int side, int index);

	/**
	 *  Sets the frame to floating state
	 * 
	 *  @deprecated use {@link #floatFrame(String, Rectangle, boolean)}. All frame accessor should use keys to prevents
	 *              memory leaks
	 */
	@java.lang.Deprecated
	public void floatFrame(DockableFrame dockableFrame, java.awt.Rectangle bounds, boolean isSingle);

	/**
	 *  Docks the frame at the specified side and index. Index is the index in the split pane.
	 * 
	 *  @param dockableFrame
	 *  @param side
	 *  @param index
	 *  @deprecated use {@link #dockFrame(String,int,int)} instead.
	 */
	@java.lang.Deprecated
	public void dockFrame(DockableFrame dockableFrame, int side, int index);

	/**
	 *  Gets the first visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the first
	 *  one. It is the first one in the array that is returned from getAllVisibleFrameKeys method.
	 * 
	 *  @return the first visible dockable frame.
	 * 
	 *  @deprecated use {@link #getFirstFrameKey()}. All frame accessor should use keys to prevents memory leaks
	 */
	@java.lang.Deprecated
	public DockableFrame getFirstFrame();

	/**
	 *  Gets the last visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the last
	 *  one. It is the last one in the array that is returned from getAllVisibleFrameKeys method.
	 * 
	 *  @return the last visible dockable frame.
	 * 
	 *  @deprecated use {@link #getLastFrameKey()}. All frame accessor should use keys to prevents memory leaks
	 */
	@java.lang.Deprecated
	public DockableFrame getLastFrame();

	/**
	 *  Gets the next visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the next
	 *  one. It is the next one in the array that is returned from getAllVisibleFrameKeys method. If the frame is the
	 *  last one, the first frame will be returned. Or if the frame is hidden, this method will return the first frame
	 *  too. So unless you have no dockable frame at all, this method will never return null.
	 * 
	 *  @param frame the current frame.
	 *  @return the next visible dockable frame.
	 * 
	 *  @deprecated use {@link #getNextFrameKey(String)}. All frame accessor should use keys to prevents memory leaks
	 */
	@java.lang.Deprecated
	public DockableFrame getNextFrame(DockableFrame frame);

	/**
	 *  Gets the previous visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the
	 *  previous one. It is the next one in the array that is returned from getAllVisibleFrameKeys method. If the frame
	 *  is the first one, the last frame will be returned. Or if the frame is hidden, this method will return the last
	 *  frame too. So unless you have no dockable frame at all, this method will never return null.
	 * 
	 *  @param frame the current frame.
	 *  @return the previous visible dockable frame.
	 * 
	 *  @deprecated use {@link #getPreviousFrameKey(String)}. All frame accessor should use keys to prevents memory
	 *              leaks
	 */
	@java.lang.Deprecated
	public DockableFrame getPreviousFrame(DockableFrame frame);

	/**
	 *  Gets the maximized frame if any.
	 * 
	 *  @return the maximized frame. If no frame is maximized, return null.
	 * 
	 *  @deprecated use {@link #getMaximizedFrame()}. All frame accessor should use keys to prevents memory leaks
	 */
	@java.lang.Deprecated
	public DockableFrame getMaximizedFrame();

	/**
	 *  Toggle between maximized and restored state.
	 * 
	 *  @param f
	 *  @deprecated use {@link #toggleMaximizeState(String)}. All frame accessor should use keys to prevents memory
	 *              leaks
	 */
	@java.lang.Deprecated
	public void toggleMaximizeState(DockableFrame f);

	/**
	 *  Hide active autohide frame immediately.
	 * 
	 *  @deprecated use {@link #stopShowingAutohideFrame()}. This method had confusing but similar functionality
	 */
	@java.lang.Deprecated
	public void hideActiveAutohideFrame();

	/**
	 *  Gets the autohide container by side. Valid side is defined in DockContext such as DockContext.DOCK_SIDE_NORTH,
	 *  DockContext.DOCK_SIDE_SOUTH, DockContext.DOCK_SIDE_EAST and DockContext.DOCK_SIDE_WEST.
	 * 
	 *  @param side
	 *  @return autohide container
	 * 
	 *  @deprecated use {@link #getAutoHideContainer(int)}. This method had a typo.
	 */
	@java.lang.Deprecated
	public AutoHideContainer getAutoHideContaner(int side);

	/**
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public void doLayout();

	/**
	 *  Gets the main JFrame.
	 * 
	 *  @return main JFrame
	 * 
	 *  @deprecated use getRootPaneContainer instead since DockingManager can support all RootPaneContainer, not just
	 *              JFrame
	 */
	@java.lang.Deprecated
	public javax.swing.JFrame getMainFrame();

	/**
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public void setAutohideShowingFrame(DockableFrame frame);

	/**
	 *  Notification from one of our floatingFrame windows that it has been deactivated
	 * 
	 *  @param windowEvent
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public void floatingFrameDeactivated(java.awt.event.WindowEvent windowEvent);

	/**
	 *  Notification from one of our floatingFrame windows that it has been activated.
	 * 
	 *  @param windowEvent
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public void floatingFrameActivated(java.awt.event.WindowEvent windowEvent);

	/**
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public void handleEscapeKey(java.awt.AWTEvent event);

	/**
	 *  Creates the AutoHideMouseListener that is used on AutoHideContainer.
	 * 
	 *  @param frame the dockable frame.
	 *  @param side  the side.
	 *  @return the MouseListener
	 * 
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public java.awt.event.MouseListener createAutoHideMouseListener(DockableFrame frame, int side);

	/**
	 *  Accessor for the flag indicating whether focus should be requested for DockableFrames during load layout. (also
	 *  implies activation, which happens when a subcomponent receives focus)
	 * 
	 *  @return if focus request is enabled during load layout
	 * 
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public boolean isFocusDuringLoadLayout();

	/**
	 *  Accessor to set the flag indicating whether focus should be requested for DockableFrames during load layout.
	 *  (also implies activation, which happens when a subcomponent receives focus)
	 * 
	 *  @param doFocus should focus requests be enabled during load layout
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public void setFocusDuringLayout(boolean doFocus);

	/**
	 *  Because requesting focus may be restricted by the DockingManager during load layout, this method allows a
	 *  DockableFrame to ask if it is allowed to request focus.
	 * 
	 *  @return Does the DockingManager allow a focus request at this time?
	 * 
	 *  @deprecated This was for internal eventing and is no longer needed.
	 */
	@java.lang.Deprecated
	public boolean isAllowRequestFocus();

	/**
	 *  Gets the default focus component. When application started, this component will get focus. Also when ESC key is
	 *  pressed in dockable frame, this component will get focus as well.
	 * 
	 *  @return the default component.
	 * 
	 *  @deprecated The Docking Manager doesn't have it's own focus policy. It routes all focus to the individual frames
	 *              or the workspace because these components implement Refocusable. {@link
	 *              Refocusable#getDefaultFocusComponent()}.
	 */
	@java.lang.Deprecated
	public java.awt.Component getDefaultFocusComponent();

	/**
	 *  Sets the default focus component.
	 * 
	 *  @param defaultFocusComponent
	 *  @deprecated The Docking Manager doesn't have it's own focus policy. It routes all focus to the individual frames
	 *              or the workspace because these components implement Refocusable. {@link
	 *              Refocusable#setDefaultFocusComponent(Component defaultFocusComponent)}.
	 *              <p/>
	 *              The approach is to now call setDefaultFocusComponent() on Workspace or DockableFrame. This will mean
	 *              that whenever the getMainContainer() (which is what is added to the user's provided content pane)
	 *              receives focus it will transfer it to the active pane's (Workspace or DockableFrame)
	 *              defaultFocusComponent. By default, we will use workspace.getDefaultFocusComponent and put focus on
	 *              it. If you want the focus to be in a DockableFrame, you can call dockingManager.activateFrame after
	 *              loadLayoutData is called.
	 */
	@java.lang.Deprecated
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent);
}
