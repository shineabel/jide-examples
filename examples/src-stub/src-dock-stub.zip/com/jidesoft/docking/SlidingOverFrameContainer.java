/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Container that holds the frames that are sliding over the docked panels.
 */
@java.lang.SuppressWarnings("serial")
public class SlidingOverFrameContainer extends javax.swing.JPanel {

	protected static boolean DEBUG;

	protected java.util.HashMap _constraints;

	protected java.awt.Rectangle rectDebug;

	protected java.awt.Container _contentPane;

	protected static final java.awt.Dimension MIN_DIM;

	protected static final java.awt.Dimension MAX_DIM;

	public SlidingOverFrameContainer(java.awt.Container contentPane) {
	}

	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	@java.lang.Override
	public void remove(int index) {
	}

	protected void paintComponent(java.awt.Graphics g) {
	}

	protected void paintRect(java.awt.Graphics2D g2) {
	}

	public java.awt.Rectangle computeLayoutBounds(java.awt.Component dockingComponent, DockableFrame f, int side, boolean ltr) {
	}

	public boolean contains(int x, int y) {
	}

	public class SlidingFrameConstraint {


		public DockableFrame frame;

		public java.awt.Component dockingComponent;

		public int steps;

		public int currentStep;

		public int side;

		public boolean isLeftToRight;

		public boolean opening;

		public SlidingOverFrameContainer.SlidingFrameConstraint() {
		}
	}

	protected class SlidingFrameLayout {


		protected java.awt.Rectangle _stepBounds;

		protected SlidingOverFrameContainer.SlidingFrameLayout() {
		}

		public void addLayoutComponent(java.awt.Component comp, Object constraints) {
		}

		public float getLayoutAlignmentX(java.awt.Container target) {
		}

		public float getLayoutAlignmentY(java.awt.Container target) {
		}

		public void invalidateLayout(java.awt.Container target) {
		}

		public java.awt.Dimension maximumLayoutSize(java.awt.Container target) {
		}

		public java.awt.Dimension minimumLayoutSize(java.awt.Container parent) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container parent) {
		}

		public void removeLayoutComponent(java.awt.Component comp) {
		}

		public void addLayoutComponent(String name, java.awt.Component comp) {
		}

		public void layoutContainer(java.awt.Container parent) {
		}

		public void setupContainer(java.awt.Container parent, java.awt.Component component, SlidingOverFrameContainer.SlidingFrameConstraint constraint) {
		}
	}
}
