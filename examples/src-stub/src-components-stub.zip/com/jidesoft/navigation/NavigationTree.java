package com.jidesoft.navigation;


/**
 *  <code>NavigationTree</code> is a special tree that is designed for the navigation purpose. It has the following
 *  features.
 *  <pre>
 *  <ul>
 *      <li>It has a special row rollover effect.</li>
 *      <li>The tree icons will be hidden when the mouse is not over and the tree is not focused.
 *  And
 *  it has fade effect
 *  when the mouse moves away from the tree.</li>
 *      <li>The row selection covers the whole row.</li>
 *      <li>The selection highlight is different when focused and not focused.</li>
 *      <li>The node will expand out of the scroll pane's viewport as tool tip when the content is
 *  not fully
 *  visible.</li>
 *  </ul>
 *  </pre>
 *  The selection and rollover effect is painted inside the paintComponent methods of the <code>NavigationTree</code>
 *  after the original tree content is painted. We can't use the cell renderer to paint the effect as it is beyond the
 *  bounds of the cell renderers. So in order to prevent the cell renderer from painting the default selection effect, we
 *  override {@link #isRowSelected(int)} method to always return false. If your code depends on this method to find out
 *  if a row is selected, you can use {@link #isRowSelectedOriginal(int)} method.
 * 
 *  @since 3.3.0
 */
public class NavigationTree extends javax.swing.JTree {

	public static final String PROPERTY_SHOW_TREE_LINES = "showTreeLines";

	public static final String PROPERTY_WIDE_SELECTION = "wideSelection";

	public static final String PROPERTY_FADE_ICON = "fadeIcon";

	public static final String PROPERTY_EXPANDED_TIP = "expandedTip";

	public NavigationTree() {
	}

	public NavigationTree(Object[] value) {
	}

	public NavigationTree(java.util.Vector value) {
	}

	public NavigationTree(java.util.Hashtable value) {
	}

	public NavigationTree(javax.swing.tree.TreeNode root) {
	}

	public NavigationTree(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	public NavigationTree(javax.swing.tree.TreeModel newModel) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Creates the <code>NavigationHelper</code> which is a helper class that paints the rollover and the selection
	 *  effect.
	 *  <p/>
	 *  By default, it creates a NavigationTreeHelper instance.
	 * 
	 *  @return a new NavigationHelper.
	 */
	protected NavigationComponentHelper createNavigationHelper() {
	}

	public boolean isIconRollover(int x, int y, int width, int height) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Overrides and always return false so that the cell renderer will not paint the selection effect. If you are using
	 *  this method before, please switch to {@link #isRowSelectedOriginal(int)}.
	 * 
	 *  @param row the row index.
	 *  @return false.
	 */
	@java.lang.Override
	public boolean isRowSelected(int row) {
	}

	/**
	 *  Delegates to super.isRowSelected(row).
	 * 
	 *  @param row the row index.
	 *  @return if the row is selected.
	 */
	public boolean isRowSelectedOriginal(int row) {
	}

	public float getIconAlpha() {
	}

	public void setIconAlpha(float iconAlpha) {
	}

	/**
	 *  Checks if the tree lines are visible. Tree lines help align the node levels. However it will clutter the user
	 *  interface. Since the <code>NavigationTree</code> is for the navigation purpose, the node level is not so
	 *  important. That's why by default, it is invisible in <code>NavigationTree</code>.
	 * 
	 *  @return true or false. False by default.
	 */
	public boolean isShowTreeLines() {
	}

	/**
	 *  Set the tree lines visible or invisible. By default, it is invisible in <code>NavigationTree</code>.
	 *  <p/>
	 *  Calling this method will trigger updateUI() being called.
	 * 
	 *  @param showTreeLines true to set the tree line visible and false to set it invisible. False by default.
	 */
	public void setShowTreeLines(boolean showTreeLines) {
	}

	/**
	 *  Checks if the selection and the rollover highlight covers the whole tree width. In a normal JTree, the selection
	 *  only covers the node width. When the node is very narrow, the selection is hard to notice. For the navigation
	 *  purpose, it is important that the selection row is noticeable. That's why we added this flag so that the
	 *  selection always cover the whole row.
	 * 
	 *  @return true or false. True by default.
	 */
	public boolean isWideSelection() {
	}

	/**
	 *  Sets the flag if the selection and the rollover highlight covers the whole tree width. It is true by default as
	 *  we want to the selection to be easily noticeable in a <code>NavigationTree</code>.
	 * 
	 *  @param wideSelection true to make the selection and the rollover highlight covers the whole tree width, false to
	 *                       only cover the tree node width. It is true by default for <code>NavigationTree</code>.
	 */
	public void setWideSelection(boolean wideSelection) {
	}

	/**
	 *  Checks if the tree icons will fade when the mouse is not over the tree and the tree doesn't have keyboard focus.
	 *  In a regular tree, the tree icons are always visible. But if the tree is used for the navigation purpose, the
	 *  tree icons are not important to show when the tree is not active as users just want to know which row is selected
	 *  and don't care whether the node is expanded or collapsed. That's why we introduced this flag to hide the tree
	 *  icons when the tree is no focused and mouse not over.
	 * 
	 *  @return true or false. True by default for the <code>NavigationTree</code>.
	 */
	public boolean isIconFade() {
	}

	/**
	 *  Sets the flag to fade the tree icons when the mouse is not over the tree and the tree doesn't have keyboard
	 *  focus.
	 * 
	 *  @param fadeIcon true to fade the tree icons. False to always show the tree icons.
	 */
	public void setFadeIcon(boolean fadeIcon) {
	}

	/**
	 *  Checks if the ExpandedTip feature is enabled.
	 * 
	 *  @return true or false.
	 *  @see ExpandedTipUtils
	 */
	public boolean isExpandedTip() {
	}

	/**
	 *  Sets the ExpandedTip flag.
	 * 
	 *  @param expandedTip true to enable the ExpandedTip feature and false to disable it. It is true by default.
	 */
	public void setExpandedTip(boolean expandedTip) {
	}

	/**
	 *  Gets the rollover row that currently has rollover effect.
	 * 
	 *  @return the row that has the rollover effect.
	 */
	public int getNavigationRolloverRow() {
	}

	/**
	 *  Sets the rollover row.
	 * 
	 *  @param navigationRolloverRow the row to show the rollover effect.
	 */
	public void setNavigationRolloverRow(int navigationRolloverRow) {
	}

	/**
	 *  The navigation tree helper class.
	 * 
	 *  @since 3.3.8
	 */
	public class NavigationTreeHelper {


		public NavigationTree.NavigationTreeHelper() {
		}

		@java.lang.Override
		public java.awt.Rectangle getRowBounds(int row) {
		}

		@java.lang.Override
		public int rowAtPoint(java.awt.Point p) {
		}

		@java.lang.Override
		public int[] getSelectedRows() {
		}

		@java.lang.Override
		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void focusGained(java.awt.event.FocusEvent e) {
		}

		@java.lang.Override
		public void focusLost(java.awt.event.FocusEvent e) {
		}
	}
}
