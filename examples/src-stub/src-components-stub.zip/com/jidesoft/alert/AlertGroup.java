/**
 *  The package contains the classes related to Alert component for JIDE Components product.
 */
package com.jidesoft.alert;


/**
 *  <code>AlertGroup</code> is used when showing multiple alerts at one time.
 *  <p/>
 *  <code>Alert</code> has an option to show at a particular location relative to the screen using {@link
 *  Alert#showPopup(int)}. For example, if you call <code>showPopup(SwingConstants.SOUTH_EAST)</code>, the alert will
 *  appear at the bottom-right corner of the screen. If you show two alerts both at
 *  <code>SwingConstants.SOUTH_EAST</code>, the two alerts will overlap. In order to solve this issue, we introduce this
 *  <code>AlertGroup</code>. To use it, you just call {@link #add(Alert)} to add all alerts to <code>AlertGroup</code>.
 *  <code>AlertGroup</code> will move the alert so that there are no overlap.
 *  <p/>
 *  Although <code>Alert</code>'s <code>showPopup(int location)</code> can support locations such as
 *  <code>SwingConstants.CENTER</code>, <code>SwingConstants.NORTH</code> etc, <code>AlertGroup</code> only handle the
 *  following four locations - <code>SwingConstants.SOUTH_EAST</code>, <code>SwingConstants.SOUTH_WEST</code>,
 *  <code>SwingConstants.NORTH_EAST</code> and <code>SwingConstants.NORTH_WEST</code>.
 *  <p/>
 *  You can also remove an alert from <code>AlertGroup</code> using {@link #remove(Alert)}. But if you don't call it, the
 *  alert will be removed automatically when it is hidden.
 */
public class AlertGroup {

	public AlertGroup() {
	}

	public void add(Alert alert) {
	}

	public void remove(Alert alert) {
	}

	/**
	 *  Check if the alert at the proposed bounds will overlap with any existing visible alerts.
	 * 
	 *  @param alert          the alert.
	 *  @param proposedBounds the proposed bounds of the alert.
	 * 
	 *  @return true if overlaps. Otherwise, false.
	 */
	protected boolean isRegionOverlap(Alert alert, java.awt.Rectangle proposedBounds) {
	}

	/**
	 *  Gets the display start location of the alert.
	 *  <p/>
	 *  This method will only gurantee no overlap if the location is <code>SwingConstants.SOUTH_EAST</code>,
	 *  <code>SwingConstants.SOUTH_WEST</code>, <code>SwingConstants.NORTH_EAST</code> or
	 *  <code>SwingConstants.NORTH_WEST</code>.
	 *  <p/>
	 *  If the whole screen is coverred with alert (which is very rare case), this method will always return at the
	 *  default location just like when <code>AlertGroup</code> is not in use at all.
	 * 
	 *  @param alert     the alert.
	 *  @param screenDim the screen dimension or the owner's dimension if displaying within the owner boundry.
	 *  @param size      the size of the alert.
	 *  @param location  the location relative to screen.
	 *  @param gap       the gap between two alerts (horizontally or vertically)
	 * 
	 *  @return the location of the alert where should be displayed which won't cause any overlap.
	 */
	public java.awt.Point getDisplayStartLocation(Alert alert, java.awt.Rectangle screenDim, java.awt.Dimension size, int location, int gap) {
	}
}
