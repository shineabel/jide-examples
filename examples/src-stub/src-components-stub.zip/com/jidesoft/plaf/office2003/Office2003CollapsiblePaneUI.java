package com.jidesoft.plaf.office2003;


public class Office2003CollapsiblePaneUI extends com.jidesoft.plaf.basic.BasicCollapsiblePaneUI {

	public Office2003CollapsiblePaneUI() {
	}

	public Office2003CollapsiblePaneUI(com.jidesoft.pane.CollapsiblePane f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createTitlePane(com.jidesoft.pane.CollapsiblePane w) {
	}
}
