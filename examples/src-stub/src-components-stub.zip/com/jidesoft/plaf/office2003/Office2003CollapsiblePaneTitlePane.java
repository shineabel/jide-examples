package com.jidesoft.plaf.office2003;


public class Office2003CollapsiblePaneTitlePane extends com.jidesoft.plaf.basic.BasicCollapsiblePaneTitlePane {

	public Office2003CollapsiblePaneTitlePane(com.jidesoft.pane.CollapsiblePane f) {
	}

	@java.lang.Override
	protected void setupCollapseButton(com.jidesoft.plaf.basic.BasicCollapsiblePaneTitlePane.BasicCollapseButton button) {
	}

	@java.lang.Override
	protected int getButtonSize() {
	}

	@java.lang.Override
	protected void paintFocusIndicator(java.awt.Graphics g, int x, int y, int w, int h) {
	}
}
