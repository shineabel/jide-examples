package com.jidesoft.plaf.vsnet;


public class VsnetCollapsiblePaneUI extends com.jidesoft.plaf.basic.BasicCollapsiblePaneUI {

	public VsnetCollapsiblePaneUI() {
	}

	public VsnetCollapsiblePaneUI(com.jidesoft.pane.CollapsiblePane f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}
}
