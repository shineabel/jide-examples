package com.jidesoft.plaf;


public abstract class StatusBarSeparatorUI extends javax.swing.plaf.SeparatorUI {

	public StatusBarSeparatorUI() {
	}
}
