package com.jidesoft.plaf.basic;


/**
 *  A basic L&F implementation of CollapsiblePane.
 */
public class BasicCollapsiblePaneUI extends com.jidesoft.plaf.CollapsiblePaneUI {

	protected com.jidesoft.pane.CollapsiblePane _pane;

	protected java.beans.PropertyChangeListener _propertyChangeListener;

	protected java.awt.LayoutManager _collapsiblePaneLayout;

	protected javax.swing.JComponent _northPane;

	protected javax.swing.JComponent _southPane;

	protected javax.swing.JComponent _westPane;

	protected javax.swing.JComponent _eastPane;

	protected javax.swing.JComponent _titlePane;

	protected javax.swing.Action _collapseAction;

	protected String _collapseText;

	public BasicCollapsiblePaneUI() {
	}

	public BasicCollapsiblePaneUI(com.jidesoft.pane.CollapsiblePane f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void uninstallDefaults() {
	}

	protected void installKeyboardActions() {
	}

	protected void installComponents() {
	}

	protected void uninstallComponents() {
	}

	protected void installListeners() {
	}

	protected void uninstallListeners() {
	}

	protected void uninstallKeyboardActions() {
	}

	@java.lang.Override
	public java.awt.Component getTitlePane() {
	}

	protected java.awt.LayoutManager createLayoutManager() {
	}

	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent x) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize(javax.swing.JComponent x) {
	}

	@java.lang.Override
	public java.awt.Dimension getMaximumSize(javax.swing.JComponent x) {
	}

	/**
	 *  Installs necessary mouse handlers on <code>newPane</code> and adds it to the frame. Reverse process for the
	 *  <code>currentPane</code>.
	 * 
	 *  @param currentPane the current pane
	 *  @param newPane     the new pane
	 */
	protected void replacePane(javax.swing.JComponent currentPane, javax.swing.JComponent newPane) {
	}

	protected javax.swing.JComponent createNorthPane(com.jidesoft.pane.CollapsiblePane pane) {
	}

	protected javax.swing.JComponent createTitlePane(com.jidesoft.pane.CollapsiblePane w) {
	}

	protected javax.swing.JComponent createSouthPane(com.jidesoft.pane.CollapsiblePane pane) {
	}

	protected javax.swing.JComponent createWestPane(com.jidesoft.pane.CollapsiblePane pane) {
	}

	protected javax.swing.JComponent createEastPane(com.jidesoft.pane.CollapsiblePane pane) {
	}

	protected final boolean isKeyBindingRegistered() {
	}

	protected final void setKeyBindingRegistered(boolean b) {
	}

	public final boolean isKeyBindingActive() {
	}

	protected final void setKeyBindingActive(boolean b) {
	}

	protected void setupMenuOpenKey() {
	}

	protected void setupMenuCloseKey() {
	}

	public javax.swing.JComponent getNorthPane() {
	}

	protected void setNorthPane(javax.swing.JComponent c) {
	}

	public javax.swing.JComponent getSouthPane() {
	}

	protected void setSouthPane(javax.swing.JComponent c) {
	}

	public javax.swing.JComponent getWestPane() {
	}

	protected void setWestPane(javax.swing.JComponent c) {
	}

	public javax.swing.JComponent getEastPane() {
	}

	protected void setEastPane(javax.swing.JComponent c) {
	}

	public ThemePainter getPainter() {
	}

	@java.lang.Override
	public javax.swing.Action getToggleAction() {
	}

	public class CollapsiblePanePropertyChangeListener {


		public BasicCollapsiblePaneUI.CollapsiblePanePropertyChangeListener() {
		}

		/**
		 *  Detects changes in state from the CollapsiblePane and handles actions.
		 */
		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}
	}

	public class CollapsiblePaneLayout {


		public BasicCollapsiblePaneUI.CollapsiblePaneLayout() {
		}

		public void addLayoutComponent(String name, java.awt.Component c) {
		}

		public void removeLayoutComponent(java.awt.Component c) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container c) {
		}

		/**
		 *  Gets minimum size.
		 * 
		 *  @param c the container
		 *  @return the minimum layout size.
		 */
		public java.awt.Dimension minimumLayoutSize(java.awt.Container c) {
		}

		public void layoutContainer(java.awt.Container c) {
		}
	}

	public class CollapseAction {


		public BasicCollapsiblePaneUI.CollapseAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}
	}
}
