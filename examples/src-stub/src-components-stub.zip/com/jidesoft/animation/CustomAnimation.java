/**
 *  The package contains the classes related to CustomAnimation, mainly used by Alert for JIDE Components product.
 */
package com.jidesoft.animation;


/**
 *  A class implements custom animations.
 *  <p/>
 *  Currently we support three kinds of animations - fly, zoom and fade - we call it effect. They all can be used during
 *  entrance and exit animation type.
 *  <p/>
 *  There are a lot of options you can control how the animation looks like. Those options include speed, smoothness (how
 *  many frames. The more the smoother), and location.
 *  <p/>
 *  In the case of fly effect animation, you also have options such as direction, start location, end location, function
 *  x and function y. Function x and function y here are just like function in the maths. Both functions together will
 *  define the path of the fly in or fly out.
 *  <p/>
 *  In the case of fade effect animation, you only have the option of end location as it stays at the same location.
 *  However you do have a function to control the fade speed at different stage. For example, if you choose
 *  FUNC_POW_HALF, it will fade faster at the beginning and slower at the end. If you choose FUNC_POW2 or FUNC_POW3, it
 *  will be the opposite.
 *  <p/>
 *  Please note, each component should have it's own <code>CustomAnimation</code> and should not share the same instance
 *  with other components. If you want the same setting of a <code>CustomAnimation</code>, you can call {@link #clone()}
 *  method to clone one.
 */
public class CustomAnimation implements java.io.Serializable, Cloneable {

	public static final int TYPE_ENTRANCE = 0;

	public static final int TYPE_EXIT = 1;

	public static final int EFFECT_FLY = 100;

	public static final int EFFECT_ZOOM = 101;

	public static final int EFFECT_FADE = 201;

	public static final int SMOOTHNESS_VERY_SMOOTH = 100;

	public static final int SMOOTHNESS_SMOOTH = 50;

	public static final int SMOOTHNESS_MEDIUM = 20;

	public static final int SMOOTHNESS_ROUGH = 10;

	public static final int SMOOTHNESS_VERY_ROUGH = 5;

	public static final int SPEED_VERY_SLOW = 200;

	public static final int SPEED_SLOW = 100;

	public static final int SPEED_MEDIUM = 50;

	public static final int SPEED_FAST = 25;

	public static final int SPEED_VERY_FAST = 10;

	public static final int IN = 0;

	public static final int OUT = 1;

	public static final int HORIZONTAL = 0;

	public static final int VERTICAL = 1;

	public static final int CENTER = 0;

	public static final int BOTTOM = 1;

	public static final int LEFT = 2;

	public static final int RIGHT = 3;

	public static final int TOP = 4;

	public static final int BOTTOM_LEFT = 5;

	public static final int BOTTOM_RIGHT = 6;

	public static final int TOP_LEFT = 7;

	public static final int TOP_RIGHT = 8;

	public static final int LEFT_DOWN = 0;

	public static final int LEFT_UP = 1;

	public static final int RIGHT_DOWN = 2;

	public static final int RIGHT_UP = 3;

	public static Function FUNC_LINEAR;

	public static Function FUNC_POW_HALF;

	public static Function FUNC_POW2;

	public static Function FUNC_POW3;

	public static Function FUNC_LOG;

	public static Function FUNC_BOUNCE;

	public static Function FUNC_VIBRATE;

	/**
	 *  Creates a <tt>CustomAnimation</tt>.
	 */
	public CustomAnimation() {
	}

	/**
	 *  Creates a <tt>CustomAnimation</tt> with several parameters.
	 * 
	 *  @param type       {@link #TYPE_ENTRANCE} or {@link #TYPE_EXIT}.
	 *  @param effect     {@link #EFFECT_FADE} or {@link #EFFECT_FLY} or {@link #EFFECT_ZOOM}
	 *  @param smoothness any positive integer. We also predefined a few values, {@link #SMOOTHNESS_VERY_ROUGH} (5),
	 *                    {@link #SMOOTHNESS_ROUGH} (10), {@link #SMOOTHNESS_MEDIUM} (25), {@link #SMOOTHNESS_SMOOTH}
	 *                    (50), and {@link #SMOOTHNESS_VERY_SMOOTH} (100). The large the value is, the smoothier the
	 *                    animation.
	 *  @param speed      any positive integer. We also predefined a few values, {@link #SPEED_VERY_SLOW} (200), {@link
	 *                    #SPEED_SLOW} (100), {@link #SPEED_MEDIUM} (50), {@link #SPEED_FAST} (25), and {@link
	 *                    #SPEED_VERY_FAST} (10). The large the value is, the slower the animation.
	 */
	public CustomAnimation(int type, int effect, int smoothness, int speed) {
	}

	/**
	 *  Gets the type of the animation. There are only two valid types - {@link #TYPE_ENTRANCE} and {@link #TYPE_EXIT}.
	 * 
	 *  @return the type of the animation.
	 */
	public int getType() {
	}

	/**
	 *  Sets the type of the animation. There are only two valid types - {@link #TYPE_ENTRANCE} and {@link #TYPE_EXIT}.
	 * 
	 *  @param type {@link #TYPE_ENTRANCE} or {@link #TYPE_EXIT}.
	 *  @see #getType()
	 */
	public void setType(int type) {
	}

	/**
	 *  Gets the effect of the animation. Valid effects are {@link #EFFECT_FLY}, {@link #EFFECT_FADE} and {@link
	 *  #EFFECT_ZOOM}.
	 * 
	 *  @return the effect of the animation.
	 */
	public int getEffect() {
	}

	/**
	 *  Sets the effect of animation. Valid effects are {@link #EFFECT_FLY}, {@link #EFFECT_FADE} and {@link
	 *  #EFFECT_ZOOM}.
	 * 
	 *  @param effect {@link #EFFECT_FADE} or {@link #EFFECT_FLY} or {@link #EFFECT_ZOOM}
	 */
	public void setEffect(int effect) {
	}

	/**
	 *  Gets the initial delay, in milliseconds. It will wait for the specified time before starting the animation.
	 * 
	 *  @return the initial delay, in milliseconds.
	 */
	public int getInitDelay() {
	}

	/**
	 *  Sets the initial delay.
	 * 
	 *  @param initDelay the initial delay, in milliseconds.
	 *  @see #getInitDelay()
	 */
	public void setInitDelay(int initDelay) {
	}

	/**
	 *  Gets the smoothness of the animation. We called in smoothness, it's actually the number of frames (or steps)
	 *  during the animation.
	 * 
	 *  @return the smoothness of the animation.
	 */
	public int getSmoothness() {
	}

	/**
	 *  Sets the smoothness. It's an integer value. There are five predefined number you can use. They are {@link
	 *  #SMOOTHNESS_VERY_SMOOTH}, {@link #SMOOTHNESS_SMOOTH}, {@link #SMOOTHNESS_MEDIUM},{@link #SMOOTHNESS_ROUGH} and
	 *  {@link #SMOOTHNESS_VERY_ROUGH}. We recommend you to use those predefined values although you can use any positive
	 *  integer value as parameter. We called it speed, but it's actually the number of milliseconds delay between two
	 *  steps. So the smaller the number, the fast the animation.
	 * 
	 *  @param smoothness the smoothness.
	 */
	public void setSmoothness(int smoothness) {
	}

	/**
	 *  Gets the speed. We called it speed, but it's actually the number of milliseconds delay between two steps. So the
	 *  smaller the number, the fast the animation.
	 * 
	 *  @return the speed
	 */
	public int getSpeed() {
	}

	/**
	 *  Sets the speed. It's an integer value. There are five predefined number you can use. They are {@link
	 *  #SPEED_VERY_FAST}, {@link #SPEED_FAST}, {@link #SPEED_MEDIUM},{@link #SPEED_SLOW} and {@link #SPEED_VERY_SLOW}.
	 *  We recommend you to use those predefined values although you can use any positive integer value as parameter.
	 * 
	 *  @param speed the speed.
	 */
	public void setSpeed(int speed) {
	}

	/**
	 *  Gets the direction of the animation. This is only used in FLY and ZOOM effect animation when the start location
	 *  is not clear.
	 * 
	 *  @return the direction.
	 */
	public int getDirection() {
	}

	/**
	 *  Sets the direction of the animation. This is only used in FLY and ZOOM type of animation when the start location
	 *  is not clear. For example, if you never call setStartLocation() but you set direction to BOTTOM for a FLY effect
	 *  entrance animation, the animation will start from the bottom of the screen and fly to the location either set by
	 *  setEndLocation() or set by showPopup(...) method vertically.
	 * 
	 *  @param direction the direction. The valid values are {@link #TOP}, {@link #TOP_LEFT}, {@link #LEFT}, {@link
	 *                   #TOP_RIGHT}, {@link #RIGHT}, {@link #BOTTOM}, {@link #BOTTOM_LEFT}, and {@link #BOTTOM_RIGHT}.
	 */
	public void setDirection(int direction) {
	}

	/**
	 *  Gets the secondary direction. This is not used right now. It is reserved for future usage because some animation
	 *  effects we will add need it.
	 * 
	 *  @return the secondary direction.
	 */
	public int getSecondaryDirection() {
	}

	/**
	 *  Sets the secondary direction.  This is not used right now. It is reserved for future usage because some animation
	 *  effects we will add need it.
	 * 
	 *  @param secondaryDirection the secondary direction.
	 */
	public void setSecondaryDirection(int secondaryDirection) {
	}

	/**
	 *  Gets the start location of the animation.
	 * 
	 *  @return the start location of the animation.
	 */
	public java.awt.Point getStartLocation() {
	}

	/**
	 *  Sets the start location of the animation. In exit type animation, the start location, if never set, is defaulted
	 *  to the current location.
	 * 
	 *  @param startLocation the start location.
	 */
	public void setStartLocation(java.awt.Point startLocation) {
	}

	/**
	 *  Gets the end location of the animation.
	 * 
	 *  @return the end location.
	 */
	public java.awt.Point getEndLocation() {
	}

	/**
	 *  Sets the end location of the animation. In entrnace type animation, the end location, if never set, is defaulted
	 *  to the current location.
	 * 
	 *  @param endLocation the end location.
	 */
	public void setEndLocation(java.awt.Point endLocation) {
	}

	/**
	 *  Gets the visible bounds. This is only used when there is no the start and end location but have direction
	 *  information. In order to calculate the location, we will use this bounds as the visible area. <br> For example,
	 *  if the direction is BOTTOM in a fly entrance animation, we will calculate the start location based on the visible
	 *  bounds so that it starts right right outside the visible bounds to get the fly-in effect.
	 * 
	 *  @return the visible bounds. By default it will use the screen bounds. If it's dual or more monitors system, it
	 *          will use the main monitor screen bounds.
	 */
	public java.awt.Rectangle getVisibleBounds() {
	}

	/**
	 *  Sets the visible bounds.
	 * 
	 *  @param visibleBounds the visible bounds of the screen.
	 */
	public void setVisibleBounds(java.awt.Rectangle visibleBounds) {
	}

	/**
	 *  Starts the animation.
	 * 
	 *  @param source the component which will animate.
	 */
	public void start(java.awt.Component source) {
	}

	/**
	 *  Gets the animator listener. Usually it will return null unless you set it. If it's null, it will setup the
	 *  default animator listener based on the effect and type.
	 * 
	 *  @return the animator listener.
	 */
	public AnimatorListener getAnimatorListener() {
	}

	/**
	 *  Sets the animator listener. Usually you don't need to set it. It will setup the default animator listener based
	 *  on the effect and type. If you decide to set it, you will have full control over how the animation works.
	 * 
	 *  @param animatorListener the animation listener.
	 */
	public void setAnimatorListener(AnimatorListener animatorListener) {
	}

	/**
	 *  Adds an <code>AnimatorListener</code> to this CustomAnimation. Please use this method if you wish to receive
	 *  notification that the animation is about to start or has just ended.
	 * 
	 *  @param listener the <code>AnimatorListener</code> to be added
	 */
	public void addAnimatorListener(AnimatorListener listener) {
	}

	/**
	 *  Removes an <code>AnimatorListener</code> from this CustomAnimation.
	 * 
	 *  @param listener the listener to be removed
	 */
	public void removeAnimatorListener(AnimatorListener listener) {
	}

	/**
	 *  Returns an array of all the <code>AnimatorListener</code>s added to this CustomAnimation with
	 *  addAnimatorListener().
	 * 
	 *  @return all of the <code>AnimatorListener</code>s added or an empty array if no listeners have been added
	 */
	public AnimatorListener[] getAnimatorListeners() {
	}

	/**
	 *  Customizes the animator. Based on the type and effect, this method will set an {@link AnimatorListener} to do the
	 *  animation using {@link Animator#addAnimatorListener(com.jidesoft.swing.AnimatorListener)} method. If you have any
	 *  new effect, you can override this method to provide your own AnimatorListener.
	 * 
	 *  @param animator the <code>Animator</code>.
	 */
	protected void customizeAnimator(Animator animator) {
	}

	/**
	 *  Stops the animation.
	 */
	public void stop() {
	}

	protected double getPercentX(int step, int totalStep) {
	}

	protected double getPercentY(int step, int totalStep) {
	}

	protected double getPercentFade(int step, int totalStep) {
	}

	protected double getPercentZoom(int step, int totalStep) {
	}

	/**
	 *  Gets the screen image.
	 * 
	 *  @return the screen image.
	 * 
	 *  @see #setScreenImage(java.awt.Image)
	 */
	public java.awt.Image getScreenImage() {
	}

	/**
	 *  Sets the screen image. This is really a hack than a feature. Because there is no way to display a transparent
	 *  JWindow using Swing, we have to use a screenshot of current screen and paint it over the JWindow to get the
	 *  transparent effect. So this method is used so that caller can set the screen image. If the future, if Swing ever
	 *  supports transparent JWindow, we will be more than happy to get rid of this method.
	 * 
	 *  @param screenImage the screen image.
	 */
	public void setScreenImage(java.awt.Image screenImage) {
	}

	/**
	 *  Sets the call back.
	 * 
	 *  @return the call back.
	 */
	public CustomAnimation.Callback getCallback() {
	}

	/**
	 *  Callback which will be called when animation ends.
	 * 
	 *  @param callback the callback.
	 */
	public void setCallback(CustomAnimation.Callback callback) {
	}

	/**
	 *  Gets the function used to calculate the x coord.
	 * 
	 *  @return the function used to calculate the x coord.
	 */
	public Function getFunctionX() {
	}

	/**
	 *  Sets the function used to calculate the x coord. Together with functionY and the start/end locations, they will
	 *  determine the exact track of a fly animation.
	 *  <p/>
	 *  Here is an example. Say the animation will start at x coord 0 and end at x coord 100. To make it simple, let's
	 *  assume there are 100 steps in this animation. If you use linear functionX, it will move steadily because in the
	 *  linear function, calculate(step, totalStep) simply returns ((double) step) / totalStep. This means at step 1,
	 *  move to x coord 1, at step 2, move to x coord 2 and so on. Now if you use pow2 function, it will move
	 *  differently. Pow2 function returns Math.pow((double) step / totalStep, 2.0). If you calculate manually, you will
	 *  find it moves slowly at the beginning and faster at the end. Pow 1/2 function on the other hand will be opposite.
	 *  It will be faster at the beginning and slower at the end. Please note, this is just the functionX which controls
	 *  the movement on x coord. If the y coord of start and end location are different, the y coord will change along
	 *  with x coord change. Combining the both functionX and functionY, it's possible to achieve any moving track as you
	 *  want from the starting location to end location. <br> Just to make it interesting, we pre-built FUNC_BOUNCE or
	 *  FUNC_VIBRATE functions you can use to create a bouncing or vibrating effect.
	 * 
	 *  @param functionX the function for X direction.
	 */
	public void setFunctionX(Function functionX) {
	}

	/**
	 *  Gets the function used to calculate the y coord.
	 * 
	 *  @return the function used to calculate the y coord.
	 * 
	 *  @see #setFunctionY(Function)
	 *  @see #setFunctionX(Function)
	 */
	public Function getFunctionY() {
	}

	/**
	 *  Sets the function used to calculate the x coord. Together with functionX and the start/end locations, they will
	 *  determine the exact track of the fly animation.
	 * 
	 *  @param functionY the function for Y direction.
	 *  @see #getFunctionY()
	 *  @see #setFunctionX(Function)
	 */
	public void setFunctionY(Function functionY) {
	}

	/**
	 *  Sets the function for fading effect. Same as functionX and functionY which controls the movement along x and y
	 *  coord, functionFade controls the transparency level of the fading effect.
	 * 
	 *  @return function for fading effect.
	 */
	public Function getFunctionFade() {
	}

	/**
	 *  Sets the function for fading effect.
	 * 
	 *  @param functionFade the function for fading calculation.
	 */
	public void setFunctionFade(Function functionFade) {
	}

	/**
	 *  Gets the function for zooming effect. Same as functionX and functionY which controls the movement along x and y
	 *  coord, functionZoom controls the size changing of the zooming effect.
	 * 
	 *  @return the function for zooming effect.
	 */
	public Function getFunctionZoom() {
	}

	/**
	 *  Sets the function for zooming effect.
	 * 
	 *  @param functionZoom the function for zooming calculation.
	 */
	public void setFunctionZoom(Function functionZoom) {
	}

	/**
	 *  Clone the <code>CustomAnimation</code>. Since <code>CustomAnimation</code> cannot be shared among several
	 *  components, it is recommended to clone a <code>CustomAnimation</code> when using it.
	 * 
	 *  @return a cloned <code>CustomAnimation</code>.
	 */
	@java.lang.Override
	public Object clone() {
	}

	/**
	 *  Checks if the animation is running.
	 * 
	 *  @return true if the animation is running.
	 */
	public boolean isRunning() {
	}

	public static interface class Callback {


		public void performed() {
		}
	}
}
