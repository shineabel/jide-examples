/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


public class DocumentPanePersistenceUtils {

	public DocumentPanePersistenceUtils() {
	}

	/**
	 *  Saves the DocumentPane's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param pane     the document pane
	 *  @param fileName the file name
	 *  @throws javax.xml.parsers.ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DocumentPane pane, String fileName) {
	}

	/**
	 *  Saves the DocumentPane's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param pane     the document pane
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DocumentPane pane, String fileName, String encoding) {
	}

	/**
	 *  Saves the DocumentPane's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param pane     the document pane
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DocumentPane pane, String fileName, String encoding, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Saves the DocumentPane's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param pane   the document pane
	 *  @param out    the output stream
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DocumentPane pane, java.io.OutputStream out) {
	}

	/**
	 *  Saves the DocumentPane's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param pane     the document pane
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DocumentPane pane, java.io.OutputStream out, String encoding) {
	}

	/**
	 *  Saves the DocumentPane's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param pane     the document pane
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DocumentPane pane, java.io.OutputStream out, String encoding, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Save the DocumentPane to a Document.
	 * 
	 *  @param pane     the document pane
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 *  @return the XML document.
	 *  @throws ParserConfigurationException if there is any parser configuration issue.
	 */
	public static org.w3c.dom.Document save(DocumentPane pane, PersistenceUtilsCallback.Save callback) {
	}

	public static void load(DocumentPane pane, java.io.InputStream in) {
	}

	public static void load(DocumentPane pane, java.io.InputStream in, PersistenceUtilsCallback.Load callback) {
	}

	public static void load(DocumentPane pane, String fileName) {
	}

	public static void load(DocumentPane pane, String fileName, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Loads the document pane from the document.
	 * 
	 *  @param pane      the DocumentPane
	 *  @param document  the document to be loaded
	 *  @param callback  the load callback to customize reading
	 */
	public static void load(DocumentPane pane, org.w3c.dom.Document document, PersistenceUtilsCallback.Load callback) {
	}
}
