/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  The container for the DocumentComponent when floating.
 * 
 *  @since 3.3.7
 */
public class DialogFloatingDocumentContainer extends javax.swing.JDialog implements FloatingDocumentContainer {

	public DialogFloatingDocumentContainer(DocumentPane documentPane) {
	}

	public void updateTitle() {
	}

	public DocumentPane getDocumentPane() {
	}

	public IDocumentGroup getDocumentGroup() {
	}

	public java.awt.Component getRoutingComponent() {
	}

	public void setRoutingKeyStrokes(boolean routingKeyStrokes) {
	}

	public boolean isRoutingKeyStrokes() {
	}
}
