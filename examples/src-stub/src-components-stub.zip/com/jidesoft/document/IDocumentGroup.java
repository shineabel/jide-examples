/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  An interface to represent the concept of document group.
 */
public interface IDocumentGroup {

	/**
	 *  Adds a document to the this document group.
	 * 
	 *  @param document document to be added
	 */
	public void addDocument(DocumentComponent document);

	/**
	 *  Adds a document to the this document group.
	 * 
	 *  @param document document to be added
	 *  @param index    the index of the document where it will be added.
	 */
	public void addDocument(DocumentComponent document, int index);

	/**
	 *  Removes document at index.
	 * 
	 *  @param index index of the document to be removed
	 */
	public void removeDocument(int index);

	/**
	 *  Removes document.
	 * 
	 *  @param document document to be removed
	 */
	public void removeDocument(DocumentComponent document);

	/**
	 *  Updates the title of document. You should call this method if the title of the document changed.
	 * 
	 *  @param document the document
	 */
	public void updateTitle(DocumentComponent document);

	/**
	 *  Updates the component of document. You should call this method if the component of the document changed.
	 * 
	 *  @param document the document
	 *  @deprecated replaced by {@link #updateComponent(DocumentComponent, java.awt.Component)}
	 */
	@java.lang.Deprecated
	public void updateComponent(DocumentComponent document);

	/**
	 *  Updates the component of document. You should call this method if the component of the document changed.
	 * 
	 *  @param document the document
	 *  @param oldComponent the old component of the document
	 */
	public void updateComponent(DocumentComponent document, java.awt.Component oldComponent);

	/**
	 *  Gets component of the selected document in this group.
	 * 
	 *  @return the component of the selected document
	 */
	public java.awt.Component getSelectedDocument();

	/**
	 *  Gets component of the selected document in this group.
	 * 
	 *  @return the index of the selected document
	 */
	public int getSelectedIndex();

	/**
	 *  Sets the selected document.
	 * 
	 *  @param component component of the selected document
	 */
	public void setSelectedDocument(java.awt.Component component);

	/**
	 *  Gets document count in this group.
	 * 
	 *  @return document count
	 */
	public int getDocumentCount();

	/**
	 *  Gets document at position <code>index</code>.
	 * 
	 *  @param index the index of the document
	 *  @return the document at position <code>index</code>
	 */
	public java.awt.Component getDocumentAt(int index);

	/**
	 *  Gets the index of the document.
	 * 
	 *  @param component the component
	 *  @return index of the document
	 */
	public int indexOfDocument(java.awt.Component component);

	/**
	 *  Moves selected document to another index.
	 * 
	 *  @param index the index of the document
	 */
	public void moveSelectedDocumentTo(int index);
}
