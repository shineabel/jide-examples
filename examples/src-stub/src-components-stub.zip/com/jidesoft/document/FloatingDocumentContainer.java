/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  The container for the DocumentComponent when floating.
 */
public interface FloatingDocumentContainer {

	public DocumentPane getDocumentPane();

	public IDocumentGroup getDocumentGroup();

	public java.awt.Component getRoutingComponent();

	public void setRoutingKeyStrokes(boolean routingKeyStrokes);

	public boolean isRoutingKeyStrokes();

	public void updateTitle();

	public void toFront();

	public void setVisible(boolean visible);

	public void pack();

	public int getX();

	public int getY();

	public boolean isActive();

	public javax.swing.JRootPane getRootPane();

	public void setBounds(java.awt.Rectangle bounds);

	public java.awt.Rectangle getBounds();

	public void setLocation(java.awt.Point p);

	public void setPreferredSize(java.awt.Dimension size);

	public void setTitle(String title);

	public String getTitle();

	public void addWindowListener(java.awt.event.WindowListener listener);
}
