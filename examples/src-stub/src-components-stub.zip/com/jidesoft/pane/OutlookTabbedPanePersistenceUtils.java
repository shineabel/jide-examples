/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  A helper class that can support persist AggregateTablePane's layout to/from xml file.
 */
public class OutlookTabbedPanePersistenceUtils {

	public OutlookTabbedPanePersistenceUtils() {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to a file.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param fileName the file name
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(OutlookTabbedPane pane, String fileName) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to an output stream.
	 * 
	 *  @param pane the OutlookTabbedPane
	 *  @param out  the output stream
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(OutlookTabbedPane pane, java.io.OutputStream out) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to an XML Document
	 * 
	 *  @param pane the OutlookTabbedPane
	 *  @return XML Document which has the OutlookTabbedPane's layout.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *           if a DocumentBuilder cannot be created which satisfies the configuration
	 */
	public static org.w3c.dom.Document save(OutlookTabbedPane pane) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to a file.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param fileName the file name
	 *  @param callback The callback which will be called when saving each element to the XML document.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(OutlookTabbedPane pane, String fileName, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to a file.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param fileName the file name
	 *  @param callback the callback which will be called when saving each element to the XML document
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(OutlookTabbedPane pane, String fileName, PersistenceUtilsCallback.Save callback, String encoding) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to an output stream.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param out      the output stream
	 *  @param callback The callback which will be called when saving each element to the XML document.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(OutlookTabbedPane pane, java.io.OutputStream out, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to an output stream.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param out      the output stream
	 *  @param callback The callback which will be called when saving each element to the XML document.
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                              if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException If the pathname argument is null or any IO errors happen
	 */
	public static void save(OutlookTabbedPane pane, java.io.OutputStream out, PersistenceUtilsCallback.Save callback, String encoding) {
	}

	/**
	 *  Saves the OutlookTabbedPane's layout to an XML Document
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param callback The callback which will be called when saving each element to the XML document.
	 *  @return XML Document which has the OutlookTabbedPane's layout.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *           if a DocumentBuilder cannot be created which satisfies the configuration
	 */
	public static org.w3c.dom.Document save(OutlookTabbedPane pane, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Loads the OutlookTabbedPane's layout from an input stream.
	 * 
	 *  @param pane the OutlookTabbedPane
	 *  @param in   the input stream
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                                   if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws org.xml.sax.SAXException if either the XML parser or the application has errors
	 *  @throws java.io.IOException      if the pathname argument is null or any IO errors happen
	 */
	public static void load(OutlookTabbedPane pane, java.io.InputStream in) {
	}

	/**
	 *  Loads the layout from xml file.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param fileName the layout file name.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                                   if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                   requested.
	 *  @throws org.xml.sax.SAXException If any parse errors occur.
	 *  @throws java.io.IOException      If the pathname argument is null or any IO errors happen
	 */
	public static void load(OutlookTabbedPane pane, String fileName) {
	}

	/**
	 *  Loads the layout from xml document.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param document the XML document
	 */
	public static void load(OutlookTabbedPane pane, org.w3c.dom.Document document) {
	}

	/**
	 *  Loads the layout from input stream.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param in       the input stream
	 *  @param callback The callback which will be called when loading each element in the XML document.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                                   if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                   requested.
	 *  @throws org.xml.sax.SAXException If any parse errors occur.
	 *  @throws java.io.IOException      If the pathname argument is null or any IO errors happen
	 */
	public static void load(OutlookTabbedPane pane, java.io.InputStream in, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Loads the layout from xml file.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param fileName the layout file name.
	 *  @param callback The callback which will be called when loading each element in the XML document.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                                   if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                   requested.
	 *  @throws org.xml.sax.SAXException If any parse errors occur.
	 *  @throws java.io.IOException      If the pathname argument is null or any IO errors happen
	 */
	public static void load(OutlookTabbedPane pane, String fileName, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Loads the layout from xml document.
	 * 
	 *  @param pane     the OutlookTabbedPane
	 *  @param document the XML document
	 *  @param callback The callback which will be called when loading each element in the XML document.
	 */
	public static void load(OutlookTabbedPane pane, org.w3c.dom.Document document, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Gets the version of the layout file. Null is the layout file is invalid.
	 * 
	 *  @param in the InputStream
	 *  @return the version.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                                   if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                   requested.
	 *  @throws org.xml.sax.SAXException If any parse errors occur.
	 *  @throws java.io.IOException      If the pathname argument is null or any IO errors happen
	 */
	public static String getVersion(java.io.InputStream in) {
	}

	/**
	 *  Gets the version of the layout file. Null is the layout file is invalid.
	 * 
	 *  @param fileName the Document for the layout
	 *  @return the version.
	 *  @throws javax.xml.parsers.ParserConfigurationException
	 *                                   if a DocumentBuilder cannot be created which satisfies the configuration
	 *                                   requested.
	 *  @throws org.xml.sax.SAXException If any parse errors occur.
	 *  @throws java.io.IOException      If the pathname argument is null or any IO errors happen
	 */
	public static String getVersion(String fileName) {
	}

	/**
	 *  Gets the version of the layout file. Null is the layout file is invalid.
	 * 
	 *  @param document the Document for the layout
	 *  @return the version.
	 */
	public static String getVersion(org.w3c.dom.Document document) {
	}
}
