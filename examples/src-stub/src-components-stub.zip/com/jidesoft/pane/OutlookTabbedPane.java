/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  OutlookTabbedPane is a changed version of JTabbedPane. As we all know, JTabbedPane provides a way to organize
 *  multiple panes and allows user to see one pane at a time. OutlookTabbedPane serves the same purpose. However it
 *  organizes the panes in a vertical way like as you see in Microsoft Outlook 2003.
 *  <p/>
 *  The interface and usage of OutlookTabbedPane are the same as JTabbedPane. We even keep the name of methods to be the
 *  same so that you easily convert from JTabbedPane to OutlookTabbedPane.
 */
public class OutlookTabbedPane extends javax.swing.JTabbedPane {

	public static final String PROPERTY_BOTTOM_BUTTON_COUNT = "bottomButtonCount";

	protected javax.swing.event.ChangeListener _selectionChangeListener;

	public static final String CONTEXT_MENU_SHOW_MORE_BUTTON = "OutlookTabbedPane.showMoreButton";

	public static final String CONTEXT_MENU_SHOW_FEWER_BUTTON = "OutlookTabbedPane.showFewerButton";

	public static final String CONTEXT_MENU_OPTION = "OutlookTabbedPane.option.dialogTitle";

	public static final String CONTEXT_MENU_ADD_REMOVE_BUTTON = "OutlookTabbedPane.addRemoveButton";

	/**
	 *  Creates OutlookTabbedPane.
	 */
	public OutlookTabbedPane() {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel. Don't call super.updateUI() since it shouldn't
	 *  use default JTabbedPane UI at all.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	protected java.awt.LayoutManager createLayout() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.Action createSwitchPageAction(String title, javax.swing.Icon icon, int index) {
	}

	/**
	 *  Gets the buttons used by this tabbedPane in a Vector.
	 * 
	 *  @return vector of buttons.
	 */
	public java.util.Vector getButtons() {
	}

	@java.lang.Override
	public void setSelectedIndex(int index) {
	}

	/**
	 *  Overrides to remove the button for the tab index. If the tab being removed is selected, it will try to select
	 *  next tab unless the removed tab is the last one. If so, it will select previous tab.
	 * 
	 *  @param index the tab index
	 */
	@java.lang.Override
	public void removeTabAt(int index) {
	}

	/**
	 *  Overrides to insert a button for this new tab.
	 * 
	 *  @param title     the title to be displayed in this tab
	 *  @param icon      the icon to be displayed in this tab
	 *  @param component The component to be displayed when this tab is clicked.
	 *  @param tip       the tooltip to be displayed for this tab
	 *  @param index     the position to insert this new tab
	 */
	@java.lang.Override
	public void insertTab(String title, javax.swing.Icon icon, java.awt.Component component, String tip, int index) {
	}

	/**
	 *  Creates the button used by OutlookTabbedPane. Subclass can override it to create its own button. But those
	 *  buttons must implement UIResource. Otherwise, a runtime IllegalArgumentException will be thrown.
	 *  <p/>
	 *  Here is the default code.
	 *  <code><pre>
	 *  OutlookButton outlookButton = new OutlookButton(action);
	 *  outlookButton.setName((String) action.getValue(Action.NAME));
	 *  customizeButton(outlookButton);
	 *  return outlookButton;
	 *  </pre></code>
	 *  where <code>OutlookButton</code> is defined as
	 *  <code><pre>
	 *  public class OutlookButton extends JideButton implements UIResource {
	 *      public OutlookButton(Action a) {
	 *          super(a);
	 *      }
	 *  }
	 *  </pre></code>
	 * 
	 *  @param action the AbstractAction
	 *  @return button used by OutlookTabbedPane.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	/**
	 *  Get the height of the button panel.
	 *  <p/>
	 *  The default value of the panel is 30.
	 * 
	 *  @return the height of the button panel.
	 */
	public int getButtonPanelHeight() {
	}

	/**
	 *  Set the height of the button panel.
	 * 
	 *  @param buttonPanelHeight the height
	 */
	public void setButtonPanelHeight(int buttonPanelHeight) {
	}

	@java.lang.Override
	public int getMnemonicAt(int tabIndex) {
	}

	@java.lang.Override
	public void setMnemonicAt(int tabIndex, int mnemonic) {
	}

	@java.lang.Override
	public int getDisplayedMnemonicIndexAt(int tabIndex) {
	}

	@java.lang.Override
	public void setDisplayedMnemonicIndexAt(int tabIndex, int mnemonicIndex) {
	}

	@java.lang.Override
	public void setTitleAt(int index, String title) {
	}

	@java.lang.Override
	public String getTitleAt(int index) {
	}

	@java.lang.Override
	public javax.swing.Icon getIconAt(int index) {
	}

	@java.lang.Override
	public void setIconAt(int index, javax.swing.Icon icon) {
	}

	@java.lang.Override
	public javax.swing.Icon getDisabledIconAt(int index) {
	}

	@java.lang.Override
	public void setDisabledIconAt(int index, javax.swing.Icon disabledIcon) {
	}

	@java.lang.Override
	public String getToolTipTextAt(int index) {
	}

	@java.lang.Override
	public void setToolTipTextAt(int index, String toolTipText) {
	}

	@java.lang.Override
	public boolean isEnabledAt(int index) {
	}

	@java.lang.Override
	public void setEnabledAt(int index, boolean enabled) {
	}

	@java.lang.Override
	public void setForegroundAt(int index, java.awt.Color foreground) {
	}

	@java.lang.Override
	public java.awt.Color getForegroundAt(int index) {
	}

	@java.lang.Override
	public void setBackgroundAt(int index, java.awt.Color background) {
	}

	@java.lang.Override
	public java.awt.Color getBackgroundAt(int index) {
	}

	/**
	 *  Gets the panel on the bottom that has the bottom buttons and the chevron.
	 * 
	 *  @return the bottom panel.
	 */
	public javax.swing.JPanel getBottomPanel() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in pane.properties that begin with "OutlookTabbedPane.".
	 * 
	 *  @param key the key to the resource.
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Creates the popup menu that is used when user clicking on the chevron on the bottom button bar. You can override
	 *  this method to customize this popup menu. The menu items all have their name which are defined as constants such
	 *  as {@link #CONTEXT_MENU_SHOW_MORE_BUTTON}, {@link #CONTEXT_MENU_SHOW_FEWER_BUTTON}, {@link #CONTEXT_MENU_OPTION},
	 *  {@link #CONTEXT_MENU_ADD_REMOVE_BUTTON}. So you can iterate through the menu items and look up by name to find
	 *  out which one to add/remove/modify.
	 * 
	 *  @return the popup menu.
	 */
	protected javax.swing.JPopupMenu createPopupMenu() {
	}

	protected void displayOptionDialog() {
	}

	/**
	 *  Customizes the option dialog. Subclass can override this method customize the dialog.
	 * 
	 *  @param dialog the option dialog
	 */
	protected void customizeOptionDialog(javax.swing.JDialog dialog) {
	}

	protected int[] createCounts() {
	}

	/**
	 *  Customizes the button used by OutlookTabbedPane. Subclass can override it to customize the button.
	 * 
	 *  @param button the button used by OutlookTabbedPane
	 */
	protected void customizeButton(javax.swing.AbstractButton button) {
	}

	/**
	 *  Customizes the button used by OutlookTabbedPane's bottom panel. Subclass can override it to customize the
	 *  button.
	 * 
	 *  @param button the button used by OutlookTabbedPane
	 */
	protected void customizeBottomButton(javax.swing.AbstractButton button) {
	}

	public String getOptionDialogTitle() {
	}

	public void setOptionDialogTitle(String optionDialogTitle) {
	}

	/**
	 *  Gets the visible tabs' index.
	 * 
	 *  @return the visible tabs' index.
	 */
	public int[] getVisibleTabs() {
	}

	/**
	 *  Sets the visible tabs.
	 * 
	 *  @param tabs the tab indices that will be visible.
	 */
	public void setVisibleTabs(int[] tabs) {
	}

	/**
	 *  Checks if the tab at the specified index is visible.
	 * 
	 *  @param index the tab index.
	 *  @return true if the tab is visible. Otherwise false.
	 */
	public boolean isTabVisibleAt(int index) {
	}

	/**
	 *  Shows or hide the tab at the specified index. Different from removeTabAt which removes the tab completely,
	 *  setTabVisible to false simply hides the tab. You can still access the tab using methods such as get/setTitleAt,
	 *  get/setIconAt etc. You can use this method to show/hide tab programmatically. User also can show/hide the tabs by
	 *  selecting "Options" menu item on the bottom of the tabbed pane.
	 * 
	 *  @param index   the tab index.
	 *  @param visible true to set the tab visible and false to set the tab invisible.
	 */
	public void setTabVisibleAt(int index, boolean visible) {
	}

	protected void fireStateChanged() {
	}

	protected String[] createTitles(java.util.Vector titles) {
	}

	/**
	 *  Gets the tab order.
	 * 
	 *  @return the tab order. It contains an string array of all tab titles in the order they are displayed.
	 */
	public String[] getTabOrder() {
	}

	/**
	 *  Sets the tab order.
	 * 
	 *  @param titles an string array of all tab titles in the order that they will be displayed.
	 *  @throws IllegalArgumentException if the title in the titles array doesn't exist in the tabbed pane.
	 */
	public void setTabOrder(String[] titles) {
	}

	/**
	 *  Gets the button count on the bottom panel.
	 * 
	 *  @return the button count on the bottom panel.
	 */
	public int getBottomButtonCount() {
	}

	/**
	 *  Sets the button count on the bottom panel. This is a bound property. {@link #PROPERTY_BOTTOM_BUTTON_COUNT}
	 *  property change event will be fired when the value changes.
	 * 
	 *  @param bottomButtonCount the button count on the bottom panel.
	 */
	public void setBottomButtonCount(int bottomButtonCount) {
	}

	/**
	 *  Gets an optional version string.
	 * 
	 *  @return version string.
	 */
	public String getVersion() {
	}

	/**
	 *  Sets version string.
	 * 
	 *  @param version the version of the saved layout.
	 */
	public void setVersion(String version) {
	}

	public void setChevronVisible(boolean visible) {
	}

	public boolean isChevronVisible() {
	}

	protected java.awt.Component getVisibleComponent() {
	}

	protected void setVisibleComponent(java.awt.Component component) {
	}

	/**
	 *  Gets the image icon used by the popup menu.
	 * 
	 *  @param iconName the location of the icon relative to OutlookTabbedPane class location. You can also think it as
	 *                  the name of the icon when you override this method and use another way to create the image icons
	 *                  to be used.
	 *  @return the image icon.
	 */
	protected javax.swing.ImageIcon getImageIcon(String iconName) {
	}

	/**
	 *  Gets the AccessibleContext associated with this JTabbedPane. For tabbed panes, the AccessibleContext takes the
	 *  form of an AccessibleJTabbedPane. A new AccessibleJTabbedPane instance is created if necessary.
	 * 
	 *  @return an AccessibleJTabbedPane that serves as the AccessibleContext of this JTabbedPane
	 */
	@java.lang.Override
	public javax.accessibility.AccessibleContext getAccessibleContext() {
	}

	public class OutlookButton {


		public OutlookTabbedPane.OutlookButton(javax.swing.Action a) {
		}
	}

	public class MouseHandler {


		public OutlookTabbedPane.MouseHandler() {
		}

		@java.lang.Override
		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}
	}

	public class OptionDialog {


		public OutlookTabbedPane.OptionDialog(java.awt.Frame owner, String title) {
		}

		public OutlookTabbedPane.OptionDialog(java.awt.Dialog owner, String title) {
		}

		@java.lang.Override
		public ButtonPanel createButtonPanel() {
		}

		protected void updateSelection(CheckBoxList list) {
		}

		protected javax.swing.ListModel createListModel(java.util.Vector titles) {
		}

		protected javax.swing.ListModel createListModel(String[] titles) {
		}

		@java.lang.Override
		public javax.swing.JComponent createBannerPanel() {
		}

		@java.lang.Override
		public javax.swing.JComponent createContentPanel() {
		}
	}

	/**
	 *  This class implements accessibility support for the <code>JTabbedPane</code> class.  It provides an
	 *  implementation of the Java Accessibility API appropriate to tabbed pane user-interface elements.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	protected class AccessibleJTabbedPane {


		/**
		 *  Constructs an AccessibleJTabbedPane
		 */
		public OutlookTabbedPane.AccessibleJTabbedPane() {
		}

		public void stateChanged(javax.swing.event.ChangeEvent e) {
		}

		/**
		 *  Get the role of this object.
		 * 
		 *  @return an instance of AccessibleRole describing the role of the object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleRole getAccessibleRole() {
		}

		/**
		 *  Returns the number of accessible children in the object.
		 * 
		 *  @return the number of accessible children in the object.
		 */
		@java.lang.Override
		public int getAccessibleChildrenCount() {
		}

		/**
		 *  Return the specified Accessible child of the object.
		 * 
		 *  @param i zero-based index of child
		 *  @return the Accessible child of the object
		 *  @throws IllegalArgumentException if index is out of bounds
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleChild(int i) {
		}

		/**
		 *  Gets the <code>AccessibleSelection</code> associated with this object.  In the implementation of the Java
		 *  Accessibility API for this class, returns this object, which is responsible for implementing the
		 *  <code>AccessibleSelection</code> interface on behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleSelection getAccessibleSelection() {
		}

		/**
		 *  Returns the <code>Accessible</code> child contained at the local coordinate <code>Point</code>, if one
		 *  exists. Otherwise returns the currently selected tab.
		 * 
		 *  @return the <code>Accessible</code> at the specified location, if it exists
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
		}

		public int getAccessibleSelectionCount() {
		}

		public javax.accessibility.Accessible getAccessibleSelection(int i) {
		}

		public boolean isAccessibleChildSelected(int i) {
		}

		public void addAccessibleSelection(int i) {
		}

		public void removeAccessibleSelection(int i) {
		}

		public void clearAccessibleSelection() {
		}

		public void selectAllAccessibleSelection() {
		}
	}
}
