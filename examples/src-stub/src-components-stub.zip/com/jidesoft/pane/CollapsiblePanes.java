/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  <code>CollapsiblePanes</code> is a container for <code>CollapsiblePane</code>.
 *  <p/>
 *  It's very simple to use this class. Usuall you want to all collapsible panes align to the top. All you need to do is
 *  to add the CollapsiblePane using {@link #add(java.awt.Component)} method. After that, call {@link #addExpansion()} so
 *  that when CollapsiblePane collapsible, the last component will act like an expansion to push all the collapsible
 *  panes up. See example code below.
 *  <pre><code>
 *  CollapsiblePanes pane = new CollapsiblePanes();
 *  CollapsiblePane fileFolderTaskPane = createFileFolderTaskPane();
 *  CollapsiblePane otherPlacesPane = createOtherPlacesPane();
 *  pane.add(fileFolderTaskPane);
 *  pane.add(otherPlacesPane);
 *  pane.addExpansion();
 *  </code></pre>
 *  On the other hand, if you want to collapsible panes to be pushed down when collapsible, you can call {@link
 *  #addExpansion()} first, then add the collapsible panes.
 * 
 *  @author Viegas Ludovic from ESI SUPINFO Paris - contributes the Scrollable code.
 */
public class CollapsiblePanes extends javax.swing.JPanel implements javax.swing.Scrollable {

	public static final String PROPERTY_AXIS = "axis";

	public static final String PROPERTY_GAP = "gap";

	/**
	 *  Creates a new <code>CollapsiblePanes</code> using JideBoxLayout.
	 */
	public CollapsiblePanes() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  After finishing add collapsible pane, you should call this method to add an expansion component so that all
	 *  collapsible pane will be pushed up.
	 */
	public void addExpansion() {
	}

	/**
	 *  Gets the axis of the JideBoxLayout used by CollapsiblePanes.
	 * 
	 *  @return the axis of the JideBoxLayout used by CollapsiblePanes.
	 */
	public int getAxis() {
	}

	/**
	 *  Sets the axis of the JideBoxLayout used by CollapsiblePanes.
	 * 
	 *  @param axis the axis of the JideBoxLayout used by CollapsiblePanes.
	 */
	public void setAxis(int axis) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Creates the default layout manager for CollapsiblePanes.
	 *  <p/>
	 *  The default implementation is like below:
	 *  <code>
	 *      return new JideBoxLayout(this, JideBoxLayout.Y_AXIS, UIDefaultsLookup.getInt("CollapsiblePanes.gap"));
	 *  </code>
	 * 
	 *  @return the layout manager.
	 *  @since 3.3.0
	 */
	protected JideBoxLayout createLayoutManager() {
	}

	public java.awt.Dimension getPreferredScrollableViewportSize() {
	}

	public int getScrollableBlockIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	public boolean getScrollableTracksViewportHeight() {
	}

	public boolean getScrollableTracksViewportWidth() {
	}

	public int getScrollableUnitIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	/**
	 *  Sets the gap between two collapsible panes.
	 * 
	 *  @param gap the new gap
	 */
	public void setGap(int gap) {
	}

	/**
	 *  Gets the gap between two collapsible panes.
	 * 
	 *  @return the gap between two collapsible panes.
	 */
	public int getGap() {
	}
}
