/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  <code>ExpandedTip</code> makes a component showing an expanded tooltip when the mouse is a node or a cell. It is the
 *  base class and has subclasses to implement for different components. It is useful for JList and JTree when they are
 *  narrow but the content is wide.
 *  <p>
 *  License notice: The file was originally copied from IntelliJ IDEA Community Edition (Apache 2.0 license) but was
 *  modified extensively to make the API easier to use.
 * 
 *  @param <S>
 *  @since 3.3.0
 */
public abstract class ExpandedTip {

	/**
	 *  The client property for ExpandedTip instance. When ExpandedTip is installed on a component, this client property
	 *  has the ExpandedTip.
	 */
	public static final String CLIENT_PROPERTY_EXPANDED_TIP = "ExpandedTip";

	protected final javax.swing.JComponent _component;

	protected ExpandedTip(javax.swing.JComponent component) {
	}

	/**
	 *  Gets the ExpandedTip installed on the component. Null is no ExpandedTip was installed.
	 * 
	 *  @param component the component
	 *  @return the ExpandedTip installed. Null is no ExpandedTip was installed.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static ExpandedTip getExpandedTip(javax.swing.JComponent component) {
	}

	public void uninstall() {
	}

	protected void updateCurrentSelection() {
	}

	protected void handleSelectionChange(int selected) {
	}

	protected void handleSelectionChange(int selected, boolean processIfUnfocused) {
	}

	public void showTip() {
	}

	public void hideTip() {
	}

	/**
	 *  Adjusts the window shape in case the tip window is not rectangular. By default, we override it and change the
	 *  window shape to rounded corner for the navigation component such as {@link com.jidesoft.navigation.NavigationTree}
	 *  and {@link com.jidesoft.navigation.NavigationList}.
	 * 
	 *  @param window      the window.
	 *  @param rightOrLeft right or left.
	 */
	protected void setWindowShape(javax.swing.JWindow window, boolean rightOrLeft) {
	}

	protected java.awt.Point createToolTipImage(int index, boolean rightOrLeft) {
	}

	protected boolean shouldDrawBorder() {
	}

	/**
	 *  Creates a BufferedImage.
	 * 
	 *  @param width  the width of the image
	 *  @param height the height of the image
	 *  @return a new BufferedImage
	 */
	protected java.awt.image.BufferedImage createImage(int width, int height) {
	}

	/**
	 *  Fills the background on the tip component.
	 * 
	 *  @param g      the graphics
	 *  @param width  the width
	 *  @param height the height
	 */
	protected void fillBackground(java.awt.Graphics2D g, int width, int height) {
	}

	/**
	 *  Paints the tip image. It will take a sub-image from the component at the specified bounds and paint it on the
	 *  provided graphics.
	 * 
	 *  @param g         the graphics
	 *  @param component the component where the sub-image is taken from
	 *  @param bounds    the bounds where the sub-image is at
	 *  @param index     the index of the row or the node
	 */
	protected void paintTipImage(java.awt.Graphics2D g, java.awt.Component component, java.awt.Rectangle bounds, int index, int scale) {
	}

	/**
	 *  Gets the visible rect of the component.
	 * 
	 *  @param index the index of the row or node
	 *  @return the visible rect of the component.
	 */
	protected java.awt.Rectangle getVisibleRect(int index) {
	}

	/**
	 *  Gets the component where the ExpandedTip is installed on.
	 * 
	 *  @return the component where the ExpandedTip is installed on.
	 */
	public javax.swing.JComponent getComponent() {
	}

	/**
	 *  Gets the target component. This component contains the image that will be put on the tip. The area of the image
	 *  is returned in the {@link #getRowBounds(int)}. What we will do is to take a capture of the image at the bounds on
	 *  the component and copy it to the tip component.
	 * 
	 *  @param index the index of the row or node.
	 *  @return the component.
	 */
	protected java.awt.Component getComponent(int index) {
	}

	/**
	 *  Gets the bounds of the image that will be put on the tip. The position is relative to the component returned from
	 *  {@link #getComponent(int)}. The bounds should cover the row or the node. We will calculate it so that only the
	 *  invisible area is shown on the tip component.
	 * 
	 *  @param index the index of the row or node.
	 *  @return the bounds.
	 */
	protected abstract java.awt.Rectangle getRowBounds(int index) {
	}

	/**
	 *  Gets the row index or the node index on the location.
	 * 
	 *  @param point the location.
	 *  @return the index of the row or node.
	 */
	protected abstract int rowAtPoint(java.awt.Point point) {
	}
}
