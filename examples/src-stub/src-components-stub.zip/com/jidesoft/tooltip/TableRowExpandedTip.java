/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  <code>TableRowExpandedTip</code> enables the ExpandedTip feature for <code>JTable</code>.
 *  <p/>
 *  Just so you know, there could be two different ways to use expanded tip for the JTable. One way is to show the whole
 *  row which is how this class implemented. The other way, which we haven't implemented yet, is to show a cell when the
 *  cell is not fully visible.
 * 
 *  @since 3.3.0
 */
public class TableRowExpandedTip extends ExpandedTip {

	public TableRowExpandedTip(javax.swing.JTable table) {
	}

	@java.lang.Override
	public void uninstall() {
	}

	public java.awt.Component getComponent(int index) {
	}

	public java.awt.Rectangle getRowBounds(int index) {
	}

	public java.awt.Rectangle getVisibleRect(int index) {
	}

	public int rowAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public void hideTip() {
	}

	@java.lang.Override
	public void showTip() {
	}

	/**
	 *  Gets the flag indicating if the header's expanded tip should be displayed as well when the row's expanded tip is
	 *  showing.
	 * 
	 *  @return true if the header's expanded tip should be displayed. Otherwise false.
	 *  @see #setShowHeaderTip(boolean)
	 *  @since 3.3.7
	 */
	public boolean isShowHeaderTip() {
	}

	/**
	 *  Sets the flag indicating if the header's expanded tip should be displayed as well when the row's expanded tip is
	 *  showing.
	 *  <p/>
	 *  By default, the flag is true. This flag only take effect if the ExpandedTip is already installed over the table
	 *  header.
	 * 
	 *  @param showHeaderTip the flag
	 *  @since 3.3.7
	 */
	public void setShowHeaderTip(boolean showHeaderTip) {
	}
}
