/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  <code>TableHeaderExpandedTip</code> enables the ExpandedTip feature for <code>JTableHeader</code>.
 * 
 *  @since 3.3.0
 */
public class TableHeaderExpandedTip extends ExpandedTip {

	public TableHeaderExpandedTip(javax.swing.table.JTableHeader tableHeader) {
	}

	@java.lang.Override
	public void uninstall() {
	}

	public java.awt.Component getComponent(int index) {
	}

	public java.awt.Rectangle getRowBounds(int index) {
	}

	public java.awt.Rectangle getVisibleRect(int index) {
	}

	@java.lang.Override
	protected java.awt.Point createToolTipImage(int index, boolean rightOrLeft) {
	}

	@java.lang.Override
	protected void paintTipImage(java.awt.Graphics2D g, java.awt.Component component, java.awt.Rectangle bounds, int index, int scale) {
	}

	public int rowAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	protected boolean shouldDrawBorder() {
	}
}
