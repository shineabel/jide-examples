/**
 *  The package contains different kinds of shadow composites for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.composite;


/**
 *  This class defines the blurred edge. Balloon tip using this
 *  compositor can produce a blurred shadow edge.
 */
public class EdgeEffectComposite implements com.jidesoft.tooltip.ShadowComposite {

	public EdgeEffectComposite() {
	}

	/**
	 *  Composing the shadow pixel color
	 */
	public int compose(double distance) {
	}

	/**
	 *  Gets the pixel of the edge that will be blurred.
	 * 
	 *  @return the blured edge size.
	 */
	public int getEdge() {
	}

	/**
	 *  Set the size of the blurred edge.
	 * 
	 *  @param edge the new size of the blurred edge.
	 */
	public void setEdge(int edge) {
	}
}
