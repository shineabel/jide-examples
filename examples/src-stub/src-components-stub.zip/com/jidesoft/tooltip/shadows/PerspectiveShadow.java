/**
 *  The package contains different kinds of shadows for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shadows;


/**
 *  Perspective shadow is shadow which has perspective casting effect.
 */
public abstract class PerspectiveShadow implements com.jidesoft.tooltip.ShadowStyle {

	/**
	 *  The shadow shearness on the y-axis direction.
	 */
	protected double _yRatio;

	/**
	 *  The shadow shearness on the x-axis direction.
	 */
	protected double _xRatio;

	/**
	 *  Creates a new instance of LeftBottomShadow
	 */
	public PerspectiveShadow() {
	}

	public java.awt.image.BufferedImage createShadow(java.awt.image.BufferedImage image, com.jidesoft.tooltip.BalloonTip balloonTip) {
	}

	public java.awt.Dimension getShadowSize(java.awt.Dimension size) {
	}

	protected abstract java.awt.Point translatePixel(int x, int y, int w, int h) {
	}

	public double getYRatio() {
	}

	public void setYRatio(double yRatio) {
	}

	public double getXRatio() {
	}

	public void setXRatio(double xRatio) {
	}
}
