/**
 *  The package contains the different shapes for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shapes;


/**
 *  A balloon shape implementation, which is a simple ellipse.
 */
public class OvalShape implements com.jidesoft.tooltip.BalloonShape {

	public OvalShape() {
	}

	/**
	 *  Create the ellipse outline.
	 */
	public java.awt.Shape createOutline(java.awt.Dimension balloonSize, java.awt.Dimension contentSize) {
	}

	public java.awt.Point getHotSpot(java.awt.Dimension balloonSize) {
	}

	/**
	 *  Get the insets.
	 */
	public java.awt.Insets getInsets(java.awt.Dimension contentSize) {
	}

	/**
	 *  Get the edge distance
	 */
	public double getEdgeDistance(java.awt.Point pixel, com.jidesoft.tooltip.BalloonTip balloonTip) {
	}
}
