/**
 *  The package contains the different shapes for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shapes;


/**
 *  A balloon shape implementation, a simple rectangle shape.
 */
public class RectangularShape extends RoundedRectangularShape {

	/**
	 *  Creates a new instance of RectangularBalloon
	 */
	public RectangularShape() {
	}

	@java.lang.Override
	public java.awt.Shape createOutline(java.awt.Dimension balloonSize, java.awt.Dimension contentSize) {
	}

	@java.lang.Override
	public double getEdgeDistance(java.awt.Point pixel, com.jidesoft.tooltip.BalloonTip balloonTip) {
	}
}
