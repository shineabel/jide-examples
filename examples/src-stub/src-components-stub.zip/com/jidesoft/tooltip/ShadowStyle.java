/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  Shadow style defines different shadow casting style, including casting direction,
 *  whether it should be a perspective casting and the position relative the balloon
 *  popup.
 */
public interface ShadowStyle {

	/**
	 *  Create shadow image using the background image of the balloon tip.
	 * 
	 *  @param image the background image of the balloon tip
	 *  @param tip   the balloon tip.
	 *  @return the shadow image of the balloon tip.
	 */
	public java.awt.image.BufferedImage createShadow(java.awt.image.BufferedImage image, BalloonTip tip);

	/**
	 *  Get the size of shadow according to the balloon size.
	 * 
	 *  @param size the balloon size.
	 *  @return the shadow size
	 */
	public java.awt.Dimension getShadowSize(java.awt.Dimension size);

	/**
	 *  Layout the balloon and shadow according to the style.
	 * 
	 *  @param balloonBounds the bounds for the balloon component.
	 *  @param shadowBounds  the bounds for the shadow component.
	 */
	public void layout(java.awt.Rectangle balloonBounds, java.awt.Rectangle shadowBounds);
}
