/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  <code>TreeExpandedTip</code> enables the ExpandedTip feature for <code>JTree</code>.
 *  <p/>
 *  License notice: The file was originally copied from IntelliJ IDEA Community Edition (Apache 2.0 license) but was
 *  modified extensively to be more easily used as a component.
 * 
 *  @since 3.3.0
 */
public class TreeExpandedTip extends ExpandedTip {

	public TreeExpandedTip(javax.swing.JTree tree) {
	}

	@java.lang.Override
	public void uninstall() {
	}

	@java.lang.Override
	protected int rowAtPoint(java.awt.Point point) {
	}

	protected java.awt.Rectangle getRowBounds(int index) {
	}

	@java.lang.Override
	protected void paintTipImage(java.awt.Graphics2D g, java.awt.Component component, java.awt.Rectangle bounds, int index, int scale) {
	}
}
