/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  An empty StatusBarItem.
 */
public class EmptyStatusBarItem extends StatusBarItem {

	public EmptyStatusBarItem() {
	}

	public String getItemName() {
	}
}
