/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  <code>StatusBarSeparator</code> provides a divider between status bar items.
 */
public class StatusBarSeparator extends javax.swing.JSeparator implements javax.swing.SwingConstants, javax.accessibility.Accessible {

	/**
	 *  Creates a new horizontal separator.
	 */
	public StatusBarSeparator() {
	}

	/**
	 *  Creates a new separator with the specified horizontal or
	 *  vertical orientation.
	 * 
	 *  @param orientation an integer specifying
	 *                     <code>SwingConstants.HORIZONTAL</code> or
	 *                     <code>SwingConstants.VERTICAL</code>
	 *  @throws IllegalArgumentException if <code>orientation</code>
	 *                                   is neither <code>SwingConstants.HORIZONTAL</code> nor
	 *                                   <code>SwingConstants.VERTICAL</code>
	 */
	public StatusBarSeparator(int orientation) {
	}

	/**
	 *  Returns the L&F object that renders this component.
	 * 
	 *  @return the SeparatorUI object that renders this component
	 */
	@java.lang.Override
	public javax.swing.plaf.SeparatorUI getUI() {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the L&F class that renders this component.
	 * 
	 *  @return the string "CommandBarSeparatorUI"
	 *  @see javax.swing.JComponent#getUIClassID
	 *  @see javax.swing.UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  return true if it supports vertical orientation.
	 * 
	 *  @return true if it supports vertical orientation
	 */
	public boolean supportVerticalOrientation() {
	}

	/**
	 *  return ture if it supports horizontal orientation.
	 * 
	 *  @return ture if it supports horizontal orientation
	 */
	public boolean supportHorizontalOrientation() {
	}
}
