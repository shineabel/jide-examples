/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  MemoryStatusBarItem is used to display current used memory vs total memory in current JVM. It also allows manually
 *  running garbage collection by pressing the garbage can button, or double clicking on the memory status area.
 *  <p/>
 *  <code>MemoryStatusBarItem</code>'s item name is "Status". We hardcoded inside this class. So if you add it to
 *  StatusBar and want to get it, you just call statusBar.getItemByName("Status"). If you want to change it to something
 *  else, you would have to override getItemName method.
 */
public class MemoryStatusBarItem extends StatusBarItem {

	protected javax.swing.JComponent _statusArea;

	protected javax.swing.AbstractButton _button;

	protected javax.swing.JPanel _buttonPanel;

	/**
	 *  Default constructor.
	 */
	public MemoryStatusBarItem() {
	}

	/**
	 *  Creates a button which will run garbage collector. Subclass can override it to create your own button.
	 * 
	 *  @return the button which will run garbage collector.
	 */
	protected javax.swing.AbstractButton createButton() {
	}

	/**
	 *  Returns the total amount of memory in the Java virtual machine.
	 * 
	 *  @return the total amount of memory in the Java virtual machine.
	 */
	protected long getTotalMemory() {
	}

	/**
	 *  Returns the maximum amount of memory that the Java virtual machine will attempt to use.
	 * 
	 *  @return the maximum amount of memory that the Java virtual machine will attempt to use.
	 */
	protected long getMaxMemory() {
	}

	/**
	 *  Gets the free memory.
	 * 
	 *  @return the free memory.
	 */
	protected long getFreeMemory() {
	}

	/**
	 *  Gets the text.
	 * 
	 *  @param freeMemory  the free memory
	 *  @param totalMemory the total memory
	 *  @param maxMemory   the max memory as defined in JVM -Xmx.
	 *  @return the formatted tooltip.
	 */
	public String formatText(long totalMemory, long freeMemory, long maxMemory) {
	}

	/**
	 *  Gets the tooltip.
	 * 
	 *  @param freeMemory  the free memory
	 *  @param totalMemory the total memory
	 *  @param maxMemory   the max memory as defined in JVM -Xmx.
	 *  @return the formatted tooltip.
	 */
	protected String formatTooltip(long freeMemory, long totalMemory, long maxMemory) {
	}

	@java.lang.Override
	public String getItemName() {
	}

	/**
	 *  Gets filled color.
	 * 
	 *  @return filled color
	 */
	public java.awt.Color getFillColor() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Set filled color.
	 * 
	 *  @param fillColor the fill color.
	 */
	public void setFillColor(java.awt.Color fillColor) {
	}

	/**
	 *  Gets the icon of GC.
	 * 
	 *  @return the icon for GC
	 */
	public javax.swing.Icon getGcIcon() {
	}

	/**
	 *  Sets the icon of GC (Gabage Collection).
	 * 
	 *  @param gcIcon the GC icon
	 */
	public void setGcIcon(javax.swing.Icon gcIcon) {
	}

	/**
	 *  Sets update interval, in mini-second. Default is 500ms. If you need to display second, make sure it's less than
	 *  1000ms.
	 * 
	 *  @param interval interval in mini-second
	 */
	public void setUpdateInterval(int interval) {
	}

	/**
	 *  Gets the update interval in mini-second.
	 * 
	 *  @return update interval in mini-second
	 */
	public int getUpdateInterval() {
	}

	/**
	 *  Starts the timer to repaint the memory status area after certain interval (2 seconds by default).
	 */
	public void start() {
	}

	/**
	 *  Stops the timer. Call this method the main frame is closing.
	 */
	public void stop() {
	}

	@java.lang.Override
	public int getPreferredWidth() {
	}

	/**
	 *  Gets the flag for showMaxMemory.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowMaxMemory() {
	}

	/**
	 *  Sets of the upper memory is the actual heap memory or the max memory.
	 * 
	 *  @param showMaxMemory true or false.
	 */
	public void setShowMaxMemory(boolean showMaxMemory) {
	}
}
