/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  A status bar item with a button.
 */
public class ButtonStatusBarItem extends StatusBarItem {

	public ButtonStatusBarItem() {
	}

	/**
	 *  Creates a button status bar item with name.
	 * 
	 *  @param name name of the status bar item
	 */
	public ButtonStatusBarItem(String name) {
	}

	/**
	 *  Creates a <code>ButtonStatusBarItem</code> with the Action set to the button.
	 * 
	 *  @param action the action on the button.
	 */
	public ButtonStatusBarItem(javax.swing.Action action) {
	}

	/**
	 *  Customize the button.
	 * 
	 *  @param button the button
	 */
	protected void customizeButton(javax.swing.AbstractButton button) {
	}

	@java.lang.Override
	public void setToolTipText(String text) {
	}

	@java.lang.Override
	public String getToolTipText() {
	}

	/**
	 *  Creates button used by this ButtonStatusBarItem.
	 * 
	 *  @return the button.
	 */
	protected javax.swing.AbstractButton createButton() {
	}

	/**
	 *  Sets text to be displayed on the button.
	 * 
	 *  @param text the new text on the button.
	 */
	public void setText(String text) {
	}

	/**
	 *  Sets tooltip to be displayed on the button.
	 * 
	 *  @param tooltip the new tooltip on the button.
	 */
	public void setToolTip(String tooltip) {
	}

	/**
	 *  Sets icon to be displayed on the button.
	 * 
	 *  @param icon the new icon on the button.
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Enable or disable the StatusBar Item.
	 * 
	 *  @param enabled true to enable the button and false to disable it.
	 */
	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Adds an <code>ActionListener</code> to the button.
	 * 
	 *  @param listener the <code>ActionListener</code> to be added
	 */
	public void addActionListener(java.awt.event.ActionListener listener) {
	}

	/**
	 *  Removes the <code>ActionListener</code> from the button.
	 * 
	 *  @param listener the <code>ActionListener</code> to be removed
	 *  @since 3.2.0
	 */
	public void removeActionListener(java.awt.event.ActionListener listener) {
	}

	@java.lang.Override
	public java.util.EventListener[] getListeners(Class listenerType) {
	}

	/**
	 *  Gets the actual component. In this case it's a button.
	 * 
	 *  @return return the button.
	 */
	public java.awt.Component getComponent() {
	}

	/**
	 *  If the <code>preferredSize</code> has been set to a non-<code>null</code> value just returns it. If the UI
	 *  delegate's <code>getPreferredSize</code> method returns a non <code>null</code> value then return that; otherwise
	 *  defer to the component's layout manager.
	 * 
	 *  @return the value of the <code>preferredSize</code> property
	 * 
	 *  @see #setPreferredSize
	 *  @see ComponentUI
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public String getItemName() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	public void doClick() {
	}

	public void doClick(int pressTime) {
	}

	/**
	 *  Sets the text horizontal alignment. The valid values for alignment are defined in {@link
	 *  JButton#setHorizontalAlignment(int)}.
	 * 
	 *  @param alignment the horizontal alignment of the button.
	 * 
	 *  @see #getHorizontalAlignment()
	 */
	public void setHorizontalAlignment(int alignment) {
	}

	/**
	 *  Gets the text horizontal alignment.
	 * 
	 *  @return alignment
	 */
	public int getHorizontalAlignment() {
	}
}
