/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  Represents a difference, as used in <code>Diff</code>. A difference consists of two pairs of starting and ending
 *  points, each pair representing either the "from" or the "to" collection passed to <code>Diff</code>. If an ending
 *  point is -1, then the difference was either a deletion or an addition. For example, if <code>getDeletedEnd()</code>
 *  returns -1, then the difference represents an addition.
 */
public class Difference {

	public static final int NONE = -1;

	/**
	 *  The point at which the deletion starts.
	 */
	protected int _deletedStart;

	/**
	 *  The point at which the deletion ends.
	 */
	protected int _deletedEnd;

	/**
	 *  The point at which the addition starts.
	 */
	protected int _addedStart;

	/**
	 *  The point at which the addition ends.
	 */
	protected int _addedEnd;

	protected boolean _conflicting;

	/**
	 *  Creates the difference for the given start and end points for the deletion and addition.
	 */
	public Difference(int deletedStart, int deletedEnd, int addedStart, int addedEnd) {
	}

	/**
	 *  Creates the difference for the given start and end points for the deletion and addition.
	 */
	protected Difference(int deletedStart, int deletedEnd, int addedStart, int addedEnd, boolean conflicting) {
	}

	/**
	 *  The point at which the deletion starts, if any. A value equal to <code>NONE</code> means this is an addition.
	 */
	public int getDeletedStart() {
	}

	/**
	 *  The point at which the deletion ends, if any. A value equal to <code>NONE</code> means this is an addition.
	 */
	public int getDeletedEnd() {
	}

	/**
	 *  The point at which the addition starts, if any. A value equal to <code>NONE</code> means this must be an
	 *  addition.
	 */
	public int getAddedStart() {
	}

	/**
	 *  The point at which the addition ends, if any. A value equal to <code>NONE</code> means this must be an addition.
	 */
	public int getAddedEnd() {
	}

	/**
	 *  Sets the point as deleted. The start and end points will be modified to include the given line.
	 */
	public void setDeleted(int line) {
	}

	/**
	 *  Adjusts the point as deleted. The start and end points will be modified to include the given line.
	 */
	public void adjustDeleted(int lineChanges) {
	}

	/**
	 *  Adjusts point as added. The start and end points will be modified to include the given line.
	 */
	public void adjustAdded(int lineChanges) {
	}

	/**
	 *  Sets the point as added. The start and end points will be modified to include the given line.
	 */
	public void setAdded(int line) {
	}

	/**
	 *  Compares this object to the other for equality. Both objects must be of type Difference, with the same starting
	 *  and ending points.
	 */
	public boolean equals(Object obj) {
	}

	public boolean equal(int i) {
	}

	public boolean contains(int i) {
	}

	/**
	 *  Returns a string representation of this difference.
	 */
	public String toString() {
	}
}
