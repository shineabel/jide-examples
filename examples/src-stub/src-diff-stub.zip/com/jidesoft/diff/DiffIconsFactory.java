/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  A helper class to contain icons for JIDE Grids product.
 */
public class DiffIconsFactory {

	public DiffIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}

	public static class Editor {


		public static final String DELETE = "icons/delete.png";

		public static final String LEFT = "icons/left.png";

		public static final String RIGHT = "icons/right.png";

		public DiffIconsFactory.Editor() {
		}
	}
}
