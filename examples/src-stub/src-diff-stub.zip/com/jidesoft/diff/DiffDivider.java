/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>DiffDivider</code> is a panel using different color area to indicate different type of changes (changed,
 *  inserted or deleted) between two panes.
 */
public class DiffDivider extends javax.swing.JPanel {

	/**
	 *  The property of selected difference.
	 * 
	 *  @since 3.4.1
	 */
	public static final String PROPERTY_SELECTED_DIFFERENCE = "selectedDifference";

	public DiffDivider() {
	}

	public DiffDivider(DiffDivider.RowConverter firstConverter, DiffDivider.RowConverter secondConverter) {
	}

	public DiffDivider(DiffDivider.RowConverter firstConverter, DiffDivider.RowConverter secondConverter, java.util.List differences) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public DiffDivider.RowConverter getFirstConverter() {
	}

	public void setFirstConverter(DiffDivider.RowConverter firstConverter) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public DiffDivider.RowConverter getSecondConverter() {
	}

	public void setSecondConverter(DiffDivider.RowConverter secondConverter) {
	}

	public java.awt.Color getInsertedColor() {
	}

	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	public java.awt.Color getChangedColor() {
	}

	public void setChangedColor(java.awt.Color changedColor) {
	}

	public java.awt.Color getDeletedColor() {
	}

	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	public java.awt.Color getConflictedColor() {
	}

	public void setConflictedColor(java.awt.Color conflictedColor) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public java.util.List getDifferences() {
	}

	public void setDifferences(java.util.List differences) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	public int getFirstOffsetY() {
	}

	public void setFirstOffsetY(int firstOffsetY) {
	}

	public int getSecondOffsetY() {
	}

	public void setSecondOffsetY(int secondOffsetY) {
	}

	public int getFirstTopMargin() {
	}

	public void setFirstTopMargin(int firstTopMargin) {
	}

	public int getSecondTopMargin() {
	}

	public void setSecondTopMargin(int secondTopMargin) {
	}

	public int getFirstBottomMargin() {
	}

	public void setFirstBottomMargin(int firstBottomMargin) {
	}

	public int getSecondBottomMargin() {
	}

	public void setSecondBottomMargin(int secondBottomMargin) {
	}

	public boolean isOpposite() {
	}

	public void setOpposite(boolean opposite) {
	}

	/**
	 *  Sets the current selected difference.
	 * 
	 *  @param selectedDifference the selected difference
	 *  @since 3.4.1
	 */
	public void setSelectedDifference(Difference selectedDifference) {
	}

	/**
	 *  Gets the current selected difference.
	 * 
	 *  @return the current selected difference.
	 *  @since 3.4.1
	 */
	public Difference getSelectedDifference() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Gets the color to identify the currently selected difference.
	 *  <p/>
	 *  The default implementation is to return c.darker().
	 * 
	 *  @param c the default inserted/deleted/changed/conflicted color
	 *  @return the derived color.
	 *  @since 3.4.1
	 */
	protected java.awt.Color getSelectedColor(java.awt.Color c) {
	}

	protected int getSecondMatchLine(int totalVisibleLines, int firstLine) {
	}

	protected int getFirstMatchLine(int totalVisibleLines, int firstLine) {
	}

	protected void adjustFirstVerticalOffset(int offsetY, int topMargin) {
	}

	protected void adjustSecondVerticalOffset(int offsetY, int topMargin) {
	}

	/**
	 *  Converts from the row index as in the <code>Difference</code> to the y position for <code>DiffDivider</code>.
	 */
	public static interface class RowConverter {


		public int indexToY(int row) {
		}
	}
}
