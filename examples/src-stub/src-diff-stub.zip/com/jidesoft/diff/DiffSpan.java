/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class DiffSpan {

	public DiffSpan(int startIndex, int stopIndex) {
	}

	public int getStartIndex() {
	}

	public int getStopIndex() {
	}
}
