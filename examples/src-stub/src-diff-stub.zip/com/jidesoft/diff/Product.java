/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public interface Product {
}
