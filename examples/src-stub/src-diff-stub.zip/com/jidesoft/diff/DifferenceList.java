/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  The Difference List created by the {@link Diff} class. This class could contain lines difference information.
 * 
 *  @since 3.5.0
 */
public class DifferenceList extends java.util.ArrayList {

	/**
	 *  The constructor.
	 */
	public DifferenceList() {
	}

	/**
	 *  Adds the lines difference.
	 * 
	 *  @param diff      the target difference instance
	 *  @param linesDiff the lines difference list
	 */
	public void addLinesDiff(Difference diff, java.util.List linesDiff) {
	}

	/**
	 *  Removes the lines difference.
	 * 
	 *  @param diff      the target difference instance
	 */
	public void removeLinesDiff(Difference diff) {
	}

	/**
	 *  Clears all lines difference
	 */
	public void clearAllLinesDiff() {
	}

	/**
	 *  Gets the lines difference.
	 * 
	 *  @param diff      the target difference instance
	 *  @return the lines difference list.
	 */
	public java.util.List getLinesDiff(Difference diff) {
	}
}
