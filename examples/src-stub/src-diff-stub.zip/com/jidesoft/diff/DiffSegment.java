/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class DiffSegment extends javax.swing.text.Segment {

	public DiffSegment(boolean ignoreWhitespace, boolean ignoreCase) {
	}

	public boolean equals(Object o) {
	}

	public int hashCode() {
	}

	public CharSequence subSequence(int start, int end) {
	}
}
