/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>CodeEditorDiffPane</code> is a diff pane based on <code>CodeEditor</code> component in JIDE Code Editor
 *  product. It can be used to compare two block of multiple line texts. The text will be displayed in a
 *  <code>CodeEditor</code> to have syntax coloring. It also uses the highlight features provided by
 *  <code>CodeEditor</code> to make it easy to see the differences.
 */
public class CodeEditorDiffPane extends BasicDiffPane {

	protected CodeEditor _fromEditor;

	protected CodeEditor _toEditor;

	protected static char[] separators;

	/**
	 *  Creates a CodeEditorDiffPane. The text to be compared can be set using {@link #setFromText(String)} and {@link
	 *  #setToText(String)} methods.
	 */
	public CodeEditorDiffPane() {
	}

	public CodeEditorDiffPane(CharSequence fromText, CharSequence toText) {
	}

	@java.lang.Override
	public javax.swing.JComponent createComponent(Object item, int index) {
	}

	@java.lang.Override
	public javax.swing.JComponent createPane(Object item, int index) {
	}

	@java.lang.Override
	protected void customizePane(javax.swing.JComponent pane, int index) {
	}

	@java.lang.Override
	protected MarkerSupport createMarkerSupport(javax.swing.JComponent component) {
	}

	@java.lang.Override
	protected RowMarginSupport createRowMarginSupport(javax.swing.JComponent component, javax.swing.JScrollPane scrollPane) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	/**
	 *  Creates the code editor.
	 *  <p/>
	 *  By default, it invokes {@link #createEditor()} to create a CodeEditor instance.
	 * 
	 *  @param index the code editor index
	 *  @return the CodeEditor instance.
	 *  @since 3.4.0
	 */
	protected CodeEditor createEditor(int index) {
	}

	protected CodeEditor createEditor() {
	}

	protected void customizeEditor(CodeEditor editor, int index) {
	}

	/**
	 *  Gets the from items that is used for Diff to compare the lines.
	 *  <p/>
	 *  If the line difference is to be highlighted, this method is not invoked. Instead, {@link #getFromText(int, int)} is used.
	 * 
	 *  @return the CharSequence array.
	 *  @see #getFromText(int, int)
	 */
	@java.lang.Override
	public CharSequence[] getFromItems() {
	}

	/**
	 *  Gets the to items that is used for Diff to compare the lines.
	 *  <p/>
	 *  If the line difference is to be highlighted, this method is not invoked. Instead, {@link #getToText(int, int)} is used.
	 * 
	 *  @return the CharSequence array.
	 *  @see #getToText(int, int)
	 */
	@java.lang.Override
	public CharSequence[] getToItems() {
	}

	/**
	 *  Creates the line char sequence for the code editor in the designated line.
	 *  <p/>
	 *  By default, a CodeEditorCharSequence is created.
	 * 
	 *  @param editor    the code editor
	 *  @param lineIndex the line number
	 *  @return the CharSequence instance.
	 *  @since 3.4.1
	 */
	protected CharSequence getLineCharSequence(CodeEditor editor, int lineIndex) {
	}

	protected javax.swing.text.Segment getFromSegment(int startLineIndex, int endLineIndex) {
	}

	protected javax.swing.text.Segment getToSegment(int startLineIndex, int endLineIndex) {
	}

	protected javax.swing.text.Segment getSegment(CodeEditor editor, int startLineIndex, int endLineIndex) {
	}

	public boolean isIgnoreWhitespaces() {
	}

	public void setIgnoreWhitespaces(boolean ignoreWhitespaces) {
	}

	public boolean is_caseSensitive() {
	}

	public void set_caseSensitive(boolean caseSensitive) {
	}

	/**
	 *  Sets the text for the from editor.
	 * 
	 *  @param fromText the new text for the from editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setFromText(String fromText) {
	}

	public String getFromText() {
	}

	/**
	 *  Creates multiple lines diff.
	 *  <p/>
	 *  The string inside the diff instance is only the related rows. The method {@link #highlightChangedExactly(java.util.List, int, int, int, int, java.awt.Color, java.awt.Color, String)}
	 *  will consider the offset and get the correct position
	 * 
	 *  @param fromStartOffset from start offset
	 *  @param fromEndOffset   from end offset
	 *  @param toStartOffset   to start offset
	 *  @param toEndOffset     to end offset
	 *  @return the Diff instance.
	 *  @since 3.4.0
	 */
	@java.lang.Override
	public Diff createLinesDiff(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset) {
	}

	/**
	 *  Gets the from text for line difference to compare.
	 * 
	 *  @param startLineIndex the start line index
	 *  @param endLineIndex   the end line index
	 *  @return the Character array for diff.
	 *  @since 3.4.1
	 */
	protected Character[] getFromText(int startLineIndex, int endLineIndex) {
	}

	/**
	 *  Gets the from text for line difference to compare.
	 * 
	 *  @param startLineIndex the start line index
	 *  @param endLineIndex   the end line index
	 *  @return the Character array for diff.
	 *  @since 3.4.1
	 */
	protected Character[] getToText(int startLineIndex, int endLineIndex) {
	}

	/**
	 *  Sets the text for the to editor.
	 * 
	 *  @param toText the new text for the to editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setToText(String toText) {
	}

	public String getToText() {
	}

	protected void synchronizeViewport(DiffDivider diffDivider, boolean startFrom) {
	}

	protected void synchronizeViewportHorizontally(boolean startFrom) {
	}

	@java.lang.Override
	protected int getSelectedIndex(int paneIndex) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	@java.lang.Override
	protected void uninstallListeners() {
	}

	/**
	 *  Splits the string with the line break.
	 *  <p/>
	 *  This method is no longer being invoked since 3.4.1.
	 * 
	 *  @param string     the string
	 *  @param  lineBreak the line break
	 *  @deprecated replaced by {@link #getLineCharSequence}.
	 */
	@java.lang.Deprecated
	protected String[] splitString(String string, String lineBreak) {
	}

	/**
	 *  Sets the read only flag. A read only diff pane will not show the buttons to apply changes.
	 * 
	 *  @param readOnly the new read only flag.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setReadOnly(boolean readOnly) {
	}

	@java.lang.Override
	public void clearHighlights() {
	}

	@java.lang.Override
	public void startHighlights() {
	}

	@java.lang.Override
	public void endHighlights() {
	}

	@java.lang.Override
	public void highlightChangedExactly(java.util.List lineDiff, int fromStartLine, int fromEndLine, int toStartLine, int toEndLine, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	protected DiffTokens getDiffTokens(javax.swing.text.Segment text) {
	}

	@java.lang.Override
	public void highlightChanged(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightInserted(int fromStartLine, int toStartLine, int toEndLine, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightDeleted(int fromStartLine, int fromEndLine, int toStartLine, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	/**
	 *  Accepts the specified Difference and return a new list of Differences.
	 * 
	 *  @param differences the list of Differences.
	 *  @param c           the Difference to be accepted.
	 * 
	 *  @return a new list of Differences.
	 */
	protected java.util.List acceptDifference(java.util.List differences, Difference c) {
	}

	/**
	 *  Deletes number of lines from the specified started line in the toEditor.
	 * 
	 *  @param toLine             the starting line
	 *  @param toNumberOfLines    the number of lines to be deleted.
	 *  @param runDiffAfterward true of run the diff() again after deleting the lines.
	 */
	public boolean delete(int toLine, int toNumberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Inserts some lines from the fromEditor to the toEditor.
	 * 
	 *  @param toLine              the insersion line in the toEditor
	 *  @param fromLine          the starting line in the fromEditor
	 *  @param fromNumberOfLines the number of lines in the fromEditor to be inserted to the toEditor.
	 *  @param runDiffAfterward  true of run the diff() again after inserting the lines.
	 */
	public boolean insert(int toLine, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Gets the flag indicating if the leading and trailing spaces should be ignored when comparing two texts.
	 * 
	 *  @return true if leading and trailing spaces should be ignored. Otherwise false.
	 *  @see #setIgnoreLeadingTrailingSpaces(boolean)
	 *  @since 3.4.1
	 *  @deprecated replaced by {@link #isIgnoreWhitespaces()}
	 */
	@java.lang.Deprecated
	public boolean isIgnoreLeadingTrailingSpaces() {
	}

	/**
	 *  Sets the flag indicating if the leading and trailing spaces should be ignored when comparing two texts.
	 *  <p/>
	 *  By default, the value is false to keep the original behavior.
	 * 
	 *  @param ignoreLeadingTrailingSpaces the flag
	 *  @since 3.4.1
	 *  @deprecated replaced by {@link #setIgnoreWhitespaces(boolean)}
	 */
	@java.lang.Deprecated
	public void setIgnoreLeadingTrailingSpaces(boolean ignoreLeadingTrailingSpaces) {
	}
}
