/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  The lazy load table row data to represent a row's data to save the memory.
 * 
 *  @since 3.4.1
 */
public class LazyLoadTableRowData {

	/**
	 *  The constructor.
	 * 
	 *  @param model    the table model
	 *  @param rowIndex the row index
	 */
	public LazyLoadTableRowData(javax.swing.table.TableModel model, int rowIndex) {
	}

	/**
	 *  Gets the real row data that consumes memory.
	 * 
	 *  @return the list of cell values.
	 */
	public java.util.List getRowData() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
