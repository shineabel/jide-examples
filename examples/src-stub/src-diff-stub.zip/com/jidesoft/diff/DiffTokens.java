/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class DiffTokens {

	public DiffTokens(java.util.List segments, java.util.List spans) {
	}

	public java.util.List getTokenValues() {
	}

	public java.util.List getTokenSpans() {
	}
}
