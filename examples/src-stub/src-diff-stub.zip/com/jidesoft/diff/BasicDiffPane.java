/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>BasicDiffPane</code> is a diff pane to compare two components that are using JScrollPane. It can be used to
 *  compare two JLists, two JTables or two JTrees.
 */
public abstract class BasicDiffPane extends AbstractDiffPane {

	protected final int GAP_TITLE_PANE = 2;

	protected javax.swing.JComponent _fromComponent;

	protected javax.swing.JComponent _toComponent;

	protected javax.swing.JScrollPane _fromScrollPane;

	protected javax.swing.JScrollPane _toScrollPane;

	protected DiffDivider _fromToDivider;

	protected AbstractMargin _fromDiffMargin;

	protected AbstractMargin _toDiffMargin;

	protected javax.swing.JComponent _fromTitle;

	protected javax.swing.JComponent _toTitle;

	protected MarginArea _fromMarginArea;

	protected MarginArea _toMarginArea;

	protected AbstractMargin _fromDiffLineNumberMargin;

	protected AbstractMargin _toDiffLineNumberMargin;

	protected MarkerArea _fromMarkerArea;

	protected MarkerArea _toMarkerArea;

	protected RowMarginSupport _fromRowMarginSupport;

	protected RowMarginSupport _toRowMarginSupport;

	protected java.util.List _differences;

	protected static final int POSITION_BEFORE_FIRST = 0;

	protected static final int POSITION_ON_FIRST = 1;

	protected static final int POSITION_IN_THE_MIDDLE = 2;

	protected static final int POSITION_ON_LAST = 3;

	protected static final int POSITION_AFTER_LAST = 4;

	protected static final int POSITION_ON_FIRST_AND_LAST = 5;

	protected boolean _diffed;

	public BasicDiffPane() {
	}

	public BasicDiffPane(Object[] items) {
	}

	@java.lang.Override
	public void flip() {
	}

	/**
	 *  Creates the DiffMargin.
	 * 
	 *  @param rowMarginSupport the row margin support
	 *  @param original         if it's the original margin
	 *  @return the DiffMargin instance.
	 *  @since 3.4.3
	 */
	protected AbstractMargin createDiffMargin(RowMarginSupport rowMarginSupport, boolean original) {
	}

	public javax.swing.JComponent createPane(Object item, int index) {
	}

	protected abstract MarkerSupport createMarkerSupport(javax.swing.JComponent component) {
	}

	protected abstract RowMarginSupport createRowMarginSupport(javax.swing.JComponent component, javax.swing.JScrollPane scrollPane) {
	}

	public DiffDivider createDivider(int index) {
	}

	@java.lang.Override
	protected void customizeDivider(DiffDivider divider, int i) {
	}

	@java.lang.Override
	public void setChangedColor(java.awt.Color changedColor) {
	}

	@java.lang.Override
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	@java.lang.Override
	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	protected javax.swing.JComponent createFromTitle() {
	}

	protected javax.swing.JComponent createToTitle() {
	}

	public String getFromTitle() {
	}

	public void setFromTitle(String title) {
	}

	public String getToTitle() {
	}

	public void setToTitle(String title) {
	}

	/**
	 *  Creates the component to display the content for the diff.
	 * 
	 *  @param item  the content to be displayed in the component.
	 *  @param index the index of the component.
	 *  @return the component.
	 */
	public abstract javax.swing.JComponent createComponent(Object item, int index) {
	}

	protected DiffDivider.RowConverter createFromRowConverter() {
	}

	public abstract Object[] getFromItems() {
	}

	public abstract Object[] getToItems() {
	}

	/**
	 *  Gets the from component.
	 * 
	 *  @return the from component.
	 *  @since 3.4.1
	 */
	public javax.swing.JComponent getFromComponent() {
	}

	/**
	 *  Gets the to component.
	 * 
	 *  @return the to component.
	 *  @since 3.4.1
	 */
	public javax.swing.JComponent getToComponent() {
	}

	protected DiffDivider.RowConverter createToRowConverter() {
	}

	protected void synchronizeViewport(DiffDivider diffDivider, boolean startFrom, boolean vertically) {
	}

	@java.lang.Override
	protected void updateActions(int index) {
	}

	protected abstract int getSelectedIndex(int paneIndex) {
	}

	/**
	 *  @param paneIndex  the index of the pane. It could be either 0 or 1 in the case of a diff pane or 0, 1, 2 in the
	 *                    case of a merge pane.
	 *  @param firstIndex the first diff index
	 *  @param lastIndex  the last diff index
	 *  @return one of the six values. They are defined as constants beginning "POSITION_".
	 */
	protected int getCaretPosition(int paneIndex, int firstIndex, int lastIndex) {
	}

	@java.lang.Override
	public void firstChange() {
	}

	@java.lang.Override
	public void previousChange() {
	}

	@java.lang.Override
	public void nextChange() {
	}

	@java.lang.Override
	public void lastChange() {
	}

	/**
	 *  Scrolls when navigating between differences.
	 * 
	 *  @param isFromComponent if the start/end row index is for the from component or the to component
	 *  @param start           the start row index
	 *  @param end             the end row index
	 *  @since 3.5.0
	 */
	protected void scrollTo(boolean isFromComponent, int start, int end) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	@java.lang.Override
	protected void uninstallListeners() {
	}

	/**
	 *  Gets the Difference list for actual UI update.
	 *  <p/>
	 *  This method is to prepare Difference list for the method {@link #diff()}. In most cases, this method will return
	 *  a Difference instance each time you invoke it.
	 *  <p/>
	 *  This method will first invoke {@link #diff(Object[], Object[])} to get the difference list. It would then check
	 *  the method {@link #isHighlightExactChange()} to determine if the line difference will be calculated.
	 * 
	 *  @return the Difference list.
	 *  @since 3.4.8
	 */
	public java.util.List getDifferencesForDiff() {
	}

	/**
	 *  Gets the existing difference list.
	 *  <p/>
	 *  This method always returns the Difference list that updated by last invocation to {@link #diff()}.
	 * 
	 *  @return the existing difference list.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public java.util.List getDifferences() {
	}

	/**
	 *  Runs the different algorithm and returns the list of Differences.
	 *  <p/>
	 *  To have line difference further, it will return a {@link DifferenceList} instance by default.
	 * 
	 *  @param from the fromText.
	 *  @param to   the toText
	 *  @return the list of Differences.
	 */
	protected java.util.List diff(Object[] from, Object[] to) {
	}

	/**
	 *  Creates the Diff instance.
	 *  <p/>
	 *  Diff is the major class that implements the comparing algorithm. You could override this method to customize the
	 *  comparing algorithm if necessary.
	 *  <p/>
	 *  By default, it simply returns new Diff<T>(from, to).
	 * 
	 *  @param from the from items
	 *  @param to   the to items
	 *  @return the created Diff instance.
	 *  @since 3.4.1
	 */
	protected Diff createDiff(Object[] from, Object[] to) {
	}

	/**
	 *  Runs the diff algorithm and displays the differences on this diff pane. <p/> By default, the implementation of
	 *  this method is <code><p> _diffed = true; List<Difference> differences = getDifferencesForDiff();
	 *  differencesUpdated(differences); return differences; </p></code>
	 * 
	 *  @return the list of Differences.
	 */
	public java.util.List diff() {
	}

	public void runDiff() {
	}

	/**
	 */
	public void clearDiff() {
	}

	/**
	 *  Checks if the highlightExactChange flag is on. If on, we will display what changed exactly if one line in the
	 *  fromEditor is changed in the toEditor if and only if there is just one change between the two lines. Otherwise,
	 *  the whole line will be highlighted.
	 * 
	 *  @return true or false.
	 */
	public boolean isHighlightExactChange() {
	}

	/**
	 *  Checks if the diff pane is read only. A read only diff pane will not show the buttons to apply changes.
	 * 
	 *  @return true or false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public boolean isReadOnly() {
	}

	/**
	 *  Sets the read only flag. A read only diff pane will not show the buttons to apply changes.
	 * 
	 *  @param readOnly the new read only flag.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setReadOnly(boolean readOnly) {
	}

	/**
	 *  Sets the highlightExactChange flag.
	 * 
	 *  @param highlightExactChange true or false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setHighlightExactChange(boolean highlightExactChange) {
	}

	/**
	 *  Updates the difference to UI.
	 * 
	 *  @param diffs the list of the differences.
	 *  @since 3.4.2
	 */
	protected void differencesUpdated(java.util.List diffs) {
	}

	/**
	 *  Customizes the line diff.
	 *  <p/>
	 *  This method is invoked before highlighting the line diff after the default line diff is generated. If you don't
	 *  feel good about the default line diff generated by the algorithm of {@link Diff}, please override this method to
	 *  pass in your own diff.
	 *  <p/>
	 *  By default, this method simply returns the linesDiff passed in.
	 * 
	 *  @param linesDiff the default line diff
	 *  @return the line diff after customized.
	 *  @since 3.4.0
	 */
	protected java.util.List customizeLinesDiff(Diff diff, java.util.List linesDiff) {
	}

	protected static int binarySearchAdded(java.util.List differences, int line) {
	}

	protected static int binarySearchDeleted(java.util.List differences, int line) {
	}

	protected int getToMatchingRow(int fromRow) {
	}

	protected int getFromMatchingRow(int toRow) {
	}

	public void clearHighlights() {
	}

	public void startHighlights() {
	}

	public void endHighlights() {
	}

	/**
	 *  Creates single line diff.
	 * 
	 *  @param toOffset   to offset
	 *  @param fromOffset from offset
	 *  @return the Diff instance.
	 *  @deprecated replaced by {@link #createLinesDiff(int, int, int, int)}
	 */
	@java.lang.Deprecated
	public Diff createLineDiff(int toOffset, int fromOffset) {
	}

	/**
	 *  Creates multiple lines diff.
	 *  <p/>
	 *  This method is not implemented by default. You will need put your multiple line difference logic here.
	 * 
	 *  @param fromStartOffset from start offset
	 *  @param fromEndOffset   from end offset
	 *  @param toStartOffset   to start offset
	 *  @param toEndOffset     to end offset
	 *  @return the Diff instance.
	 *  @since 3.4.0
	 */
	protected Diff createLinesDiff(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset) {
	}

	public void highlightChangedExactly(java.util.List lineDiff, int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	public void highlightChanged(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	public void highlightInserted(int fromStartOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	public void highlightDeleted(int fromStartOffset, int fromEndOffset, int toStartOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	/**
	 *  Accepts the specified Difference and return a new list of Differences.
	 * 
	 *  @param differences the list of Differences.
	 *  @param c           the Difference to be accepted.
	 *  @return a new list of Differences.
	 */
	protected java.util.List acceptDifference(java.util.List differences, Difference c) {
	}

	/**
	 *  Deletes number of lines from the specified started line in the toEditor.
	 * 
	 *  @param toLine           the starting line
	 *  @param toNumberOfLines  the number of lines to be deleted.
	 *  @param runDiffAfterward true of run the diff() again after deleting the lines.
	 *  @return true or false. True means the operation is successful.
	 */
	public abstract boolean delete(int toLine, int toNumberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Inserts some lines from the fromEditor to the toEditor.
	 * 
	 *  @param toLine            the insertion line in the toEditor
	 *  @param fromLine          the starting line in the fromEditor
	 *  @param fromNumberOfLines the number of lines in the fromEditor to be inserted to the toEditor.
	 *  @param runDiffAfterward  true of run the diff() again after inserting the lines.
	 *  @return true or false. True means the operation is successful.
	 */
	public abstract boolean insert(int toLine, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Replaces number of lines from the specified started line in the toEditor with some lines from the fromEditor.
	 * 
	 *  @param toLine            the starting line in the toEditor
	 *  @param toNumberOfLines   the number of lines to be replaced from the toEditor.
	 *  @param fromLine          the starting line in the fromEditor
	 *  @param fromNumberOfLines the number of lines in the fromEditor to be copied to the toEditor.
	 *  @param runDiffAfterward  true of run the diff() again after replacing the lines.
	 *  @return true or false. True means the operation is successful.
	 */
	public boolean replace(int toLine, int toNumberOfLines, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Gets the flag indicating if BasicDiffPane should select the difference on clicking navigation buttons.
	 * 
	 *  @return true if the difference should be selected. Otherwise false.
	 *  @see #setSelectOnNavigation(boolean)
	 *  @since 3.4.0
	 */
	public boolean isSelectOnNavigation() {
	}

	/**
	 *  Sets the flag indicating if BasicDiffPane should select the difference on clicking navigation buttons.
	 *  <p/>
	 *  By default, the flag is true.
	 * 
	 *  @param selectOnNavigation the flag
	 *  @since 3.4.0
	 */
	public void setSelectOnNavigation(boolean selectOnNavigation) {
	}
}
