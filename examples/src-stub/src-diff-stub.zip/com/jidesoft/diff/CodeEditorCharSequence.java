/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  The CharSequence class used by CodeEditorDiffPane and CodeEditorMergePane to save memory usage.
 * 
 *  @since 3.4.1
 */
public class CodeEditorCharSequence implements CharSequence {

	/**
	 *  The constructor.
	 * 
	 *  @param editor                      the code editor
	 *  @param line                        the line number inside the code editor
	 *  @param ignoreLeadingTrailingSpaces the flag to indicate if leading and trailing spaces should be ignored
	 */
	public CodeEditorCharSequence(CodeEditor editor, int line, boolean ignoreLeadingTrailingSpaces) {
	}

	@java.lang.Override
	public int length() {
	}

	@java.lang.Override
	public char charAt(int index) {
	}

	@java.lang.Override
	public CharSequence subSequence(int start, int end) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
