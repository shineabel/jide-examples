/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>CodeEditorMergePane</code> is a merge pane based on <code>CodeEditor</code> component in JIDE Code Editor
 *  product. It can be used to compare three block of multiple line texts. The text will be displayed in a
 *  <code>CodeEditor</code> to have syntax coloring. It also uses the highlight features provided by
 *  <code>CodeEditor</code> to make it easy to see the differences and let user do the merging.
 */
public class CodeEditorMergePane extends AbstractMergePane {

	protected final int GAP_TITLE_PANE = 2;

	protected CodeEditor _fromEditor;

	protected CodeEditor _toEditor;

	protected CodeEditor _otherEditor;

	protected DiffMargin _fromDiffMargin;

	protected DiffMargin _otherDiffMargin;

	public CodeEditorMergePane() {
	}

	public CodeEditorMergePane(String fromText, String toText, String otherText) {
	}

	public javax.swing.JComponent createPane(Object item, int index) {
	}

	@java.lang.Override
	public DiffDivider createDivider(int index) {
	}

	protected void customizeDivider(DiffDivider divider, int index) {
	}

	@java.lang.Override
	public void setChangedColor(java.awt.Color changedColor) {
	}

	@java.lang.Override
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	@java.lang.Override
	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	@java.lang.Override
	public void setConflictedColor(java.awt.Color conflictedColor) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	protected javax.swing.JComponent createFromTitle() {
	}

	protected javax.swing.JComponent createToTitle() {
	}

	protected javax.swing.JComponent createOtherTitle() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getFromTitle() {
	}

	public void setFromTitle(String title) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getToTitle() {
	}

	public void setToTitle(String title) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getOtherTitle() {
	}

	public void setOtherTitle(String title) {
	}

	/**
	 *  Creates the code editor.
	 *  <p/>
	 *  By default, it invokes {@link #createEditor()} to create a CodeEditor instance.
	 * 
	 *  @param index the code editor index
	 *  @return the CodeEditor instance.
	 *  @since 3.4.1
	 */
	protected CodeEditor createEditor(int index) {
	}

	protected CodeEditor createEditor() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void customizeEditor(CodeEditor editor, int index) {
	}

	/**
	 *  Gets the from code editor.
	 * 
	 *  @return the from code editor.
	 *  @since 3.4.1
	 */
	public CodeEditor getFromEditor() {
	}

	/**
	 *  Gets the to code editor.
	 * 
	 *  @return the to code editor.
	 *  @since 3.4.1
	 */
	public CodeEditor getToEditor() {
	}

	/**
	 *  Gets the other code editor.
	 * 
	 *  @return the other code editor.
	 *  @since 3.4.1
	 */
	public CodeEditor getOtherEditor() {
	}

	/**
	 *  Gets the from items to compare.
	 * 
	 *  @return the CharSequence array from the from editor.
	 *  @since 3.4.1
	 */
	public CharSequence[] getFromItems() {
	}

	/**
	 *  Gets the to items to compare.
	 * 
	 *  @return the CharSequence array from the to editor.
	 *  @since 3.4.1
	 */
	public CharSequence[] getToItems() {
	}

	/**
	 *  Gets the other items to compare.
	 * 
	 *  @return the CharSequence array from the other editor.
	 *  @since 3.4.1
	 */
	public CharSequence[] getOtherItems() {
	}

	/**
	 *  Creates the line char sequence for the code editor in the designated line.
	 *  <p/>
	 *  By default, a CodeEditorCharSequence is created.
	 * 
	 *  @param editor    the code editor
	 *  @param lineIndex the line number
	 *  @return the CharSequence instance.
	 *  @since 3.4.1
	 */
	protected CharSequence createLineCharSequence(CodeEditor editor, int lineIndex) {
	}

	/**
	 *  Sets the text for the from editor.
	 * 
	 *  @param fromText the new text for the from editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setFromText(String fromText) {
	}

	public String getFromText() {
	}

	/**
	 *  Sets the text for the to editor.
	 * 
	 *  @param toText the new text for the to editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setToText(String toText) {
	}

	public String getToText() {
	}

	/**
	 *  Sets the text for the other editor.
	 * 
	 *  @param otherText the new text for the other editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setOtherText(String otherText) {
	}

	public String getOtherText() {
	}

	protected DiffDivider.RowConverter createFromRowConverter() {
	}

	protected DiffDivider.RowConverter createToRowConverter() {
	}

	protected DiffDivider.RowConverter createOtherRowConverter() {
	}

	protected void synchronizeViewport(DiffDivider diffDivider, CodeEditor firstEditor, CodeEditor secondEditor, boolean changeFromFirst) {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	@java.lang.Override
	protected void updateActions(int index) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	/**
	 *  Splits the string with the line break.
	 *  <p/>
	 *  This method is no longer being invoked since 3.4.1.
	 * 
	 *  @param string     the string
	 *  @param  lineBreak the line break
	 *  @deprecated replaced by {@link #createLineCharSequence(com.jidesoft.editor.CodeEditor, int)}.
	 */
	@java.lang.Deprecated
	protected String[] splitString(String string, String lineBreak) {
	}

	/**
	 *  Merges to get the conflicts.
	 * 
	 *  @param fromText  the from text
	 *  @param toText    the to text
	 *  @param otherText the other text
	 *  @return the list of conflicts.
	 *  @deprecated replaced by {@link #createMerge()}.
	 */
	@java.lang.Deprecated
	protected java.util.List merge(String fromText, String toText, String otherText) {
	}

	/**
	 *  Creates the merge.
	 *  <p/>
	 *  By default, it returns new Merge<CharSequence>(getFromItems(), getToItems(), getOtherItems()).
	 * 
	 *  @return the Merge instance.
	 *  @since 3.4.1
	 */
	protected Merge createMerge() {
	}

	/**
	 *  Checks if the diff pane is read only. A read only merge pane will not show the buttons to apply changes.
	 * 
	 *  @return true or false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public boolean isReadOnly() {
	}

	/**
	 *  Sets the read only flag. A read only merge pane will not show the buttons to apply changes.
	 * 
	 *  @param readOnly the new read only flag.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setReadOnly(boolean readOnly) {
	}

	protected java.util.List getFromToDifferences(java.util.List conflicts) {
	}

	protected java.util.List getToOtherDifferences(java.util.List conflicts) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public java.util.List getConflicts() {
	}

	protected java.util.List acceptConflict(java.util.List conflicts, Difference c) {
	}

	protected java.util.List ignoreConflict(java.util.List conflicts, Difference c) {
	}

	protected java.util.List acceptDocumentChange(java.util.List conflicts, javax.swing.event.DocumentEvent e) {
	}

	public java.util.List merge() {
	}

	/**
	 *  Clears the merge results.
	 */
	public void clearMerge() {
	}

	public void delete(int line, int numberOfLines, boolean runMergeAfterward) {
	}

	public void insert(CodeEditor codeEditor, int line, int fromLine, int fromNumberOfLines, boolean runMergeAfterward) {
	}

	public void replace(CodeEditor codeEditor, int line, int numberOfLines, int fromLine, int fromNumberOfLines, boolean runMergeAfterward) {
	}

	@java.lang.Override
	protected void firstChange() {
	}

	@java.lang.Override
	protected void previousChange() {
	}

	@java.lang.Override
	protected void nextChange() {
	}

	@java.lang.Override
	protected void lastChange() {
	}

	@java.lang.Override
	public void acceptNonConflicts() {
	}

	/**
	 *  Checks if there is any conflicting changes during the merging process.
	 * 
	 *  @return true or false. If false, it means all the changes are non-conflicts. You could call {@link
	 *          #acceptNonConflicts()} to accept all the changes.
	 */
	public boolean isConflicted() {
	}

	/**
	 *  Gets the flag indicating if the leading and trailing spaces should be ignored when comparing two texts.
	 * 
	 *  @return true if leading and trailing spaces should be ignored. Otherwise false.
	 *  @see #setIgnoreLeadingTrailingSpaces(boolean)
	 *  @since 3.4.1
	 */
	public boolean isIgnoreLeadingTrailingSpaces() {
	}

	/**
	 *  Sets the flag indicating if the leading and trailing spaces should be ignored when comparing two texts.
	 *  <p/>
	 *  By default, the value is false to keep the original behavior.
	 * 
	 *  @param ignoreLeadingTrailingSpaces the flag
	 *  @since 3.4.1
	 */
	public void setIgnoreLeadingTrailingSpaces(boolean ignoreLeadingTrailingSpaces) {
	}
}
