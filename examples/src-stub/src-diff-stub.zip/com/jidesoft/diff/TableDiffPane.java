/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class TableDiffPane extends BasicDiffPane {

	protected DiffTableStyleProvider _fromTableStyleProvider;

	protected DiffTableStyleProvider _toTableStyleProvider;

	public TableDiffPane() {
	}

	/**
	 *  Creates TableDiffPane. The items should two TableModels.
	 * 
	 *  @param items two table models.
	 */
	public TableDiffPane(Object[] items) {
	}

	@java.lang.Override
	public void flip() {
	}

	/**
	 *  Creates the array from the table model.
	 *  <p/>
	 *  Since 3.4.1, the contents of the array are changed. In earlier releases, it was an array of String. Now, it's an
	 *  instance of LazyLoadTableRowData. You could override {@link #getTableRowData(javax.swing.table.TableModel, int)}
	 *  to change the behavior.
	 * 
	 *  @param tableModel the table model
	 *  @return the array for diff
	 */
	protected Object[] createArrayFromTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Creates the table row data.
	 * 
	 *  @param tableModel the table model
	 *  @param rowIndex   the row index
	 *  @return the LazyLoadTableRowData instance by default.
	 *  @since 3.4.1
	 */
	protected Object getTableRowData(javax.swing.table.TableModel tableModel, int rowIndex) {
	}

	@java.lang.Override
	protected void customizePane(javax.swing.JComponent component, int index) {
	}

	@java.lang.Override
	protected void customizePanes(javax.swing.JComponent[] panes) {
	}

	@java.lang.Override
	protected MarkerSupport createMarkerSupport(javax.swing.JComponent component) {
	}

	@java.lang.Override
	protected RowMarginSupport createRowMarginSupport(javax.swing.JComponent component, javax.swing.JScrollPane scrollPane) {
	}

	/**
	 *  Creates a CellStyleTable so that it can use the cell style feature to show the difference highlights.
	 * 
	 *  @param item  the content to be displayed in the component.
	 *  @param index the index of the component.
	 *  @return a CellStyleTable.
	 */
	@java.lang.Override
	public javax.swing.JComponent createComponent(Object item, int index) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	/**
	 *  Gets the from items that is used for Diff to compare the lines.
	 *  <p/>
	 *  If the line difference is to be highlighted, this method is not invoked. Instead, {@link #getFromItems(int, int)} is used.
	 * 
	 *  @return the Object array.
	 *  @see #getFromItems(int, int)
	 */
	@java.lang.Override
	public Object[] getFromItems() {
	}

	/**
	 *  Gets the to items that is used for Diff to compare the lines.
	 *  <p/>
	 *  If the line difference is to be highlighted, this method is not invoked. Instead, {@link #getToItems(int, int)} is used.
	 * 
	 *  @return the Object array.
	 *  @see #getToItems(int, int)
	 */
	@java.lang.Override
	public Object[] getToItems() {
	}

	/**
	 *  Gets the from items for line difference to compare.
	 * 
	 *  @param startRow the start row index
	 *  @param endRow   the end row index
	 *  @return the list of Object for diff.
	 *  @since 3.4.1
	 */
	protected java.util.List getFromItems(int startRow, int endRow) {
	}

	/**
	 *  Gets the to items for line difference to compare.
	 * 
	 *  @param startRow the start row index
	 *  @param endRow   the end row index
	 *  @return the list of Object for diff.
	 *  @since 3.4.1
	 */
	protected java.util.List getToItems(int startRow, int endRow) {
	}

	@java.lang.Override
	protected int getSelectedIndex(int paneIndex) {
	}

	/**
	 *  Creates multiple lines diff.
	 *  <p/>
	 *  The cell value array inside the diff instance is only the values in the related rows. The method
	 *  {@link #highlightChangedExactly(java.util.List, int, int, int, int, java.awt.Color, java.awt.Color, String)} will
	 *  consider the offset and get the correct position
	 * 
	 *  @param fromStartOffset from start offset
	 *  @param fromEndOffset   from end offset
	 *  @param toStartOffset   to start offset
	 *  @param toEndOffset     to end offset
	 *  @return the Diff instance.
	 *  @since 3.4.0
	 */
	@java.lang.Override
	protected Diff createLinesDiff(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset) {
	}

	@java.lang.Override
	public void highlightChangedExactly(java.util.List lineDiff, int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightChanged(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightInserted(int fromStartOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightDeleted(int fromStartOffset, int fromEndOffset, int toStartOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void clearHighlights() {
	}

	@java.lang.Override
	public boolean delete(int toLine, int toNumberOfLines, boolean runDiffAfterward) {
	}

	@java.lang.Override
	public boolean insert(int toLine, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	@java.lang.Override
	public void setChangedColor(java.awt.Color changedColor) {
	}

	@java.lang.Override
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	@java.lang.Override
	public void setDeletedColor(java.awt.Color deletedColor) {
	}
}
