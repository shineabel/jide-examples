/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  The style provider class to display table difference.
 */
public class DiffTableStyleProvider {

	/**
	 *  The shared CELL_STYLE instance in use.
	 */
	protected final CellStyle CELL_STYLE;

	public DiffTableStyleProvider() {
	}

	/**
	 *  Constructor with a diff pane.
	 * 
	 *  @param diffPane the table diff pane it works for.
	 */
	public DiffTableStyleProvider(TableDiffPane diffPane, int index) {
	}

	/**
	 *  Gets the inserted color.
	 * 
	 *  @return the inserted color.
	 *  @see #setInsertedColor(java.awt.Color)
	 */
	public java.awt.Color getInsertedColor() {
	}

	/**
	 *  Sets the inserted color.
	 *  <p/>
	 *  By default, it gets color from UIDefaults with the key "DiffMerge.inserted".
	 * 
	 *  @param insertedColor the inserted color
	 */
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	/**
	 *  Gets the changed color.
	 * 
	 *  @return the changed color.
	 *  @see #setChangedColor(java.awt.Color)
	 */
	public java.awt.Color getChangedColor() {
	}

	/**
	 *  Sets the changed color.
	 *  <p/>
	 *  By default, it gets color from UIDefaults with the key "DiffMerge.changed".
	 * 
	 *  @param changedColor the changed color
	 */
	public void setChangedColor(java.awt.Color changedColor) {
	}

	/**
	 *  Gets the deleted color.
	 * 
	 *  @return the deleted color.
	 *  @see #setDeletedColor(java.awt.Color)
	 */
	public java.awt.Color getDeletedColor() {
	}

	/**
	 *  Sets the deleted color.
	 *  <p/>
	 *  By default, it gets color from UIDefaults with the key "DiffMerge.deleted".
	 * 
	 *  @param deletedColor the deleted color
	 */
	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	/**
	 *  Gets the conflicted color.
	 * 
	 *  @return the conflicted color.
	 *  @see #setConflictedColor(java.awt.Color)
	 */
	public java.awt.Color getConflictedColor() {
	}

	/**
	 *  Sets the deleted color.
	 *  <p/>
	 *  By default, it gets color from UIDefaults with the key "DiffMerge.conflicted".
	 * 
	 *  @param conflictedColor the deleted color
	 */
	public void setConflictedColor(java.awt.Color conflictedColor) {
	}

	@java.lang.Override
	public CellStyle getCellStyleAt(javax.swing.JTable table, int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the cell's style. It should be DiffMarkerArea.TYPE_INSERTED, DiffMarkerArea.TYPE_DELETED, DiffMarkerArea.TYPE_CHANGED
	 *  or DiffMarkerArea.TYPE_CONFLICTED.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @return the cell style of the cell.
	 */
	protected int getCellStyle(int row, int column) {
	}

	@java.lang.Override
	public java.awt.Color getGridColor(int row) {
	}

	@java.lang.Override
	public java.awt.Color getVerticalGridColor(int column) {
	}

	/**
	 *  Clears all highlights.
	 */
	public void clearAllHighlights() {
	}

	/**
	 *  Adds a changed cell highlight.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @since 3.4.0
	 */
	public void addChangedCellHighlight(int row, int column) {
	}

	/**
	 *  Adds a deleted cell highlight.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @since 3.4.0
	 */
	public void addDeletedCellHighlight(int row, int column) {
	}

	/**
	 *  Adds an inserted cell highlight.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @since 3.4.0
	 */
	public void addInsertedCellHighlight(int row, int column) {
	}

	/**
	 *  Adds a conflicted cell highlight.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @since 3.4.0
	 */
	public void addConflictedCellHighlight(int row, int column) {
	}

	/**
	 *  Adds changed rows highlight.
	 * 
	 *  @param start   the start row index
	 *  @param end     the end row index
	 */
	public void addChangedHighlight(int start, int end) {
	}

	/**
	 *  Adds deleted rows highlight.
	 * 
	 *  @param start   the start row index
	 *  @param end     the end row index
	 */
	public void addDeletedHighlight(int start, int end) {
	}

	/**
	 *  Adds inserted rows highlight.
	 * 
	 *  @param start   the start row index
	 *  @param end     the end row index
	 */
	public void addInsertedHighlight(int start, int end) {
	}

	/**
	 *  Adds conflicted rows highlight.
	 * 
	 *  @param start   the start row index
	 *  @param end     the end row index
	 */
	public void addConflictHighlight(int start, int end) {
	}

	/**
	 *  Adds a position highlight.
	 * 
	 *  @param row the row index
	 */
	public void addPositionHighlight(int row) {
	}
}
