/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  This enum makes it possible to be selective about which elements displayed on a chart cast a shadow
 */
public final class ShadowVisibility extends Enum {

	public static final ShadowVisibility NONE;

	public static final ShadowVisibility ALL;

	public static final ShadowVisibility SOME;

	public static ShadowVisibility[] values() {
	}

	public static ShadowVisibility valueOf(String name) {
	}
}
