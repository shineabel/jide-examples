/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A ChartModel that presents a reduced-size version of its delegate by sampling its data. A sampling rate of 10 means
 *  that only one in 10 points of the original data set appear in the points presented by this model. It therefore
 *  represents a 10-fold reduction in size.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class SamplingModel extends AbstractDelegatingChartModel {

	public SamplingModel() {
	}

	public SamplingModel(AnnotatedChartModel delegate) {
	}

	public int getSamplingRate() {
	}

	public void setSamplingRate(int samplingRate) {
	}

	@java.lang.Override
	public int getAnnotationCount() {
	}

	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}

	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	@java.lang.Override
	public int getPointCount() {
	}

	@java.lang.Override
	protected void update() {
	}
}
