/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A basic implementation that performs the identity transformation for any type
 */
public class IdentityTransform implements InvertibleTransform {

	public IdentityTransform() {
	}

	public Object transform(Object x) {
	}

	public Object inverseTransform(Object x) {
	}
}
