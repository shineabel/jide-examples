/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


public class XmlHighlightAdapter extends javax.xml.bind.annotation.adapters.XmlAdapter {

	public XmlHighlightAdapter() {
	}

	@java.lang.Override
	public String marshal(Highlight h) {
	}

	@java.lang.Override
	public Highlight unmarshal(String highlightString) {
	}
}
