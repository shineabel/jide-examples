/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A Transform that also provides an inverse transformation. Applying the transform followed by the inverse transform
 *  should return the original value for all values in the allowable range.
 * 
 *  @author Simon White
 */
public interface InvertibleTransform extends Transform {

	public Object inverseTransform(Object t);
}
