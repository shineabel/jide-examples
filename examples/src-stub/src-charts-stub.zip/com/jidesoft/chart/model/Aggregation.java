/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  An interface that collects together multiple items and presents one item
 *  to represent the multiple values. An example is the mean average of (some property of) a population.
 *  You can also use the same interface to provide median and mode averages, or to sum values or
 *  generate prototypical object instances.
 */
public interface Aggregation {

	public Object aggregate(java.util.List items);
}
