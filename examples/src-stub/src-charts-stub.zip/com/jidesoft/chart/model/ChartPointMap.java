/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


public class ChartPointMap implements Chartable3D, ChartableMap, Highlightable {

	public ChartPointMap() {
	}

	@java.lang.Override
	public Positionable getX() {
	}

	@java.lang.Override
	public Positionable getY() {
	}

	@java.lang.Override
	public Positionable getZ() {
	}

	public void setX(Positionable xPos) {
	}

	public void setY(Positionable yPos) {
	}

	public void setZ(Positionable zPos) {
	}

	@java.lang.Override
	public Highlight getHighlight() {
	}

	@java.lang.Override
	public void setHighlight(Highlight highlight) {
	}

	public void setValue(String name, Positionable pos) {
	}

	public Positionable getValue(String name) {
	}

	@java.lang.Override
	public java.util.Collection getValues() {
	}

	@java.lang.Override
	public int compareTo(Chartable other) {
	}
}
