/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


public interface ChartableMap extends Chartable {

	public void setValue(String name, Positionable pos);

	public Positionable getValue(String name);

	public java.util.Collection getValues();
}
