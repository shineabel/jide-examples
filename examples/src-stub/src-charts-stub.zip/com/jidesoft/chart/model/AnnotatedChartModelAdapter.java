/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A class that accepts a regular ChartModel and exposes the interface of an Annotated ChartModel
 */
public class AnnotatedChartModelAdapter implements AnnotatedChartModel, ChartModelListener {

	public AnnotatedChartModelAdapter(ChartModel delegate) {
	}

	public ChartModel getDelegate() {
	}

	public void setDelegate(ChartModel newDelegate) {
	}

	public void addChartModelListener(ChartModelListener listener) {
	}

	public void removeChartModelListener(ChartModelListener listener) {
	}

	protected void fireModelChanged() {
	}

	public void chartModelChanged() {
	}

	public void update() {
	}

	public String getName() {
	}

	public Chartable getPoint(int n) {
	}

	public int getPointCount() {
	}

	public boolean isCyclical() {
	}

	public java.util.Iterator iterator() {
	}

	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public int getAnnotationCount() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}
}
