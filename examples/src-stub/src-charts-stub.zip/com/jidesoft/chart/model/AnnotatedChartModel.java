/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A ChartModel that can be annotated
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface AnnotatedChartModel extends ChartModel, AnnotationModel {
}
