/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A ChartCategory is an extension of a Category that allows you to set a highlight.
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartCategory extends <any> implements com.jidesoft.chart.util.Named {

	public ChartCategory(Object value) {
	}

	public ChartCategory(String name, Object value) {
	}

	public ChartCategory(String name, Object value, Highlight highlight) {
	}

	public ChartCategory(Object value, Highlight highlight) {
	}

	public ChartCategory(Object value, <any> range) {
	}

	public ChartCategory(Object value, <any> range, Highlight highlight) {
	}

	public Highlight getHighlight() {
	}

	public void setHighlight(Highlight highlight) {
	}

	@java.lang.Override
	public String toString() {
	}
}
