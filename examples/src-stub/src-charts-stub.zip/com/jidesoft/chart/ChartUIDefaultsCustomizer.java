/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Class to initialise UIDefaults values used by the Charts package
 */
public class ChartUIDefaultsCustomizer {

	public ChartUIDefaultsCustomizer() {
	}

	public void customize(javax.swing.UIDefaults defaults) {
	}
}
