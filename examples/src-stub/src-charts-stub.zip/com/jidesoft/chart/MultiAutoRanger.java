/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public interface MultiAutoRanger extends AutoRanger {

	public java.util.Map getAxisRanges(Chart chart);
}
