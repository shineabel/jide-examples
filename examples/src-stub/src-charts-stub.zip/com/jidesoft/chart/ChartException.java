/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A general exception that may be thrown when a problem arises in the charting package or related to charting
 *  @see ChartBoundsException
 */
public class ChartException extends Exception {

	public ChartException() {
	}

	public ChartException(String message) {
	}

	public ChartException(Throwable throwable) {
	}

	public ChartException(String message, Throwable throwable) {
	}
}
