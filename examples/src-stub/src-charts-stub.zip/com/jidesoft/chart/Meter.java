/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A graphical meter dial
 * 
 *  @author Simon
 */
@java.lang.SuppressWarnings("serial")
public class Meter extends javax.swing.JComponent {

	public Meter() {
	}

	/**
	 *  @return the current value of the gauge
	 */
	public double getValue() {
	}

	/**
	 *  Set the value of the gauge
	 * 
	 *  @param value the new value
	 */
	public void setValue(double value) {
	}

	/**
	 *  @return the color of the needle on the gauge
	 */
	public java.awt.Color getNeedleColor() {
	}

	/**
	 *  Set the color of the needle on the gauge
	 * 
	 *  @param needleColor the new color
	 */
	public void setNeedleColor(java.awt.Color needleColor) {
	}

	/**
	 *  @return the base color of the face of the display
	 */
	public java.awt.Color getFaceColor() {
	}

	/**
	 *  Sets the base color of the face of the display
	 * 
	 *  @param faceColor the new color of the display
	 */
	public void setFaceColor(java.awt.Color faceColor) {
	}

	/**
	 *  @return the color of the ticks
	 */
	public java.awt.Color getTickColor() {
	}

	/**
	 *  Sets the color of the ticks (value markers) in the display
	 * 
	 *  @param tickColor the new color of the ticks in the display
	 */
	public void setTickColor(java.awt.Color tickColor) {
	}

	/**
	 *  The main method for painting the display
	 */
	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}
}
