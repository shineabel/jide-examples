/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public class PointLegendItem extends javax.swing.JComponent implements LegendItem {

	public PointLegendItem(model.Chartable chartable, model.ChartModel model, Chart chart) {
	}

	public PointLegendItem.LabelSource getLabelSource() {
	}

	public void setLabelSource(PointLegendItem.LabelSource labelSource) {
	}

	public String getLabel() {
	}

	public model.Chartable getChartable() {
	}

	public void setChartable(model.Chartable chartable) {
	}

	public model.ChartModel getModel() {
	}

	public void setModel(model.ChartModel model) {
	}

	public java.awt.Component getComponent() {
	}

	public model.Chartable getItem() {
	}

	public model.ChartModel getSource() {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	public static final class LabelSource {


		public static final PointLegendItem.LabelSource X_POS;

		public static final PointLegendItem.LabelSource Y_POS;

		public static final PointLegendItem.LabelSource NAME;

		public static PointLegendItem.LabelSource[] values() {
		}

		public static PointLegendItem.LabelSource valueOf(String name) {
		}
	}
}
