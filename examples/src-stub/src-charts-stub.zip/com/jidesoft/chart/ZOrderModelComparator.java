/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public class ZOrderModelComparator implements java.util.Comparator {

	public ZOrderModelComparator(Chart chart) {
	}

	public int compare(model.ChartModel model1, model.ChartModel model2) {
	}
}
