/**
 *  The package contains classes supporting filtering data in JIDE Charts product.
 */
package com.jidesoft.chart.filter;


/**
 *  A class that enables you to create one or more filters on chartable points. For example, only display points in the
 *  region p &lt;= x &lt;= q is an AxisFilter on x
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class AxisFilter implements com.jidesoft.chart.util.Filter {

	public AxisFilter() {
	}

	public AxisFilter(com.jidesoft.chart.Orientation orientation) {
	}

	public AxisFilter(double min, double max) {
	}

	public AxisFilter(com.jidesoft.chart.Orientation orientation, double min, double max) {
	}

	public Double getMin() {
	}

	public void setMin(Double min) {
	}

	public Double getMax() {
	}

	public void setMax(Double max) {
	}

	public com.jidesoft.chart.Orientation getOrientation() {
	}

	public void setOrientation(com.jidesoft.chart.Orientation orientation) {
	}

	public boolean isValueFiltered(com.jidesoft.chart.model.Chartable p) {
	}

	@java.lang.Override
	public String toString() {
	}
}
