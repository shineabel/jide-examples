/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  This exception may be thrown when a value is outside of the expected range.
 *  For numeric ranges the value would be less than the minimum allowed value; for other ranges the meaning
 *  is the same with an appropriately understood meaning of 'less than'.
 *  @see ChartBoundsException
 */
public class BelowBoundsException extends ChartBoundsException {

	/**
	 *  Zero-args constructor
	 */
	public BelowBoundsException() {
	}

	public BelowBoundsException(double newBound) {
	}

	/**
	 *  @param message the detail message
	 *  @param throwable the cause
	 */
	public BelowBoundsException(double newBound, String message, Throwable throwable) {
	}

	/**
	 *  @param message the detail message
	 */
	public BelowBoundsException(double newBound, String message) {
	}

	/**
	 *  @param throwable the cause of the Exception
	 */
	public BelowBoundsException(double newBound, Throwable throwable) {
	}

	public double getBound() {
	}

	public void setBound(double bound) {
	}
}
