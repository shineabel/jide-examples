package com.jidesoft.chart.xml;


public class XmlFontAdapter extends javax.xml.bind.annotation.adapters.XmlAdapter {

	public XmlFontAdapter() {
	}

	@java.lang.Override
	public String marshal(java.awt.Font font) {
	}

	@java.lang.Override
	public java.awt.Font unmarshal(String fontString) {
	}
}
