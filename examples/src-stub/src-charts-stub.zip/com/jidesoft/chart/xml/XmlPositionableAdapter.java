package com.jidesoft.chart.xml;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 24/04/11 at 23:32
 */
public class XmlPositionableAdapter extends javax.xml.bind.annotation.adapters.XmlAdapter {

	public XmlPositionableAdapter() {
	}

	@java.lang.Override
	public String marshal(Positionable v) {
	}

	@java.lang.Override
	public Positionable unmarshal(String v) {
	}
}
