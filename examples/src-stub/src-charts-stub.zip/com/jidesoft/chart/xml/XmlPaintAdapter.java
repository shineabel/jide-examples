package com.jidesoft.chart.xml;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 09-Sep-2010
 *  A Color can be provided either as an RGB value or an RGBA value,
 *  as for example 'rgb(128,128,128)' which is a mid-grey, or 'rgba(255,0,0,128)',
 *  which is a translucent red.
 */
public class XmlPaintAdapter extends javax.xml.bind.annotation.adapters.XmlAdapter {

	public XmlPaintAdapter() {
	}

	@java.lang.Override
	public String marshal(java.awt.Paint paint) {
	}

	@java.lang.Override
	public java.awt.Paint unmarshal(String paintString) {
	}
}
