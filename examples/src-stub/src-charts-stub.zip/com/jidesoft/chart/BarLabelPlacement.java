/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public final class BarLabelPlacement extends Enum {

	public static final BarLabelPlacement START;

	public static final BarLabelPlacement BAR_CENTER;

	public static final BarLabelPlacement CENTER;

	public static final BarLabelPlacement BEFORE_BAR_END;

	public static final BarLabelPlacement AFTER_BAR_END;

	public static final BarLabelPlacement END;

	public static BarLabelPlacement[] values() {
	}

	public static BarLabelPlacement valueOf(String name) {
	}
}
