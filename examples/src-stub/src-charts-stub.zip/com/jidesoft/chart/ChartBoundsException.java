/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  An exception that may be thrown when a value is outside of the expected range of values
 * 
 *  @see AboveBoundsException
 *  @see BelowBoundsException
 */
public class ChartBoundsException extends ChartException {

	public ChartBoundsException() {
	}

	public ChartBoundsException(String message) {
	}

	public ChartBoundsException(Throwable throwable) {
	}

	public ChartBoundsException(String message, Throwable throwable) {
	}
}
