/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  An abstract superclass for point filters. The interface is the same as the old RGBImageFilter.
 */
public abstract class PointFilter extends AbstractBufferedImageOp {

	protected boolean canFilterIndexColorModel;

	public PointFilter() {
	}

	public java.awt.image.BufferedImage filter(java.awt.image.BufferedImage src, java.awt.image.BufferedImage dst) {
	}

	public void setDimensions(int width, int height) {
	}

	public abstract int filterRGB(int x, int y, int rgb) {
	}
}
