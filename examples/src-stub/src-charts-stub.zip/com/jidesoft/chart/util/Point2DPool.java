/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  A Pool class that makes it possible to reuse instances of Point2D.Double.
 *  This specialized solution avoid the problems of additional object creation due to autoboxing in a more generic solution.
 */
public class Point2DPool {

	protected java.awt.geom.Point2D create(double x, double y) {
	}

	public java.awt.geom.Point2D borrow(double x, double y) {
	}

	public void replace(java.awt.geom.Point2D p) {
	}

	/**
	 *  Removes any available objects from the pool.
	 *  You probably don't need to call this, as the intention of pooling is to leave objects
	 *  in the pool so that they can be reused.
	 */
	public void clear() {
	}

	public static Point2DPool instance() {
	}
}
