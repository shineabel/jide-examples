/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  An interface for objects that can be named
 */
public interface Nameable extends Named {

	/**
	 *  Specify the name of the object
	 *  @param name the name of the object
	 */
	public void setName(String name);
}
