/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  An interface for objects whose name can be retrieved
 */
public interface Named {

	/**
	 *  Retrieves the name of the object
	 *  @return the name of the object
	 */
	public String getName();
}
