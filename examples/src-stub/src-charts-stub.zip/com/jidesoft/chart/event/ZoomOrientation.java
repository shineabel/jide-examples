/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  Indicates whether a zoom is for just one axis or two axes.
 *  
 *  @see MouseWheelZoomer
 */
public final class ZoomOrientation extends Enum {

	/**
	 *  Zoom in the horizontal direction only
	 */
	public static final ZoomOrientation HORIZONTAL;

	/**
	 *  Zoom in the vertical direction only
	 */
	public static final ZoomOrientation VERTICAL;

	/**
	 *  Zoom in both the horizontal and vertical directions
	 */
	public static final ZoomOrientation BOTH;

	public static ZoomOrientation[] values() {
	}

	public static ZoomOrientation valueOf(String name) {
	}
}
