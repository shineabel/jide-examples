/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


public interface ImageChangeListener {

	public void imageChanged(ImageChangeEvent event);
}
