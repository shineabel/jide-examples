/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  An interface implemented by objects interested in zooming behaviour.
 */
public interface ZoomListener {

	/**
	 *  The callback method on the listening object that is invoked when the user zooms in or out of a chart.
	 *  @param event the event
	 */
	public void zoomChanged(ChartSelectionEvent event);
}
