/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 22/04/11 at 16:23
 */
public class ImageChangeEvent extends java.util.EventObject {

	public ImageChangeEvent(Object source) {
	}
}
