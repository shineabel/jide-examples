/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Provides predefined shapes for points
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public final class PointShape extends Enum {

	public static final PointShape CIRCLE;

	public static final PointShape DISC;

	public static final PointShape SQUARE;

	public static final PointShape BOX;

	public static final PointShape DIAMOND;

	public static final PointShape DOWN_TRIANGLE;

	public static final PointShape UP_TRIANGLE;

	public static final PointShape HORIZONTAL_LINE;

	public static final PointShape VERTICAL_LINE;

	public static final PointShape UPRIGHT_CROSS;

	public static final PointShape DIAGONAL_CROSS;

	public static PointShape[] values() {
	}

	public static PointShape valueOf(String name) {
	}

	public java.awt.Shape paint(java.awt.Graphics g, double x, double y, double pointSize, java.awt.Paint fill, boolean withOutline, java.awt.Color outlineColor, float outlineWidth) {
	}

	/**
	 *  A modified version of valueOf() that is case insensitive and trims the input string of any leading or trailing white space
	 *  @param str the name of the shape
	 *  @return the PointShape enum instance
	 */
	public static PointShape fromString(String str) {
	}
}
