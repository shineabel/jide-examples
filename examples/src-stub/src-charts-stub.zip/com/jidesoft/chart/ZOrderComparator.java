/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public class ZOrderComparator implements java.util.Comparator {

	public ZOrderComparator() {
	}

	@java.lang.Override
	public int compare(Object o1, Object o2) {
	}
}
