/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


public final class LineFillExtent extends Enum {

	public static final LineFillExtent TO_ZERO;

	public static final LineFillExtent TO_LEADING_EDGE;

	public static final LineFillExtent TO_TRAILING_EDGE;

	public static LineFillExtent[] values() {
	}

	public static LineFillExtent valueOf(String name) {
	}
}
