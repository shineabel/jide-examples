/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


public final class ZAlignment extends Enum {

	public static final ZAlignment FRONT;

	public static final ZAlignment CENTER;

	public static final ZAlignment BACK;

	public static ZAlignment[] values() {
	}

	public static ZAlignment valueOf(String name) {
	}
}
