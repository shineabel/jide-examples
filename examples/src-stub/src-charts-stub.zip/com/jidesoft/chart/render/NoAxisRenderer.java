/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A class that implements the IAxisRenderer interface but does not render an axis
 */
public class NoAxisRenderer implements AxisRenderer {

	public NoAxisRenderer() {
	}

	/**
	 *  Do nothing as this is the no axis renderer, so it doesn't render anything
	 */
	public void renderAxis(java.awt.Graphics g, int x, int y, int length, com.jidesoft.chart.Orientation orientation) {
	}

	public int getBreadth() {
	}

	public void setBreadth(int breadth) {
	}
}
