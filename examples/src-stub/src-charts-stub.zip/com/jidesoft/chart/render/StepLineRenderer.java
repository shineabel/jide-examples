/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A renderer for drawing stepped lines on a chart. Consecutive points in the ChartModel are joined by
 *  straight line segments.
 */
public class StepLineRenderer extends AbstractLineRenderer {

	public static final String PROPERTY_CHART = "Chart";

	/**
	 *  Creates a DefaultLineRenderer using the supplied chart object as the chart object onto which
	 *  lines should be drawn.
	 *  @param chart the chart object
	 */
	public StepLineRenderer(com.jidesoft.chart.Chart chart) {
	}

	/**
	 *  Returns the chart associated with this renderer
	 *  @return the chart object associated with this renderer
	 */
	public com.jidesoft.chart.Chart getChart() {
	}

	/**
	 *  Sets the chart onto which the lines should be drawn
	 *  @param chart the Chart object
	 */
	public void setChart(com.jidesoft.chart.Chart chart) {
	}

	/**
	 *  Adds a property change listener to this object
	 *  @param listener a property change listener
	 */
	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Remove the supplied property change listener from this object
	 *  @param listener the property change listener to remove
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.SuppressWarnings("cast")
	public java.awt.Shape renderLine(java.awt.Graphics g, com.jidesoft.chart.model.ChartModel m, int[] xPoints, int[] yPoints, com.jidesoft.chart.style.ChartStyle style) {
	}
}
