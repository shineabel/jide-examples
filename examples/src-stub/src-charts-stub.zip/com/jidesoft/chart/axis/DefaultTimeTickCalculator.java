/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  A default implementation of a tick calculator for time-based axes.
 *  Note that if you want to use a specific time zone for your display, you have two options:
 *  either call setTimeZone() if you want to use the default date formats, or use setDateFormat()
 *  if you want to specify the date format yourself and set the TimeZone on the DateFormat object.
 */
public class DefaultTimeTickCalculator extends AbstractTimeTickCalculator {

	public DefaultTimeTickCalculator() {
	}

	@java.lang.Override
	public Tick[] calculateTicks(<any> r) {
	}

	public static java.util.Calendar min(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double yearsDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double weeksDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double daysDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double hoursDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double minutesDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static double secondsDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}

	public static long millisDiff(java.util.Calendar c1, java.util.Calendar c2) {
	}
}
