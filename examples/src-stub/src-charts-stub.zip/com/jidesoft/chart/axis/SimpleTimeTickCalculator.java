/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  SimpleTimeTickCalculator provides an easy way of generating ticks on a time axis
 *  by specifying the Calendar.FIELD value (and an optional increment) that should
 *  separate two adjacent ticks.
 * 
 *  <p><b>Note:</b> This class is in Beta status - let us know if you discover any problems</p>
 */
public class SimpleTimeTickCalculator extends AbstractTimeTickCalculator {

	public SimpleTimeTickCalculator(int field) {
	}

	public SimpleTimeTickCalculator(int field, int increment) {
	}

	protected java.text.DateFormat createDateFormat(int field) {
	}

	@java.lang.Override
	public Tick[] calculateTicks(<any> r) {
	}
}
