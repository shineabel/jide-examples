/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  An abstract super class that makes it easier to create a custom time tick calculator.
 */
public abstract class AbstractTimeTickCalculator implements TimeTickCalculator {

	public static final String PROPERTY_TIME_ZONE = "Time Zone";

	public AbstractTimeTickCalculator() {
	}

	public java.text.DateFormat getDateFormat() {
	}

	public void setDateFormat(java.text.DateFormat dateFormat) {
	}

	public java.util.TimeZone getTimeZone() {
	}

	public void setTimeZone(java.util.TimeZone timeZone) {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public abstract Tick[] calculateTicks(<any> r) {
	}
}
