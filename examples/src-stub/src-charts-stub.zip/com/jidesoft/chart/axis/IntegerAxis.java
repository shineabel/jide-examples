/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  A NumericAxis that, by default, generates ticks for Integer values only.
 */
public class IntegerAxis extends NumericAxis {

	public IntegerAxis() {
	}

	public IntegerAxis(com.jidesoft.chart.annotation.AutoPositionedLabel label) {
	}

	public IntegerAxis(int min, int max) {
	}

	public IntegerAxis(int min, int max, String text) {
	}

	public IntegerAxis(<any> range) {
	}

	public IntegerAxis(<any> range, String text) {
	}
}
