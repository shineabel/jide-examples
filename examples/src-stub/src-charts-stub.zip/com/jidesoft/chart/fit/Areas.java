/**
 *  Contains classes to support interpolation of chart models, either for aesthetics or for better approximations of functions.
 */
package com.jidesoft.chart.fit;


/**
 *  This class provides methods for computing the area under a curve (but assumes the points
 *  of the curves are joined by straight line segments)
 */
public class Areas {

	public Areas() {
	}

	public static double areaUnder(com.jidesoft.chart.model.ChartModel model) {
	}

	public static double areaUnder(com.jidesoft.chart.model.ChartModel model, double from, double to) {
	}
}
