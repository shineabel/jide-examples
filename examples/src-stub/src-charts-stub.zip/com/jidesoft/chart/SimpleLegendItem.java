/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public class SimpleLegendItem extends javax.swing.JComponent implements LegendItem {

	public SimpleLegendItem(PointShape shape, java.awt.Paint fill, String label) {
	}

	public PointShape getShape() {
	}

	public void setShape(PointShape shape) {
	}

	public java.awt.Paint getFill() {
	}

	public void setFill(java.awt.Paint fill) {
	}

	public java.awt.Component getComponent() {
	}

	public String getLabel() {
	}

	public void setLabel(String label) {
	}

	public Object getItem() {
	}

	public Object getSource() {
	}

	public java.awt.Color getOutlineColor() {
	}

	public void setOutlineColor(java.awt.Color outlineColor) {
	}

	public int getOutlineWidth() {
	}

	public void setOutlineWidth(int outlineWidth) {
	}

	public void paintComponent(java.awt.Graphics g) {
	}
}
