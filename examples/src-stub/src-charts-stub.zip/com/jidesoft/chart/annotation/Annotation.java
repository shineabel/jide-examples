/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


/**
 *  This interface is used as a semantic tag
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface Annotation {
}
