/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


/**
 *  An enum for the most common angles of rotation
 * 
 *  @deprecated Please use the enum at com.jidesoft.chart.util.Rotation instead
 */
public final class Rotation extends Enum {

	public static final Rotation NONE;

	public static final Rotation QUARTER_CLOCKWISE;

	public static final Rotation HALF;

	public static final Rotation QUARTER_ANTICLOCKWISE;

	public static Rotation[] values() {
	}

	public static Rotation valueOf(String name) {
	}

	/**
	 *  Converts the convenient symbolic values into doubles in radians
	 * 
	 *  @return the angle in radians for the rotation represented by this instance
	 */
	public double doubleValue() {
	}
}
