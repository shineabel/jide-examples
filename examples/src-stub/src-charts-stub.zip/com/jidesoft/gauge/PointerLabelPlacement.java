/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2012 All Rights Reserved
 *  Created: 19/08/2012 at 21:15
 */
public final class PointerLabelPlacement extends Enum {

	public static final PointerLabelPlacement ABOVE;

	public static final PointerLabelPlacement BELOW;

	public static final PointerLabelPlacement LEFT;

	public static final PointerLabelPlacement RIGHT;

	public static PointerLabelPlacement[] values() {
	}

	public static PointerLabelPlacement valueOf(String name) {
	}
}
