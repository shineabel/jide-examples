/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class NeedleLegendItem extends javax.swing.JComponent implements com.jidesoft.chart.LegendItem {

	public NeedleLegendItem(Dial dial, String needleName) {
	}

	public java.awt.Component getComponent() {
	}

	public String getLabel() {
	}

	public Positionable getItem() {
	}

	public GaugeModel getSource() {
	}

	public void paintComponent(java.awt.Graphics g) {
	}
}
