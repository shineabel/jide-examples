/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A class for specifying the appearance of a tick displayed on a Dial
 *  This class will be removed some time after JIDE release 3.4.5
 *  @deprecated Please use DialTickStyle for styling of Dial Ticks.
 */
public class GaugeTickStyle extends DialTickStyle {

	public GaugeTickStyle() {
	}

	/**
	 *  Create a tick style instance by specifying the tick length.
	 *  Tick lengths are provided as a proportion of the width of the axis.
	 *  @param tickLength the length of the ticks
	 */
	public GaugeTickStyle(double tickLength) {
	}
}
