/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  Contains information about the presentation of the needle
 */
public class NeedleStyle {

	public NeedleStyle() {
	}

	public java.awt.Color getOutlineColor() {
	}

	public void setOutlineColor(java.awt.Color outlineColor) {
	}

	public java.awt.BasicStroke getOutlineStroke() {
	}

	public void setOutlineStroke(java.awt.BasicStroke outlineStroke) {
	}

	public void setFillPaint(java.awt.Paint paint) {
	}

	public java.awt.Paint getFillPaint() {
	}

	/**
	 *  Returns the length of the head of the needle
	 *  @return the length of the head of the needle
	 */
	public double getHeadLength() {
	}

	/**
	 *  Specify the length of the head of the needle, as a proportion of the radius
	 *  @param headLength the length of the head of the needle
	 */
	public void setHeadLength(double headLength) {
	}

	/**
	 *  Returns the width of the head of the needle
	 *  @return the width of the head of the needle
	 */
	public double getHeadWidth() {
	}

	/**
	 *  Specify the width of the head of the needle, as a proportion of the radius
	 *  @param headWidth the width of the head of the needle
	 */
	public void setHeadWidth(double headWidth) {
	}

	/**
	 *  Returns the length of the tail of the needle
	 *  @return the length of the tail of the needle
	 */
	public double getTailLength() {
	}

	/**
	 *  Specify the length of the tail of the needle, as a proportion of the radius
	 *  @param tailLength the length of the tail of the needle
	 */
	public void setTailLength(double tailLength) {
	}

	/**
	 *  Returns the width of the tail of the needle
	 *  @return the width of the tail of the needle
	 */
	public double getTailWidth() {
	}

	/**
	 *  Specify the width of the tail of the needle
	 *  @param tailWidth the width of the tail of the needle
	 */
	public void setTailWidth(double tailWidth) {
	}

	/**
	 *  Returns the width of the base of the needle, as a proportion of the radius
	 *  @return the width of the base of the needle
	 */
	public double getBaseWidth() {
	}

	/**
	 *  Specify the width of the base of the needle
	 *  @param baseWidth the width of the base of the needle
	 */
	public void setBaseWidth(double baseWidth) {
	}

	/**
	 *  Returns the shape of the head of the needle
	 *  @return the shape of the head of the needle
	 */
	public NeedleEndShape getHeadShape() {
	}

	/**
	 *  Specify the shape of the head of the needle
	 *  @param headShape the shape of the head of the needle
	 */
	public void setHeadShape(NeedleEndShape headShape) {
	}

	/**
	 *  Returns the shape of the tail of the needle
	 *  @return the shape of the tail of the needle
	 */
	public NeedleEndShape getTailShape() {
	}

	/**
	 *  Specify the shape of the tail of the needle
	 *  @param tailShape the shape of the tail of the needle
	 */
	public void setTailShape(NeedleEndShape tailShape) {
	}

	/**
	 *  Returns a boolean to indicate whether the needle is visible.
	 */
	public boolean isVisible() {
	}

	/**
	 *  Specify whether the needle should be visible; true by default.
	 *  This is useful because you can make a needle temporarily invisible without removing it from the dial.
	 *  @param visible whether the needle should be visible
	 */
	public void setVisible(boolean visible) {
	}
}
