/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A kind of border for a Dial, except that a frame can have a Paint as a fill and
 *  can itself be surrounded by a line border.
 * 
 *  @see Dial#setFrame
 */
public class DialFrame {

	public DialFrame() {
	}

	/**
	 *  Returns the current fill used for the frame
	 *  @return the current fill used for the frame
	 */
	public java.awt.Paint getFill() {
	}

	/**
	 *  Specify the fill for the frame. You can use a solid color or a gradient paint (or even a TexturePaint...)
	 *  @param fill the fill (paint) to use for the frame
	 */
	public void setFill(java.awt.Paint fill) {
	}

	/**
	 *  Return the width of the frame as a proportion of the radius
	 *  @return the width of the frame as a proportion of the radius
	 */
	public double getFrameWidth() {
	}

	/**
	 *  Specify the frame width in terms of the radius of the dial
	 *  @param frameWidth the width of the frame specified as a proportion of the radius
	 */
	public void setFrameWidth(double frameWidth) {
	}

	/**
	 *  Returns the color of the inner border of the frame
	 *  @return the color of the inner border of the frame
	 */
	public java.awt.Color getInnerBorderColor() {
	}

	/**
	 *  Specify the color of the inner border of the frame
	 *  @param innerBorderColor the color of the inner border of the frame
	 */
	public void setInnerBorderColor(java.awt.Color innerBorderColor) {
	}

	/**
	 *  Returns the width of the inner border in pixels
	 *  @return the width of the inner border in pixels
	 */
	public int getInnerBorderWidth() {
	}

	/**
	 *  Specify the width of the inner border in pixels
	 *  @param innerBorderWidth the width of the inner border in pixels
	 */
	public void setInnerBorderWidth(int innerBorderWidth) {
	}

	/**
	 *  Returns the Color of the outer border of the frame
	 *  @return the Color of the outer border of the frame
	 */
	public java.awt.Color getOuterBorderColor() {
	}

	/**
	 *  Specify the Color of the outer border of the frame
	 *  @param outerBorderColor the outer border Color of the frame
	 */
	public void setOuterBorderColor(java.awt.Color outerBorderColor) {
	}

	/**
	 *  Returns the width of the outer border in pixels
	 *  @return the width of the outer border in pixels
	 */
	public int getOuterBorderWidth() {
	}

	/**
	 *  Specify the width of the outer border in pixels
	 *  @param outerBorderWidth the width of the outer border in pixels
	 */
	public void setOuterBorderWidth(int outerBorderWidth) {
	}

	/**
	 *  Returns the closest that the frame may pass the pivot point specified as a proportion of the dial radius
	 *  @return the closest that the frame may pass the pivot point specified as a proportion of the dial radius
	 */
	public double getMidChordRadius() {
	}

	/**
	 *  Specify the closest that the frame may pass the pivot point specified as a proportion of the dial radius
	 *  @param midChordRadius the closes that the frame may pass to the dial pivot point
	 */
	public void setMidChordRadius(double midChordRadius) {
	}

	/**
	 *  Returns the extra angle of curvature added to the main arc making up the frame. Set this to something like 10
	 *  degrees if you don't like sharp edges.
	 *  @return the extra angle of curvature added to the main arc making up the frame
	 */
	public double getArcEndAngle() {
	}

	/**
	 *  The extra angle of curvature added to the main arc making up the frame. Set this to something like 10
	 *  degrees if you don't like sharp edges.
	 *  @param arcEndAngle the extra angle of curvature at the end of the main frame arcs.
	 */
	public void setArcEndAngle(double arcEndAngle) {
	}
}
