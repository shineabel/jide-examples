/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class DialIntervalMarkerLegendItem extends javax.swing.JComponent implements com.jidesoft.chart.LegendItem {

	public DialIntervalMarkerLegendItem(DialIntervalMarker intervalMarker, String intervalName) {
	}

	public DialIntervalMarker getIntervalMarker() {
	}

	public void setIntervalMarker(DialIntervalMarker intervalMarker) {
	}

	public java.awt.Component getComponent() {
	}

	public String getLabel() {
	}

	public Positionable getItem() {
	}

	public GaugeModel getSource() {
	}

	protected java.awt.Paint createFill() {
	}

	public void paintComponent(java.awt.Graphics g) {
	}
}
