/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  The usual renderer for a needle. By recognising a NeedleStyle, this class is already quite configurable, so you
 *  should not normally need to define a custom renderer.
 */
public class DefaultNeedleRenderer implements NeedleRenderer {

	public DefaultNeedleRenderer() {
	}

	public ShadowRenderer getShadowRenderer() {
	}

	public void setShadowRenderer(ShadowRenderer shadowRenderer) {
	}

	/**
	 *  Paints the pointer in the centre of the display
	 * 
	 *  @param g2d    the graphics context into which we should paint
	 *  @param x      the x coordinate of the centre of the dial
	 *  @param y      the y coordinate of the centre of the dial
	 *  @param angle  the angle at which to draw the pointer in degrees
	 *  @param radius the radius of the dial
	 */
	public java.awt.Shape paintNeedle(java.awt.Graphics2D g2d, AbstractGauge m, Double value, double x, double y, double angle, double radius, NeedleStyle style) {
	}
}
