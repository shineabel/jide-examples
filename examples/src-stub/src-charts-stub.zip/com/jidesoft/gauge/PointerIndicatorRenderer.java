/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class PointerIndicatorRenderer extends AbstractIndicatorRenderer {

	public PointerIndicatorRenderer() {
	}

	public PointerIndicatorRenderer(PointerIndicatorPlacement placement) {
	}

	/**
	 *  Returns the breadth of the pointer as a proportion of the breadth of the bullet
	 *  @return the breadth of the pointer as a proportion of the breadth of the bullet
	 */
	public double getPointerBreadth() {
	}

	/**
	 *  Sets the breadth of the pointer as a proportion of the breadth of the bullet
	 *  @param pointerBreadth the breadth of the pointer as a proportion of the breadth of the bullet
	 */
	public void setPointerBreadth(double pointerBreadth) {
	}

	/**
	 *  Returns the length of the pointer as a proportion of the breadth of the bullet
	 *  @return the length of the pointer as a proportion of the breadth of the bullet
	 */
	public double getPointerLength() {
	}

	/**
	 *  Sets the length of the pointer as a proportion of the breadth of the bullet
	 *  @param pointerLength the length of the pointer (default value is 0.15)
	 */
	public void setPointerLength(double pointerLength) {
	}

	/**
	 *  Returns the placement of the pointer
	 *  @return the placement of the pointer
	 *  @deprecated in favour of more flexible property getPointerPlacement()
	 *  @see #getPointerPlacement()
	 */
	public BulletAxisPlacement getAxisPlacement() {
	}

	/**
	 *  Specify the placement of the pointer
	 *  @param axisPlacement where to place the pointer
	 *  @deprecated in favour of setPointerPlacement()
	 *  @see #setPointerPlacement(PointerIndicatorPlacement)
	 */
	public void setAxisPlacement(BulletAxisPlacement axisPlacement) {
	}

	/**
	 *  Returns the placement position of the pointer within the Bullet
	 *  @return the placement of the pointer within the Bullet
	 */
	public PointerIndicatorPlacement getPointerPlacement() {
	}

	/**
	 *  Specify the placement position of the pointer within the Bullet
	 *  @param pointerPlacement where to place the pointer
	 */
	public void setPointerPlacement(PointerIndicatorPlacement pointerPlacement) {
	}

	public PointerLabelPlacement getLabelPlacement() {
	}

	public void setLabelPlacement(PointerLabelPlacement labelPlacement) {
	}

	@java.lang.Override
	protected java.awt.Shape calculateShape(Bullet bullet, Double value) {
	}

	protected java.awt.Shape calculateShape(com.jidesoft.chart.Orientation orientation, double pixelValue, double[] positions) {
	}

	protected void drawIndicator(java.awt.Graphics2D g, Bullet bullet, java.awt.Shape shape, IndicatorStyle style) {
	}

	protected void drawIndicator(java.awt.Graphics2D g, double bulletPixelBreadth, java.awt.Shape shape, IndicatorStyle style) {
	}

	@java.lang.Override
	public void paintLabel(java.awt.Graphics2D g2d, Bullet bullet, Double value, IndicatorStyle style) {
	}

	@java.lang.Override
	public java.awt.Shape paintLegendItem(java.awt.Graphics g, Bullet bullet, IndicatorStyle style, int w, int h) {
	}
}
