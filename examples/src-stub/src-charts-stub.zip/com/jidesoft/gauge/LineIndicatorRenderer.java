/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A marker class for a specific value along a Bullet.
 */
public class LineIndicatorRenderer extends AbstractIndicatorRenderer {

	public LineIndicatorRenderer() {
	}

	/**
	 *  Returns the value that determines how much of the breadth of the bullet is covered by this marker
	 *  @return a value between 0 and 1
	 */
	public double getBreadth() {
	}

	/**
	 *  Specify how much of the breadth of the bullet should be taken up by this marker. By default this is 0.75
	 *  @param breadth a value between 0 and 1 (inclusive) (default 0.75)
	 */
	public void setBreadth(double breadth) {
	}

	public double getLength() {
	}

	public void setLength(double length) {
	}

	public javax.swing.border.Border getBorder() {
	}

	public void setBorder(javax.swing.border.Border border) {
	}

	public LineLabelPlacement getLabelPlacement() {
	}

	public void setLabelPlacement(LineLabelPlacement labelPlacement) {
	}

	public double getLinePosition() {
	}

	public void setLinePosition(double linePosition) {
	}

	@java.lang.Override
	protected java.awt.Shape calculateShape(Bullet bullet, Double value) {
	}

	protected void drawIndicator(java.awt.Graphics2D g, Bullet bullet, java.awt.Shape shape, IndicatorStyle style) {
	}

	public void paintLabel(java.awt.Graphics2D g2d, Bullet bullet, Double value, IndicatorStyle style) {
	}

	@java.lang.Override
	public java.awt.Shape paintLegendItem(java.awt.Graphics g, Bullet bullet, IndicatorStyle style, int w, int h) {
	}
}
