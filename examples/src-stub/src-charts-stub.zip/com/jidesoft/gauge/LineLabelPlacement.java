/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2012 All Rights Reserved
 *  Created: 20/08/2012 at 00:33
 */
public final class LineLabelPlacement extends Enum {

	public static final LineLabelPlacement ABOVE;

	public static final LineLabelPlacement BELOW;

	public static final LineLabelPlacement LEFT;

	public static final LineLabelPlacement RIGHT;

	public static LineLabelPlacement[] values() {
	}

	public static LineLabelPlacement valueOf(String name) {
	}
}
