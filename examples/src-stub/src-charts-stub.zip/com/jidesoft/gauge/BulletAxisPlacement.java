/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A class that enables you to specify where a bullet axis should be placed
 */
public final class BulletAxisPlacement extends Enum {

	public static final BulletAxisPlacement LEADING;

	public static final BulletAxisPlacement TRAILING;

	public static BulletAxisPlacement[] values() {
	}

	public static BulletAxisPlacement valueOf(String name) {
	}
}
