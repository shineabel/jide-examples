/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class BulletIntervalMarkerLegendItem extends javax.swing.JComponent implements com.jidesoft.chart.LegendItem {

	public BulletIntervalMarkerLegendItem(BulletIntervalMarker intervalMarker, String intervalName) {
	}

	public BulletIntervalMarker getIntervalMarker() {
	}

	public void setIntervalMarker(BulletIntervalMarker intervalMarker) {
	}

	public java.awt.Component getComponent() {
	}

	public String getLabel() {
	}

	public Positionable getItem() {
	}

	public GaugeModel getSource() {
	}

	protected java.awt.Paint createFill() {
	}

	public void paintComponent(java.awt.Graphics g) {
	}
}
