/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class BulletTickStyle extends AbstractGaugeTickStyle {

	public BulletTickStyle() {
	}

	/**
	 *  Create a BulletTickStyle and provide a length for the ticks as a proportion of the breadth of the bullet
	 *  (by default, 0.2)
	 *  @param tickLength the length of ticks as a proportion of the breadth of the bullet
	 */
	public BulletTickStyle(double tickLength) {
	}

	/**
	 *  Specify the width of a tick in proportion to its length (by default, 0.075)
	 *  @return the width of a tick in proportion to its length.
	 */
	@java.lang.Override
	public double getTickWidth() {
	}

	/**
	 *  Specify the width of a tick in proportion to its length
	 *  @param tickWidth the width proportion of a tick (default 0.075)
	 */
	@java.lang.Override
	public void setTickWidth(double tickWidth) {
	}
}
