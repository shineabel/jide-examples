/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A renderer to be used with the Bullet class and which renders its value as a horizontal or vertical bar whose
 *  length indicates the value.
 */
public class BarIndicatorRenderer extends AbstractIndicatorRenderer {

	public BarIndicatorRenderer() {
	}

	public com.jidesoft.chart.BarLabelPlacement getLabelPlacement() {
	}

	public void setLabelPlacement(com.jidesoft.chart.BarLabelPlacement labelPlacement) {
	}

	public double getBarBreadth() {
	}

	public void setBarBreadth(double barBreadth) {
	}

	public double getBarPosition() {
	}

	public void setBarPosition(double barPosition) {
	}

	/**
	 *  Returns the border to be applied to the Indicator, or null if no border is defined
	 *  @return the Border to be applied to the Indicator
	 */
	public javax.swing.border.Border getBorder() {
	}

	/**
	 *  If a border is defined, it overrides any outline defined in the IndicatorStyle
	 *  @param border the Border to be applied to the bar indicator
	 */
	public void setBorder(javax.swing.border.Border border) {
	}

	protected java.awt.Shape calculateShape(Bullet bullet, Double value) {
	}

	protected void drawIndicator(java.awt.Graphics2D g, Bullet bullet, java.awt.Shape shape, IndicatorStyle style) {
	}

	@java.lang.Override
	public void paintLabel(java.awt.Graphics2D g2d, Bullet bullet, Double value, IndicatorStyle style) {
	}

	@java.lang.Override
	public java.awt.Shape paintLegendItem(java.awt.Graphics g, Bullet bullet, IndicatorStyle style, int w, int h) {
	}
}
