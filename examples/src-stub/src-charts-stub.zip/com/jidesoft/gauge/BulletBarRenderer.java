/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A renderer that displays each bar of a bar chart as a Bullet
 */
public class BulletBarRenderer extends Bullet implements com.jidesoft.chart.render.BarRenderer2D {

	public BulletBarRenderer() {
	}

	@java.lang.Override
	public java.awt.Dimension getSize() {
	}

	@java.lang.Override
	public int getMinimumBreadth() {
	}

	@java.lang.Override
	public java.awt.Shape renderBar(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y, int width, int height) {
	}

	@java.lang.Override
	public java.awt.Shape renderBar(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, double x, double y, double width, double height) {
	}
}
