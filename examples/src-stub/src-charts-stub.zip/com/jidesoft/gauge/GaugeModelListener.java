/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public interface GaugeModelListener extends java.util.EventListener {

	public void gaugeChanged(GaugeModelEvent e);
}
