/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class BulletIndicatorLegendItem extends javax.swing.JComponent implements com.jidesoft.chart.LegendItem {

	public BulletIndicatorLegendItem(Bullet bullet, String indicatorName) {
	}

	public java.awt.Component getComponent() {
	}

	public String getLabel() {
	}

	public Positionable getItem() {
	}

	public GaugeModel getSource() {
	}

	public void paintComponent(java.awt.Graphics g) {
	}
}
