/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A class to use as a marker for a value on a dial. The position property marks the value along the dial axis
 *  at which the marker appears. For the shape of the marker use the MarkerShape enum, or some other custom
 *  implementation of the MarkerShapeFactory interface.
 *  <p>You can fill the marker with a plain color or a Paint. Paint patterns are not rotated (but the shapes that they
 *  fill are rotated according to their position on the dial axis), so you might consider
 *  using a DialRadialPaint to highlight the tip of a triangular marker.</p>
 */
public class DialValueMarker implements com.jidesoft.chart.Drawable {

	public DialValueMarker(Dial dial) {
	}

	public DialValueMarker(Dial dial, double position, double radius) {
	}

	public Dial getDial() {
	}

	public void setDial(Dial dial) {
	}

	public double getPosition() {
	}

	public void setPosition(double position) {
	}

	public double getRadius() {
	}

	public void setRadius(double radius) {
	}

	public java.awt.Paint getFill() {
	}

	public void setFill(java.awt.Paint fill) {
	}

	public java.awt.Color getBorderColor() {
	}

	public void setBorderColor(java.awt.Color borderColor) {
	}

	public java.awt.Stroke getBorderStroke() {
	}

	public void setBorderStroke(java.awt.Stroke borderStroke) {
	}

	public double getHeight() {
	}

	public void setHeight(double height) {
	}

	public double getWidth() {
	}

	public void setWidth(double width) {
	}

	/**
	 *  Simultaneously set the width and height to be the same. Good for circles and equilateral triangles
	 *  @param size the size of the shape as a proportion of the radius of the dial
	 */
	public void setSize(double size) {
	}

	public MarkerShapeFactory getShape() {
	}

	public void setShape(MarkerShapeFactory shapeFactory) {
	}

	public void draw(java.awt.Graphics g) {
	}
}
