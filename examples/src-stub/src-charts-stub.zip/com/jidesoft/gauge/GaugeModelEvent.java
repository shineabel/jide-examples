/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class GaugeModelEvent extends java.util.EventObject {

	public GaugeModelEvent(Object source, String needleName, Positionable pos) {
	}

	public String getNeedleName() {
	}

	public Positionable getPositionable() {
	}

	@java.lang.Override
	public String toString() {
	}
}
