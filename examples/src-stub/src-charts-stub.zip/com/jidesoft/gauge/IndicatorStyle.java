/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public class IndicatorStyle {

	public IndicatorStyle() {
	}

	public java.awt.Paint getFill() {
	}

	public void setFill(java.awt.Paint fill) {
	}

	public IndicatorStyle withFill(java.awt.Paint fill) {
	}

	/**
	 *  Returns the color of the outline
	 *  @return the color of the outline
	 */
	public java.awt.Color getOutline() {
	}

	/**
	 *  Specify the color of the outline
	 *  @param outlineColor the color of the outline
	 */
	public void setOutline(java.awt.Color outlineColor) {
	}

	public IndicatorStyle withOutline(java.awt.Color outline) {
	}

	/**
	 *  Returns the width of the outline
	 *  @return the width of the outline
	 */
	public float getOutlineWidth() {
	}

	/**
	 *  Specify the width of the outline of the indicator, given as a percentage of the width of the bullet.
	 *  In practice this means that a value of 1 should give a fine outline, whereas a value of say, 3, would give
	 *  a thicker outline.
	 *  @param outlineWidth the width of the outline
	 */
	public void setOutlineWidth(float outlineWidth) {
	}

	/**
	 *  Specify the width of the outline of the indicator and return this object
	 *  @param outlineWidth the width of the outline of the indicator
	 *  @return this object, so method calls can be chained together
	 */
	public IndicatorStyle withOutlineWidth(float outlineWidth) {
	}
}
