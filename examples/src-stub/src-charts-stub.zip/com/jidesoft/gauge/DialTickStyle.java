/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2012 All Rights Reserved
 *  Created: 07/04/2012 at 18:14
 */
public class DialTickStyle extends AbstractGaugeTickStyle {

	/**
	 *  Tick start determines the position of the tick relative to the axis. The size of tick start is in proportion
	 *  of the axis width. Ticks will be painted from this position towards the center of the dial. The default value is
	 *  0.0, which means the ticks will be painted at the outside of the axis.
	 */
	protected double tickStart;

	public DialTickStyle() {
	}

	public DialTickStyle(double tickLength) {
	}

	/**
	 *  The positioning of the start of the ticks, expressed as a proportion of the radius towards the centre of the dial
	 *  from the outer border of the dial axis
	 *  @return the positioning of the start of the ticks
	 */
	public double getTickStart() {
	}

	/**
	 *  The positioning of the start of the ticks, expressed as a proportion of the radius towards the centre of the dial
	 *  from the outer border of the dial axis
	 *  @param tickStart the positioning of the start of the ticks
	 */
	public void setTickStart(double tickStart) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}
}
