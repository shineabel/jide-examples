/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  An Axis type for bullet charts
 */
public class BulletAxis extends AbstractNumericGaugeAxis {

	public BulletAxis() {
	}

	/**
	 *  Construct a BulletAxis and provide start and end values to define the axis range
	 *  @param rangeStart the start of the axis range
	 *  @param rangeEnd the end of the axis range
	 */
	public BulletAxis(double rangeStart, double rangeEnd) {
	}

	/**
	 *  Construct a BulletAxis, providing start and end values to define the axis range as well as intervals
	 *  between the major and minor ticks
	 *  @param rangeStart the start of the axis range
	 *  @param rangeEnd the end of the axis range
	 *  @param majorTickInterval the gap between major ticks along the axis
	 *  @param minorTickInterval the gap between minor ticks along the axis
	 */
	public BulletAxis(double rangeStart, double rangeEnd, double majorTickInterval, double minorTickInterval) {
	}

	public double getTickLabelRotation() {
	}

	public void setTickLabelRotation(double tickLabelRotation) {
	}

	/**
	 *  Returns the current location of the axis in the bullet chart
	 *  @return the current location of the axis in the bullet chart
	 */
	public BulletAxisPlacement getPlacement() {
	}

	/**
	 *  Specify where the axis should be placed in the bullet chart
	 *  @param placement where the axis should be placed
	 */
	public void setPlacement(BulletAxisPlacement placement) {
	}

	/**
	 *  Returns a boolean to indicate whether the axis is painted
	 *  @return a boolean to indicate whether the axis is painted
	 */
	public boolean isVisible() {
	}

	/**
	 *  Specify whether the axis is painted
	 *  @param visible true if the axis is painted; false to omit it
	 */
	public void setVisible(boolean visible) {
	}
}
