/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  The directions are named according to the direction in which you read the text
 *  (assuming a language that reads left to right).
 */
public final class DialLabelOrientation extends Enum {

	public static final DialLabelOrientation TANGENTIAL_CLOCKWISE;

	public static final DialLabelOrientation TANGENTIAL_ANTICLOCKWISE;

	public static final DialLabelOrientation PERPENDICULAR_OUTWARD;

	public static final DialLabelOrientation PERPENDICULAR_INWARD;

	public static final DialLabelOrientation UPRIGHT;

	public static DialLabelOrientation[] values() {
	}

	public static DialLabelOrientation valueOf(String name) {
	}
}
