/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A resizable label that aligns itself with a Bullet
 */
public class BulletLabel extends javax.swing.JLabel {

	public BulletLabel(Bullet bullet) {
	}

	public BulletLabel(Bullet bullet, javax.swing.Icon image) {
	}

	public BulletLabel(Bullet bullet, javax.swing.Icon image, int horizontalAlignment) {
	}

	public BulletLabel(Bullet resizableComponent, String text) {
	}

	public BulletLabel(Bullet resizableComponent, String text, int horizontalAlignment) {
	}

	public BulletLabel(Bullet resizableComponent, String text, javax.swing.Icon icon, int horizontalAlignment) {
	}

	public boolean isAlignToBullet() {
	}

	public void setAlignToBullet(boolean alignToBullet) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}
}
