/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


public final class PointerIndicatorPlacement extends Enum {

	public static final PointerIndicatorPlacement LEADING_INSIDE;

	public static final PointerIndicatorPlacement LEADING_OUTSIDE;

	public static final PointerIndicatorPlacement TRAILING_INSIDE;

	public static final PointerIndicatorPlacement TRAILING_OUTSIDE;

	public static PointerIndicatorPlacement[] values() {
	}

	public static PointerIndicatorPlacement valueOf(String name) {
	}
}
