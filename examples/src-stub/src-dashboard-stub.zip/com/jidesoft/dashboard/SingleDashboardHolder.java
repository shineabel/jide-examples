/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>SingleDashboardHolder</code> creates a single dashboard that implements DashboardHolder interface.
 */
public class SingleDashboardHolder extends Dashboard implements GadgetPaletteInstaller, DashboardHolder {

	protected GadgetManager _gadgetManager;

	public SingleDashboardHolder() {
	}

	public SingleDashboardHolder(GadgetManager gadgetManager) {
	}

	public SingleDashboardHolder(String key) {
	}

	public SingleDashboardHolder(String key, String title) {
	}

	public SingleDashboardHolder(String key, String title, int columnCount) {
	}

	@java.lang.Override
	protected void initDashboard() {
	}

	public GadgetManager getGadgetManager() {
	}

	public Dashboard getActiveDashboard() {
	}

	public Dashboard createDashboard(String key) {
	}

	public boolean isUseFloatingPalette() {
	}

	public void setUseFloatingPalette(boolean useFloatingPalette) {
	}

	protected GadgetPalette createGadgetPalette() {
	}

	public java.awt.Container getValidParent(java.awt.Component c) {
	}

	/**
	 *  Sets the palette side.
	 * 
	 *  @param paletteSide the palette side
	 */
	public void setPaletteSide(int paletteSide) {
	}

	/**
	 *  Gets the palette side. It should be WEST, EAST, NORTH or SOUTH. By default, it's SOUTH.
	 * 
	 *  @return the palette side.
	 *  @see #setPaletteSide(int)
	 */
	@java.lang.Override
	public int getPaletteSide() {
	}

	public void showPalette() {
	}

	/**
	 *  Shows the palette.
	 */
	public void showPalette(java.awt.Component invoker) {
	}

	public void hidePalette() {
	}

	/**
	 *  Checks if the palette is visible.
	 * 
	 *  @return true if the palette is visible. Otherwise false.
	 */
	public boolean isPaletteVisible() {
	}

	/**
	 *  Toggles the palette visibility.
	 * 
	 *  @param invoker the invoker that calls to this togglePalette method.
	 */
	public void togglePalette(java.awt.Component invoker) {
	}
}
