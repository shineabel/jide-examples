/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>GadgetPaletteButton</code> is the button on the palette.
 */
public class GadgetPaletteButton extends JideToggleButton implements GadgetPaletteSupport {

	public GadgetPaletteButton(GadgetPalette gadgetPalette, Gadget element) {
	}

	@java.lang.Override
	public Gadget getGadget() {
	}

	public GadgetPalette getGadgetPalette() {
	}
}
