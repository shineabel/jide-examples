/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


public class ResizableGadgetContainer extends JideSplitPane {

	public ResizableGadgetContainer(int gap) {
	}

	/**
	 *  Gets the settings.
	 * 
	 *  @return a map of the settings. The key is the name of the setting and the value of the map is the value of the
	 *          setting. The value must be a string in order to be persisted in the xml format. If your original data
	 *          format is not string, you need to convert to string first. You could leverage ObjectConverterManager and
	 *          ObjectConverter to do it.
	 */
	public java.util.Map getSettings() {
	}

	/**
	 *  Sets the settings.
	 * 
	 *  @param settings the setting map
	 */
	public void setSettings(java.util.Map settings) {
	}
}
