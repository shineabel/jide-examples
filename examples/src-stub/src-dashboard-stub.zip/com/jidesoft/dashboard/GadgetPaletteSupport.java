/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  An interface supported by the Dashboard. A component can implement this interface if it wants to be the palette that
 *  can be dragged to the dashboard to create gadget component.
 */
public interface GadgetPaletteSupport {

	public Gadget getGadget();
}
