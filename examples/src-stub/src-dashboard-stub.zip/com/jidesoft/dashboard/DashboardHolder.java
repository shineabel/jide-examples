/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>DashboardHolder</code> interface is used to indicate the container can hold <code>Dashboard</code>.
 *  <p/>
 *  If your DashboardHolder may contain multiple Dashboard's, please register a DashboardListener to the GadgetManager
 *  this holder created and listen to the DASHBOARD_REMOVED event so that you could manage the active dashboard correctly.
 * 
 *  @see com.jidesoft.dashboard.Dashboard
 */
public interface DashboardHolder {

	/**
	 *  Gets the gadget manager.
	 * 
	 *  @return the gadget manager.
	 */
	public GadgetManager getGadgetManager();

	public Dashboard getActiveDashboard();

	public Dashboard createDashboard(String key);
}
