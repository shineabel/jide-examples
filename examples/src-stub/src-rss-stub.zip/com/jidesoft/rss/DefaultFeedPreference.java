/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  Default implementation of <code>FeedPreference</code>.
 */
public class DefaultFeedPreference implements FeedPreference {

	public DefaultFeedPreference() {
	}

	public boolean isAllowDuplicatedChannels() {
	}

	public void setAllowDuplicatedChannels(boolean allowDuplicatedChannels) {
	}

	public String getBrowser() {
	}

	public void setBrowser(String browser) {
	}

	public String getDescription() {
	}

	public void setDescription(String description) {
	}

	public int getMaxCacheItems() {
	}

	public void setMaxCacheItems(int maxCacheItems) {
	}

	public String getName() {
	}

	public void setName(String name) {
	}

	public boolean isUseDefaultBrowser() {
	}

	public void setUseDefaultBrowser(boolean useDefaultBrowser) {
	}

	public long getId() {
	}

	public void setId(long id) {
	}

	public int getRefreshTime() {
	}

	public void setRefreshTime(int refreshTime) {
	}
}
