package com.jidesoft.plaf;


public abstract class CommandBarTitleBarUI extends javax.swing.plaf.MenuBarUI {

	public CommandBarTitleBarUI() {
	}
}
