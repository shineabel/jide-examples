package com.jidesoft.plaf.metal;


public class MetalCommandBarTitleBarUI extends com.jidesoft.plaf.basic.BasicCommandBarTitleBarUI {

	public MetalCommandBarTitleBarUI(com.jidesoft.action.CommandBarTitleBar titleBar) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
