/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  Interface to customer a popup menu for <code>DockableBar</code>.
 */
public interface DockableBarPopupMenuCustomizer {

	/**
	 *  Allow user to customize the popup menu. Popup menu will be shown when user
	 *  right click on the <code>DockableBarContainer</code> or <code>DockableBar</code>.
	 * 
	 *  @param menu               Popup menu to be customized
	 *  @param dockableBarManager the DockableBarManager
	 *  @param component          the component for the popup menu. It could be <code>DockableBarContainer</code> or <code>DockableBar</code> or null.
	 */
	public void customizePopupMenu(javax.swing.JPopupMenu menu, DockableBarManager dockableBarManager, java.awt.Component component);
}
