/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>Chevron</code> is a special component used by CommandBar. Usually chevron appears at the end of the command
 *  bar. It provides a place to access hidden components when the command bar can't show all its buttons or other
 *  components.
 */
public class Chevron extends JideMenu implements javax.swing.SwingConstants, javax.swing.plaf.UIResource {

	/**
	 *  Property name of whether the chevron has more hidden components.
	 */
	public static final String PROPERTY_SHOWMORE = "showMore";

	/**
	 *  Property name of whether the chevron has additional options.
	 */
	public static final String PROPERTY_SHOWOPTIONS = "showOption";

	/**
	 *  Creates a new chevron.
	 */
	public Chevron() {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the LookAndFeel class that renders this component.
	 * 
	 *  @return the string "ChevronUI"
	 *  @see javax.swing.JComponent#getUIClassID
	 *  @see javax.swing.UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Checks if there are hidden components on the command bar. If there are hidden components, the UI of Chevron will
	 *  show some symbol such as a left arrow to indicate there are more components. Different LookAndFeel may display
	 *  different symbol to indicate showMore property is true..
	 * 
	 *  @return true if there are hidden components.
	 */
	public boolean isShowMore() {
	}

	/**
	 *  Sets the showMore attribute and fires property change event.
	 * 
	 *  @param showMore true or false.
	 */
	public void setShowMore(boolean showMore) {
	}

	/**
	 *  Checks if there are additional options can be set on the command bar. Usually those additional options are
	 *  customizing command bar, adding or removing buttons etc. If so, the UI of Chevron will show some symbol such as a
	 *  down arrow to indicate there are additional options. Different LookAndFeels may show different symbol to indicate
	 *  showOptions property is true..
	 * 
	 *  @return true if there are additional options on command bar.
	 */
	public boolean isShowOptions() {
	}

	/**
	 *  Sets the showOptions attribute and fires property change event.
	 * 
	 *  @param showOptions true or false.
	 */
	public void setShowOptions(boolean showOptions) {
	}
}
