/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>DockableBarHolder</code> interface is used to indicate the container can hold
 *  <code>DockableBar</code>s.
 *  <br>
 *  You can make <code>JFrame</code> a <code>DockableBarHolder</code> simply by implementing
 *  this interface. Or you can use two pre-build <code>JFrame</code> - <code>DefaultDockableBarHolder</code>
 *  which supports <code>DockableBar</code>s or <code>DefaultDockableBarDockableHolder</code> which supports both
 *  <code>DockableBar</code>s and <code>DockableFrame</code>s.
 * 
 *  @see DockableBar
 */
public interface DockableBarHolder {

	/**
	 *  Return the <code>DockableBarManager</code> that manages the <code>DockableBarHolder</code>.
	 *  There is only one <code>DockableBarManager</code> allowed in each <code>DockableBarHolder</code>.
	 * 
	 *  @return the DockableBarManager that manages the <code>DockableBarHolder</code>.
	 */
	public DockableBarManager getDockableBarManager();
}
