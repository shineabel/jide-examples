/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>CommandBarTitleBar</code> is used in <code>CommandBar</code> when it's in floating mode.
 */
public class CommandBarTitleBar extends javax.swing.JMenuBar implements javax.swing.MenuElement, javax.swing.SwingConstants, javax.swing.plaf.UIResource {

	public CommandBarTitleBar(String title) {
	}

	/**
	 *  Returns the L&F object that renders this component.
	 * 
	 *  @return the CommandBarTitleBarUI object that renders this component
	 */
	@java.lang.Override
	public javax.swing.plaf.MenuBarUI getUI() {
	}

	/**
	 *  Sets the L&F object that renders this component.
	 * 
	 *  @param ui the CommandBarTitleBarUI L&F object
	 *  @see javax.swing.UIDefaults#getUI
	 */
	public void setUI(com.jidesoft.plaf.CommandBarTitleBarUI ui) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the L&F class that renders this component.
	 * 
	 *  @return the string "CommandBarTitleBarUI"
	 * 
	 *  @see javax.swing.JComponent#getUIClassID
	 *  @see javax.swing.UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  return true if it supports vertical orientation.
	 * 
	 *  @return true if it supports vertical orientation
	 */
	public boolean supportVerticalOrientation() {
	}

	/**
	 *  return true if it supports horizontal orientation.
	 * 
	 *  @return true if it supports horizontal orientation
	 */
	public boolean supportHorizontalOrientation() {
	}

	/**
	 *  Changes the orientation.
	 * 
	 *  @param orientation
	 */
	public void setOrientation(int orientation) {
	}

	/**
	 *  Gets the orientation.
	 * 
	 *  @return orientation
	 */
	public int getOrientation() {
	}

	@java.lang.Override
	public void processMouseEvent(java.awt.event.MouseEvent event, javax.swing.MenuElement[] path, javax.swing.MenuSelectionManager manager) {
	}

	@java.lang.Override
	public void processKeyEvent(java.awt.event.KeyEvent event, javax.swing.MenuElement[] path, javax.swing.MenuSelectionManager manager) {
	}

	@java.lang.Override
	public void menuSelectionChanged(boolean isIncluded) {
	}

	/**
	 *  Implemented to be a <code>MenuElement</code> -- returns the menus in this menu bar. This is the reason for
	 *  implementing the <code>MenuElement</code> interface -- so that the menu bar can be treated the same as other menu
	 *  elements.
	 * 
	 *  @return an array of menu items in the menu bar.
	 */
	@java.lang.Override
	public javax.swing.MenuElement[] getSubElements() {
	}

	/**
	 *  Implemented to be a <code>MenuElement</code>. Returns this object.
	 * 
	 *  @return the current <code>Component</code> (this)
	 * 
	 *  @see #getSubElements
	 */
	@java.lang.Override
	public java.awt.Component getComponent() {
	}

	/**
	 *  Gets the title of this title bar.
	 * 
	 *  @return the title.
	 */
	public String getTitle() {
	}

	/**
	 *  Sets the title of this title bar.
	 * 
	 *  @param title the new title bar.
	 */
	public void setTitle(String title) {
	}

	/**
	 *  Overridden to always return false.
	 * 
	 *  @return false.
	 */
	public boolean isMenuBar() {
	}
}
