/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>DockableBar</code> is the base component that works with DockableBarManager.
 *  <p/>
 *  The DockableBar can be placed horizontally or vertically. If vertically, only child components that implemented
 *  Alignable and say it returns true in supportVerticalOrientation method will be placed on vertical DockableBar. By
 *  default, all components will be placed on horizontal DockableBar no matter it implements Alignable. But if a
 *  component implements Alignable and returns false in its supportHorizontalOrientation method, it will not be shown on
 *  horizontal DockableBar.
 * 
 *  @see Alignable
 */
public abstract class DockableBar extends javax.swing.JMenuBar implements Dockable, javax.swing.SwingConstants {

	/**
	 *  Constrained property name indicating that the key of the dockable bar.
	 */
	public static final String PROPERTY_KEY = "key";

	/**
	 *  Constrained property name indicating that the key of the DockableBar.
	 */
	public static final String PROPERTY_TITLE = "title";

	/**
	 *  Constrained property name indicating that the DockableBar is floatable.
	 */
	public static final String PROPERTY_FLOATABLE = "floatable";

	/**
	 *  Constrained property name indicating that the DockableBar is floatable.
	 */
	public static final String PROPERTY_REARRANGABLE = "rearrangable";

	/**
	 *  Constrained property name indicating that the DockableBar is stretching.
	 */
	public static final String PROPERTY_STRETCH = "stretch";

	/**
	 *  Constrained property name indicating that the DockableBar can be hidden.
	 */
	public static final String PROPERTY_HIDABLE = "hidable";

	/**
	 *  Constrained property name indicating that the DockableBar is hidden.
	 */
	public static final String PROPERTY_HIDDEN = "hidden";

	/**
	 *  Constrained property name indicating that the DockableBar is docked.
	 */
	public static final String PROPERTY_HORI_DOCKED = "horiDocked";

	/**
	 *  Constrained property name indicating that the DockableBar is docked.
	 */
	public static final String PROPERTY_VERT_DOCKED = "vertDocked";

	/**
	 *  Constrained property name indicating that the DockableBar is floated.
	 */
	public static final String PROPERTY_FLOATED = "floating";

	public static final String PROPERTY_INIT_SIDE = "initSide";

	public static final String PROPERTY_INIT_MODE = "initMode";

	public static final String PROPERTY_INIT_INDEX = "initIndex";

	public static final String PROPERTY_INIT_SUBINDEX = "initSubindex";

	public static final String PROPERTY_ALLOWED_DOCK_SIDES = "allowedDockSides";

	public static final String PROPERTY_UNDOCKED_BOUNDS = "undockedBounds";

	protected int _orientation;

	public static final String PROPERTY_CHEVRON_ALWAYS_VISIBLE = "chevronAlwaysVisible";

	public static final String PROPERTY_PAINT_BACKGROUND = "paintBackground";

	public static final String PROPERTY_MENU_BAR = "menuBar";

	/**
	 *  Bound property name for the events regarding the DockableBar availability.
	 */
	public static final String PROPERTY_AVAILABLE = "available";

	/**
	 *  Creates a DockableBar. Key can uniquely identify a DockableBar if it will be added to DockableBarManager. If you
	 *  use this constructor, you should call {@link #setKey(String)} to give it a unique key before adding to
	 *  DockableBarManager.
	 */
	public DockableBar() {
	}

	/**
	 *  Creates a DockableBar with a specified key.
	 * 
	 *  @param key the key for the DockableBar. It is used to uniquely identify a DockableBar in DockableBarManager. If
	 *             setTitle() is never called, key will be used as the title of DockableBar as well.
	 */
	public DockableBar(String key) {
	}

	/**
	 *  Creates a DockableBar with a specified key and title.
	 * 
	 *  @param key   the key for the DockableBar. It is used to uniquely identify a DockableBar in DockableBarManager.
	 *  @param title the text will be shown on the title bar when the DockableBar is floating.
	 */
	public DockableBar(String key, String title) {
	}

	/**
	 *  Gets the context of DockableBar. The context contains a lot of information that user can set during
	 *  initialization. One it has been set, it will be persisted when application closed and be reloaded when
	 *  application restarted.
	 * 
	 *  @return the context.
	 */
	public DockableBarContext getContext() {
	}

	/**
	 *  Sets the context of DockableBar.
	 * 
	 *  @param context the new DockableBarContext
	 */
	public void setContext(DockableBarContext context) {
	}

	/**
	 *  Sets the key of DockableBar. The key is used to uniquely identify DockableBars in DockableBarManager.
	 * 
	 *  @param key the key of DockableBar.
	 */
	public void setKey(String key) {
	}

	/**
	 *  Gets the key of DockableBar.
	 * 
	 *  @return the key of DockableBar.
	 */
	public String getKey() {
	}

	/**
	 *  Sets the title of DockableBar. The title is the text that will be shown on the title bar of DockableBar when it
	 *  is floating.
	 * 
	 *  @param title the new title
	 */
	public void setTitle(String title) {
	}

	/**
	 *  Gets the title of DockableBar.
	 * 
	 *  @return the title of DockableBar.
	 */
	public String getTitle() {
	}

	public DockableBarManager getDockableBarManager() {
	}

	public void setDockableBarManager(DockableBarManager dockingManager) {
	}

	/**
	 *  Checks if the DockableBar is hidden. The information is actually on the context. This method is equivalent to
	 *  <code>getContext().isHidden()</code>.
	 * 
	 *  @return true if the DockableBar is hidden. Otherwise, false.
	 */
	public boolean isHidden() {
	}

	/**
	 *  Sets the DockableBar to hidden state. Please note, this method simply made a state change and fire property
	 *  change event. It won't hide the DockableBar. If you want to hide a DockableBar, you should call
	 *  dockableBarManager.hideDockableBar().
	 * 
	 *  @throws PropertyVetoException of the property change is vetoed.
	 */
	public void setHidden() {
	}

	/**
	 *  Checks if the DockableBar is floating. The information is actually on the context. This method is equivalent to
	 *  <code>getContext().isFloating()</code>.
	 * 
	 *  @return true if the DockableBar is floating. Otherwise, false.
	 */
	public boolean isFloating() {
	}

	/**
	 *  Sets the DockableBar to floating state. Please note, this method simply made a state change and fire property
	 *  change event. It won't make the DockableBar floating. If you want to float a DockableBar, you should call
	 *  dockableBarManager.floatDockableBar().
	 * 
	 *  @throws PropertyVetoException of the property change is vetoed.
	 */
	public void setFloating() {
	}

	/**
	 *  Checks if the DockableBar is docked vertically (on the east side or west side). The information is actually on
	 *  the context. This method is equivalent to <code>getContext().isVertDocked()</code>.
	 * 
	 *  @return true if the DockableBar is docked vertically. Otherwise, false.
	 */
	public boolean isVertDocked() {
	}

	/**
	 *  Sets the DockableBar to vertically docked state. Please note, this method simply made a state change and fire
	 *  property change event. It won't make the DockableBar docking. If you want to dock a DockableBar, you should call
	 *  dockableBarManager.dockDockableBar().
	 * 
	 *  @throws PropertyVetoException of the property change is vetoed.
	 */
	public void setVertDocked() {
	}

	/**
	 *  Checks if the DockableBar is docked horizontally (on the north side or south side). The information is actually
	 *  on the context. This method is equivalent to <code>getContext().isVertDocked()</code>.
	 * 
	 *  @return true if the DockableBar is docked horizontally. Otherwise, false.
	 */
	public boolean isHoriDocked() {
	}

	public void setHoriDocked() {
	}

	/**
	 *  Adds the specified listener to receive DockableBarEvent from this DockableBar.
	 * 
	 *  @param l the DockableBarListener
	 */
	public void addDockableBarListener(event.DockableBarListener l) {
	}

	/**
	 *  Removes the specified DockableBar listener so that it no longer receives DockableBarEvent from this DockableBar.
	 * 
	 *  @param l the DockableBarListener
	 */
	public void removeDockableBarListener(event.DockableBarListener l) {
	}

	/**
	 *  Returns an array of all the <code>DockableBarListener</code>s added to this <code>DockableBar</code> with
	 *  <code>addDockableBarListener</code>.
	 * 
	 *  @return all of the <code>DockableBarListener</code>s added or an empty array if no listeners have been added
	 *  @see #addDockableBarListener
	 *  @since 1.4
	 */
	public event.DockableBarListener[] getDockableBarListeners() {
	}

	/**
	 *  Fires a DockableBarEvent.
	 * 
	 *  @param id the type of the event being fired; one of the following: If the event type is not one of the above,
	 *            nothing happens.
	 */
	protected void fireDockableBarEvent(int id) {
	}

	/**
	 *  Get dock id.
	 * 
	 *  @return the an int id that unique identify the component.
	 */
	public int getDockID() {
	}

	public void setDockID(int id) {
	}

	public void resetDockID() {
	}

	/**
	 *  Gets the <code>floatable</code> property.
	 * 
	 *  @return the value of the <code>floatable</code> property
	 *  @see #setFloatable
	 */
	public boolean isFloatable() {
	}

	/**
	 *  Sets the <code>floatable</code> property.
	 * 
	 *  @param b if <code>true</code>, the command bar can be floated; <code>false</code> otherwise
	 *  @see #isFloatable
	 */
	public void setFloatable(boolean b) {
	}

	/**
	 *  Gets the <code>rearrangeable</code> property.
	 * 
	 *  @return the value of the <code>rearrangeable</code> property
	 *  @see #setRearrangable
	 */
	public boolean isRearrangable() {
	}

	/**
	 *  Sets the <code>rearrangeable</code> property.
	 * 
	 *  @param b if <code>true</code>, the command bar can be floated; <code>false</code> otherwise
	 *  @see #isRearrangable
	 */
	public void setRearrangable(boolean b) {
	}

	/**
	 *  Gets the <code>hidable</code> property.
	 * 
	 *  @return the value of the <code>hidable</code> property
	 *  @see #setHidable
	 */
	public boolean isHidable() {
	}

	/**
	 *  Sets the <code>hidable</code> property.
	 * 
	 *  @param b if <code>true</code>, the tool bar can be hidden; <code>false</code> otherwise
	 *  @see #isHidable
	 */
	public void setHidable(boolean b) {
	}

	public java.awt.Rectangle getUndockedBounds() {
	}

	public void setUndockedBounds(java.awt.Rectangle undockedBounds) {
	}

	/**
	 *  Checks if the DockableBar is stretching. Stretch is true means it will occupy the whole row in
	 *  DockableBarContainer and no other <code>DockableBar</code> can be at the same row.
	 * 
	 *  @return true if the DockableBar is stretching.
	 */
	public boolean isStretch() {
	}

	/**
	 *  Sets the stretch property to a new value.
	 * 
	 *  @param stretch true or false.
	 */
	public void setStretch(boolean stretch) {
	}

	/**
	 *  Returns the current orientation of the tool bar.  The value is either <code>HORIZONTAL</code> or
	 *  <code>VERTICAL</code>.
	 * 
	 *  @return an integer representing the current orientation -- either <code>HORIZONTAL</code> or
	 *          <code>VERTICAL</code>
	 *  @see #setOrientation
	 */
	public int getOrientation() {
	}

	/**
	 *  Sets the orientation of the DockableBar.  The orientation must have either the value <code>HORIZONTAL</code> or
	 *  <code>VERTICAL</code>. If <code>orientation</code> is an invalid value, an exception will be thrown.
	 * 
	 *  @param orientation the new orientation -- either <code>HORIZONTAL</code> or </code>VERTICAL</code>
	 *  @throws IllegalArgumentException if orientation is neither <code>HORIZONTAL</code> nor <code>VERTICAL</code>
	 *  @see #getOrientation
	 */
	public void setOrientation(int orientation) {
	}

	@java.lang.Override
	public void setLayout(java.awt.LayoutManager mgr) {
	}

	/**
	 *  Implementing method in Alignable.
	 * 
	 *  @return returns true by default since DockableBar should support vertical orientation.
	 */
	public boolean supportVerticalOrientation() {
	}

	/**
	 *  Implementing method in Alignable.
	 * 
	 *  @return returns true by default since DockableBar should support horizontal orientation.
	 */
	public boolean supportHorizontalOrientation() {
	}

	protected void checkOrientation(int orientation) {
	}

	/**
	 *  Gets the sides which the <code>DockableBar</code> can dock to. By default, the value is
	 *  DockableBarContext.DOCK_SIDE_ALL meaning it can dock to all four sides.
	 * 
	 *  @return the sides which the DockableBar can dock to.
	 */
	public int getAllowedDockSides() {
	}

	/**
	 *  Sets the sides which the DockableBar can dock to.
	 * 
	 *  @param allowedDockSides true or false.
	 */
	public void setAllowedDockSides(int allowedDockSides) {
	}

	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	/**
	 *  Gets initial state.
	 * 
	 *  @return initial state
	 */
	public int getInitMode() {
	}

	/**
	 *  Sets the initial state.
	 * 
	 *  @param initMode
	 */
	public void setInitMode(int initMode) {
	}

	/**
	 *  Gets the initial side.
	 * 
	 *  @return the initial side.
	 */
	public int getInitSide() {
	}

	/**
	 *  Sets the initial side.
	 * 
	 *  @param initSide the initial size such as DOCK_SIDE_NORTH, DOCK_SIDE_SOUTH, DOCK_SIDE_EAST and DOCK_SIDE_WEST as
	 *                  defined in DockableBarContext.
	 */
	public void setInitSide(int initSide) {
	}

	/**
	 *  Gets the init index.
	 * 
	 *  @return init index.
	 */
	public int getInitIndex() {
	}

	/**
	 *  Sets initial index. After setting initial side and mode, user can use this parameter to define initial position.
	 * 
	 *  @param initIndex the initial index
	 */
	public void setInitIndex(int initIndex) {
	}

	/**
	 *  Gets the init index.
	 * 
	 *  @return init index.
	 */
	public int getInitSubindex() {
	}

	/**
	 *  Sets initial index. After setting initial side and mode, user can use this parameter to define initial position.
	 * 
	 *  @param initSubindex the initial index
	 */
	public void setInitSubindex(int initSubindex) {
	}

	public void readElement(org.w3c.dom.Element element) {
	}

	public void adjustChildrenOrientation(int orientation) {
	}

	/**
	 *  Checks if the DockableBar is available.
	 * 
	 *  @return true if it's available.
	 */
	public boolean isAvailable() {
	}

	/**
	 *  Sets true to make the DockableBar available.
	 * 
	 *  @param avail true or false.
	 */
	public void setAvailable(boolean avail) {
	}

	/**
	 *  Checks if the chevron is always visible. The chevron will be shown if there are hidden component. If there is no
	 *  hidden component, by default we have UIDefault "Chevron.alwaysVisible" to control it. It is global setting per
	 *  L&F. If the UIDefault is true, we will also look at return value from this method to decide if the chevron is
	 *  visible. Only when both are true, we show the chevron when there is no hidden component.
	 * 
	 *  @return true or false.
	 */
	public boolean isChevronAlwaysVisible() {
	}

	/**
	 *  Sets the flag if the chevron should always be visible even when there is no hidden component. It works with
	 *  UIDefault "Chevron.alwaysVisible". Only when both the return value from this method and the UIDefault
	 *  "Chevron.alwaysVisible" are true, we always show the chevron. The default return value of this method is true.
	 * 
	 *  @param chevronAlwaysVisible true or false.
	 */
	public void setChevronAlwaysVisible(boolean chevronAlwaysVisible) {
	}

	/**
	 *  Checks if the background of command bar should be painted.
	 * 
	 *  @return true if the background should be painted.
	 */
	public boolean isPaintBackground() {
	}

	/**
	 *  Sets if the background of command bar should be painted.
	 * 
	 *  @param paintBackground true or false.
	 */
	public void setPaintBackground(boolean paintBackground) {
	}

	/**
	 *  Overrides to call setPaintBackground(isOpaque).By default, paintBackground is true and opaque is false. User can
	 *  call setPaintBackground to decide if the background should be painted. But if user calls setOpaque, we assume
	 *  they want it still works as expected. That's why we change paintBackground to make it the same as opaque.
	 * 
	 *  @param isOpaque true or false.
	 */
	@java.lang.Override
	public void setOpaque(boolean isOpaque) {
	}

	/**
	 *  Checks if the command bar is used as menu bar.
	 * 
	 *  @return true if command bar is used as menu bar.
	 */
	public boolean isMenuBar() {
	}

	/**
	 *  If a CommandBar is used as menu bar, you should call this method and set the value to true.
	 *  <p/>
	 *  Please note, if your application needs to run under Mac OS X, you should use CommandMenuBar instead of using
	 *  CommandBar and setMenuBar(true). Using CommandMenuBar is the only way to support screen menu bar on Mac OS X.
	 * 
	 *  @param menuBar true or false.
	 */
	public void setMenuBar(boolean menuBar) {
	}
}
