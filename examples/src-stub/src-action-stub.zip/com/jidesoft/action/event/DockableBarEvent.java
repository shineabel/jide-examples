/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


/**
 *  An <code>AWTEvent</code> that adds support for <code>DockableBar</code> objects as the event source.
 * 
 *  @see com.jidesoft.action.DockableBar
 *  @see DockableBarListener
 */
public class DockableBarEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>DockableBar</code> events.
	 */
	public static final int DOCKABLE_BAR_FIRST = 4999;

	/**
	 *  The last number in the range of IDs used for <code>DockableBar</code> events.
	 */
	public static final int DOCKABLE_BAR_LAST = 5005;

	/**
	 *  This event is delivered when the <code>DockableBar</code> is first added to DockableBarManager.
	 */
	public static final int DOCKABLE_BAR_ADDED = 4999;

	/**
	 *  This event is delivered when the <code>DockableBar</code> is removed from DockableBarManager.
	 */
	public static final int DOCKABLE_BAR_REMOVED = 5000;

	/**
	 *  This event is delivered when showFrame is called on the <code>DockableBar</code> .
	 * 
	 *  @see com.jidesoft.action.DockableBar#show
	 */
	public static final int DOCKABLE_BAR_SHOWN = 5001;

	/**
	 *  This event is delivered when hideFrame is called on the <code>DockableBar</code>.
	 */
	public static final int DOCKABLE_BAR_HIDDEN = 5002;

	/**
	 *  This event indicates that the <code>DockableBar</code> has been changed from other state to horizontal state.
	 */
	public static final int DOCKABLE_BAR_HORI_DOCKED = 5003;

	/**
	 *  This event indicates that the <code>DockableBar</code> has been changed from other state to vertical docking
	 *  state.
	 */
	public static final int DOCKABLE_BAR_VERT_DOCKED = 5004;

	/**
	 *  This event indicates that the <code>DockableBar</code> has been changed from other state to floating state.
	 */
	public static final int DOCKABLE_BAR_FLOATING = 5005;

	/**
	 *  Constructs an <code>DockableBarEvent</code> object.
	 * 
	 *  @param source the <code>DockableBar</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public DockableBarEvent(com.jidesoft.action.DockableBar source, int id) {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	@java.lang.Override
	public String paramString() {
	}

	/**
	 *  Returns the originator of the event.
	 * 
	 *  @return the <code>DockableBar</code> object that originated the event
	 */
	public com.jidesoft.action.DockableBar getDockableBar() {
	}
}
