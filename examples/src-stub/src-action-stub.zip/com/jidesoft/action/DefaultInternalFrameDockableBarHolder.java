/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  An JInternalFrame implementation of DockableBarHolder.
 */
public class DefaultInternalFrameDockableBarHolder extends javax.swing.JInternalFrame implements DockableBarHolder {

	public DefaultInternalFrameDockableBarHolder() {
	}

	public DefaultInternalFrameDockableBarHolder(String title) {
	}

	public DefaultInternalFrameDockableBarHolder(String title, boolean resizable) {
	}

	public DefaultInternalFrameDockableBarHolder(String title, boolean resizable, boolean closable) {
	}

	public DefaultInternalFrameDockableBarHolder(String title, boolean resizable, boolean closable, boolean maximizable) {
	}

	public DefaultInternalFrameDockableBarHolder(String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
	}

	/**
	 *  Create a content container and add it to CENTER of JInternalFrame content pane.
	 * 
	 *  @param container the container where the <code>DockableBarManager</code> is installed.
	 */
	protected void initFrame(java.awt.Container container) {
	}

	protected DockableBarManager createDockableBarManager(java.awt.Container contentContainer) {
	}

	protected com.jidesoft.swing.ContentContainer createContentContainer() {
	}

	/**
	 *  Gets the default dockable bar manager.
	 * 
	 *  @return dockable bar manager.
	 */
	public DockableBarManager getDockableBarManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableBarHolder,
	 *  it's the same value that is returned from getDockableBarManager().
	 * 
	 *  @return layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Override in DefaultDockableBarHolder to return the menu bar in DockableBarManager.
	 * 
	 *  @return the menubar for this frame
	 */
	@java.lang.Override
	public javax.swing.JMenuBar getJMenuBar() {
	}

	protected boolean isContentPaneCheckingEnabled() {
	}

	protected void setContentPaneCheckingEnabled(boolean contentPaneCheckingEnabled) {
	}
}
