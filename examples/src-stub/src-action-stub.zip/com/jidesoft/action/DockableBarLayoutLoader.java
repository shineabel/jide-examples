/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>DockableBarLoader</code> is a utility that loads a layout produced by action framework without
 *  actually loading it into a DockableBarManager. You can use it to find out what dockable bars are in
 *  the layout without loading it.
 *  <p/>
 *  Here is how you use it.
 *  <code><pre>
 *  DockableBarLoader loader = new DockableBarLoader();
 *  loader.setProfileKey("jidesoft");
 *  loader.loadLayoutData();
 *  </pre></code>
 *  After that, you can call loader's getContext() to find out what dockable bars are in the layout and what initial states they are in.
 */
public class DockableBarLayoutLoader extends AbstractLayoutPersistence {

	public DockableBarLayoutLoader() {
	}

	public void loadInitialLayout(org.w3c.dom.Document layoutDocument) {
	}

	@java.lang.Override
	public boolean loadLayoutFrom(org.w3c.dom.Document document) {
	}

	public boolean loadLayoutFrom(java.io.InputStream in) {
	}

	public boolean isLoadDataSuccessful() {
	}

	@java.lang.Override
	public void saveLayoutTo(org.w3c.dom.Document document) {
	}

	public void saveLayoutTo(java.io.OutputStream out) {
	}

	public void resetToDefault() {
	}

	public void beginLoadLayoutData() {
	}

	public java.awt.Rectangle getBounds() {
	}

	public int getState() {
	}

	public java.util.Map getContexts() {
	}

	public static void main(String[] args) {
	}
}
