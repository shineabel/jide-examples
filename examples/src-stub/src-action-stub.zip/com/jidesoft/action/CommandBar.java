/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>CommandBar</code> is a special DockableBar which is used to implement components like toolbars and menu bars.
 */
public class CommandBar extends DockableBar implements javax.swing.SwingConstants {

	/**
	 *  Listener to re-validate window if components are added to or removed from a floating CommandBar.
	 */
	protected CommandBar.CommandBarContainerListener _commandBarContainerListener;

	/**
	 *  Flag indicating that a batch of add-component or remove-component operations is taking place; so don't
	 *  re-validate the window until the flag is reset, indicating that the batch is complete.
	 */
	protected boolean _changingContainer;

	/**
	 *  Creates a new CommandBar; orientation defaults to <code>HORIZONTAL</code>.
	 */
	public CommandBar() {
	}

	/**
	 *  Creates a new CommandBar with the specified <code>orientation</code>. The <code>orientation</code> must be either
	 *  <code>HORIZONTAL</code> or <code>VERTICAL</code>.
	 * 
	 *  @param orientation the orientation desired
	 */
	public CommandBar(int orientation) {
	}

	/**
	 *  Creates a new CommandBar with the specified <code>key</code>.
	 * 
	 *  @param key the key of the CommandBar
	 */
	public CommandBar(String key) {
	}

	/**
	 *  Creates a new CommandBar with the specified key and title.  The key is used as the title of the undocked
	 *  CommandBar.  The default orientation is <code>HORIZONTAL</code>.
	 * 
	 *  @param key   the key of the CommandBar
	 *  @param title the title
	 */
	public CommandBar(String key, String title) {
	}

	/**
	 *  Creates a new CommandBar with a specified <code>key</code> and <code>orientation</code>. All other constructors
	 *  call this constructor. If <code>orientation</code> is an invalid value, an exception will be thrown.
	 * 
	 *  @param key         the key of the CommandBar
	 *  @param title       the title of the CommandBar
	 *  @param orientation the initial orientation -- it must be either <code>HORIZONTAL</code> or <code>VERTICAL</code>
	 */
	public CommandBar(String key, String title, int orientation) {
	}

	/**
	 *  Returns the CommandBar's current UI.
	 * 
	 *  @see #setUI
	 */
	@java.lang.Override
	public javax.swing.plaf.MenuBarUI getUI() {
	}

	/**
	 *  Notification from the <code>UIFactory</code> that the L&F has changed. Called to replace the UI with the latest
	 *  version from the <code>UIFactory</code>.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the L&F class that renders this component.
	 * 
	 *  @return the string "CommandBarUI"
	 * 
	 *  @see javax.swing.JComponent#getUIClassID
	 *  @see javax.swing.UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Sets the margin between the CommandBar's border and its buttons. Setting to <code>null</code> causes the
	 *  CommandBar to use the default margins. The CommandBar's default <code>Border</code> object uses this value to
	 *  create the proper margin. However, if a non-default border is set on the CommandBar, it is that
	 *  <code>Border</code> object's responsibility to create the appropriate margin space (otherwise this property will
	 *  effectively be ignored).
	 * 
	 *  @param m an <code>Insets</code> object that defines the space between the border and the buttons
	 *  @see java.awt.Insets
	 */
	@java.lang.Override
	public void setMargin(java.awt.Insets m) {
	}

	/**
	 *  Returns the margin between the CommandBar's border and its buttons.
	 * 
	 *  @return an <code>Insets</code> object containing the margin values
	 * 
	 *  @see java.awt.Insets
	 */
	@java.lang.Override
	public java.awt.Insets getMargin() {
	}

	/**
	 *  Gets the <code>borderPainted</code> property.
	 * 
	 *  @return the value of the <code>borderPainted</code> property
	 * 
	 *  @see #setBorderPainted
	 */
	@java.lang.Override
	public boolean isBorderPainted() {
	}

	/**
	 *  Sets the <code>borderPainted</code> property, which is <code>true</code> if the border should be painted. The
	 *  default value for this property is <code>true</code>. Some look and feels might not implement painted borders;
	 *  they will ignore this property.
	 * 
	 *  @param b if true, the border is painted
	 *  @see #isBorderPainted
	 */
	@java.lang.Override
	public void setBorderPainted(boolean b) {
	}

	/**
	 *  Paints the CommandBar's border if the <code>borderPainted</code> property is <code>true</code>.
	 * 
	 *  @param g the <code>Graphics</code> context in which the painting is done
	 *  @see javax.swing.JComponent#paint
	 *  @see javax.swing.JComponent#setBorder
	 */
	@java.lang.Override
	protected void paintBorder(java.awt.Graphics g) {
	}

	/**
	 *  Set flag indicating that a batch of add-component or remove-component operations is taking place. Re-validate the
	 *  window when the flag is reset, indicating that the batch is complete.
	 * 
	 *  @param newChangingContainer true to indicate the container is being changed. False to indicate it stops
	 *                              changing.
	 */
	public void setChangingContainer(boolean newChangingContainer) {
	}

	public void validateWindowIfFloating() {
	}

	/**
	 *  Appends a separator of default size to the end of the CommandBar. The default size is determined by the current
	 *  look and feel.
	 */
	public void addSeparator() {
	}

	/**
	 *  Appends a separator of a specified size to the end of the CommandBar.
	 *  <p/>
	 *  In current implementation, we don't support different size separator, so this method is the same as {@link
	 *  #addSeparator()}.
	 * 
	 *  @param size the <code>Dimension</code> of the separator
	 */
	public void addSeparator(java.awt.Dimension size) {
	}

	/**
	 *  Adds a new <code>JButton</code> which dispatches the action.
	 *  <p/>
	 *  <p/>
	 *  As of 1.3, this is no longer the preferred method for adding <code>Action</code>s to a container.  Instead it is
	 *  recommended to configure a control with an action using using <code>setAction</code>, and then add that control
	 *  directly to the <code>Container</code>.
	 * 
	 *  @param a the <code>Action</code> object to add as a new menu item
	 *  @return the new button which dispatches the action
	 */
	public javax.swing.JComponent add(javax.swing.Action a) {
	}

	/**
	 *  Factory method which creates the <code>JButton</code> for <code>Action</code>s added to the
	 *  <code>CommandBar</code>. The default name is empty if a <code>null</code> action is passed.
	 *  <p/>
	 *  <p/>
	 *  As of 1.3, this is no longer the preferred method for adding <code>Action</code>s to a <code>Container</code>.
	 *  Instead it is recommended to configure a control with an action using <code>setAction</code>, and then add that
	 *  control directly to the <code>Container</code>.
	 * 
	 *  @param a the <code>Action</code> for the button to be added
	 *  @return the newly created button
	 * 
	 *  @see javax.swing.Action
	 */
	protected javax.swing.JComponent createActionComponent(javax.swing.Action a) {
	}

	/**
	 *  Returns a properly configured <code>PropertyChangeListener</code> which updates the control as changes to the
	 *  <code>Action</code> occur, or <code>null</code> if the default property change listener for the control is
	 *  desired.
	 *  <p/>
	 *  <p/>
	 *  As of 1.3, this is no longer the preferred method for adding <code>Action</code>s to a <code>Container</code>.
	 *  Instead it is recommended to configure a control with an action using <code>setAction</code>, and then add that
	 *  control directly to the <code>Container</code>.
	 * 
	 *  @param component the component
	 *  @return <code>null</code>
	 */
	protected java.beans.PropertyChangeListener createActionChangeListener(javax.swing.JComponent component) {
	}

	/**
	 *  Overrides superclass to handle special UIResources when they are added.
	 *  <p/>
	 *  There are three UIResource (gripper, title bar and chevron) being added to CommandBar in BasicCommandBarUI. To
	 *  keep it transparent to users, if the comp is an instance of UIResource, it will be added as usual. If it's not a
	 *  UIResource, it will be added at index + 3. Corresponding methods are changed too. For example, getMenuCount()
	 *  will return the actual getComponentCount() - 3. getMenu(int index) will return the actual component at index +
	 *  3.
	 * 
	 *  @param comp        the component to be enhanced
	 *  @param constraints the constraints to be enforced on the component
	 *  @param index       the index of the component
	 */
	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	/**
	 *  Checks if the menu bar is used as screen menu bar (on Mac OS X only).
	 * 
	 *  @param jMenuBar the JMenuBar
	 *  @return true if it will be used as screen menu bar. Otherwise, false.
	 */
	public static boolean isScreenMenuBar(javax.swing.JMenuBar jMenuBar) {
	}

	/**
	 *  Gets the preferred row count when the CommandBar is in floating mode.
	 * 
	 *  @return the preferred row count.
	 */
	public int getPreferredRowCount() {
	}

	/**
	 *  Sets the preferred row count when the CommandBar is in floating mode.
	 * 
	 *  @param preferredRowCount the preferred row count
	 */
	public void setPreferredRowCount(int preferredRowCount) {
	}

	/**
	 *  Gets an array of all hidden components.
	 * 
	 *  @return the array of all hidden components.
	 */
	public java.awt.Component[] getHiddenComponents() {
	}

	/**
	 *  Overridden to remove the component from the hiddenComponents list if it isn't in the components list.
	 * 
	 *  @param comp the component to be removed
	 */
	@java.lang.Override
	public void remove(java.awt.Component comp) {
	}

	/**
	 *  Overridden to remove the clear the hiddenComponents list as well as the components list.
	 */
	@java.lang.Override
	public void removeAll() {
	}

	/**
	 *  Removes all components from the hidden components list.
	 */
	public void removeAllHiddenComponents() {
	}

	/**
	 *  Returns the number of items in the menu bar. Since there are three UIResource (gripper, title bar and chevron)
	 *  being added to CommandBar in BasicCommandBarUI to keep it transparent to users, this method return the actual
	 *  component count - 3.
	 * 
	 *  @return the number of items in the menu bar
	 */
	@java.lang.Override
	public int getMenuCount() {
	}

	/**
	 *  Returns the menu at the specified position in the menu bar. Since there are three UIResource (gripper, title bar
	 *  and chevron) being added to CommandBar in BasicCommandBarUI to keep it transparent to users, this method return
	 *  the component whose actual index is index + 3.
	 * 
	 *  @param index an integer giving the position in the menu bar, where 0 is the first position
	 *  @return the <code>JMenu</code> at that position, or <code>null</code> if if there is no <code>JMenu</code> at
	 *          that position (ie. if it is a <code>JMenuItem</code>)
	 */
	@java.lang.Override
	public javax.swing.JMenu getMenu(int index) {
	}

	/**
	 *  adds a expansion component. Components added after the expansion will be aligned to the other end of command
	 *  bar.
	 *  <p/>
	 *  Expansion only has effect when the command bar is in stretched mode. A typical use case is for a menu bar. You
	 *  can add several menus, add a filter, then add Help menu. All menus before the expansion will align to the left
	 *  end. Help menu will be aligned to the right end.
	 *  <p/>
	 *  By default, we treat CommandBar.Expansion, a JTextField, a JComboBox as expandable by default. However, you can
	 *  use a client property called "CommandBar.expandable" to make any component expandable or not. If it is "true", we
	 *  return false. If "false" , we return false. Otherwise we return true only if the component is an instance of
	 *  CommandBar.Expansion, a JTextField, a JComboBox.
	 * 
	 *  @see #setStretch(boolean)
	 */
	public void addExpansion() {
	}

	@java.lang.Override
	public void adjustChildrenOrientation(int orientation) {
	}

	protected class CommandBarContainerListener {


		protected CommandBar.CommandBarContainerListener() {
		}

		public void componentAdded(java.awt.event.ContainerEvent e) {
		}

		public void componentRemoved(java.awt.event.ContainerEvent e) {
		}
	}

	/**
	 *  A filler component that can be added to CommandBar to push components after it to align to the other end.
	 */
	public static class Expansion {


		public CommandBar.Expansion() {
		}

		public boolean supportVerticalOrientation() {
		}

		public boolean supportHorizontalOrientation() {
		}

		public int getOrientation() {
		}

		public void setOrientation(int orientation) {
		}
	}
}
