/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  As command bars are around the border of top level windows, MainContainer is the rectangle area among those command
 *  bars.
 */
public class MainContainer extends javax.swing.JPanel {

	public MainContainer() {
	}

	@java.lang.Override
	public void updateUI() {
	}
}
