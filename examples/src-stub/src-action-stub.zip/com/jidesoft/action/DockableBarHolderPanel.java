/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  A JPanel which can be used as DockableBarHolder.
 */
public class DockableBarHolderPanel extends com.jidesoft.swing.ContentContainer implements DockableBarHolder {

	public DockableBarHolderPanel(javax.swing.RootPaneContainer container) {
	}

	protected DockableBarManager createDockableBarManager(javax.swing.RootPaneContainer container) {
	}

	public DockableBarManager getDockableBarManager() {
	}

	public void dispose() {
	}

	/**
	 *  DockableBarManager manages the layout and the content of DockableBarDockableHolderPanel so we override this
	 *  setLayout method to do nothing, so calling this method will have no effect.
	 * 
	 *  @param mgr
	 *  @since 2.7.2
	 */
	@java.lang.Override
	public void setLayout(java.awt.LayoutManager mgr) {
	}
}
