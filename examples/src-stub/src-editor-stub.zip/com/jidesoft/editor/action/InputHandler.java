/**
 *  The package contains classes for input handlers for JIDE Code Editor product.
 */
package com.jidesoft.editor.action;


/**
 *  An input handler converts the user's key strokes into concrete actions. It also takes care of macro recording and
 *  action repetition.<p>
 *  <p/>
 *  This class provides all the necessary support code for an input handler, but doesn't actually do any key binding
 *  logic. It is up to the implementations of this class to do so.
 * 
 *  @author Slava Pestov
 *  @version $Id: InputHandler.java,v 1.14 1999/12/13 03:40:30 sp Exp $
 *  @see com.jidesoft.editor.action.DefaultInputHandler
 *  <p/>
 *  08/12/2002	Clipboard actions	(Oliver Henning)
 */
public abstract class InputHandler extends java.awt.event.KeyAdapter {

	/**
	 *  Deletes a char before the caret if there is no selection. If there is a selection, delete all selected texts.
	 *  <p/>
	 *  The default keystroke for this action is Backspace.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#backspaceChar()
	 */
	public static final javax.swing.Action BACKSPACE;

	/**
	 *  Deletes from current caret to the start of the word if the caret is not at the start of the word or to the start
	 *  of the previous word if the caret is currently at the start of the word.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Backspace / Meta+Backspace.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#backspaceWord()
	 */
	public static final javax.swing.Action BACKSPACE_WORD;

	/**
	 *  Deletes a char at the caret if there is no selection. If there is a selection, delete all selected texts.
	 *  <p/>
	 *  The default keystroke for this action is Delete
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#deleteChar()
	 */
	public static final javax.swing.Action DELETE;

	/**
	 *  Deletes from current caret to the start of the next word.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Delete / Meta+Delete.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#deleteWord()
	 */
	public static final javax.swing.Action DELETE_WORD;

	/**
	 *  Deletes the entire line including line break associated with the line.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Delete.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#deleteLine()
	 */
	public static final javax.swing.Action DELETE_LINE;

	/**
	 *  Deletes current selected text if any then inserts a line break. It will also add empty spaces following the white
	 *  spaces in the previous line. The caret will be put in the first non-space character or the end of the new line.
	 *  <p/>
	 *  The default keystroke for this action is Enter.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#insertBreak()
	 */
	public static final javax.swing.Action INSERT_BREAK;

	/**
	 *  Deletes current selected text if any then inserts a line break. It will also add empty spaces following the white
	 *  spaces in the previous line. The caret will stay in the end of the current line.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Enter / Meta+Enter.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#splitLine()
	 */
	public static final javax.swing.Action SPLIT_LINE;

	/**
	 *  Inserts a line break after the end of the line where the caret is. It will also add empty spaces following the
	 *  white spaces in the previous line. Just clears selection and leaves the selected text no touch if there is any
	 *  selection. The caret will be put in the first non-space character or the end of the new line.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Enter.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#startNewLine()
	 */
	public static final javax.swing.Action START_NEW_LINE;

	/**
	 *  Indents all selected lines no matter if the selection is a line selection or not if there is a selection. If
	 *  there is no selection, a tab or several white spaces will be inserted at the caret position.
	 *  <p/>
	 *  The default keystroke for this action is Tab.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#indentSelection()
	 */
	public static final javax.swing.Action INDENT_SELECTION;

	/**
	 *  Indents all selected lines no matter if the selection is a line selection or not if there is a selection. If
	 *  there is no selection, the line where the caret resides will be unindented.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Tab.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#unindentSelection()
	 */
	public static final javax.swing.Action UNINDENT_SELECTION;

	/**
	 *  Joins all selected lines by deleting line breaks and the empty spaces leading the lines. If there is no
	 *  selection, the line where the caret resides and the next line will be joined. The current selection should be
	 *  kept and the caret will be moved to where the last join happens.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+J / Meta+Shift+J.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#joinLines()
	 */
	public static final javax.swing.Action JOIN_LINES;

	/**
	 *  Moves the caret to the end of the line where the caret resides and clears current selection.
	 *  <p/>
	 *  The default keystroke for this action is End.
	 * 
	 *  @see CodeEditor#moveToLineEnd(boolean)
	 */
	public static final javax.swing.Action END;

	/**
	 *  Moves the caret to the end of the document.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+End / Meta+End.
	 * 
	 *  @see CodeEditor#moveToDocumentEnd(boolean)
	 */
	public static final javax.swing.Action DOCUMENT_END;

	/**
	 *  Selects all text in the document.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+A / Meta+A.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#selectAll()
	 */
	public static final javax.swing.Action SELECT_ALL;

	/**
	 *  Extends selection from current caret position to the end of the line where the caret resides.
	 *  <p/>
	 *  The default keystroke for this action is Shift+End.
	 * 
	 *  @see CodeEditor#moveToLineEnd(boolean)
	 */
	public static final javax.swing.Action SELECT_END;

	/**
	 *  Extends selection from current caret position to the end of the document.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+End / Meta+Shift+End.
	 * 
	 *  @see CodeEditor#moveToDocumentEnd(boolean)
	 */
	public static final javax.swing.Action SELECT_DOC_END;

	/**
	 *  Moves the caret to the start of the line where the caret resides.
	 *  <p/>
	 *  The default keystroke for this action is Home.
	 * 
	 *  @see CodeEditor#moveToLineStart(boolean)
	 */
	public static final javax.swing.Action HOME;

	/**
	 *  Moves the caret to the start of the document.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Home / Meta+Home.
	 * 
	 *  @see CodeEditor#moveToDocumentStart(boolean)
	 */
	public static final javax.swing.Action DOCUMENT_HOME;

	/**
	 *  Extends selection from current caret position to the start of the line where the caret resides.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Home.
	 * 
	 *  @see CodeEditor#moveToLineStart(boolean)
	 */
	public static final javax.swing.Action SELECT_HOME;

	/**
	 *  Extends selection from current caret position to the end of the document.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Home / Meta+Shift+Home.
	 * 
	 *  @see CodeEditor#moveToDocumentStart(boolean)
	 */
	public static final javax.swing.Action SELECT_DOC_HOME;

	/**
	 *  Moves the caret to the next column if {@link CodeEditor#isVirtualSpaceAllowed()} is true. Otherwise moves the
	 *  caret to the next char excluding line breaks.
	 *  <p/>
	 *  The default keystroke for this action is Right.
	 * 
	 *  @see CodeEditor#moveToNextChar(boolean)
	 */
	public static final javax.swing.Action NEXT_CHAR;

	/**
	 *  Moves the caret to the next line. The column may change if {@link CodeEditor#isVirtualSpaceAllowed()} is false.
	 *  <p/>
	 *  The default keystroke for this action is Down.
	 * 
	 *  @see CodeEditor#moveToNextLine(boolean)
	 */
	public static final javax.swing.Action NEXT_LINE;

	/**
	 *  Moves the caret to the next page. The column may change if {@link CodeEditor#isVirtualSpaceAllowed()} is false.
	 *  <p/>
	 *  The default keystroke for this action is Pgdn.
	 * 
	 *  @see CodeEditor#moveToNextPage(boolean)
	 */
	public static final javax.swing.Action NEXT_PAGE;

	/**
	 *  Moves the caret to the word start of the next word.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Right / Meta+Right.
	 * 
	 *  @see CodeEditor#moveToNextWord(boolean)
	 */
	public static final javax.swing.Action NEXT_WORD;

	/**
	 *  Extends selection from current caret position to the next column if {@link CodeEditor#isVirtualSpaceAllowed()} is
	 *  true. Otherwise extends selection to the next char excluding line breaks.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Right.
	 * 
	 *  @see CodeEditor#moveToNextChar(boolean)
	 */
	public static final javax.swing.Action SELECT_NEXT_CHAR;

	/**
	 *  Extends selection from current caret position to the next line.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Down.
	 * 
	 *  @see CodeEditor#moveToNextLine(boolean)
	 */
	public static final javax.swing.Action SELECT_NEXT_LINE;

	/**
	 *  Extends selection from current caret position to the next page.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Pgdn.
	 * 
	 *  @see CodeEditor#moveToNextPage(boolean)
	 */
	public static final javax.swing.Action SELECT_NEXT_PAGE;

	/**
	 *  Extends selection from current caret position to the word start of the next word.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Right / Meta+Shift+Right.
	 * 
	 *  @see CodeEditor#moveToNextWord(boolean)
	 */
	public static final javax.swing.Action SELECT_NEXT_WORD;

	/**
	 *  Toggles the editing mode between overwrite and insert. The caret will change accordingly.
	 *  <p/>
	 *  The default keystroke for this action is Insert.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#toggleOverwrite()
	 */
	public static final javax.swing.Action OVERWRITE;

	/**
	 *  Moves the caret to the previous column or stay at column 0 if {@link CodeEditor#isVirtualSpaceAllowed()} is true.
	 *  Otherwise moves the caret to the previous char excluding line breaks.
	 *  <p/>
	 *  The default keystroke for this action is Left.
	 * 
	 *  @see CodeEditor#moveToPreviousChar(boolean)
	 */
	public static final javax.swing.Action PREV_CHAR;

	/**
	 *  Moves the caret to the previous line. The column may change if {@link CodeEditor#isVirtualSpaceAllowed()} is
	 *  false.
	 *  <p/>
	 *  The default keystroke for this action is Up.
	 * 
	 *  @see CodeEditor#moveToPreviousLine(boolean)
	 */
	public static final javax.swing.Action PREV_LINE;

	/**
	 *  Moves the caret to the previous page. The column may change if {@link CodeEditor#isVirtualSpaceAllowed()} is
	 *  false.
	 *  <p/>
	 *  The default keystroke for this action is Pgup.
	 * 
	 *  @see CodeEditor#moveToPreviousPage(boolean)
	 */
	public static final javax.swing.Action PREV_PAGE;

	/**
	 *  Moves caret to the the word start of the current word if the caret is not on the start of the current word or to
	 *  the word start of the previous word if the caret is on the start of the current word.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Left / Meta+Left.
	 * 
	 *  @see CodeEditor#moveToPreviousWord(boolean)
	 */
	public static final javax.swing.Action PREV_WORD;

	/**
	 *  Shows a dialog so that the customer could input a line number then jump to the line.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+G / Meta+G.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#promptGotoLine()
	 */
	public static final javax.swing.Action GOTO_LINE;

	/**
	 *  Shows a find and replace dialog to let the customer input searching text then search the text in the document or
	 *  the current selected text.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+F / Meta+F.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#find()
	 */
	public static final javax.swing.Action FIND;

	/**
	 *  Looks for the next match in the document or the current selected text.
	 *  <p/>
	 *  The default keystroke for this action is F3.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#findNext()
	 */
	public static final javax.swing.Action FIND_NEXT;

	/**
	 *  Looks for the previous match in the document or the current selected text.
	 *  <p/>
	 *  The default keystroke for this action is Shift+F3.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#findPrevious()
	 */
	public static final javax.swing.Action FIND_PREVIOUS;

	/**
	 *  Shows a find and replace dialog to let the customer input searching text then search the text in the document or
	 *  the current selected text.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+R / Meta+R.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#replace()
	 */
	public static final javax.swing.Action REPLACE;

	/**
	 *  Shows a Searchable popup to start searching quickly.
	 *  <p/>
	 *  The default keystroke for this action is Alt+F3.
	 * 
	 *  @see CodeEditor#quickSearch(String)
	 */
	public static final javax.swing.Action QUICK_SEARCH;

	/**
	 *  Extends selection from current caret position to the previous column or stay at column 0 if {@link
	 *  CodeEditor#isVirtualSpaceAllowed()} is true. Otherwise extends selection to the previous char excluding line
	 *  breaks.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Left.
	 * 
	 *  @see CodeEditor#moveToNextChar(boolean)
	 */
	public static final javax.swing.Action SELECT_PREV_CHAR;

	/**
	 *  Extends selection from current caret position to the previous line.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Up.
	 * 
	 *  @see CodeEditor#moveToPreviousLine(boolean)
	 */
	public static final javax.swing.Action SELECT_PREV_LINE;

	/**
	 *  Extends selection from current caret position to the next page.
	 *  <p/>
	 *  The default keystroke for this action is Shift+Pgup.
	 * 
	 *  @see CodeEditor#moveToPreviousPage(boolean)
	 */
	public static final javax.swing.Action SELECT_PREV_PAGE;

	/**
	 *  Extends selection from current caret position to the word start of the current word if the caret is not on the
	 *  start of the current word or to the word start of the previous word if the caret is on the start of the current
	 *  word.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Left / Meta+Shift+Left.
	 * 
	 *  @see CodeEditor#moveToPreviousWord(boolean)
	 */
	public static final javax.swing.Action SELECT_PREV_WORD;

	/**
	 *  Selects the word in current caret position.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+W / Meta+W.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#selectWord()
	 */
	public static final javax.swing.Action SELECT_WORD;

	/**
	 *  Selects the block between the closest pair of brackets which contains current caret.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+B / Meta+B.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#selectToMatchingBracket()
	 */
	public static final javax.swing.Action SELECT_TO_MATCHING_BRACKET;

	public static final javax.swing.Action REPEAT;

	/**
	 *  Toggles selection mode between normal selection mode and column selection mode.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+\ / Alt+Shift+Insert.
	 * 
	 *  @see com.jidesoft.editor.selection.SelectionModel#setColumnSelectionMode(boolean)
	 */
	public static final javax.swing.Action TOGGLE_RECT;

	/**
	 *  Inserts the selected text to the start of the current selection. Keeps the current selection and the current
	 *  caret position. If there is no selection, the current line will be duplicated.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+D / Meta+D.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#duplicateSelection()
	 */
	public static final javax.swing.Action DUPLICATE_SELECTION;

	/**
	 *  Comments all selected lines using line comments no matter if the selection is a line selection or not if there is
	 *  a selection. If there is no selection, the line where the caret resides will be commented.
	 *  <p/>
	 *  It works only if you use LanguageSpec's configureCodeEditor to configure a CodeEditor. Otherwise it doesn't know
	 *  what line comment string to use.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Slash / Meta+Slash.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#lineComments()
	 */
	public static final javax.swing.Action LINE_COMMENTS;

	/**
	 *  Comments the selected text using block comments. It works only if you use LanguageSpec's configureCodeEditor to
	 *  configure a CodeEditor. Otherwise it doesn't know what block comment string to use.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Slash / Meta+Shift+Slash.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#blockComments()
	 */
	public static final javax.swing.Action BLOCK_COMMENTS;

	/**
	 *  Places the selected text into the clipboard. If there is no selection, selects the current line then places the
	 *  selected line into the clipboard.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+C / Meta+C.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#clipboardCopy()
	 */
	public static final javax.swing.Action CLIP_COPY;

	/**
	 *  Inserts the clipboard contents into the document. Deletes current selected text first if there is any.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+V / Meta+V.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#clipboardPaste()
	 */
	public static final javax.swing.Action CLIP_PASTE;

	/**
	 *  Shows a dialog so that the customer could choose text from the clipboard contents to paste.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+V / Meta+Shift+V.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#pasteWithDialog()
	 */
	public static final javax.swing.Action CLIP_PASTE_WITH_DIALOG;

	/**
	 *  Deletes the selected text from the text area and places it into the clipboard. If there is no selection, the
	 *  current line where the caret resides will be selected and deleted and placed into the clipboard.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+X / Meta+X.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#clipboardCut()
	 */
	public static final javax.swing.Action CLIP_CUT;

	/**
	 *  Undo the last action (if possible).
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Z / Meta+Z.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#undo()
	 */
	public static final javax.swing.Action UNDO;

	/**
	 *  Redo the last action (if possible).
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Z / Meta+Shift+Z.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#redo()
	 */
	public static final javax.swing.Action REDO;

	/**
	 *  If there is no folding and has selection, the selected text will be folded and shown as "...". If the entire
	 *  folded texts are selected, the folding will be removed. If there is no folding and no selection, do nothing.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Period / Meta+Period.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#toggleFoldingSelection()
	 */
	public static final javax.swing.Action FOLD_SELECTION;

	/**
	 *  Expands the folded span if any.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Equals / Meta+Equals.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#expandFolding()
	 */
	public static final javax.swing.Action EXPAND_FOLDING;

	/**
	 *  Collapses the expanded span if any.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Minus / Meta+Minus.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#collapseFolding()
	 */
	public static final javax.swing.Action COLLAPSE_FOLDING;

	/**
	 *  Expands all folded spans.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Equals / Meta+Shift+Equals.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#expandAll()
	 */
	public static final javax.swing.Action EXPAND_ALL;

	/**
	 *  Collapses all expanded spans.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+Minus / Meta+Shift+Minus.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#collapseAll()
	 */
	public static final javax.swing.Action COLLAPSE_ALL;

	/**
	 *  Inserts the string into the document. Deletes the selected text first if there is a selection.
	 *  <p/>
	 *  This is the default action for any other key strokes if the action for that key stroke is not defined.
	 * 
	 *  @see CodeEditor#insertChar(String)
	 */
	public static final javax.swing.Action INSERT_CHAR;

	/**
	 *  Toggles the case when typing an alphabetic char.
	 *  <p/>
	 *  The default keystroke for this action is Ctrl+Shift+U / Meta+Shift+U.
	 * 
	 *  @see com.jidesoft.editor.CodeEditor#toggleCase()
	 */
	public static final javax.swing.Action TOGGLE_CASE;

	/**
	 *  Clears the selection if any. If there is no selection, clears any highlights. If there is no selection and
	 *  highlights, does nothing.
	 *  <p/>
	 *  The default keystroke for this action is Escape.
	 */
	public static final javax.swing.Action ESCAPE;

	protected static final java.util.Hashtable ACTIONS;

	protected javax.swing.Action _grabAction;

	protected boolean _repeat;

	protected int _repeatCount;

	protected InputHandler.MacroRecorder recorder;

	public InputHandler() {
	}

	protected static void initDefaultActions() {
	}

	/**
	 *  Adds an action to editor's action map.
	 * 
	 *  @param name   the name of the action. It must be unique. Otherwise, it will overwrite the previous action with
	 *                the same name.
	 *  @param action the action listener.
	 */
	public static void addAction(String name, javax.swing.Action action) {
	}

	/**
	 *  Adds an action to editor's action map.
	 * 
	 *  @param action the action. The name of the action must be unique. Otherwise, it will overwrite the previous action
	 *                with the same name.
	 */
	public static void addAction(javax.swing.Action action) {
	}

	/**
	 *  Removes the action.
	 * 
	 *  @param name the name of the action.
	 */
	public static void removeAction(String name) {
	}

	/**
	 *  Returns a named text area action.
	 * 
	 *  @param name the action name
	 *  @return the action.
	 */
	public static javax.swing.Action getAction(String name) {
	}

	/**
	 *  Returns the name of the specified text area action.
	 * 
	 *  @param listener the action listener
	 *  @return the action name.
	 */
	public static String getActionName(java.awt.event.ActionListener listener) {
	}

	/**
	 *  Gets the actions.
	 * 
	 *  @return an enumeration of all available actions.
	 */
	public static java.util.Enumeration getActions() {
	}

	/**
	 *  Handle a key pressed event. This will look up the binding for the key stroke and execute it.
	 */
	@java.lang.Override
	public void keyPressed(java.awt.event.KeyEvent evt) {
	}

	/**
	 *  Handle a key typed event. This inserts the key into the text area.
	 */
	@java.lang.Override
	public void keyTyped(java.awt.event.KeyEvent evt) {
	}

	/**
	 *  Finds the action associated with the keystroke.
	 * 
	 *  @param keyStroke the keystroke
	 *  @return the action associated with the keystroke.
	 */
	public abstract Object findAction(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Grabs the next key typed event and invokes the specified action with the key as a the action command.
	 * 
	 *  @param listener The action
	 */
	public void grabNextKeyStroke(javax.swing.Action listener) {
	}

	/**
	 *  Returns if repeating is enabled. When repeating is enabled, actions will be executed multiple times. This is
	 *  usually invoked with a special key stroke in the input handler.
	 * 
	 *  @return true or false.
	 */
	public boolean isRepeatEnabled() {
	}

	/**
	 *  Enables repeating. When repeating is enabled, actions will be executed multiple times. Once repeating is enabled,
	 *  the input handler should read a number from the keyboard.
	 * 
	 *  @param repeat the flag
	 */
	public void setRepeatEnabled(boolean repeat) {
	}

	/**
	 *  Returns the number of times the next action will be repeated.
	 * 
	 *  @return the count.
	 */
	public int getRepeatCount() {
	}

	/**
	 *  Sets the number of times the next action will be repeated.
	 * 
	 *  @param repeatCount The repeat count
	 */
	public void setRepeatCount(int repeatCount) {
	}

	/**
	 *  If this is non-null, all executed actions should be forwarded to the recorder.
	 * 
	 *  @return the macro recorder.
	 */
	public InputHandler.MacroRecorder getMacroRecorder() {
	}

	/**
	 *  Sets the macro recorder. If this is non-null, all executed actions should be forwarded to the recorder.
	 * 
	 *  @param recorder The macro recorder
	 */
	public void setMacroRecorder(InputHandler.MacroRecorder recorder) {
	}

	/**
	 *  Executes the specified action, repeating and recording it as necessary.
	 * 
	 *  @param listener      The action listener
	 *  @param source        The event source
	 *  @param actionCommand The action command
	 */
	public boolean executeAction(javax.swing.Action listener, Object source, String actionCommand) {
	}

	/**
	 *  Returns the text area that fired the specified event.
	 * 
	 *  @param evt The event
	 *  @return the CodeEditor.
	 */
	public static com.jidesoft.editor.CodeEditor getCodeEditor(java.util.EventObject evt) {
	}

	/**
	 *  If a key is being grabbed, this method should be called with the appropriate key event. It executes the grab
	 *  action with the typed character as the parameter.
	 * 
	 *  @param evt the key event
	 */
	protected void handleGrabAction(java.awt.event.KeyEvent evt) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String modifySelectionOnPaste(com.jidesoft.editor.CodeEditor syntaxArea, String selection) {
	}

	/**
	 *  If an action implements this interface, it should not be repeated. Instead, it will handle the repetition
	 *  itself.
	 */
	public static interface class NonRepeatable {

	}

	/**
	 *  If an action implements this interface, it should not be recorded by the macro recorder. Instead, it will do its
	 *  own recording.
	 */
	public static interface class NonRecordable {

	}

	/**
	 *  For use by EditAction.Wrapper only.
	 * 
	 *  @since jEdit 2.2final
	 */
	public static interface class Wrapper {

	}

	/**
	 *  Macro recorder.
	 */
	public static interface class MacroRecorder {


		public void actionPerformed(javax.swing.Action listener, String actionCommand) {
		}
	}
}
