/**
 *  The package contains classes for input handlers for JIDE Code Editor product.
 */
package com.jidesoft.editor.action;


/**
 *  The default input handler. It maps sequences of keystrokes into actions and inserts key typed
 *  events into the text area. Internally, it used ShortcutSchemaManager from JIDE Shortcut Editor to
 *  define all the shortcuts. By default, there are two ShortcutSchemas - one is the default one,
 *  EditorShortcutSchema; the other is MacOSXEditorShortcutSchema for Mac OSX.
 * 
 *  @author Slava Pestov
 *  @version $Id: DefaultInputHandler.java,v 1.2 2003/11/22 03:39:20 bradford Exp $
 */
public class DefaultInputHandler extends InputHandler {

	protected ShortcutSchemaManager _shortcutSchemaManager;

	/**
	 *  Creates a new input handler with no key bindings defined.
	 */
	public DefaultInputHandler() {
	}

	/**
	 *  Finds the action associated with the keystroke.
	 * 
	 *  @param keyStroke the keystroke
	 * 
	 *  @return the action associated with the keystroke.
	 */
	@java.lang.Override
	public Object findAction(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Gets the ShortcutSchemaManager used by this DefaultInputHandler.
	 * 
	 *  @return the ShortcutSchemaManager.
	 */
	public ShortcutSchemaManager getShortcutSchemaManager() {
	}

	/**
	 *  Sets the the ShortcutSchemaManager.
	 * 
	 *  @param shortcutSchemaManager a new ShortcutSchemaManager.
	 */
	public void setShortcutSchemaManager(ShortcutSchemaManager shortcutSchemaManager) {
	}
}
