/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  The TransferHandler for CodeEditor.
 * 
 *  @since 3.5.11
 */
public class CodeEditorTransferHandler extends javax.swing.TransferHandler implements javax.swing.plaf.UIResource {

	protected CodeEditorTransferHandler(CodeEditor editor) {
	}

	/**
	 *  Create a Transferable to use as the source for a data transfer.
	 * 
	 *  @param c The component holding the data to be transferred.  This argument is provided to enable sharing of
	 *           TransferHandlers by multiple components.
	 *  @return The representation of the data to be transferred.
	 */
	@java.lang.Override
	protected java.awt.datatransfer.Transferable createTransferable(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public boolean canImport(javax.swing.JComponent c, java.awt.datatransfer.DataFlavor[] transferFlavors) {
	}

	@java.lang.Override
	public boolean importData(javax.swing.JComponent comp, java.awt.datatransfer.Transferable t) {
	}

	@java.lang.Override
	public int getSourceActions(javax.swing.JComponent c) {
	}
}
