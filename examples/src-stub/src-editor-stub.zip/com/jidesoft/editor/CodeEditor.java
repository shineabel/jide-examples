/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  CodeEditor is a text component for source code viewing and editing.
 *  <p/>
 *  It contains <code>CodeEditorPainter</code> as its major area to display/edit the code. If you want to add mouse
 *  listener, please make sure you invoke <code>yourCodeEditor.getPainter().addMouseListener()</code>. Same rule applies
 *  to mouse motion listeners and key listeners.
 *  <p/>
 *  On the left of the major edit area, it's margin area panel, you could invoke {@link #getMarginArea()} to get the
 *  panel and add new margin area to it. By default, we added {@link RowNumberMargin} to the left, you could add other
 *  margin components to that area if you want to customize it to have something like break point, bookmark, etc. You
 *  could invoke {@link #setLineNumberVisible(boolean)} to make the default line number margin invisible.
 *  <p/>
 *  Each CodeEditor could define a single {@link com.jidesoft.editor.marker.MarkerArea}. It's not part of the CodeEditor.
 *  However, usually you would layout it on the right of the major edit area and the vertical scroll bar. With the help
 *  of MarkerArea, you would be able to add some parse information to that area to indicate wrong input or warning
 *  information. Please check out <code>PhpSyntaxParsingDemo</code> for the detail implementations.
 *  <p/>
 *  To help searching inside the CodeEditor, CodeEditor provides two solutions. One is integrated {@link
 *  com.jidesoft.search.FindAndReplace} which could be triggered with CTRL+F. That will provide REGEX searching or normal
 *  wildcard searching options. Another searching option is the uninstallable {@link
 *  com.jidesoft.editor.CodeEditorSearchable}. You could find the detail implementation at <code>CodeEditorDemo</code>
 *  <p/>
 *  Please invoke {@link #getHighlighter()} to highlight some part of your target documents if necessary.
 *  <p/>
 *  Sometimes, the customers may need to collapse several parts of code to help reviewing or editing. In this case, you
 *  may utilize {@link #getFoldingModel()} and invoke {@link com.jidesoft.editor.folding.FoldingModel#addFoldingSpan(int,
 *  int, String)} to add the folding spans. As long as you define your folding spans with initial index, CodeEditor will
 *  update the indices appropriately based on the recent character inputs. You could leverage {@link
 *  com.jidesoft.editor.margin.CodeFoldingMargin} to help your customer gain a better sense of where the code folding is.
 *  Please be noted that, so far if you allow tabs in your document, this feature would behave incorrectly. We will fix
 *  this issue in later releases.
 *  <p/>
 *  Please invoke {@link #setTokenMarker(com.jidesoft.editor.tokenmarker.TokenMarker)} to set your customized token
 *  marker. JIDE provided several default TokenMakers for your quick use.
 *  <p/>
 *  Please invoke {@link #getInputHandler()} to get the InputHandler instance. If you want to change the default key
 *  combinations, you would need access that class.
 *  <p/>
 *  In normal cases, please just invoke {@link #setText(String)} to feed CodeEditor the string to review or edit. Please
 *  invoke {@link #getText()} to get current string in the memory after editing to output. However, if you are reviewing
 *  or editing a large document and worry about the memory, please invoke {@link #setFileName(String)} )} to feed
 *  CodeEditor with strings from the input stream. In this case, CodeEditor will utilize {@link
 *  com.jidesoft.editor.LazyLoadDocument} to load the file page by page to save the memory. You would need invoke {@link
 *  #exportToOutputStream(java.io.OutputStream)} to output the string after editing. If you do have a large file, please
 *  try not to invoke {@link #getText()}. Otherwise, it may cause heap memory used up.
 * 
 *  @author Slava Pestov
 *  @author JIDE Software, Inc.
 */
public class CodeEditor extends javax.swing.JComponent implements selection.SelectionListener, caret.CaretListener, java.beans.PropertyChangeListener, com.jidesoft.search.FindResultIntepreter, LineBreak {

	/**
	 *  Adding components with this name to the text area will place them left of the horizontal scroll bar.
	 */
	public static String LEFT_OF_SCROLLBAR;

	public static final String PROPERTY_OVERWRITE_ENABLED = "overwriteEnabled";

	public static final String PROPERTY_FIRST_LINE = "firstLine";

	public static final String PROPERTY_VISIBLE_LINES = "visibleLines";

	public static final String PROPERTY_COLUMN_SELECTION_ENABLED = "columnSelectionEnabled";

	public margin.MarginArea _marginArea;

	public RowNumberMargin _lineNumberMargin;

	protected static java.util.List _clipboards;

	public Searchable _searchable;

	public javax.swing.Timer _inspectionTimer;

	protected CodeEditorSettings _defaultSettings;

	protected DefaultCodeEditorSettings _localSettings;

	public static final String PROPERTY_EDITABLE = "editable";

	protected static String CENTER;

	protected static String RIGHT;

	protected static String LEFT;

	protected static String BOTTOM;

	/**
	 *  @deprecated no longer use static field to track the CodeEditor that has focus.
	 */
	@java.lang.Deprecated
	protected static CodeEditor focusedComponent;

	/**
	 *  @deprecated no longer use static field to start one timer for all CodeEditors. Each CodeEditor manages its own
	 *  timer.
	 */
	@java.lang.Deprecated
	protected static javax.swing.Timer caretTimer;

	protected CodeEditorPainter _painter;

	protected boolean _caretVisible;

	protected boolean _editable;

	protected CodeEditorSettings _settings;

	protected int _firstLine;

	protected int _visibleLines;

	protected int _horizontalOffset;

	protected javax.swing.JScrollBar _verticalScrollBar;

	protected javax.swing.JScrollBar _horizontalScrollBar;

	protected boolean _scrollBarsInitialized;

	protected SyntaxDocument _document;

	protected CodeEditor.DocumentHandler _documentHandler;

	protected javax.swing.event.UndoableEditListener _undoableEditListener;

	public javax.swing.text.Segment lineSegment;

	protected boolean biasLeft;

	/**
	 *  Model column of the bracket.
	 */
	protected int bracketPosition;

	/**
	 *  Model line of the bracket.
	 */
	protected int bracketLine;

	/**
	 *  Magic caret in X.
	 */
	protected int _magicCaret;

	protected boolean _overwrite;

	protected caret.CaretModel _caretModel;

	protected selection.SelectionModel _selectionModel;

	public static final String PROPERTY_TAB_SIZE = "tabSize";

	public static final String PROPERTY_REPLACE_TAB_WITH_SPACE = "replaceTabWithSpace";

	public static final String PROPERTY_LINE_BREAK_STYLE = "lineBreakStyle";

	public static final String PROPERTY_MAX_NUMBER_OF_CLIPBOARDS = "maxNumberOfClipboards";

	public static final String SMART_HOME_END_PROPERTY = "InputHandler.homeEnd";

	/**
	 *  Creates a new CodeEditor with the default settings.
	 */
	public CodeEditor() {
	}

	/**
	 *  Creates a new CodeEditor with the specified settings.
	 * 
	 *  @param defaults The default settings
	 */
	public CodeEditor(DefaultSettings defaults) {
	}

	/**
	 *  Creates a <code>Searchable</code> for the <code>CodeEditor</code>.
	 * 
	 *  @param editor the <code>CodeEditor</code>.
	 * 
	 *  @return a <code>Searchable</code> for <code>CodeEditor</code>.
	 */
	protected Searchable createSearchable(CodeEditor editor) {
	}

	/**
	 *  Swaps the left and right component. By default, we have MarginArea on the left hand side and vertical scrollbar
	 *  on the right hand side. This swap method will swap the two components and put MarginArea to the right side and
	 *  the vertical scroll bar to the left side.
	 */
	public void swap() {
	}

	protected CodeEditorPainter createCodeEditorPainter(CodeEditor editor) {
	}

	/**
	 *  Creates the default TransferHandler.
	 * 
	 *  @return the created TransferHandler instance.
	 * 
	 *  @since 3.4.7
	 */
	protected javax.swing.TransferHandler createDefaultTransferHandler() {
	}

	/**
	 *  Creates the scroll bars used by the CodeEditor. There are two of them - one vertical and the other horizontal.
	 * 
	 *  @param orientation the orientation of the scroll bar.
	 * 
	 *  @return the scroll bar.
	 */
	protected javax.swing.JScrollBar createScrollBar(int orientation) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	@java.lang.Override
	public javax.swing.TransferHandler getTransferHandler() {
	}

	/**
	 *  Returns the syntax styles used to paint colorized text. Entry <i>n</i> will be used to paint tokens with id =
	 *  <i>n</i>.
	 * 
	 *  @return return the syntax styles.
	 * 
	 *  @see Token
	 */
	public final SyntaxStyleSchema getStyles() {
	}

	/**
	 *  Sets the syntax styles used to paint colorized text. Entry <i>n</i> will be used to paint tokens with id =
	 *  <i>n</i>.
	 * 
	 *  @param styles The syntax styles
	 * 
	 *  @see Token
	 */
	public final void setStyles(SyntaxStyleSchema styles) {
	}

	/**
	 *  Returns the caret color.
	 * 
	 *  @return the caret color.
	 */
	public final java.awt.Color getCaretColor() {
	}

	/**
	 *  Sets the caret color.
	 * 
	 *  @param caretColor The caret color
	 */
	public final void setCaretColor(java.awt.Color caretColor) {
	}

	/**
	 *  Returns the selection color.
	 * 
	 *  @return the selection color.
	 */
	public final java.awt.Color getSelectionColor() {
	}

	/**
	 *  Sets the selection color.
	 * 
	 *  @param selectionColor The selection color
	 */
	public final void setSelectionColor(java.awt.Color selectionColor) {
	}

	/**
	 *  Returns the line highlight color.
	 * 
	 *  @return the line highlight color.
	 */
	public final java.awt.Color getLineHighlightColor() {
	}

	/**
	 *  Sets the line highlight color.
	 * 
	 *  @param lineHighlightColor The line highlight color
	 */
	public final void setLineHighlightColor(java.awt.Color lineHighlightColor) {
	}

	/**
	 *  Checks if the line highlight is visible.
	 * 
	 *  @return true if line highlight is enabled, false otherwise.
	 */
	public final boolean isLineHighlightVisible() {
	}

	/**
	 *  Enables or disables current line highlighting.
	 * 
	 *  @param lineHighlight True if current line highlight should be enabled, false otherwise
	 */
	public final void setLineHighlight(boolean lineHighlight) {
	}

	/**
	 *  Returns the bracket highlight color.
	 * 
	 *  @return the bracket highlight color.
	 */
	public final java.awt.Color getBracketHighlightColor() {
	}

	/**
	 *  Sets the bracket highlight color.
	 * 
	 *  @param bracketHighlightColor The bracket highlight color
	 */
	public final void setBracketHighlightColor(java.awt.Color bracketHighlightColor) {
	}

	/**
	 *  Checks if the bracket highlight is visible.
	 * 
	 *  @return true if bracket highlighting is enabled, false otherwise. When bracket highlighting is enabled, the
	 *  bracket matching the one before the caret (if any) is highlighted.
	 */
	public final boolean isBracketHighlightVisible() {
	}

	/**
	 *  Enables or disables bracket highlighting. When bracket highlighting is enabled, the bracket matching the one
	 *  before the caret (if any) is highlighted.
	 * 
	 *  @param bracketHighlight True if bracket highlighting should be enabled, false otherwise
	 */
	public final void setBracketHighlightVisible(boolean bracketHighlight) {
	}

	/**
	 *  Checks if the block caret is used. By default the caret is drawn as one vertical line. If the flag returns true,
	 *  a block will be used as caret.
	 * 
	 *  @return true if the caret should be drawn as a block, false otherwise.
	 */
	public final boolean isBlockCaret() {
	}

	/**
	 *  Sets if the caret should be drawn as a block, false otherwise.
	 * 
	 *  @param blockCaret True if the caret should be drawn as a block, false otherwise.
	 */
	public final void setBlockCaret(boolean blockCaret) {
	}

	/**
	 *  Returns true if the caret is blinking, false otherwise.
	 * 
	 *  @return true if the caret should blink. Otherwise false.
	 */
	public final boolean isCaretBlinks() {
	}

	/**
	 *  Toggles caret blinking.
	 * 
	 *  @param caretBlinks True if the caret should blink, false otherwise
	 */
	public void setCaretBlinks(boolean caretBlinks) {
	}

	/**
	 *  Returns the special characters such as space, tab and end of line color.
	 * 
	 *  @return the color of special characters.
	 */
	public final java.awt.Color getSpecialCharactersColor() {
	}

	/**
	 *  Sets the special characters such as space, tab and end of line color.
	 * 
	 *  @param specialCharactersColor The EOL marker color
	 */
	public final void setSpecialCharactersColor(java.awt.Color specialCharactersColor) {
	}

	/**
	 *  Get the flag indicating if the special characters are visible.
	 * 
	 *  @return true if special characters such as space, tab and end of line are drawn, false otherwise.
	 */
	public final boolean isSpecialCharactersVisible() {
	}

	/**
	 *  Sets if special characters such as space, tab and end of line are to be drawn.
	 * 
	 *  @param visible True if special characters such as space, tab and end of line should be drawn, false otherwise
	 */
	public final void setSpecialCharactersVisible(boolean visible) {
	}

	/**
	 *  Get the paint invalid flag.
	 * 
	 *  @return true if invalid lines are painted as red tildes (~). Otherwise false.
	 */
	public boolean isPaintInvalid() {
	}

	/**
	 *  Sets if invalid lines are to be painted as red tildes.
	 * 
	 *  @param paintInvalid True if invalid lines should be drawn, false otherwise
	 */
	public void setPaintInvalid(boolean paintInvalid) {
	}

	public boolean isVirtualSpaceAllowed() {
	}

	public void setVirtualSpaceAllowed(boolean virtualSpaceAllowed) {
	}

	public com.jidesoft.marker.MarkerArea getMarkerArea() {
	}

	public void setMarkerArea(com.jidesoft.marker.MarkerArea markerArea) {
	}

	/**
	 *  setPainter must be called first
	 * 
	 *  @param defaults the default settings
	 */
	public void initializeDefaultSettings(DefaultSettings defaults) {
	}

	public void addCodeInspector(CodeInspector inspector) {
	}

	public void removeCodeInspector(CodeInspector inspector) {
	}

	public CodeInspector[] getCodeInspectors() {
	}

	public int getCodeInspectorCount() {
	}

	public CodeInspector getCodeInspector(int i) {
	}

	/**
	 *  Check if autoInspecting is on. If it is on, the inspection will be triggered automatically when document
	 *  changes.
	 * 
	 *  @return the true if autoInspecting is on. Other returns false.
	 */
	public boolean isAutoInspecting() {
	}

	/**
	 *  Sets autoInspecting option. If it is on, the inspection will be triggered automatically when document changes.
	 * 
	 *  @param autoInspecting true to turn autoInspecting on. False to turn it off.
	 */
	public void setAutoInspecting(boolean autoInspecting) {
	}

	/**
	 *  Interrupts the inspection, if it is inspecting.
	 */
	public void stopInspectCode() {
	}

	/**
	 *  Triggers <code>CodeInspector</code>s added to this CodeEditor to inspect the code.
	 */
	public void inspectCode() {
	}

	/**
	 *  Triggers <code>CodeInspector</code>s added to this CodeEditor to inspect the code.
	 * 
	 *  @param event the DocumentEvent. It's up to <code>CodeInspector</code> if it will look at the DocumentEvent to do
	 *               incremental inspection.
	 */
	public void inspectCode(javax.swing.event.DocumentEvent event) {
	}

	public int getLineHeight() {
	}

	/**
	 *  Returns if this component can be traversed by pressing the Tab key. This returns false.
	 */
	@java.lang.Override
	public final boolean isManagingFocus() {
	}

	/**
	 *  Get CodeEditorPainter instance.
	 * 
	 *  @return the object responsible for painting this text area.
	 */
	public final CodeEditorPainter getPainter() {
	}

	/**
	 *  Returns the input handler.
	 * 
	 *  @return the input handler.
	 */
	public final action.InputHandler getInputHandler() {
	}

	/**
	 *  Sets the input handler.
	 * 
	 *  @param inputHandler The new input handler
	 */
	public void setInputHandler(action.InputHandler inputHandler) {
	}

	/**
	 *  Returns true if the caret is visible, false otherwise.
	 * 
	 *  @return true if caret is visible. Otherwise false.
	 */
	public final boolean isCaretVisible() {
	}

	/**
	 *  Sets if the caret should be visible.
	 * 
	 *  @param caretVisible True if the caret should be visible, false otherwise
	 */
	public void setCaretVisible(boolean caretVisible) {
	}

	/**
	 *  Blinks the caret.
	 */
	public final void blinkCaret() {
	}

	/**
	 *  Returns the number of lines from the top and button of the text area that are always visible.
	 * 
	 *  @return the number of lines from the top and button of the text area that are always visible.
	 */
	public final int getElectricScroll() {
	}

	/**
	 *  Sets the number of lines from the top and bottom of the text area that are always visible
	 * 
	 *  @param electricScroll The number of lines always visible from the top or bottom
	 */
	public final void setElectricScroll(int electricScroll) {
	}

	/**
	 *  Updates the state of the scroll bars. This should be called if the number of lines in the document changes, or
	 *  when the size of the text are changes.
	 */
	public void updateScrollBars() {
	}

	/**
	 *  Returns the first line displayed at the text area's origin.
	 * 
	 *  @return the first line displayed at the text area's origin.
	 */
	public final int getFirstLine() {
	}

	/**
	 *  Sets the line displayed at the text area's origin without updating the scroll bars.
	 * 
	 *  @param firstLine the first view line to display.
	 */
	public void setFirstLine(int firstLine) {
	}

	/**
	 *  @return the number of lines visible in this text area.
	 */
	public final int getVisibleLines() {
	}

	/**
	 *  Recalculates the number of visible lines. This should not be called directly.
	 */
	public final void recalculateVisibleLines() {
	}

	/**
	 *  Returns the horizontal offset of drawn lines.
	 * 
	 *  @return the horizontal offset.
	 */
	public final int getHorizontalOffset() {
	}

	/**
	 *  Sets the horizontal offset of drawn lines. This can be used to implement horizontal scrolling.
	 * 
	 *  @param horizontalOffset offset The new horizontal offset
	 */
	public void setHorizontalOffset(int horizontalOffset) {
	}

	/**
	 *  A fast way of changing both the first line and horizontal offset.
	 * 
	 *  @param firstLine        The new first line
	 *  @param horizontalOffset The new horizontal offset
	 * 
	 *  @return True if any of the values were changed, false otherwise
	 */
	public boolean setOrigin(int firstLine, int horizontalOffset) {
	}

	/**
	 *  Ensures that the caret is visible by scrolling the text area if necessary.
	 * 
	 *  @return True if scrolling was actually performed, false if the caret was already visible
	 */
	public boolean scrollToCaret() {
	}

	/**
	 *  Ensures that the specified line and offset is visible by scrolling the text area if necessary.
	 * 
	 *  @param position the caret model position
	 * 
	 *  @return True if scrolling was actually performed, false if the line and offset was already visible
	 */
	public boolean scrollTo(caret.CaretPosition position) {
	}

	/**
	 *  Ensures that the specified line and offset is visible by scrolling the text area if necessary.
	 * 
	 *  @param vp the caret view position
	 * 
	 *  @return True if scrolling was actually performed, false if the line and offset was already visible
	 */
	public boolean scrollToViewPosition(caret.CaretPosition vp) {
	}

	/**
	 *  Ensures that the specified line and offset is visible by scrolling the text area if necessary.
	 * 
	 *  @param vp        the caret view position
	 *  @param anotherVp another caret view position. non-null value means this view position is better to be considered
	 *                   on scrolling
	 * 
	 *  @return True if scrolling was actually performed, false if the line and offset was already visible
	 * 
	 *  @since 3.3.2
	 */
	protected boolean scrollToViewPosition(caret.CaretPosition vp, caret.CaretPosition anotherVp) {
	}

	/**
	 *  Creates the DocumentEvent for replace all. It is invoked only once after replacing all is finished.
	 * 
	 *  @return a DocumentEvent.
	 * 
	 *  @since 3.5.7
	 */
	protected javax.swing.event.DocumentEvent createReplaceAllDocumentEvent() {
	}

	/**
	 *  Converts a line index to y coordinate.
	 * 
	 *  @param line the view line index
	 * 
	 *  @return the y coordinate of the line.
	 */
	public int lineToY(int line) {
	}

	/**
	 *  Converts a y co-ordinate to a line index.
	 *  <p/>
	 *  The meaning of the return value is changed since 2.10.2. Right now it returns view line instead of model line.
	 *  Please invoke xyToOffset() to get the offset first, then invoke offsetToModelPosition() to get the model line.
	 * 
	 *  @param y The y coordinate
	 * 
	 *  @return the view line index at the y coordinate.
	 */
	public int yToLine(int y) {
	}

	/**
	 *  Converts an offset in a document into an x co-ordinate. This is a slow version that can be used any time.
	 * 
	 *  @param offset the offset in a document
	 * 
	 *  @return the X to start painting the offset.
	 */
	public final int offsetToX(int offset) {
	}

	/**
	 *  Converts an offset in a line into an x co-ordinate. This is a slow version that can be used any time.
	 * 
	 *  @param line   The line
	 *  @param offset The model offset, from the start of the line
	 * 
	 *  @return the X to start painting the offset.
	 * 
	 *  @deprecated replaced by {@link #offsetToX(int)}
	 */
	@java.lang.Deprecated
	public final int offsetToX(int line, int offset) {
	}

	/**
	 *  Converts an offset in a line into an x co-ordinate. This is a fast version that should only be used if no changes
	 *  were made to the text since the last repaint.
	 * 
	 *  @param line   The line
	 *  @param offset The offset, from the start of the line
	 * 
	 *  @return the X to start painting the offset.
	 * 
	 *  @deprecated replaced by {@link #_offsetToX(int)}
	 */
	@java.lang.Deprecated
	public int _offsetToX(int line, int offset) {
	}

	/**
	 *  Converts an offset in a document into an x co-ordinate. This is a fast version that should only be used if no
	 *  changes were made to the text since the last repaint.
	 * 
	 *  @param offset The offset, from the start of the line
	 * 
	 *  @return the X to start painting the offset.
	 */
	public int _offsetToX(int offset) {
	}

	/**
	 *  Converts from x position (in pixels) to column. Because we only support fix-width font, this method has nothing
	 *  to do with the actual text. All it does is to use the char width to divide the x position. It does consider the
	 *  horizontal scroll bar position when calculating.
	 * 
	 *  @param x the x position in pixels. The x position is not counted from the line beginning but from the first
	 *           visible pixel because of the scroll bar.
	 * 
	 *  @return the column
	 * 
	 *  @deprecated as this method doesn't consider the actual font it is used so when the font is not fix-width, this
	 *  method will return the wrong result. The correct one to use is {@link #xToColumn(int, int)} which takes the line
	 *  index.
	 */
	public int xToColumn(int x) {
	}

	/**
	 *  Converts from x position (in pixels) to column. The difference between this method and xToOffset is this method
	 *  will consider the virtual spaces after the line end. For example, if line 0 has 10 characters, each character
	 *  needs 6 pixels, <code>xToOffset(0, 66)</code> will return 10 but <code>xToColumn(0, 66)</code> will return 11.
	 *  <p/>
	 *  The meaning of the input parameter is changed to view line since 2.10.2. If you ever invoked this method before,
	 *  please re-check and make sure you will invoke this method with view line index instead of model line index.
	 * 
	 *  @param viewLine the view line index
	 *  @param x        the x position in pixels
	 * 
	 *  @return the view column
	 */
	public int xToColumn(int viewLine, int x) {
	}

	/**
	 *  Converts from the column to x position (in pixels). Because we only support fix-width font, this method has
	 *  nothing to do with the actual text. All it does is to use the char width to multiple the column. It does consider
	 *  the horizontal scroll bar position when calculating.
	 * 
	 *  @param column the column
	 * 
	 *  @return the x position.
	 * 
	 *  @deprecated as this method doesn't consider the actual font it is used so when the font is not fix-width, this
	 *  method will return the wrong result. The correct one to use is {@link #columnToX(int, int)} which takes the line
	 *  index.
	 */
	@java.lang.Deprecated
	public int columnToX(int column) {
	}

	/**
	 *  Converts from the column to x position (in pixels). The x position is not counted from the line beginning but
	 *  from the first visible pixel because of the scroll bar. The different between this method and the offsetToX
	 *  method is this method will consider the virtual spaces after the line end. For example, if line 0 has 10
	 *  characters, each character needs 6 pixels, <code>offsetToX(0, 11)</code> will return 60 but <code>columnToX(0,
	 *  11)</code> will return 66.
	 * 
	 *  @param line   the view line index
	 *  @param column the view column
	 * 
	 *  @return the x position. The x position is not counted from the line beginning but from the first visible pixel
	 *  because of the scroll bar
	 */
	public int columnToX(int line, int column) {
	}

	/**
	 *  Converts an x co-ordinate to an offset within a document.
	 *  <p/>
	 *  In previous releases earlier than 2.10.2, the definition of the first parameter and the return value are
	 *  different. If you ever invoked this method explicitly, please use the following code to replace the original
	 *  implementation. <code> int viewLine = modelToViewLine(modelLine); int offsetInDocument = xToOffset(viewLine, x);
	 *  int offsetInLine = offsetInDocument - getLineStartOffset(modelLine); </code>
	 * 
	 *  @param viewLine the view line
	 *  @param x        The x co-ordinate
	 * 
	 *  @return the     offset within the document.
	 */
	public int xToOffset(int viewLine, int x) {
	}

	/**
	 *  Converts a point to an offset in the document.
	 * 
	 *  @param x The x co-ordinate of the point
	 *  @param y The y co-ordinate of the point
	 * 
	 *  @return the offset in the document at the x and y coordinates.
	 */
	public int xyToOffset(int x, int y) {
	}

	/**
	 *  Returns the document this text area is editing.
	 * 
	 *  @return the document.
	 */
	public final SyntaxDocument getDocument() {
	}

	/**
	 *  Sets the document this text area is editing.
	 * 
	 *  @param document The document
	 */
	public void setDocument(SyntaxDocument document) {
	}

	/**
	 *  Returns the document's token marker. Equivalent to calling <code>getDocument().getTokenMarker()</code>.
	 * 
	 *  @return the token marker.
	 */
	public final tokenmarker.TokenMarker getTokenMarker() {
	}

	/**
	 *  Sets the document's token marker. Equivalent to calling <code>getDocument().setTokenMarker()</code>.
	 * 
	 *  @param tokenMarker The token marker
	 */
	public final void setTokenMarker(tokenmarker.TokenMarker tokenMarker) {
	}

	/**
	 *  Returns the length of the document. Equivalent to calling <code>getDocument().getLength()</code>.
	 * 
	 *  @return the document length.
	 */
	public final int getDocumentLength() {
	}

	/**
	 *  Returns the number of lines in the document.
	 * 
	 *  @return the number of lines in the document.
	 */
	public final int getLineCount() {
	}

	public int getVisualLineCount() {
	}

	/**
	 *  Returns the line containing the specified offset.
	 * 
	 *  @param offset The offset
	 * 
	 *  @return the line number of the offset.
	 */
	public final int getLineNumber(int offset) {
	}

	/**
	 *  Returns the start offset of the specified line.
	 * 
	 *  @param line The line
	 * 
	 *  @return The start offset of the specified line, or -1 if the line is invalid
	 */
	public int getLineStartOffset(int line) {
	}

	/**
	 *  Returns the start offset of the specified line exclude the spaces.
	 * 
	 *  @param line The line
	 * 
	 *  @return The start offset of the specified line, or -1 if the line is invalid
	 */
	public int getLineStartOffsetNoSpace(int line) {
	}

	/**
	 *  Returns the end offset of the specified line.
	 * 
	 *  @param line The line
	 * 
	 *  @return The end offset of the specified line, or -1 if the line is invalid.
	 */
	public int getLineEndOffset(int line) {
	}

	/**
	 *  Gets the length of the specified line.
	 * 
	 *  @param line the line
	 * 
	 *  @return the length of the specified line.
	 */
	public int getLineLength(int line) {
	}

	/**
	 *  Returns the entire text of this text area.
	 * 
	 *  @return the text with the line break style as specified on this code editor.
	 */
	public String getText() {
	}

	/**
	 *  Sets the entire text of this CodeEditor.
	 *  <p/>
	 *  Please note, the text can have any kind of line breaks. Internally, we will use {@link #importText(String,
	 *  StringBuffer)} to convert. If you know your text doesn't have any inconsistency in the line breaks, you can use
	 *  {@link #setRawText(String)} to avoid the unnecessary conversion. Otherwise we will try to import the first 1000
	 *  (of course only if the text length is less than 1000) to see what the line style is.
	 * 
	 *  @param text the new text.
	 */
	public void setText(String text) {
	}

	public void append(String text) {
	}

	/**
	 *  Returns the specified substring of the document.
	 * 
	 *  @param start The start offset
	 *  @param len   The length of the substring
	 * 
	 *  @return The substring, or null if the offsets are invalid
	 */
	public final String getText(int start, int len) {
	}

	/**
	 *  Copies the specified substring of the document into a segment. If the offsets are invalid, the segment will
	 *  contain a null string.
	 * 
	 *  @param start   The start offset
	 *  @param len     The length of the substring
	 *  @param segment The segment
	 */
	public final void getText(int start, int len, javax.swing.text.Segment segment) {
	}

	/**
	 *  Converts text with LINE_BREAK_CODE_EDITOR as line break to the line break style on this code editor.
	 * 
	 *  @param in  the text with LINE_BREAK_CODE_EDITOR as line break.
	 *  @param out the text using the line break style set on the code editor as line break.
	 * 
	 *  @return the line break style used in the input string.
	 */
	protected int exportText(String in, StringBuffer out) {
	}

	/**
	 *  Converts the text with any line break style to LINE_BREAK_CODE_EDITOR style (LF only).
	 * 
	 *  @param in  the text with any line break style.
	 *  @param out the text with LINE_BREAK_CODE_EDITOR as line break style.
	 * 
	 *  @return the line break style used in the input string.
	 */
	protected int importText(String in, StringBuffer out) {
	}

	/**
	 *  Returns the entire text of this text area. Please note, the text will use LF as line break. If you want the
	 *  proper line break according to the line break style on this code editor, use {@link #exportText(String,
	 *  StringBuffer)})} instead.
	 * 
	 *  @return the entire text of this text area.
	 */
	public String getRawText() {
	}

	/**
	 *  Sets the content of the code editor. Different from {@link #setText(String)}, this method assumes the line break
	 *  used in the text is LF only. If you are not sure about this, you should use {@link #setText(String)} instead.
	 * 
	 *  @param text the raw text.
	 */
	public void setRawText(String text) {
	}

	/**
	 *  Returns the text on the specified line.
	 * 
	 *  @param lineIndex The line
	 * 
	 *  @return The text, or null if the line is invalid
	 */
	public final String getLineText(int lineIndex) {
	}

	/**
	 *  Copies the text on the specified line into a segment. If the line is invalid, the segment will contain a null
	 *  string.
	 * 
	 *  @param lineIndex The line
	 *  @param segment   the segment
	 * 
	 *  @return true if getLineText succeed. Otherwise returns false.
	 */
	public final boolean getLineText(int lineIndex, javax.swing.text.Segment segment) {
	}

	/**
	 *  Sets the text on the specified line.
	 * 
	 *  @param lineIndex the line index
	 *  @param text      the text
	 */
	public final void setLineText(int lineIndex, String text) {
	}

	/**
	 *  Gets the selection start offset on the entire document.
	 * 
	 *  @return the selection start offset.
	 */
	public final int getSelectionStart() {
	}

	/**
	 *  Gets the offset where the selection starts on the specified line.
	 * 
	 *  @param line the specified line
	 * 
	 *  @return the offset where the selection starts on the specified line.
	 */
	public int getSelectionStart(int line) {
	}

	/**
	 *  Gets the selection start line.
	 * 
	 *  @return the selection start line.
	 */
	public final int getSelectionStartLine() {
	}

	/**
	 *  Sets the selection start. The new selection will be the new selection start and the old selection end.
	 * 
	 *  @param selectionStart The selection start
	 * 
	 *  @see #select(int, int)
	 */
	public final void setSelectionStart(int selectionStart) {
	}

	/**
	 *  Surrounds the selected text with <code>prefix</code> and <code>postfix</code>.
	 * 
	 *  @param prefix  String
	 *  @param postfix String
	 */
	public final void surroundSelection(String prefix, String postfix) {
	}

	/**
	 *  Selects the word in current caret position.
	 */
	public void selectWord() {
	}

	public void selectWord(String noWordSep) {
	}

	public int[] getCurrentWordBounds() {
	}

	public String getLeftWordPart() {
	}

	public String getLeftWordPart(String nonwordDelimiters) {
	}

	public int[] getCurrentWordBounds(String nonwordDelimiters) {
	}

	public String getCurrentWord() {
	}

	public String getCurrentWord(String noWordDelimiters) {
	}

	/**
	 *  Selects the block between the closest pair of brackets which contains current caret.
	 */
	public void selectToMatchingBracket() {
	}

	/**
	 *  Selects the code block surrounding the caret.
	 */
	public void selectBlock() {
	}

	public void gotoEndOfLine() {
	}

	public void commentLine(int line) {
	}

	public void commentLine() {
	}

	public void indentSelectedLines() {
	}

	public void indentLinesBetween(int startLine, int endLine) {
	}

	public void indentLine(int line) {
	}

	/**
	 *  Select the model line.
	 * 
	 *  @param line the model line index
	 */
	public void selectLine(int line) {
	}

	/**
	 *  Select the model lines.
	 * 
	 *  @param start the start model line index
	 *  @param end   the end model line index
	 */
	public void selectLines(int start, int end) {
	}

	/**
	 *  @return the selection end offset.
	 */
	public final int getSelectionEnd() {
	}

	/**
	 *  Gets the offset where the selection ends on the specified line.
	 * 
	 *  @param line the specified line
	 * 
	 *  @return the offset where the selection ends on the specified line.
	 */
	public int getSelectionEnd(int line) {
	}

	/**
	 *  @return the selection end line.
	 */
	public final int getSelectionEndLine() {
	}

	/**
	 *  Sets the selection end. The new selection will be the old selection start and the new selection end.
	 * 
	 *  @param selectionEnd The selection end
	 * 
	 *  @see #select(int, int)
	 */
	public final void setSelectionEnd(int selectionEnd) {
	}

	/**
	 *  Gets the lead offset of the selection. If the selection model has no selection, it will return the caret offset
	 *  in CaretModel. If it has selection and the caret offset is at the selection end, it will return the selection
	 *  start. In all other cases, the selection end will be returned.
	 * 
	 *  @return the lead selection offset.
	 */
	public int getLeadSelectionOffset() {
	}

	/**
	 *  Gets the anchor offset of the selection. If the selection model has no selection, it will return the caret offset
	 *  in CaretModel. If it has selection and the caret offset is at the selection start, it will return the selection
	 *  end. In all other cases, the selection start will be returned.
	 * 
	 *  @return the lead selection offset.
	 */
	public int getAnchorSelectionOffset() {
	}

	/**
	 *  Returns the mark position. This will be the opposite selection bound to the caret position.
	 * 
	 *  @return the mark position.
	 */
	public final int getMarkPosition() {
	}

	/**
	 *  Sets the caret position. The new selection will consist of the caret position only (hence no text will be
	 *  selected)
	 * 
	 *  @param caret The caret position
	 * 
	 *  @see #select(int, int)
	 */
	public final void select(int caret) {
	}

	/**
	 *  Selects all text in the document.
	 */
	public final void selectAll() {
	}

	/**
	 *  Moves the mark to the caret position.
	 */
	public final void selectNone() {
	}

	/**
	 *  Selects from the start offset to the end offset. This is the general selection method used by all other selecting
	 *  methods. The caret position will be start if start < end, and end if end > start.
	 *  <p/>
	 *  By default, this method will scroll to make caret visible only if the code editor has focus.
	 * 
	 *  @param start The start offset
	 *  @param end   The end offset
	 */
	public void select(int start, int end) {
	}

	/**
	 *  Selects from the start offset to the end offset. This is the general selection method used by all other selecting
	 *  methods. The caret position will be start if start < end, and end if end > start. This method can scroll the
	 *  caret visible depending on the value of the scroll parameter.
	 * 
	 *  @param start  The start offset
	 *  @param end    The end offset
	 *  @param scroll true or false. True to scroll the caret visible after selecting the text.
	 */
	public void select(int start, int end, boolean scroll) {
	}

	/**
	 *  @return the selected text, or null if no selection is active.
	 */
	public final String getSelectedText() {
	}

	/**
	 *  Replaces the selection with the specified text.
	 * 
	 *  @param selectedText The replacement text for the selection
	 */
	public void setSelectedText(String selectedText) {
	}

	/**
	 *  Returns true if this text area is editable, false otherwise.
	 * 
	 *  @return true if the CodeEditor is editable.
	 */
	public final boolean isEditable() {
	}

	/**
	 *  Sets if this component is editable.
	 * 
	 *  @param editable True if this text area should be editable, false otherwise
	 */
	public final void setEditable(boolean editable) {
	}

	/**
	 *  Returns the `magic' caret position. This can be used to preserve the column position when moving up and down
	 *  lines.
	 * 
	 *  @return the magic caret position.
	 */
	public final int getMagicCaretPosition() {
	}

	/**
	 *  Sets the `magic' caret position. This can be used to preserve the column position when moving up and down lines.
	 * 
	 *  @param magicCaret The magic caret position
	 */
	public final void setMagicCaretPosition(int magicCaret) {
	}

	/**
	 *  Similar to <code>setSelectedText()</code>, but overwrite the appropriate number of characters if overwrite mode
	 *  is enabled.
	 * 
	 *  @param str The string
	 * 
	 *  @see #setSelectedText(String)
	 *  @see #isOverwriteEnabled()
	 */
	public void overwriteSetSelectedText(String str) {
	}

	/**
	 *  @return true if overwrite mode is enabled, false otherwise.
	 */
	public final boolean isOverwriteEnabled() {
	}

	/**
	 *  Sets if overwrite mode should be enabled.
	 * 
	 *  @param overwrite True if overwrite mode should be enabled, false otherwise.
	 */
	public final void setOverwriteEnabled(boolean overwrite) {
	}

	/**
	 *  @return true if the selection is rectangular, false otherwise.
	 */
	public final boolean isSelectionRectangular() {
	}

	/**
	 *  Sets if the selection should be rectangular.
	 * 
	 *  @param rectSelect True if the selection should be rectangular, false otherwise.
	 */
	public final void setSelectionRectangular(boolean rectSelect) {
	}

	/**
	 *  @return the position of the highlighted bracket (the bracket matching the one before the caret)
	 */
	public final int getBracketPosition() {
	}

	/**
	 *  @return the line of the highlighted bracket (the bracket matching the one before the caret)
	 */
	public final int getBracketLine() {
	}

	/**
	 *  Undo the last action (if possible).
	 */
	public void undo() {
	}

	/**
	 *  Redo the last action (if possible).
	 */
	public void redo() {
	}

	@java.lang.Override
	public void addNotify() {
	}

	@java.lang.Override
	public void removeNotify() {
	}

	/**
	 *  Forwards key events directly to the input handler. This is slightly faster than using a KeyListener because some
	 *  Swing overhead is avoided.
	 */
	@java.lang.Override
	public void processKeyEvent(java.awt.event.KeyEvent evt) {
	}

	protected void updateBracketHighlight(int newCaretPosition) {
	}

	protected void documentChanged(javax.swing.event.DocumentEvent evt) {
	}

	/**
	 *  Gets the flag indicating if the caret currently is blinking.
	 * 
	 *  @return true if the caret is blinking. Otherwise false.
	 * 
	 *  @since 3.3.7
	 */
	public boolean isBlink() {
	}

	/**
	 *  Sets the flag indicating if the caret currently is blinking.
	 * 
	 *  @param blink the flag
	 * 
	 *  @since 3.3.7
	 */
	public void setBlink(boolean blink) {
	}

	/**
	 *  Pauses the blink and set caret to display. Please make sure that you will invoke {@link #blinkCaret()} to restart
	 *  the caret blinking.
	 */
	public void pauseBlink() {
	}

	/**
	 *  Get the flag indicating TAB key is to alignment or just add fixed number of spaces.
	 *  <p/>
	 *  This flag will only take effect when {@link #isReplaceTabWithSpace()} returns true.
	 *  <p/>
	 *  The default value of this flag is false to keep original behavior. If you want to make tab align the column,
	 *  please set this flag to true.
	 * 
	 *  @return the flag.
	 */
	public boolean isTabAlignment() {
	}

	/**
	 *  Set the flag indicating TAB key is to alignment or just add fixed number of spaces.
	 * 
	 *  @param tabAlignment the flag
	 * 
	 *  @see #isTabAlignment()
	 */
	public void setTabAlignment(boolean tabAlignment) {
	}

	/**
	 *  Get the horizontal scroll bar policy.
	 *  <p/>
	 *  The return value could be {@link ScrollPane#SCROLLBARS_ALWAYS}, {@link ScrollPane#SCROLLBARS_AS_NEEDED} or {@link
	 *  ScrollPane#SCROLLBARS_NEVER}. By default the value is {@link ScrollPane#SCROLLBARS_ALWAYS} for backward
	 *  compatibility.
	 * 
	 *  @return the policy.
	 */
	public int getHorizontalScrollBarPolicy() {
	}

	/**
	 *  Set the horizontal scroll bar policy.
	 * 
	 *  @param horizontalScrollBarPolicy the policy.
	 * 
	 *  @see #getHorizontalScrollBarPolicy()
	 */
	public void setHorizontalScrollBarPolicy(int horizontalScrollBarPolicy) {
	}

	/**
	 *  Get the vertical scroll bar policy.
	 *  <p/>
	 *  The return value could be {@link ScrollPane#SCROLLBARS_ALWAYS}, {@link ScrollPane#SCROLLBARS_AS_NEEDED} or {@link
	 *  ScrollPane#SCROLLBARS_NEVER}. By default the value is {@link ScrollPane#SCROLLBARS_ALWAYS} for backward
	 *  compatibility.
	 * 
	 *  @return the policy.
	 */
	public int getVerticalScrollBarPolicy() {
	}

	/**
	 *  Set the vertical scroll bar policy.
	 * 
	 *  @param verticalScrollBarPolicy the policy.
	 * 
	 *  @see #getVerticalScrollBarPolicy()
	 */
	public void setVerticalScrollBarPolicy(int verticalScrollBarPolicy) {
	}

	/**
	 *  Get the flag indicating if the tooltip should be displayed while the mouse hover on a marked text.
	 *  <p/>
	 *  By default, the flag is false. You could set it to true to display the tooltip for the offsets defined in marker
	 *  model.
	 * 
	 *  @return true if tooltip should be displayed. Otherwise false.
	 * 
	 *  @see #getMarkerModel()
	 */
	public boolean isShowToolTipOverMarkedText() {
	}

	/**
	 *  Set the flag indicating if tooltip should be displayed while the mouse hover on a marked text.
	 * 
	 *  @param showToolTipOverMarkedText the flag
	 * 
	 *  @see #isShowToolTipOverMarkedText()
	 */
	public void setShowToolTipOverMarkedText(boolean showToolTipOverMarkedText) {
	}

	/**
	 *  Get the full path to the file that the CodeEditor is currently editing.
	 * 
	 *  @return the file name.
	 */
	public String getFileName() {
	}

	/**
	 *  Set the full path to a local file on the CodeEditor. Unless {@link #setText(String)} where the content of the
	 *  file is loaded fully into memory, CodeEditor will load the file using lazy-loading.
	 *  <p/>
	 *  This method is not a replacement of {@link #setText(String)} so that you don't need to read the file yourself.
	 *  Calling this method will reset the Document of this CodeEditor to a new instance of document called {@link
	 *  com.jidesoft.editor.LazyLoadDocument}. LazyLoadDocument provides lazy loading function so it can load huge files
	 *  very fast.
	 * 
	 *  @param pathToFile the full path to a local file. By default, UTF-8 is used to read the file. If you need to
	 *                    specify the charset, please use {@link #setFileName(String, String)}.
	 */
	public void setFileName(String pathToFile) {
	}

	/**
	 *  Set the full path to a local file on the CodeEditor. Unless {@link #setText(String)} where the content of the
	 *  file is loaded fully into memory, CodeEditor will load the file using lazy-loading.
	 *  <p/>
	 *  This method is not a replacement of {@link #setText(String)} so that you don't need to read the file yourself.
	 *  Calling this method will reset the Document of this CodeEditor to a new instance of document called {@link
	 *  com.jidesoft.editor.LazyLoadDocument}. LazyLoadDocument provides lazy loading function so it can load huge files
	 *  very fast.
	 * 
	 *  @param pathToFile the full path to a local file.
	 */
	public void setFileName(String pathToFile, String charsetName) {
	}

	/**
	 *  Creates the LazyLoadDocument instance.
	 * 
	 *  @return the LazyLoadDocument instance.
	 */
	protected LazyLoadDocument createLazyLoadDocument() {
	}

	/**
	 *  Exports the contents inside the CodeEditor to an output stream.
	 *  <p/>
	 *  Please be noted that, the contents can not be saved to the same file as {@link #getFileName()}
	 * 
	 *  @param outputStream the output stream
	 * 
	 *  @return true if exporting successfully. Otherwise false.
	 * 
	 *  @throws IOException          if there is any I/O issue.
	 *  @throws BadLocationException if there is any document reading issue.
	 */
	public boolean exportToOutputStream(java.io.OutputStream outputStream) {
	}

	protected java.io.OutputStreamWriter createOutputStreamWriter(java.io.OutputStream outputStream) {
	}

	/**
	 *  Get the flag indicating if the content should be visible right now.
	 * 
	 *  @return true if the content should be visible. Otherwise false.
	 * 
	 *  @see #setContentVisible(boolean)
	 */
	public boolean isContentVisible() {
	}

	/**
	 *  Set the flag indicating if the content should be visible right now.
	 *  <p/>
	 *  By default, the flag is true to paint contents. In some scenarios, for example, dragging scroll bars in a
	 *  extremely large file, setting this flag to false will speed up the dragging process.
	 * 
	 *  @param contentVisible the flag
	 */
	public void setContentVisible(boolean contentVisible) {
	}

	/**
	 *  Get the flag indicating if the contents in the code editor should be hidden while the page need to be loaded.
	 * 
	 *  @return true if the contents need to be hidden. Otherwise false.
	 * 
	 *  @see #setDelayContentsOnLoading(boolean)
	 */
	public boolean isDelayContentsOnLoading() {
	}

	/**
	 *  Set the flag indicating if the contents in the code editor should be hidden while the page need to be loaded.
	 *  <p/>
	 *  By default, the flag is false to leave contents visible. However, if you don't like to see the obvious slowness
	 *  on huge files on dragging the thumb in the vertical scroll bar, please set this flag to true.
	 * 
	 *  @param delayContentsOnLoading the flag
	 */
	public void setDelayContentsOnLoading(boolean delayContentsOnLoading) {
	}

	/**
	 *  Gets the flag indicating if prompt dialog position should be changed to show current selected text.
	 * 
	 *  @return true if prompt dialog position to be changed. Otherwise false.
	 * 
	 *  @see #setChangePromptDialogPosition(boolean)
	 */
	public boolean isChangePromptDialogPosition() {
	}

	/**
	 *  Sets the flag indicating if prompt dialog position should be changed to show current selected text.
	 *  <p/>
	 *  By default, this flag is false. The prompt dialog will not change its position on searching, which helps the
	 *  client to click "replace" continuously. Target CodeEditor will be scrolled to show current selection.
	 *  <p/>
	 *  You could change this flag to true to switch to the behavior before 2.11.1.
	 * 
	 *  @param changePromptDialogPosition the flag
	 */
	public void setChangePromptDialogPosition(boolean changePromptDialogPosition) {
	}

	/**
	 *  Gets the flag indicating if the pasted multiple-line text should respect the indent of the previous line.
	 * 
	 *  @return true if indent to be respected. Otherwise false.
	 * 
	 *  @see #setIndentOnPasting(boolean)
	 */
	public boolean isIndentOnPasting() {
	}

	/**
	 *  Sets the flag indicating if the pasted multiple-line text should respect the indent of the previous line.
	 *  <p/>
	 *  By default, the flag is true.
	 * 
	 *  @param indentOnPasting the flag
	 */
	public void setIndentOnPasting(boolean indentOnPasting) {
	}

	/**
	 *  Gets the flag indicating if only visible text should be copied to clipboard or dragged.
	 * 
	 *  @return true if only visible text should be copied. Otherwise false.
	 * 
	 *  @see #setCopyVisibleTextOnly(boolean)
	 *  @since 3.4.1
	 */
	public boolean isCopyVisibleTextOnly() {
	}

	/**
	 *  Sets the flag indicating if only visible text should be copied to clipboard or dragged.
	 *  <p/>
	 *  The default value is false to keep the behavior backward compatibility.
	 * 
	 *  @param copyVisibleTextOnly the flag
	 * 
	 *  @since 3.4.1
	 */
	public void setCopyVisibleTextOnly(boolean copyVisibleTextOnly) {
	}

	/**
	 *  Gets the flag indicating if the line comment action should skip the empty lines.
	 * 
	 *  @return true if the empty lines should be skipped. Otherwise false.
	 * 
	 *  @see #setSkipsEmptyLinesOnLineComments(boolean)
	 *  @since 3.4.3
	 */
	public boolean isSkipsEmptyLinesOnLineComments() {
	}

	/**
	 *  Sets the flag indicating if the line comment action should skip the empty lines.
	 *  <p/>
	 *  By default, the value is false to keep backward compatibility.
	 * 
	 *  @param skipsEmptyLinesOnLineComments the flag
	 * 
	 *  @since 3.4.3
	 */
	public void setSkipsEmptyLinesOnLineComments(boolean skipsEmptyLinesOnLineComments) {
	}

	/**
	 *  The action to take while page loading process is failed. In most cases, it's caused by memory used up.
	 *  <p/>
	 *  By default, it do nothing. You could override this method to release memory from other parts of your
	 *  application.
	 * 
	 *  @param e the page load event.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void pageLoadFailedHandling(PageLoadEvent e) {
	}

	@java.lang.Override
	public boolean getFocusTraversalKeysEnabled() {
	}

	public boolean getFocusCycleRoot() {
	}

	/**
	 *  Checks if the mouse event indicates a ColumnSelectionModel.
	 *  <p/>
	 *  By default, it returns true if the ALT_MASK is on. You could change it to the code below to switch back to the
	 *  old behavior earlier than 3.3.0.
	 *  <code><pre>
	 *  return (evt.getModifiers() & InputEvent.CTRL_MASK) != 0;
	 *  </pre></code>
	 * 
	 *  @param evt the mouse event
	 * 
	 *  @return true if the mouse event indicates a ColumnSelectionMode. Otherwise false.
	 * 
	 *  @since 3.3.0
	 */
	protected boolean isColumnSelectionMode(java.awt.event.MouseEvent evt) {
	}

	/**
	 *  Scrolls up by one page.
	 */
	public void scrollUpPage() {
	}

	/**
	 *  Scrolls down by one page.
	 */
	public void scrollDownPage() {
	}

	public margin.MarginArea getMarginArea() {
	}

	public void setMarginArea(margin.MarginArea marginArea) {
	}

	public void setLineNumberVisible(boolean visible) {
	}

	public boolean isLineNumberVisible() {
	}

	public RowNumberMargin getLineNumberMargin() {
	}

	public caret.CaretModel getCaretModel() {
	}

	public selection.SelectionModel getSelectionModel() {
	}

	public void selectionChanged(selection.SelectionEvent e) {
	}

	/**
	 *  Create ClipboardOwner instance.
	 * 
	 *  @return the ClipboardOwner instance.
	 */
	protected java.awt.datatransfer.ClipboardOwner createClipboardOwner() {
	}

	public void caretUpdated(caret.CaretEvent e) {
	}

	/**
	 *  Create selection model for CodeEditor. The default implementation is new DefaultSelectionModel(this). You can
	 *  override this method to create your selection model.
	 * 
	 *  @return a DefaultSelectionModel instance.
	 */
	protected selection.SelectionModel createSelectionModel() {
	}

	/**
	 *  Get model position from view position.
	 *  <p/>
	 *  If there is no folding span those two positions should be the same.
	 *  <p/>
	 *  If there are folding spans, find the closest folded span to get the relative position.
	 *  <p/>
	 *  If it's on the folded descriptions, use the model position of the first offset of the folded span.
	 * 
	 *  @param p the view position.
	 * 
	 *  @return the model position.
	 */
	public caret.CaretPosition viewToModelPosition(caret.CaretPosition p) {
	}

	/**
	 *  Get view position from model position.
	 *  <p/>
	 *  If there is no folding span those two positions should be the same.
	 *  <p/>
	 *  If there are folding spans, find the closest folded span to get the relative position.
	 *  <p/>
	 *  If it's inside a folded span, use the view position of the first offset of the folded span.
	 * 
	 *  @param p the model position.
	 * 
	 *  @return the view position.
	 */
	public caret.CaretPosition modelToViewPosition(caret.CaretPosition p) {
	}

	public caret.CaretPosition offsetToModelPosition(int offset) {
	}

	public caret.CaretPosition offsetToViewPosition(int offset) {
	}

	public int modelPositionToOffset(caret.CaretPosition p) {
	}

	/**
	 *  Converts the offset as in the Document to the view line in the editor.
	 *  <p/>
	 *  The return value is changed to mean view line instead of model line since 2.10.2. If you ever invoked this method
	 *  before and intended to get model line. Please use {@link #getLineNumber(int)} instead.
	 * 
	 *  @param offset the offset in the document
	 * 
	 *  @return the view line number contains the character at that offset.
	 * 
	 *  @deprecated replaced by {@link #offsetToViewPosition(int)}
	 */
	@java.lang.Deprecated
	public int offsetToLine(int offset) {
	}

	public int getTabSize() {
	}

	public void setTabSize(int tabSize) {
	}

	public boolean isReplaceTabWithSpace() {
	}

	public void setReplaceTabWithSpace(boolean replaceTabWithSpace) {
	}

	/**
	 *  Gets the default line break style. If you are on Windows or MacOSX, LINE_BREAK_PC will be returned. If you are on
	 *  Mac classic, LINE_BREAK_MAC will be returned. if you are on UNIX, LINE_BREAK_UNIX will be returned. Otherwise, we
	 *  will return LINE_BREAK_PC as the default one.
	 * 
	 *  @return the default line break depending on the platform.
	 */
	public int getDefaultLineBreakStyle() {
	}

	public int getLineBreakStyle() {
	}

	public boolean isLineBreakStyleMixed() {
	}

	public void setLineBreakStyle(int lineBreakStyle) {
	}

	public void discardAllEdits() {
	}

	/**
	 *  Shows a dialog so that the customer could input a line number then jump to the line.
	 */
	public void promptGotoLine() {
	}

	public void promptGotoLineAtView() {
	}

	public void promptGotoOffset() {
	}

	/**
	 *  Go to the model line.
	 * 
	 *  @param line the model line index
	 */
	public void gotoLine(int line) {
	}

	/**
	 *  Go to the view line.
	 * 
	 *  @param line the view line index
	 */
	public void gotoLineAtView(int line) {
	}

	/**
	 *  Go to the offset.
	 * 
	 *  @param offset the offset in the document
	 */
	public void gotoOffset(int offset) {
	}

	public MarkerModel getMarkerModel() {
	}

	public void setMarkerModel(MarkerModel markerModel) {
	}

	public int getMaxNumberOfClipboards() {
	}

	public void setMaxNumberOfClipboards(int maxNumberOfClipboards) {
	}

	/**
	 *  Sets the <code>dragEnabled</code> property, which must be <code>true</code> to enable automatic drag handling
	 *  (the first part of drag and drop) on this component. The <code>transferHandler</code> property needs to be set to
	 *  a non-<code>null</code> value for the drag to do anything.  The default value of the <code>dragEnabled</code
	 *  property is <code>false</code>.
	 *  <p/>
	 *  When automatic drag handling is enabled, most look and feels begin a drag-and-drop operation whenever the user
	 *  presses the mouse button over a selection and then moves the mouse a few pixels. Setting this property to
	 *  <code>true</code> can therefore have a subtle effect on how selections behave.
	 *  <p/>
	 *  Some look and feels might not support automatic drag and drop; they will ignore this property.  You can work
	 *  around such look and feels by modifying the component to directly call the <code>exportAsDrag</code> method of a
	 *  <code>TransferHandler</code>.
	 * 
	 *  @param b the value to set the <code>dragEnabled</code> property to
	 * 
	 *  @throws HeadlessException if <code>b</code> is <code>true</code> and <code>GraphicsEnvironment.isHeadless()</code>
	 *                            returns <code>true</code>
	 *  @see java.awt.GraphicsEnvironment#isHeadless
	 *  @see #getDragEnabled
	 *  @see #setTransferHandler(javax.swing.TransferHandler)
	 *  @see TransferHandler
	 */
	public void setDragEnabled(boolean b) {
	}

	/**
	 *  Gets the value of the <code>dragEnabled</code> property.
	 * 
	 *  @return the value of the <code>dragEnabled</code> property
	 * 
	 *  @see #setDragEnabled(boolean)
	 */
	public boolean getDragEnabled() {
	}

	@java.lang.Override
	public void setFont(java.awt.Font font) {
	}

	public Searchable getSearchable() {
	}

	public com.jidesoft.search.FindAndReplace getFindAndReplace() {
	}

	public java.awt.Point getCaretLocation() {
	}

	public java.awt.Point getCaretLocationOnScreen() {
	}

	public void showMessage(String message) {
	}

	/**
	 *  Shows a find dialog to let the customer input searching text then search the text in the document or the current
	 *  selected text.
	 */
	public void find() {
	}

	/**
	 *  Looks for the next match in the document or the current selected text.
	 */
	public void findNext() {
	}

	/**
	 *  Looks for the previous match in the document or the current selected text.
	 */
	public void findPrevious() {
	}

	/**
	 *  Shows a find and replace dialog to let the customer input searching text then search the text in the document or
	 *  the current selected text.
	 */
	public void replace() {
	}

	/**
	 *  Shows a Searchable popup to start searching quickly.
	 * 
	 *  @param searchingText the searching text
	 */
	public void quickSearch(String searchingText) {
	}

	/**
	 *  Moves the caret to the end of the line where the caret resides. Extends the selection if the select parameter is
	 *  true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 */
	public void moveToLineEnd(boolean select) {
	}

	/**
	 *  Moves the caret to the start of the line where the caret resides. Extends the selection if the select parameter
	 *  is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 */
	public void moveToLineStart(boolean select) {
	}

	/**
	 *  Moves the caret to the start of the document. Extends the selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 */
	public void moveToDocumentStart(boolean select) {
	}

	/**
	 *  Moves the caret to the end of the document. Extends the selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 */
	public void moveToDocumentEnd(boolean select) {
	}

	/**
	 *  Moves the caret to the next column if {@link #isVirtualSpaceAllowed()} is true. Otherwise moves the caret to the
	 *  next char excluding line breaks. Extends the selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 * 
	 *  @see #isVirtualSpaceAllowed()
	 */
	public void moveToNextChar(boolean select) {
	}

	/**
	 *  Moves the caret to the next line. The column may change if {@link #isVirtualSpaceAllowed()} is false. Extends the
	 *  selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 * 
	 *  @see #isVirtualSpaceAllowed()
	 */
	public void moveToNextLine(boolean select) {
	}

	/**
	 *  Moves the caret to the next page. The column may change if {@link #isVirtualSpaceAllowed()} is false. Extends the
	 *  selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 * 
	 *  @see #isVirtualSpaceAllowed()
	 */
	public void moveToNextPage(boolean select) {
	}

	/**
	 *  Moves caret to the the word start of the next word. Extends the selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the text between current caret and new caret should be selected.
	 */
	public void moveToNextWord(boolean select) {
	}

	/**
	 *  If toWordStart is false, moves caret to the the word end of the current word if the caret is not on the end of
	 *  the current word or to the word end of the next word if the caret is on the end of the current word.
	 *  <p/>
	 *  If toWordStart is true, moves caret to the the word start of the next word.
	 * 
	 *  @param select      the flag indicating if the text between current caret and new caret should be selected
	 *  @param toWordStart the flag indicating if the caret should be put at the start of the word
	 */
	public void moveToNextWord(boolean select, boolean toWordStart) {
	}

	/**
	 *  Moves the caret to the previous column or stay at column 0 if {@link #isVirtualSpaceAllowed()} is true. Otherwise
	 *  moves the caret to the previous char excluding line breaks. Extends the selection if the select parameter is
	 *  true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 * 
	 *  @see #isVirtualSpaceAllowed()
	 */
	public void moveToPreviousChar(boolean select) {
	}

	/**
	 *  Moves the caret to the previous line. The column may change if {@link #isVirtualSpaceAllowed()} is false. Extends
	 *  the selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 * 
	 *  @see #isVirtualSpaceAllowed()
	 */
	public void moveToPreviousLine(boolean select) {
	}

	/**
	 *  Moves the caret to the previous page. The column may change if {@link #isVirtualSpaceAllowed()} is false. Extends
	 *  the selection if the select parameter is true.
	 * 
	 *  @param select the flag indicating if the caret moving will extend selection or not
	 * 
	 *  @see #isVirtualSpaceAllowed()
	 */
	public void moveToPreviousPage(boolean select) {
	}

	/**
	 *  Moves caret to the the word start of the current word if the caret is not on the start of the current word or to
	 *  the word start of the previous word if the caret is on the start of the current word. Extends the selection if
	 *  the select parameter is true.
	 * 
	 *  @param select the flag indicating if the text between current caret and new caret should be selected.
	 */
	public void moveToPreviousWord(boolean select) {
	}

	/**
	 *  If toWordEnd is false, moves caret to the the word start of the current word if the caret is not on the start of
	 *  the current word or to the word start of the previous word if the caret is on the start of the current word.
	 *  <p/>
	 *  If toWordEnd is true, moves caret to the the word end of the previous word.
	 * 
	 *  @param select    the flag indicating if the text between current caret and new caret should be selected.
	 *  @param toWordEnd the flag indicating if the caret should be put at the end of the word
	 */
	public void moveToPreviousWord(boolean select, boolean toWordEnd) {
	}

	/**
	 *  Adjusts the column selection model to false when the caret is moving without selection.
	 * 
	 *  @param select if this caret moving causes a new selection
	 * 
	 *  @since 3.4.2
	 */
	protected void adjustColumnSelectionModelOnCaretMoving(boolean select) {
	}

	/**
	 *  Toggles the editing mode between overwrite and insert. The caret will change accordingly.
	 */
	public void toggleOverwrite() {
	}

	/**
	 *  Deletes current selected text if any then inserts a line break. It will also add empty spaces following the white
	 *  spaces in the previous line. The caret will stay in the end of the current line.
	 */
	public void splitLine() {
	}

	/**
	 *  Deletes current selected text if any then inserts a line break. It will also add empty spaces following the white
	 *  spaces in the previous line. The caret will be put in the first non-space character or the end of the new line.
	 */
	public void insertBreak() {
	}

	/**
	 *  Inserts a line break after the end of the line where the caret is. It will also add empty spaces following the
	 *  white spaces in the previous line. Just clears selection and leaves the selected text no touch if there is any
	 *  selection. The caret will be put in the first non-space character or the end of the new line.
	 */
	public void startNewLine() {
	}

	/**
	 *  Indents all selected lines no matter if the selection is a line selection or not if there is a selection. If
	 *  there is no selection, a tab or several white spaces will be inserted at the caret position.
	 * 
	 *  @see #isReplaceTabWithSpace()
	 *  @see #getTabSize()
	 */
	public void indentSelection() {
	}

	/**
	 *  Indents all selected lines no matter if the selection is a line selection or not if there is a selection. If
	 *  there is no selection, the line where the caret resides will be unindented.
	 */
	public void unindentSelection() {
	}

	public boolean indentLine(int lineIndex, boolean decrease) {
	}

	/**
	 *  Returns the line's current leading indent.
	 * 
	 *  @param lineIndex       The line number
	 *  @param whitespaceChars If this is non-null, the number of whitespace characters is stored at the 0 index
	 * 
	 *  @return the current indent.
	 */
	public int getCurrentIndentForLine(int lineIndex, int[] whitespaceChars) {
	}

	/**
	 *  Inserts the string into the document. Deletes the selected text first if there is a selection.
	 * 
	 *  @param str the string to insert
	 */
	public void insertChar(String str) {
	}

	/**
	 *  Joins all selected lines by deleting line breaks and the empty spaces leading the lines. If there is no
	 *  selection, the line where the caret resides and the next line will be joined. The current selection should be
	 *  kept and the caret will be moved to where the last join happens.
	 */
	public void joinLines() {
	}

	/**
	 *  Toggles the case when typing an alphabetic char.
	 */
	public void toggleCase() {
	}

	/**
	 *  Inserts the selected text to the start of the current selection. Keeps the current selection and the current
	 *  caret position. If there is no selection, the current line will be duplicated.
	 */
	public void duplicateSelection() {
	}

	/**
	 *  Deletes a char before the caret if there is no selection. If there is a selection, delete all selected texts.
	 */
	public void backspaceChar() {
	}

	/**
	 *  Deletes from current caret to the start of the word if the caret is not at the start of the word or to the start
	 *  of the previous word if the caret is currently at the start of the word.
	 */
	public void backspaceWord() {
	}

	/**
	 *  Deletes a char at the caret if there is no selection. If there is a selection, delete all selected texts.
	 */
	public void deleteChar() {
	}

	/**
	 *  Deletes from current caret to the start of the next word.
	 */
	public void deleteWord() {
	}

	/**
	 *  Deletes the entire line including line break associated with the line.
	 */
	public void deleteLine() {
	}

	/**
	 *  Deletes the selected text from the text area and places it into the clipboard. If there is no selection, the
	 *  current line where the caret resides will be selected and deleted and placed into the clipboard.
	 */
	public void clipboardCut() {
	}

	/**
	 *  Moves the selected text to the offset.
	 * 
	 *  @param offset the offset
	 */
	public void clipboardMove(int offset) {
	}

	/**
	 *  Places the selected text into the clipboard. If there is no selection, selects the current line then places the
	 *  selected line into the clipboard.
	 */
	public void clipboardCopy() {
	}

	/**
	 *  Inserts the clipboard contents into the document. Deletes current selected text first if there is any.
	 */
	public void clipboardPaste() {
	}

	/**
	 *  Shows a dialog so that the customer could choose text from the clipboard contents to paste.
	 */
	public void pasteWithDialog() {
	}

	/**
	 *  Comments all selected lines using line comments no matter if the selection is a line selection or not if there is
	 *  a selection. If there is no selection, the line where the caret resides will be commented.
	 *  <p/>
	 *  It works only if you use LanguageSpec's configureCodeEditor to configure a CodeEditor. Otherwise it doesn't know
	 *  what line comment string to use.
	 */
	public void lineComments() {
	}

	/**
	 *  Comments the selected text using block comments. It works only if you use LanguageSpec's configureCodeEditor to
	 *  configure a CodeEditor. Otherwise it doesn't know what block comment string to use.
	 */
	public void blockComments() {
	}

	public folding.FoldingModel getFoldingModel() {
	}

	public void setFoldingModel(folding.FoldingModel foldingModel) {
	}

	/**
	 *  Expands the folded span if any.
	 */
	public void expandFolding() {
	}

	/**
	 *  Collapses the expanded span if any.
	 */
	public void collapseFolding() {
	}

	/**
	 *  Expands all folded spans.
	 */
	public void expandAll() {
	}

	/**
	 *  Collapses all expanded spans.
	 */
	public void collapseAll() {
	}

	/**
	 *  If there is no folding and has selection, the selected text will be folded and shown as "...". If the entire
	 *  folded texts are selected, the folding will be removed. If there is no folding and no selection, do nothing.
	 */
	public void toggleFoldingSelection() {
	}

	public int modelToViewLine(int line) {
	}

	public int viewToModelLine(int line) {
	}

	@java.lang.Override
	public void repaint() {
	}

	@java.lang.Override
	public void repaint(long tm) {
	}

	public java.awt.Dimension getContentSize() {
	}

	protected java.awt.Dimension recalculateContentSize() {
	}

	protected void resetContentSize() {
	}

	public void configureStyledLabel(StyledLabel styledLabel, Object userObject) {
	}

	/**
	 *  Gets the resource string used by CodeEditor.
	 * 
	 *  @param key the resource key
	 * 
	 *  @return the localized resource string.
	 */
	public String getResourceString(String key) {
	}

	public java.awt.Rectangle modelToView(int offset) {
	}

	/**
	 *  @param startOffset the start offset
	 *  @param endOffset   the end offset
	 * 
	 *  @return the view rectangle from the start offset to the end offset.
	 * 
	 *  @throws BadLocationException     if the startOffset or endOffset is out of the boundary of the document.
	 *  @throws IllegalArgumentException if the startOffset and endOffset is not in the same visible line.
	 */
	public java.awt.Rectangle modelToView(int startOffset, int endOffset) {
	}

	/**
	 *  Fetches the object responsible for making highlights.
	 * 
	 *  @return the highlighter
	 */
	public highlight.Highlighter getHighlighter() {
	}

	/**
	 *  Sets the highlighter to be used.  By default this will be set by the UI that gets installed. This can be changed
	 *  to a custom highlighter if desired.  The highlighter can be set to <code>null</code> to disable it. A
	 *  PropertyChange event ("highlighter") is fired when a new highlighter is installed.
	 * 
	 *  @param h the highlighter
	 * 
	 *  @see #getHighlighter
	 */
	public void setHighlighter(highlight.Highlighter h) {
	}

	/**
	 *  Fetches the object responsible for making fixed highlights that can only be changed through code.
	 * 
	 *  @return the highlighter
	 */
	public highlight.Highlighter getFixedHighlighter() {
	}

	/**
	 *  Sets the fixed highlighter to be used.  Different from regular highlighter which can be set using setHighlighter
	 *  method, the fixed highlighter can only be changed by code. So while the regular highlighter can be cleared when
	 *  the users press escape key, the fixed highlighter will stay.
	 * 
	 *  @param h the highlighter
	 * 
	 *  @see #getHighlighter
	 */
	public void setFixedHighlighter(highlight.Highlighter h) {
	}

	/**
	 *  Creates the object to use for adding highlights.  By default an instance of DefaultUIResourceHighlighter is
	 *  created.  This method can be redefined to provide something else that implements the Highlighter interface or a
	 *  subclass of DefaultHighlighter.
	 * 
	 *  @return the highlighter
	 */
	protected highlight.Highlighter createHighlighter() {
	}

	/**
	 *  Gets all the column guides. Please note, the actual instances of the column guides used by code editor will be in
	 *  the returned array. You can call setter to change the column guides. However it will not take affect until the
	 *  code editor is repainted.
	 * 
	 *  @return the column guides.
	 */
	public ColumnGuide[] getColumnGuides() {
	}

	/**
	 *  Gets all the column guides.
	 * 
	 *  @return all the column guides.
	 */
	protected java.util.List internalGetColumnGuides() {
	}

	/**
	 *  Adds a column guide and repaint the code editor.
	 * 
	 *  @param guide the column guide
	 */
	public void addColumnGuide(ColumnGuide guide) {
	}

	/**
	 *  Removes a column guide and repaint the code editor.
	 * 
	 *  @param guide the column guide
	 */
	public void removeColumnGuide(ColumnGuide guide) {
	}

	/**
	 *  Removes all column guides that were added before and repaint the code editor.
	 */
	public void removeAllColumnGuides() {
	}

	/**
	 *  Clears the selection if any. If there is no selection, clears any highlights. If there is no selection and
	 *  highlights, does nothing.
	 */
	public void escape() {
	}

	/**
	 *  Loads the default actions to the ActionMap so that other tools can look up the action map to find out the
	 *  actions. The actions we loaded are "copy", "cut", "paste", "delete", "undo", "redo", and "selectAll".
	 */
	public void loadActionMap() {
	}

	public void setCaretPosition(int offset) {
	}

	public int getCaretPosition() {
	}

	/**
	 *  Gets the vertical scroll bar used by CodeEditor.
	 * 
	 *  @return the vertical scroll bar.
	 */
	public javax.swing.JScrollBar getVerticalScrollBar() {
	}

	/**
	 *  Gets the horizontal scroll bar used by CodeEditor.
	 * 
	 *  @return the horizontal scroll bar.
	 */
	public javax.swing.JScrollBar getHorizontalScrollBar() {
	}

	/**
	 *  Get corresponding column in the new line which visually in the same column of the column in the old line.
	 * 
	 *  @param column  the column in the old line
	 *  @param oldLine the old line
	 *  @param newLine the new line
	 * 
	 *  @return the column in the new line.
	 */
	public int getCorrespondingColumn(int column, int oldLine, int newLine) {
	}

	@java.lang.Override
	public java.awt.im.InputMethodRequests getInputMethodRequests() {
	}

	public void setOverlayVisible(boolean visible) {
	}

	public javax.swing.JComponent createOverlay() {
	}

	@java.lang.Override
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	/**
	 *  Customizes the dialog to be visible. Those dialog include ClipboardsDialog and FindAndReplaceDialog.
	 *  <p/>
	 *  You could try to customize its location or size before it is visible.
	 * 
	 *  @param dialog the dialog to be customized.
	 */
	protected void customizeDialog(StandardDialog dialog) {
	}

	/**
	 *  Customizes the dialog to be pack. Those dialog include ClipboardsDialog and FindAndReplaceDialog.
	 *  <p/>
	 *  You could try to customize its data model before the panel inside it is actually created.
	 * 
	 *  @param dialog the dialog to be customized.
	 * 
	 *  @since 3.5.9
	 */
	protected void customizeDialogData(StandardDialog dialog) {
	}

	/**
	 *  Clears clipboards memory.
	 */
	public static void clearClipboards() {
	}

	/**
	 *  Gets the flag indicating if the column selection mode should be automatically adjusted on mouse dragging.
	 * 
	 *  @return true if the mode should be adjusted. Otherwise false.
	 * 
	 *  @see #setAdjustColumnSelectionOnMouseEvent(boolean)
	 */
	public boolean isAdjustColumnSelectionOnMouseEvent() {
	}

	/**
	 *  Sets the flag indicating if the column selection mode should be automatically adjusted on mouse dragging.
	 *  <p/>
	 *  By default, the flag is true. You could disable this flag to let your explicit setting always takes effective.
	 * 
	 *  @param adjustColumnSelectionOnMouseEvent the flag
	 */
	public void setAdjustColumnSelectionOnMouseEvent(boolean adjustColumnSelectionOnMouseEvent) {
	}

	/**
	 *  Disposes the CodeEditor.
	 *  <p/>
	 *  If you have one document for multiple CodeEditor instances, you will need invoke this method to release the
	 *  memory when you want to remove a CodeEditor while keeping other CodeEditors in working.
	 *  <p/>
	 *  By default, it will invoke getMarkerArea().dispose() and setDocument(null) to release the memory.
	 * 
	 *  @since 3.4.6
	 */
	public void dispose() {
	}

	/**
	 *  Checks whether pressing enter key will automatically indent the new line to match with the previous line.
	 * 
	 *  @return true or false
	 * 
	 *  @since 3.6.8
	 */
	public boolean isAutoIndent() {
	}

	/**
	 *  Sets the flag whether pressing enter key will automatically indent the new line to match with the previous line.
	 * 
	 *  @param autoIndent true or false
	 * 
	 *  @since 3.6.8
	 */
	public void setAutoIndent(boolean autoIndent) {
	}

	public static class DefaultUIResourceHighlighter {


		public CodeEditor.DefaultUIResourceHighlighter() {
		}
	}
}
