/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A dialog to display multiple clipboards and user can select which clipboard to paste.
 */
public class ClipboardsDialog extends StandardDialog {

	public javax.swing.JList _list;

	public javax.swing.JTextArea _textArea;

	public java.awt.Font _font;

	public ClipboardsDialog(java.awt.Frame owner, String title, java.util.List clipboards, java.awt.Font font) {
	}

	public ClipboardsDialog(java.awt.Dialog owner, String title, java.util.List clipboards, java.awt.Font font) {
	}

	public java.awt.datatransfer.Transferable getSelectedClipboard() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}
}
