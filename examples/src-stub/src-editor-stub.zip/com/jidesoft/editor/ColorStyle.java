/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>ColorStyle</code> is an interface for colors. It basically has
 *  two colors - background or foreground. User can set and get both colors
 *  using this interface.
 */
public interface ColorStyle extends Style {

	/**
	 *  Sets the background.
	 * 
	 *  @param background the new background.
	 */
	public void setBackground(java.awt.Color background);

	/**
	 *  Gets the background.
	 * 
	 *  @return the background.
	 */
	public java.awt.Color getBackground();

	/**
	 *  Sets the foreground.
	 * 
	 *  @param foreground the new foreground.
	 */
	public void setForeground(java.awt.Color foreground);

	/**
	 *  Gets the foreground.
	 * 
	 *  @return the foreground.
	 */
	public java.awt.Color getForeground();
}
