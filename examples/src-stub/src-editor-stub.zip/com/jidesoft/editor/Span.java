/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  An interface to represent a span of text in the document.
 */
public interface Span {

	/**
	 *  Gets the start offset of the span, which is inclusive.
	 * 
	 *  @return the start offset of the span.
	 */
	public int getStartOffset();

	/**
	 *  Gets the end offset of the span, which is exclusive.
	 * 
	 *  @return the end offset of the span.
	 */
	public int getEndOffset();

	/**
	 *  Checks if the span is valid.
	 * 
	 *  @return true if the span is valid.
	 */
	public boolean isValid();
}
