/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  A <code>StatusBarItem</code> to show the caret view position of a <code>CodeEditor</code>.
 *  Typically, users are interested in the caret model position which is displayed in {@link CaretModelPositionStatusBarItem}.
 *  This status bar item as well as and {@link CaretOffsetStatusBarItem} are mainly used internally for debugging purpose.
 */
public class CaretViewPositionStatusBarItem extends CaretStatusBarItem {

	public CaretViewPositionStatusBarItem() {
	}

	public CaretViewPositionStatusBarItem(String name) {
	}

	@java.lang.Override
	public void initialize() {
	}

	@java.lang.Override
	public void caretUpdated(com.jidesoft.editor.CodeEditor editor) {
	}
}
