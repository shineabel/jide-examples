/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  A <code>StatusBarItem</code> to show the caret model position of a <code>CodeEditor</code>.
 *  This is the typical information users are interested in. We also have {@link CaretViewPositionStatusBarItem}
 *  and {@link CaretOffsetStatusBarItem} which also show the other kinds of caret positions. But they are mainly for debugging purpose.
 */
public class CaretModelPositionStatusBarItem extends CaretStatusBarItem {

	public CaretModelPositionStatusBarItem() {
	}

	public CaretModelPositionStatusBarItem(String name) {
	}

	@java.lang.Override
	public void initialize() {
	}

	@java.lang.Override
	public void caretUpdated(com.jidesoft.editor.CodeEditor editor) {
	}
}
