/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>CodeEditorMarginSupport</code> provides the margin support for CodeEditor and its subclasses.
 */
public class CodeEditorMarginSupport {

	protected CodeEditor _codeEditor;

	public CodeEditorMarginSupport(CodeEditor codeEditor) {
	}

	public CodeEditor getCodeEditor() {
	}

	@java.lang.Override
	public int getViewPosition() {
	}

	@java.lang.Override
	public int getViewSize() {
	}

	@java.lang.Override
	public void installListeners(RepaintCallback repaintCallback, ModelChangedCallback modelChangedCallback) {
	}

	@java.lang.Override
	public void uninstallListeners(RepaintCallback repaintCallback, ModelChangedCallback modelChangedCallback) {
	}
}
