/**
 *  The package contains classes for the selection model for JIDE Code Editor product.
 */
package com.jidesoft.editor.selection;


/**
 *  <code>SelectionEvent</code> is used to notify interested parties that
 *  selection has been changed in the <code>SelectionModel</code>.
 *  The event has both the old selection start/end offset and the new selection start/end offset.
 */
public class SelectionEvent extends java.util.EventObject {

	public SelectionEvent(com.jidesoft.editor.CodeEditor editor, int oldSelectionStart, int oldSelectionEnd, int newSelectionStart, int newSelectionEnd) {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public int getOldSelectionStart() {
	}

	public int getOldSelectionEnd() {
	}

	public int getNewSelectionStart() {
	}

	public int getNewSelectionEnd() {
	}

	@java.lang.Override
	public String toString() {
	}
}
