/**
 *  The package contains classes for the selection model for JIDE Code Editor product.
 */
package com.jidesoft.editor.selection;


/**
 *  An interface to represent the selection in CodeEditor.
 */
public interface SelectionModel {

	/**
	 *  Gets the offset of the selection start.
	 * 
	 *  @return the offset of the selection start.
	 */
	public int getSelectionStart();

	/**
	 *  Gets the offset of the selection end.
	 * 
	 *  @return the offset of the selection end.
	 */
	public int getSelectionEnd();

	/**
	 *  Gets the view position of the selection start.
	 * 
	 *  @return the view position of the selection start.
	 *  @since 3.3.3
	 */
	public com.jidesoft.editor.caret.CaretPosition getSelectionStartViewPosition();

	/**
	 *  Gets the view position of the selection end.
	 * 
	 *  @return the view position of the selection end.
	 *  @since 3.3.3
	 */
	public com.jidesoft.editor.caret.CaretPosition getSelectionEndViewPosition();

	/**
	 *  Gets the line number of the selection start.
	 * 
	 *  @return the line number of the selection start.
	 */
	public int getSelectionStartLine();

	/**
	 *  Gets the line number of the selection end.
	 * 
	 *  @return the line number of the selection end.
	 */
	public int getSelectionEndLine();

	/**
	 *  Gets the selected text.
	 * 
	 *  @return the selected text.
	 */
	public String getSelectedText();

	/**
	 *  Sets the selection.
	 * 
	 *  @param start the start of the selection
	 *  @param end   the end of the selection
	 */
	public void setSelection(int start, int end);

	/**
	 *  Sets the selection.
	 * 
	 *  @param startPosition the start of the selection
	 *  @param endPosition   the end of the selection
	 *  @since 3.3.3
	 */
	public void setSelection(com.jidesoft.editor.caret.CaretPosition startPosition, com.jidesoft.editor.caret.CaretPosition endPosition);

	/**
	 *  Gets the offset in the document based on the offset in the selection.
	 * 
	 *  @param offsetInSelection the offset in the selection
	 *  @return the offset in the document. -1 if the offset does not exist in the document.
	 *  @since 3.3.3
	 */
	public int offsetInSelectionToOffsetInDocument(int offsetInSelection);

	/**
	 *  Gets the offset in the selection based on the offset in the document.
	 * 
	 *  @param offsetInSDocument the offset in the document
	 *  @return the offset in the selection.
	 *  @since 3.3.3
	 */
	public int offsetInDocumentToOffsetInSelection(int offsetInSDocument);

	/**
	 *  Clears the selection.
	 */
	public void clearSelection();

	/**
	 *  Checks if the <code>SelectionModel</code> has any selection.
	 * 
	 *  @return true if it has selection. Otherwise false.
	 */
	public boolean hasSelection();

	/**
	 *  Checks if the <code>SelectionModel</code> is in column selection mode, a.k.a vertical selection.
	 * 
	 *  @return true if in column selection mode.
	 */
	public boolean isColumnSelectionMode();

	/**
	 *  Sets the <code>SelectionModel</code> to column selection mode.
	 * 
	 *  @param columnSelectionMode the flag
	 */
	public void setColumnSelectionMode(boolean columnSelectionMode);

	/**
	 *  Adds a <code>SelectionListener</code> to the <code>SelectionModel</code> to receive any selection change event.
	 * 
	 *  @param selectionListener the selection listener
	 */
	public void addSelectionListener(SelectionListener selectionListener);

	/**
	 *  Removes the <code>SelectionListener</code> from the <code>SelectionModel</code> that was added before.
	 * 
	 *  @param selectionListener the selection listener
	 */
	public void removeSelectionListener(SelectionListener selectionListener);

	/**
	 *  Gets all the <code>SelectionListener</code>s added to this <code>SelectionModel</code>.
	 * 
	 *  @return all the <code>SelectionListener</code>s added to this <code>SelectionModel</code>.
	 */
	public SelectionListener[] getSelectionListeners();
}
