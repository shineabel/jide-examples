/**
 *  The package contains classes for code folding for JIDE Code Editor product.
 */
package com.jidesoft.editor.folding;


/**
 *  The listener interface for receiving folding span events.
 */
public interface FoldingSpanListener extends java.util.EventListener {

	/**
	 *  Called when folding span changed such as a folding span is added or removed, expanded or collapsed.
	 * 
	 *  @param e
	 */
	public void foldingSpanChanged(FoldingSpanEvent e);
}
