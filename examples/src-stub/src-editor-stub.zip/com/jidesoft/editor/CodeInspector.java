/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  An interface to inspect the code. You can add your own inspector to inspect the code. If there are any warnings or
 *  errors or other kinds of information during inspection, you can add them to <code>MarkerModel</code> so that the
 *  <code>MarkerArea</code> can display them as markers on the left side of the <code>CodeEditor</code>.
 */
public interface CodeInspector {

	/**
	 *  Inspects the code editor and add the markers to the MarkerModel.
	 * 
	 *  @param codeEditor the CodeEditor
	 *  @param evt        the DocumentEvent if the inspection is triggered by a DocumentEvent. Or null if it is triggered
	 *                    manually.
	 *  @param model      the marker model. You can add marker to this marker model while inspecting.
	 */
	public void inspect(CodeEditor codeEditor, javax.swing.event.DocumentEvent evt, MarkerModel model);
}
