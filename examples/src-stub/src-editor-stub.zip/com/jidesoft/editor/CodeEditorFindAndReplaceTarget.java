/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A <code>FindAndReplaceTarget</code> implementation for <code>CodeEditor</code>.
 */
public class CodeEditorFindAndReplaceTarget implements com.jidesoft.search.FindAndReplaceTarget, javax.swing.event.DocumentListener {

	public CodeEditorFindAndReplaceTarget(CodeEditor codeEditor) {
	}

	public com.jidesoft.search.FindResultIntepreter getIntepreter() {
	}

	public CodeEditor getCodeEditor() {
	}

	public javax.swing.JComponent getConfigurationPanel() {
	}

	public boolean hasNext() {
	}

	public void next() {
	}

	public boolean hasPrevious() {
	}

	public void previous() {
	}

	public int getCurrentPosition(boolean forward) {
	}

	public void adjustCurrentPosition(String searchingText, boolean forward) {
	}

	public void highlight(int start, int end) {
	}

	public void replace(int offset, int len, String str) {
	}

	public java.awt.Window getPromptDialogParent() {
	}

	public java.awt.Point getPromptDialogLocation(java.awt.Rectangle dialogBounds) {
	}

	public java.awt.Point getPromptDialogLocation() {
	}

	public void scrollToShowCaret(java.awt.Rectangle promptDialogBounds) {
	}

	public String getCurrentName() {
	}

	public CharSequence getCurrentText() {
	}

	public void showMessage(String message) {
	}

	public void replaceAllStarts() {
	}

	public void replaceAllEnds() {
	}

	protected void setTargetChanged(boolean targetChanged) {
	}

	public boolean isTargetChanged() {
	}

	public void insertUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void removeUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void changedUpdate(javax.swing.event.DocumentEvent e) {
	}

	public String getResourceString(String key) {
	}

	public java.util.Locale getLocale() {
	}
}
