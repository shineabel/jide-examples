/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


public class CodeEditorResource {

	public CodeEditorResource() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
