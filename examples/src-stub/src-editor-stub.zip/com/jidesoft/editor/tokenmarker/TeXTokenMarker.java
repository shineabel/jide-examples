/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  TeX token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: TeXTokenMarker.java,v 1.16 1999/12/13 03:40:30 sp Exp $
 */
public class TeXTokenMarker extends TokenMarker {

	public static final byte BDFORMULA = 100;

	public static final byte EDFORMULA = 101;

	public TeXTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
