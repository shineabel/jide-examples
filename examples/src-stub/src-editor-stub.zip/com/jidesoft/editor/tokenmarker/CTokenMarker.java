/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  C token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: CTokenMarker.java,v 1.34 1999/12/13 03:40:29 sp Exp $
 */
public class CTokenMarker extends TokenMarker {

	public CTokenMarker() {
	}

	public CTokenMarker(boolean cpp, com.jidesoft.editor.KeywordMap keywords) {
	}

	/**
	 *  Get current keywords in using.
	 * 
	 *  @return get the current keywords in using.
	 */
	public com.jidesoft.editor.KeywordMap getCurrentKeywords() {
	}

	/**
	 *  Set the keywords to be current in using.
	 * 
	 *  @param keywords the keywords
	 */
	public void setCurrentKeywords(com.jidesoft.editor.KeywordMap keywords) {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
