/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Verilog token marker.
 * 
 *  @author Bogdan Mitu
 *  @version $Id: VerilogTokenMarker.java,v 1.1.1.1 2001/08/20 22:31:50 gfx Exp $
 */
public class VerilogTokenMarker extends TokenMarker {

	public VerilogTokenMarker() {
	}

	public VerilogTokenMarker(com.jidesoft.editor.KeywordMap keywords) {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
