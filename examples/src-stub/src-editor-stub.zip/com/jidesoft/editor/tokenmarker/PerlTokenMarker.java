/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Perl token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: PerlTokenMarker.java,v 1.11 1999/12/13 03:40:30 sp Exp $
 */
public class PerlTokenMarker extends TokenMarker {

	public static final byte S_ONE = 100;

	public static final byte S_TWO = 101;

	public static final byte S_END = 102;

	public PerlTokenMarker() {
	}

	public PerlTokenMarker(com.jidesoft.editor.KeywordMap keywords) {
	}

	@java.lang.Override
	public void insertLines(int index, int lines) {
	}

	@java.lang.Override
	public void deleteLines(int index, int lines) {
	}

	@java.lang.Override
	protected void ensureCapacity(int index) {
	}

	@java.lang.Override
	public byte markTokensImpl(byte _token, javax.swing.text.Segment line, int lineIndex) {
	}
}
