/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Plain TokenMarker that marks all texts as normal text. If you want folding span feature however no need for any TokenMarker,
 *  please let your CodeEditor use this TokenMaker.
 * 
 *  @since 3.2.0
 */
public class PlainTokenMarker extends TokenMarker {

	public PlainTokenMarker() {
	}

	@java.lang.Override
	protected byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
