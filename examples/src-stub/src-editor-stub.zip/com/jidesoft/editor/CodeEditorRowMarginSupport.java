/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>CodeEditorRowMarginSupport</code> provides the margin support for CodeEditor and its subclasses.
 */
public class CodeEditorRowMarginSupport extends CodeEditorMarginSupport {

	public CodeEditorRowMarginSupport(CodeEditor codeEditor) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	@java.lang.Override
	public int getRowHeight(int row) {
	}

	@java.lang.Override
	public int positionToRow(int position) {
	}

	@java.lang.Override
	public int rowToPosition(int row) {
	}

	@java.lang.Override
	public void scrollTo(int beginRow, int endRow, boolean select) {
	}

	@java.lang.Override
	public int visualRowToActualRow(int visualRow) {
	}

	@java.lang.Override
	public int actualRowToVisualRow(int actualRow) {
	}

	@java.lang.Override
	public int getBaselineAdjustment() {
	}
}
