/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>Marker</code> represents a range of text in code editor used by the {@link com.jidesoft.marker.MarkerModel}. It
 *  has a start offset and an end offset. By default, there are two types of markers - error and warning. But you can
 *  always define your own types of markers. You can also associate a tooltip with a marker. The tooltip will be shown
 *  when user mouse moves over the marker stripe.
 * 
 *  @deprecated please use com.jidesoft.marker.Marker.
 */
@java.lang.Deprecated
public class Marker extends com.jidesoft.marker.Marker {

	public Marker(int startOffset, int endOffset, int type, String tooltip) {
	}
}
