/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  An interface to paint the marker stripes.
 * 
 *  @deprecated please use com.jidesoft.marker.MarkerStripePainter instead.
 */
@java.lang.Deprecated
public interface MarkerStripePainter {

	/**
	 *  Paints the marker stripe.
	 *  <p/>
	 *  Please note, you don't need to reset the color used in this paint method because we will reset it after the
	 *  paint() of all painters are called.
	 * 
	 *  @param markerArea
	 *  @param g
	 *  @param marker
	 *  @param rect
	 */
	public void paint(com.jidesoft.marker.MarkerArea markerArea, java.awt.Graphics g, com.jidesoft.marker.Marker marker, java.awt.Rectangle rect);
}
