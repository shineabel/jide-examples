/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  An interface to store the marker information in an editor.
 * 
 *  @deprecated please use {@link com.jidesoft.marker.MarkerModel} instead.
 */
@java.lang.Deprecated
public interface MarkerModel {
}
