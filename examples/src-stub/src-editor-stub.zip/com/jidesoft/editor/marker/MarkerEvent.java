/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerEvent</code> is used to notify interested parties that marker has been changed in the
 *  <code>MarkerModel</code>.
 * 
 *  @deprecated please com.jidesoft.marker.MarkerEvent instead
 */
@java.lang.Deprecated
public class MarkerEvent extends com.jidesoft.marker.MarkerEvent {

	/**
	 *  Creates a <code>MarkerEvent</code>.
	 * 
	 *  @param source
	 *  @param marker
	 *  @param type
	 */
	public MarkerEvent(Object source, com.jidesoft.marker.Marker marker, int type) {
	}

	/**
	 *  Creates a <code>MarkerEvent</code>.
	 * 
	 *  @param source
	 *  @param marker
	 *  @param type
	 *  @param isAdjusting
	 */
	public MarkerEvent(Object source, com.jidesoft.marker.Marker marker, int type, boolean isAdjusting) {
	}
}
