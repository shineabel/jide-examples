/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerStripe</code> is a panel to display all the markers in a marker model. The paint of each stripe is done
 *  by a class called {@link com.jidesoft.marker.MarkerStripePainter}. By default, {@link
 *  com.jidesoft.marker.DefaultMarkerStripePainter} is used. You can always set your own painter by calling {@link
 *  #setPainter(com.jidesoft.marker.MarkerStripePainter)}.
 */
public class MarkerStripe extends com.jidesoft.marker.MarkerStripe {

	public MarkerStripe(MarkerArea markerArea) {
	}

	public MarkerStripe(com.jidesoft.editor.CodeEditor codeEditor, MarkerArea markerArea) {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor) {
	}

	/**
	 *  Gets the markers at the y positions. Since each y position could represent a range of lines in code editor, thus
	 *  there could be multiple markers in that line range. That's why method returns a list of Markers. This method is
	 *  protected so subclass can use it get the markers then paint them.
	 * 
	 *  @param p the mouse position
	 *  @return the markers at the y positions.
	 */
	protected java.util.List getMarkersAt(java.awt.Point p) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}
}
