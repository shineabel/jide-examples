/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerEye</code> is a panel to indicate the inspecting status. The paint of MarkerEye is done by a class called
 *  {@link com.jidesoft.marker.MarkerEyePainter}. By default, {@link com.jidesoft.marker.DefaultMarkerEyePainter} is
 *  used. You can always set your own painter by calling {@link #setPainter(com.jidesoft.marker.MarkerEyePainter)}.
 * 
 *  @author Patrick Gotthardt
 */
public class MarkerEye extends com.jidesoft.marker.MarkerEye {

	/**
	 *  Creates a <code>MarkerEye</code>.
	 * 
	 *  @param markerArea
	 */
	public MarkerEye(MarkerArea markerArea) {
	}

	/**
	 *  Creates a <code>MarkerEye</code>.
	 * 
	 *  @param codeEditor
	 *  @param markerArea
	 */
	public MarkerEye(com.jidesoft.editor.CodeEditor codeEditor, MarkerArea markerArea) {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor codeEditor) {
	}
}
