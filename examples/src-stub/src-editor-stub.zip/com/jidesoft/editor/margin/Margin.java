/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  An interface for the margin component. Margin is used for as children component for {@link MarginArea} in {@link
 *  CodeEditor}.
 */
public interface Margin {

	/**
	 *  Gets the code editor.
	 * 
	 *  @return the code editor.
	 */
	public com.jidesoft.editor.CodeEditor getCodeEditor();

	/**
	 *  Sets the code editor.
	 * 
	 *  @param editor
	 */
	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor);
}
