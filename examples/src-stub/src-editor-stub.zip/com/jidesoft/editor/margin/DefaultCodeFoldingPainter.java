/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  The default painter for code folding.
 */
public class DefaultCodeFoldingPainter implements CodeFoldingPainter {

	public DefaultCodeFoldingPainter() {
	}

	public int paintFoldingStart(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state) {
	}

	public int paintFoldingEnd(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state) {
	}

	public void paintCollapsedFolding(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state) {
	}

	public void paintExpandedFolding(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state) {
	}

	public void paintFoldingLine(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state) {
	}

	public void paintBackground(java.awt.Component c, java.awt.Graphics g, java.awt.Rectangle rect) {
	}

	public int getPreferredWidth() {
	}
}
