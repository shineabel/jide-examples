/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A margin component for line numbers.
 */
public class LineNumberMargin extends AbstractLineMargin {

	public LineNumberMargin(com.jidesoft.editor.CodeEditor editor) {
	}

	@java.lang.Override
	public void paintLineMargin(java.awt.Graphics g, java.awt.Rectangle rect, int line) {
	}

	public int getPreferredWidth() {
	}

	@java.lang.Override
	public String getToolTipText(int line) {
	}

	/**
	 *  Gets the flag indicating if tooltip should be displayed.
	 * 
	 *  @return true if tooltip should be displayed. Otherwise false.
	 * 
	 *  @see #setShowTooltip(boolean)
	 */
	public boolean isShowTooltip() {
	}

	/**
	 *  Sets the flag indicating if tooltip should be displayed.
	 *  <p/>
	 *  By default, the value is true to keep original behavior.
	 * 
	 *  @param showTooltip the flag
	 */
	public void setShowTooltip(boolean showTooltip) {
	}

	@java.lang.Override
	protected MarginSupport.ModelChangedCallback createModelChangedCallback() {
	}
}
