/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  The event to represent a change during finding and replacing.
 *  Each event will have a status id and some optional fields depending on what kind of status it is.
 *  See below for a list of possible status and which optional fields are available in each status.
 *  <ul>
 *  <li> SEARCH_STARTED: this event is fired when searching or replacing starts. There is no data in this event.
 *  <li> SEARCH_STARTED_TEXT: this event is fired when it starts to work on a new piece of text. getTargetName() will give you the new name.
 *  This event will fire even if you just have one piece of text, so you can always use this event to find out the name of the text. During searching-all,
 *  you can use the name to display a status message so that user knows
 *  <li> SEARCH_FINISHED: this event is fired when searching or replacing is done. If you are doing a searching-all, getFindResults() will
 *  tell you all the find results. If you are doing a interactive searching/replacing, getFindResults() will be null.
 *  <li> SEARCH_FINISHED_TEXT: this event is fired when searching or replacing is done with a piece of text.
 *  If you are doing a searching-all, getFindResults() will tell you all the find results. If you are doing
 *  an interactive searching/replacing, getFindResults() will be null. In either case, getTargetName() will always tell you
 *  the text name, just like in SEARCH_STARTED_TEXT.
 *  <li> SEARCH_FOUND: This event is fired when a matching text is found. getFindResult() will always be a non-null value which tells you
 *  the start and end offset of the matching text. This event is fired for both interactive search and search-all.
 *  <li> SEARCH_REPLACED: This event is fired when a matching text is found and replaced with the replacement text. getFindResult() will always be a non-null value which tells you
 *  the start and end offset of the matching text. getReplaceText() will tell you the replacement text. This event is fired for both interactive replace and replace-all.
 *  <ul>
 */
public class FindAndReplaceEvent extends java.util.EventObject {

	public static final int SEARCH_STARTED = 0;

	public static final int SEARCH_STARTED_TEXT = 1;

	public static final int SEARCH_FINISHED = 2;

	public static final int SEARCH_FINISHED_TEXT = 3;

	public static final int SEARCH_FOUND = 4;

	public static final int SEARCH_REPLACED = 5;

	public FindAndReplaceEvent(Object source, int id) {
	}

	public FindAndReplaceEvent(Object source, int status, FindResult findResult) {
	}

	public FindAndReplaceEvent(Object source, int status, String targetName, FindResults findResults) {
	}

	public FindAndReplaceEvent(Object source, int status, FindResults findResults) {
	}

	public FindAndReplaceEvent(Object source, int status, String targetName) {
	}

	public FindAndReplaceEvent(Object source, int status, FindResult findResult, String replaceString) {
	}

	public int getStatus() {
	}

	public FindResult getFindResult() {
	}

	public FindResults getFindResults() {
	}

	public String getTargetName() {
	}

	public String getReplaceText() {
	}

	@java.lang.Override
	public String toString() {
	}
}
