/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindAndReplaceDialog</code> is the dialog used when user wants to find and replace a text. The implementation
 *  of this dialog is actually very simple because the logic and the UI is actually in <code>FindAndReplace</code> and
 *  <code>FindAndReplacePanel</code> respectively. If you want to use find and replace feature in somewhere that is not a
 *  dialog, you can actually do it by using <code>FindAndReplace</code> and <code>FindAndReplacePanel</code> directly.
 */
public class FindAndReplaceDialog extends StandardDialog {

	protected FindAndReplacePanel _findAndReplacePanel;

	protected FindAndReplace _findAndReplace;

	public FindAndReplaceDialog(java.awt.Frame owner, String title, FindAndReplace findAndReplace) {
	}

	public FindAndReplaceDialog(java.awt.Dialog owner, String title, FindAndReplace findAndReplace) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	public FindAndReplace getFindAndReplace() {
	}
}
