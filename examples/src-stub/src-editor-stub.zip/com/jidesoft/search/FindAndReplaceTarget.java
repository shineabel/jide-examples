/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindAndReplaceTarget</code> is the target that <code>FindAndReplace</code> works on. Basically it abstracts all
 *  the methods that <code>FindAndReplace</code> needs in order to perform find and replace on anything.
 *  <p/>
 *  <code>FindAndReplaceTarget</code> can represent a piece of text, several pieces of text, a file, all files in the
 *  same folder, or a list of files at any location. By default, we provide CodeEditorFindAndReplaceTarget for one
 *  CodeEditor, CodeEditorSelectionFindAndReplaceTarget for the selection in a CodeEditor and
 *  CodeEditorDocumentPaneFindAndReplaceTarget for all CodeEditor inside a DocumentPane.
 */
public interface FindAndReplaceTarget {

	/**
	 *  <code>FindAndReplaceTarget</code> can be added to <code>FindAndReplacePanel</code> so that user can configure it.
	 *  The panel returned from this method is the panel. <code>FindAndReplacePanel</code> will add a radio button before
	 *  the configuration panel, so there is no need to have a radio button inside the panel. If there is nothing to
	 *  configure for this target, you just return a JLabel with the descriptive name. For example, something like new
	 *  JLabel("Selection") if the target is for the selected text in a CodeEditor.
	 *  <p/>
	 *  <code>FindAndReplacePanel</code> will arrange all configuration panels vertically, so you should make sure the
	 *  configuration panel are arranged horizontally (very wide instead very tall) so that the overall appearance looks
	 *  good. If for whatever reason you have to make the configuration very tall, you may need to override {@link
	 *  FindAndReplacePanel#createTargetPanel()} method so that you can do the layout of the configuration panels
	 *  yourself.
	 * 
	 *  @return the configuration panel.
	 */
	public javax.swing.JComponent getConfigurationPanel();

	/**
	 *  Gets the name of the target.
	 * 
	 *  @return the name of the target.
	 */
	public String getCurrentName();

	/**
	 *  Gets the current text.
	 * 
	 *  @return the current text.
	 */
	public CharSequence getCurrentText();

	/**
	 *  Gets the current position where the next search will start. Usually in a CodeEditor, it will be the caret
	 *  position.
	 * 
	 *  @param forward true or false.
	 *  @return the current position.
	 */
	public int getCurrentPosition(boolean forward);

	/**
	 *  Adjusts current position according to searching text in the first attempt to search.
	 * 
	 *  @param searchingText current searching text
	 *  @param forward true or false.
	 */
	public void adjustCurrentPosition(String searchingText, boolean forward);

	/**
	 *  Highlights the text to indicate the text matches the searching criteria.
	 * 
	 *  @param start the start offset of the text that is found.
	 *  @param end   the end offset of the text that is found.
	 */
	public void highlight(int start, int end);

	/**
	 *  Replaces some text with the new text. This method is used to replace the text.
	 * 
	 *  @param offset the offset from the beginning.
	 *  @param len    the number of characters to be replaced.
	 *  @param str    the new text to replace the old text.
	 *  @throws BadLocationException if the given offset is not a valid position within the document
	 */
	public void replace(int offset, int len, String str);

	/**
	 *  Replace all starts. This is used by undo feature so that when undo this operation, it undoes all string that were
	 *  replaced.
	 */
	public void replaceAllStarts();

	/**
	 *  Replace all ends. This is used by undo feature so that when undo this operation, it undoes all string that were
	 *  replaced.
	 */
	public void replaceAllEnds();

	/**
	 *  Gets the window that can be used as the parent of the prompt dialog.
	 * 
	 *  @return the window that can be used as the parent of the prompt dialog.
	 */
	public java.awt.Window getPromptDialogParent();

	/**
	 *  Gets the prompt dialog location. Please note, the location is the screen location. We need this location in order
	 *  to show the prompt dialog where it doesn't obscure the text behind especially where the text is found.
	 * 
	 *  @param dialogBounds the bounds of the dialog before determining its location
	 *  @return the prompt dialog location.
	 */
	public java.awt.Point getPromptDialogLocation(java.awt.Rectangle dialogBounds);

	/**
	 *  Gets the default prompt dialog location without concerning the caret position.
	 * 
	 *  @return the prompt dialog location.
	 */
	public java.awt.Point getPromptDialogLocation();

	/**
	 *  Scrolls to show caret.
	 * 
	 *  @param promptDialogBounds the prompt dialog bounds
	 */
	public void scrollToShowCaret(java.awt.Rectangle promptDialogBounds);

	/**
	 *  Shows a message. <code>FindAndReplace</code> needs to provide some feedback to user. It will call this method to
	 *  show user a message. It's up to you how to implement it. In CodeEditor, we use a JidePopup to display a
	 *  tooltip-like popup near the caret. You can display a message in your status bar if you want.
	 * 
	 *  @param message the message
	 */
	public void showMessage(String message);

	/**
	 *  Checks if there is more chunk of text after the current text when FindAndReplace reaches the end of the current
	 *  text when searching forward.
	 * 
	 *  @return true if there is another piece of text after the current text.
	 */
	public boolean hasNext();

	/**
	 *  Changes the current text to the next one.
	 */
	public void next();

	/**
	 *  Checks if there is more chunk of text before the current text when FindAndReplace reaches the start of the
	 *  current text when searching backward.
	 * 
	 *  @return true if there is another piece of text after the current text.
	 */
	public boolean hasPrevious();

	/**
	 *  Changes the current text to the previous one.
	 */
	public void previous();

	/**
	 *  Gets the interpreter that can understand the start offset and end offset in a <code>FindResult</code>.
	 *  <code>CodeEditor</code> implements FindResultIntepreter.
	 * 
	 *  @return the FindResultIntepreter.
	 */
	public FindResultIntepreter getIntepreter();

	/**
	 *  Checks if the text in the target changes.
	 * 
	 *  @return true if the text changes. Otherwise false.
	 */
	public boolean isTargetChanged();

	/**
	 *  Gets resource string from target.
	 * 
	 *  @param key the resource key
	 *  @return the localized resource string.
	 */
	public String getResourceString(String key);

	/**
	 *  Gets the target's locale.
	 * 
	 *  @return the locale in use.
	 */
	public java.util.Locale getLocale();
}
