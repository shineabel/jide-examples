/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindResult</code> represents one occurrence of the find result. <code>FindResults</code> represents all the
 *  <code>FindResult</code>s in one piece of the text.
 */
public class FindResults {

	public FindResults(String name, FindResultIntepreter intepreter) {
	}

	/**
	 *  Gets the name of the find results.
	 * 
	 *  @return the name of the find results.
	 */
	public String getName() {
	}

	/**
	 *  Adds a <code>FindResult</code>.
	 * 
	 *  @param findResult
	 */
	public void addFindResult(FindResult findResult) {
	}

	/**
	 *  Adds a <code>FindResults</code>. Please note, it doesn't take each <code>FindResult</code> of the
	 *  <code>FindResults</code> and add them separately. It will simply add a FindResults as a whole thing. By allowing
	 *  adding <code>FindResults</code> to <code>FindResults</code>, you can easily form a tree of
	 *  <code>FindResult</code>s.
	 * 
	 *  @param findResults
	 */
	public void addFindResults(FindResults findResults) {
	}

	/**
	 *  Gets the element at the index.
	 * 
	 *  @param index
	 *  @return the element at the index.
	 */
	public Object getElementAt(int index) {
	}

	/**
	 *  Gets the element count.
	 * 
	 *  @return the element count.
	 */
	public int getElementCount() {
	}

	/**
	 *  Gets the number of FindResult. It will recursively iterate into each FindResults and find all FindResult(s).
	 * 
	 *  @return the number of all FindResult(s).
	 */
	public int getNumberOfFindResults() {
	}

	/**
	 *  Gets the first match result for the interpreter.
	 * 
	 *  @param interpreter the target interpreter
	 *  @return the first match result. null if there is no match.
	 *  @since 3.3.1
	 */
	public FindResult getFirstFindResult(FindResultIntepreter interpreter) {
	}

	/**
	 *  Gets the interpreter.
	 * 
	 *  @return the interpreter.
	 */
	public FindResultIntepreter getIntepreter() {
	}
}
