/**
 *  The package contains all kinds of fields based on text fields for JIDE Grids product.
 */
package com.jidesoft.field;


/**
 *  <code>IPTextField</code> is a component for editing an IP address. It can accept IP address as either a String such
 *  as "255.16.32.15" (using {@link #setText(String)} or an int array such as new int[]{255, 16, 32, 15} (using {@link
 *  #setValue(int[])} . It also can return IP address in either of the two formats. You can use static methods {@link
 *  #convertIPToString(int[])} and {@link #convertStringToIP(String)} to convert between the two formats.
 *  <p/>
 *  <code>IPTextField</code> also supports subnet mask. You can specify a Class B mask "255.255.0.0" for example using
 *  {@link #setSubnetMask(String)} method. Any IP addresses that are outside the subnet will be automatically corrected.
 *  <p/>
 *  Here are some technical notes. At first glance, you may think it is possible to implement IPTextField using
 *  JFormattedTextField with MaskFormatter. Sure, it can get your almost there. However it's not easy to enforce each
 *  octet of the IP address to less than 255. In our implementation, we actually use four JTextFields for each octet and
 *  three JLabels for the "." between octets. However we still want to give user the impression that it is one text
 *  field. That's why we add code to handle all the keystrokes that can be possibly used. For example, left, right, home,
 *  end and backspace keys will transverse among text fields transparently. "." key will navigate to next field. You could
 *  invoke {@link #getTextFields()} to get all the JTextFields it created.
 *  <p/>
 *  Although it is one of the JTextFields that owns the focus, you may want to know if IPTextField right now "owns" the
 *  focus. For this purpose, you could add focus listener to this component. As long as the focus is switched between the
 *  JTextFields inside, you will not get the listener triggered.
 *  <p/>
 *  This component is still in beta.
 */
public class IPTextField extends javax.swing.JPanel {

	public final String PROPERTY_SUBNET_MASK = "subnetMask";

	public final String PROPERTY_EDITABLE = "editable";

	protected transient javax.swing.event.ChangeEvent changeEvent;

	public IPTextField() {
	}

	public IPTextField(String ip) {
	}

	public IPTextField(int[] ip) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Sets the IP as text.
	 * 
	 *  @param str the new IP text
	 */
	public void setText(String str) {
	}

	/**
	 *  Gets the IP as text. If an octet is not filled in, it will be 0.
	 * 
	 *  @return IP as text.
	 */
	public String getText() {
	}

	/**
	 *  Sets the IP as int[]. Each part in the IP address is an integer in the array.
	 * 
	 *  @param ip the IP address int array
	 */
	public void setValue(int[] ip) {
	}

	/**
	 *  Gets the IP address as int[]. If an octet is not filled in, it will be 0.
	 * 
	 *  @return IP address as int[].
	 */
	public int[] getValue() {
	}

	/**
	 *  Gets the raw texts in each text field.
	 * 
	 *  @return the actual text that is in each text field.
	 *  @see #setRawText(String[])
	 */
	public String[] getRawText() {
	}

	/**
	 *  Sets the raw texts in each text field.
	 * 
	 *  @param rawText the actual text that is in each text field.
	 */
	public void setRawText(String[] rawText) {
	}

	/**
	 *  Checks if the value in IPTextField is valid. It will return false if <ul> <li>Any of the text fields is empty
	 *  <li>Any of the text fields contains an invalid number character. <li>Any of the text fields contains an int value
	 *  less than 0 or greater than 255. </ul> Even if this method returns false, {@link #getValue()} will fill invalid
	 *  fields with 0 to make a valid IP address. However if you use {@link #getRawText()}, it will give you the exact
	 *  text in each octet so that you can check to see which value is invalid.
	 * 
	 *  @return true if the value is valid. Otherwise false.
	 */
	public boolean isValueValid() {
	}

	public int[] getSubnetMask() {
	}

	public void setSubnetMask(int[] subnetMask) {
	}

	public void setSubnetMask(String subnetMask) {
	}

	/**
	 *  Converts an ip (int array) to a string.
	 * 
	 *  @param ip the IP address in int array
	 *  @return the String of the IP.
	 */
	public static String convertIPToString(int[] ip) {
	}

	/**
	 *  Converts a string to ip (int array).
	 * 
	 *  @param str the IP string
	 *  @return the IP address in int array.
	 */
	public static int[] convertStringToIP(String str) {
	}

	@java.lang.Override
	public void requestFocus() {
	}

	@java.lang.Override
	public boolean requestFocus(boolean temporary) {
	}

	@java.lang.Override
	public boolean requestFocusInWindow() {
	}

	@java.lang.Override
	public boolean hasFocus() {
	}

	/**
	 *  Creates the text fields for this IPTextField.
	 * 
	 *  @param previousTextField the previous JTextField
	 *  @return the text field.
	 */
	protected javax.swing.JTextField createTextField(javax.swing.JTextField previousTextField) {
	}

	@java.lang.Override
	public void setFocusable(boolean focusable) {
	}

	@java.lang.Override
	public void addFocusListener(java.awt.event.FocusListener l) {
	}

	@java.lang.Override
	public void removeFocusListener(java.awt.event.FocusListener l) {
	}

	@java.lang.Override
	public java.awt.event.FocusListener[] getFocusListeners() {
	}

	/**
	 *  Check if the input character should trigger navigating to next available field.
	 *  </p>
	 *  By default, '.' and ' ' are both deemed as the navigation key.
	 * 
	 *  @param ch the input character
	 *  @return true if the character input is a navigation key. Otherwise false.
	 */
	protected boolean isNavigateToNextField(char ch) {
	}

	/**
	 *  Returns the boolean indicating whether this <code>IPTextField</code> is editable or not.
	 * 
	 *  @return the boolean value
	 *  @see #setEditable
	 */
	public boolean isEditable() {
	}

	/**
	 *  Sets the specified boolean to indicate whether or not this <code>IPTextField</code> should be editable. A
	 *  PropertyChange event ("editable") is fired when the state is changed.
	 * 
	 *  @param b the boolean to be set
	 *  @see #isEditable
	 */
	public void setEditable(boolean b) {
	}

	/**
	 *  Gets the four text fields that used by this IPTextField.
	 *  <p/>
	 *  Please note, we make this method public in 1.9.3 release because there are users need to access the JTextFields
	 *  directly. Ideally, you shouldn't be aware of the four JTextFields as it's our implementation to use four
	 *  JTextField. We might roll out another implement to just use one JTextField.
	 * 
	 *  @return the four text fields that used by this IPTextField
	 */
	public javax.swing.JTextField[] getTextFields() {
	}

	/**
	 *  Adds a <code>ChangeListener</code> to the model.
	 * 
	 *  @param l the <code>ChangeListener</code> to be added
	 *  @see #removeChangeListener(javax.swing.event.ChangeListener)
	 *  @see #getChangeListeners()
	 */
	public void addChangeListener(javax.swing.event.ChangeListener l) {
	}

	/**
	 *  Removes a <code>ChangeListener</code> from the model.
	 * 
	 *  @param l the <code>ChangeListener</code> to be removed
	 */
	public void removeChangeListener(javax.swing.event.ChangeListener l) {
	}

	/**
	 *  Returns an array of all the <code>ChangeListener</code>s added to this <code>DefaultColorSelectionModel</code>
	 *  with <code>addChangeListener</code>.
	 * 
	 *  @return all of the <code>ChangeListener</code>s added, or an empty array if no listeners have been added
	 */
	public javax.swing.event.ChangeListener[] getChangeListeners() {
	}

	/**
	 *  Runs each <code>ChangeListener</code>'s <code>stateChanged</code> method.
	 *  <p/>
	 * 
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireStateChanged() {
	}

	@java.lang.SuppressWarnings("override")
	public int getBaseline(int width, int height) {
	}

	/**
	 *  Set the tool tips to the sub fields
	 *  @param toolTips The String array of tool tips, will try to set the most available toop tips to the sub fields
	 *  @since 3.4.6
	 */
	public void setToolTipText(String[] toolTips) {
	}

	/**
	 *  Set the tool tip to the component, could be forwarded to set the tool tip of sub fields
	 *  @param text the tool tip text
	 *  @param forward if true, the text will be forwarded to sub fields
	 */
	public void setToolTipText(String text, boolean forward) {
	}

	@java.lang.Override
	public void setToolTipText(String text) {
	}
}
