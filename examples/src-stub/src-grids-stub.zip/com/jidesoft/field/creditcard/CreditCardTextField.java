package com.jidesoft.field.creditcard;


/**
 *  <code>CreditCardTextField</code> is a <code>LabeledTextField</code> which can accept and verify credit card numbers.
 *  After user enters the number, it has method to verify if the number is a valid credit card number. If validated, what
 *  type of credit card it is and then display an icon for the credit card type next to it.
 */
public class CreditCardTextField extends LabeledTextField {

	public static final String PROPERTY_VALIDATE_ON_FLY = "validateOnFly";

	public static final String PROPERTY_MASK_ENABLED = "maskEnabled";

	public CreditCardTextField() {
	}

	public CreditCardTextField(javax.swing.Icon icon) {
	}

	public CreditCardTextField(javax.swing.Icon icon, String labelText) {
	}

	/**
	 *  Creates the text field. We override to set the columns of the text field to 16 which is enough for most credit
	 *  card numbers.
	 * 
	 *  @return text field.
	 */
	@java.lang.Override
	protected javax.swing.JTextField createTextField() {
	}

	/**
	 *  Set the allowed credit card issuer names. Only those card issuers are allowed when doing the validation.
	 * 
	 *  @param allowedCardIssuerNames the allowed credit card issuers names
	 */
	public void setAllowedCardIssuerNames(String[] allowedCardIssuerNames) {
	}

	/**
	 *  Gets allowed credit card issuers' name in an array.
	 * 
	 *  @return credit card issuers' name
	 */
	public String[] getAllowedCardIssuerNames() {
	}

	/**
	 *  Get the credit card number
	 * 
	 *  @return the input card number which is valid.
	 */
	public String getCreditCardNumber() {
	}

	/**
	 *  Get issuer of the card number if valid. This method will call {@link #validateCardNumber()} first.
	 * 
	 *  @return the CardIssuer.
	 */
	public CardIssuer getCardIssuer() {
	}

	/**
	 *  Gets the credit card mask. This mask is used to hide certain digits of the credit card number when the field is
	 *  not in focus.
	 * 
	 *  @return the CreditCardMask
	 */
	public CreditCardMask getCreditCardMask() {
	}

	/**
	 *  Sets CreditCardMask. This mask is used to hide certain digits of the credit card number when the field is not in
	 *  focus.
	 * 
	 *  @param mask a new CreditCardMask
	 */
	public void setCreditCardMask(CreditCardMask mask) {
	}

	/**
	 *  Enables/disables the mask feature. If enabled, we will use the CreditCardMask to hide certain digits of the
	 *  credit card number when the field is not in focus.
	 * 
	 *  @param enabled true to enable the mask feature and false to disable it.
	 */
	public void setMaskEnabled(boolean enabled) {
	}

	/**
	 *  Checks if the mask feature is enabled.
	 * 
	 *  @return true or false.
	 */
	public boolean isMaskEnabled() {
	}

	/**
	 *  Checks if we will validate the credit card number on fly. It is true by default.
	 * 
	 *  @return true or false.
	 */
	public boolean isValidateOnFly() {
	}

	/**
	 *  Enables/disables the validate on fly feature
	 * 
	 *  @param validateOnFly true or false.
	 */
	public void setValidateOnFly(boolean validateOnFly) {
	}

	/**
	 *  Get the icon which is displayed when there is no input number.
	 * 
	 *  @return the icon which is displayed when there is no input number.
	 */
	public javax.swing.Icon getCreditCardIcon() {
	}

	/**
	 *  Sets the icon which is displayed when the input number is invalid.
	 * 
	 *  @param icon a new icon which will be displayed when there is no input number.
	 */
	public void setCreditCardIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the icon which is displayed when the input number is invalid.
	 * 
	 *  @return the icon which is displayed when the input number is invalid.
	 */
	public javax.swing.Icon getInvalidCreditCardIcon() {
	}

	/**
	 *  set the icon which is displayed when the input number is invalid.
	 * 
	 *  @param icon the icon which is displayed when the input number is invalid.
	 */
	public void setInvalidCreditCardIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Checks if the input number is a valid credit card number.
	 * 
	 *  @return true if the number is valid, false if invalid.
	 */
	public boolean validateCardNumber() {
	}

	/**
	 *  Displays the actual card number.
	 */
	public void unmaskCardNumber() {
	}

	/**
	 *  Masks the card number so that the actual number is not displayed.
	 */
	public void maskCardNumber() {
	}
}
