package com.jidesoft.field.creditcard;


/**
 *  AmericanExpress credit card Issuer.
 */
public class JCB implements CardIssuer {

	/**
	 *  Issuer Name
	 */
	public static final String NAME = "JCB";

	/**
	 *  Code to be returned when card number is not start with 3
	 */
	public static final int VAILDATE_ERROR_NOT_START_WITH_3 = 600;

	public static final int VAILDATE_ERROR_NOT_START_WITH_2131_OR_1800 = 601;

	public JCB() {
	}

	/**
	 *  Card number length should be 16, Issuer Identifier should be "3xxxx".
	 * 
	 *  @param cardNumber number to be checked
	 *  @return 0-the number is valid, other-invalid
	 */
	public int isCardNumberValid(String cardNumber) {
	}

	/**
	 *  Get card issuer's name
	 * 
	 *  @return card issuer's name
	 */
	public String getName() {
	}

	/**
	 *  Get card issuer's icon
	 * 
	 *  @return card issuer's icon
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  set card issuer's icon
	 * 
	 *  @param icon card issuer's icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}
}
