/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <tt>CalculatorComboBox</tt> is an AbstractComboBox that uses Calculator as popup panel. It is a ideal input field if
 *  you want to input a double value especially user might want to do some simple arithmetic calculation. For example,
 *  user can type in "10*24" directly in the text field of the combobox and get the result "240" displayed in the text
 *  field.
 */
public class CalculatorComboBox extends AbstractComboBox {

	public CalculatorComboBox() {
	}

	public CalculatorComboBox(Class clazz) {
	}

	protected Calculator createCalculator() {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	@java.lang.Override
	protected javax.swing.JTextField createTextField() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	@java.lang.Override
	public void focusGained(java.awt.event.FocusEvent e) {
	}

	public Calculator getCalculator() {
	}

	@java.lang.Override
	public void setSelectedItem(Object anObject, boolean fireEvent) {
	}

	@java.lang.Override
	public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {
	}

	protected String convertElementToString(Object value) {
	}
}
