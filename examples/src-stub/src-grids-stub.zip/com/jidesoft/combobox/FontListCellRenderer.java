/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


public class FontListCellRenderer extends javax.swing.DefaultListCellRenderer {

	public FontListCellRenderer() {
	}

	public FontListCellRenderer(javax.swing.ListCellRenderer delegateCellRenderer) {
	}

	@java.lang.Override
	public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	}
}
