/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>CheckBoxTreeChooserPanel</code> is a PopupPanel that can choose values from a check box _checkBoxTree. It is
 *  similar to TreeChooserPanel except it uses CheckBox as the _checkBoxTree leaf and multiple values could be selected.
 *  @since 3.4.1
 */
public class CheckBoxTreeChooserPanel extends TreeChooserPanel implements DefaultButtonProvider {

	protected javax.swing.JButton _okButton;

	protected javax.swing.JButton _cancelButton;

	protected javax.swing.Action _okAction;

	protected javax.swing.Action _cancelAction;

	/**
	 *  Creates a new <code>CheckBoxTreeChooserPanel</code>.
	 */
	public CheckBoxTreeChooserPanel() {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeChooserPanel</code>.
	 * 
	 *  @param okAction     the ok action
	 *  @param cancelAction the cancel action
	 */
	public CheckBoxTreeChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeChooserPanel</code> with a TreeModel.
	 * 
	 *  @param model the TreeModel to create tree odel
	 */
	public CheckBoxTreeChooserPanel(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeChooserPanel</code> with a TreeModel.
	 * 
	 *  @param model        the tree model
	 *  @param okAction     the ok action
	 *  @param cancelAction the cancel action
	 */
	public CheckBoxTreeChooserPanel(javax.swing.tree.TreeModel model, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	@java.lang.Override
	protected javax.swing.JTree createTree(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Configures the tree. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup.
	 * 
	 *  @param tree the JTree
	 */
	@java.lang.Override
	protected void setupTree(javax.swing.JTree tree) {
	}

	public void setOkAction(javax.swing.Action okAction) {
	}

	public javax.swing.Action getOkAction() {
	}

	public void setCancelAction(javax.swing.Action cancelAction) {
	}

	public javax.swing.Action getCancelAction() {
	}

	@java.lang.Override
	public javax.swing.JButton getDefaultButton() {
	}

	public java.awt.Component createButtonPanel(int alignment) {
	}

	@java.lang.Override
	protected void initComponents() {
	}

	/**
	 *  Setup tree selections when item state changed
	 * 
	 *  @param e the item change event
	 */
	@java.lang.Override
	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}
}
