/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  This <code>PopupPanel</code> is part of <code>AbstractComboBox</code>. ComboBox usually needs a popup panel, either
 *  as drop down or a dialog. In either case, it is used to select something. All subclasses of
 *  <code>AbstractComboBox</code> should use <code>PopupPanel</code> or subclass of <code>PopupPanel</code> to create a
 *  panel that can be used by <code>AbstractComboBox</code>. <br> <code>PopupPanel</code> extends <code>JPanel</code>. In
 *  addition, it implements <code>ItemSelectable</code> interface. It also can take <code>ItemListener</code> so that any
 *  selection change event can be fired.
 */
public class PopupPanel extends javax.swing.JPanel implements java.awt.ItemSelectable {

	public static final String SELECTED_BY_MOUSE_ROLLOVER = "PopupPanel.selectedByMouseRollover";

	protected Object _previousSelectedObject;

	/**
	 *  Creates a <code>PopupPanel</code> with <code>FlowLayout</code>.
	 */
	public PopupPanel() {
	}

	/**
	 *  Creates a <code>PopupPanel</code> with the specified layout.
	 * 
	 *  @param layout the layout
	 */
	public PopupPanel(java.awt.LayoutManager layout) {
	}

	/**
	 *  Gets the selected object.
	 * 
	 *  @return the selected object
	 */
	public Object getSelectedObject() {
	}

	/**
	 *  Removes all listeners it created. It should only be invoked by ExComboBoxPopup when the popup is reset. You should
	 *  not invoke this method at any circumstance.
	 * 
	 *  @since 3.5.8
	 */
	public void removeAllListeners() {
	}

	/**
	 *  Sets the selected object and fire <code>ItemEvent</code>. It will still fire event even the new selected object
	 *  is the same as old selected object.
	 * 
	 *  @param selectedObject new selected object
	 */
	public void setSelectedObject(Object selectedObject) {
	}

	/**
	 *  Sets the selected object and fire <code>ItemEvent</code>. It will still fire event even the new selected object
	 *  is the same as old selected object.
	 * 
	 *  @param selectedObject new selected object
	 *  @param fireEvent      if fire the ItemEvent
	 */
	public void setSelectedObject(Object selectedObject, boolean fireEvent) {
	}

	/**
	 *  Sets the selected object and fire <code>ItemEvent</code>. It will still fire event even the new selected object
	 *  is the same as old selected object.
	 * 
	 *  @param selectedObject new selected object
	 *  @param comboBox       the corresponding combo box instance
	 *  @deprecated replaced by {@link #setSelectedObject(Object)}
	 */
	@java.lang.Deprecated
	public void setSelectedObject(Object selectedObject, AbstractComboBox comboBox) {
	}

	/**
	 *  Sets the selected object and fire <code>ItemEvent</code>. It will still fire event even the new selected object
	 *  is the same as old selected object.
	 * 
	 *  @param selectedObject new selected object
	 *  @param comboBox       the corresponding comboBox instance
	 *  @param fireEvent      if fire the ItemEvent for popupPanel. It will fire ItemEvent for comboBox anyway
	 *  @deprecated replaced by {@link #setSelectedObject(Object, boolean)}
	 */
	@java.lang.Deprecated
	public void setSelectedObject(Object selectedObject, AbstractComboBox comboBox, boolean fireEvent) {
	}

	/**
	 *  Adds an <code>ItemListener</code>.
	 *  <p/>
	 *  <code>aListener</code> will receive one or two <code>ItemEvent</code>s when the selected item changes.
	 * 
	 *  @param l the <code>ItemListener</code> that is to be notified
	 *  @see #setSelectedObject
	 */
	public void addItemListener(java.awt.event.ItemListener l) {
	}

	/**
	 *  Adds an <code>ItemListener</code>.
	 *  <p/>
	 *  <code>aListener</code> will receive one or two <code>ItemEvent</code>s when the selected item changes.
	 * 
	 *  @param l     the <code>ItemListener</code> that is to be notified
	 *  @param index the index of the ItemListener
	 *  @see #setSelectedObject
	 */
	public void addItemListener(java.awt.event.ItemListener l, int index) {
	}

	/**
	 *  Removes an <code>ItemListener</code>.
	 * 
	 *  @param aListener the <code>ItemListener</code> to remove
	 *  @see #getItemListeners()
	 */
	public void removeItemListener(java.awt.event.ItemListener aListener) {
	}

	/**
	 *  Returns an array of all the <code>ItemListener</code>s added to this JComboBox with addItemListener().
	 * 
	 *  @return all of the <code>ItemListener</code>s added or an empty array if no listeners have been added
	 */
	public java.awt.event.ItemListener[] getItemListeners() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.
	 * 
	 *  @param e the event of interest
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireItemStateChanged(java.awt.event.ItemEvent e) {
	}

	/**
	 *  Returns the selected items or <code>null</code> if no items are selected.
	 * 
	 *  @return the selected objects.
	 */
	public Object[] getSelectedObjects() {
	}

	/**
	 *  Checks if the popup panel should be stretched be the same width as the combobox. Default is false.
	 * 
	 *  @return true or false.
	 */
	public boolean isStretchToFit() {
	}

	/**
	 *  Sets the flag if the popup panel should be stretched or shrunk to be the same width as the combobox. Default is
	 *  false.
	 * 
	 *  @param stretchToFit true or false.
	 */
	public void setStretchToFit(boolean stretchToFit) {
	}

	/**
	 *  Some popup panel doesn't have a OK or Cancel button to confirm the selection. If so, when showing the popup panel
	 *  in dialog, additional buttons such as "OK", "Cancel" and "Reset" will be added. So return true if this popup
	 *  panel need those button; and false if no button is needed. <br> Default is true.
	 * 
	 *  @return true if those select buttons need to be added
	 *  @see #setNeedButtons(boolean)
	 */
	public boolean needsButtons() {
	}

	/**
	 *  Configure if buttons are needed.
	 * 
	 *  @param needButtons the flag
	 */
	public void setNeedButtons(boolean needButtons) {
	}

	/**
	 *  Checks if reset button is visible when popup panel is display in dialog in DIALOG type AbstractComboBox.
	 * 
	 *  @return true by default. Subclass can override this method to return false if reset button should be visible.
	 */
	public boolean isResetButtonVisible() {
	}

	/**
	 *  Gets the default focus component. The default focus component will gain focus when popup is shown.
	 * 
	 *  @return the default focus component.
	 */
	public java.awt.Component getDefaultFocusComponent() {
	}

	/**
	 *  Sets the default focus component. The default focus component will gain focus when popup is shown.
	 * 
	 *  @param defaultFocusComponent a component inside the popup panel.
	 */
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent) {
	}

	@java.lang.Override
	public void requestFocus() {
	}

	/**
	 *  Gets the title of the popup panel. The title is used as the dialog title bar when the combobox is dialog popup.
	 * 
	 *  @return the title.
	 */
	public String getTitle() {
	}

	/**
	 *  Sets the title of the popup panel. The title is used as the dialog title bar when the combobox is dialog popup.
	 * 
	 *  @param title title of the popup panel
	 */
	public void setTitle(String title) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public void setPreferredSize(java.awt.Dimension preferredSize) {
	}

	public java.awt.Dimension getActualPreferredSize() {
	}

	/**
	 *  Checks if popup panel is resizable. This property is used in AbstractComboBox. If a popup panel is resizable, the
	 *  drop down popup will be resizable. If AbstractComboBox is DIALOG type, the dialog will resizable.
	 * 
	 *  @return true if resizable.
	 */
	public boolean isResizable() {
	}

	/**
	 *  Sets the resizable property.
	 * 
	 *  @param resizable true or false. True to make the popup panel resizable. If the popup panel is shown as popup, the
	 *                   popup will be resizable. If the popup panel is shown as a dialog, the dialog will be resizable.
	 *  @see #isResizable()
	 */
	public void setResizable(boolean resizable) {
	}

	/**
	 *  Gets the resizable corners. The value is a bitwise OR of eight constants defined in {@link Resizable}.
	 * 
	 *  @return resizable corners.
	 */
	public int getResizableCorners() {
	}

	/**
	 *  Sets resizable corners.
	 * 
	 *  @param resizableCorners new resizable corners. The value is a bitwise OR of eight constants defined in {@link
	 *                          Resizable}.
	 */
	public void setResizableCorners(int resizableCorners) {
	}

	public java.awt.event.MouseMotionListener getMouseMotionListener() {
	}

	public java.awt.event.MouseListener getMouseListener() {
	}

	/**
	 *  Gets the previously selected object. This value is set when {@link #setSelectedObject(Object, boolean)} is called
	 *  with fireEvent parameter set to true.
	 * 
	 *  @return the previously selected object.
	 */
	public Object getPreviousSelectedObject() {
	}
}
