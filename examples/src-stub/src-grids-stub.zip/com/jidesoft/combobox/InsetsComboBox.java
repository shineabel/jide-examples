/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>InsetsComboBox</code> is a combobox which can be used to choose a <code>Insets</code>.
 */
public class InsetsComboBox extends AbstractComboBox {

	/**
	 *  Creates a new <code>InsetsComboBox</code> using ColorChooserPanel with 40 colors.
	 */
	public InsetsComboBox() {
	}

	/**
	 *  Creates a new <code>InsetsComboBox</code>.
	 * 
	 *  @param Insets the insets
	 */
	public InsetsComboBox(java.awt.Insets Insets) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	/**
	 *  Creates an InsetsChooserPanel as the popup. Below is the default implementation.
	 *  <pre><code>
	 *  return createInsetsChooserPanel(getDefaultOKAction(), getDefaultCancelAction());
	 *  </code></pre>
	 *  <p/>
	 *  Subclass can override this method to provide your own InsetsChooserPanel.
	 * 
	 *  @return a InsetsChooserPanel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates an InsetsChooserPanel as the popup. Below is the default implementation.
	 *  <pre><code>
	 *  return new InsetsChooserPanel(okAction, cancelAction);
	 *  </code></pre>
	 *  <p/>
	 *  Subclass can override this method to provide your own InsetsChooserPanel.
	 * 
	 *  @param okAction     the ok action
	 *  @param cancelAction the cancel action
	 *  @return a InsetsChooserPanel.
	 */
	protected PopupPanel createInsetsChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Gets selected Insets.
	 * 
	 *  @return the selected Insets.
	 */
	public java.awt.Insets getSelectedInsets() {
	}

	protected void updateInsetsFromEditorComponent() {
	}

	/**
	 *  Sets selected Insets.
	 * 
	 *  @param Insets the insets
	 */
	public void setSelectedInsets(java.awt.Insets Insets) {
	}

	@java.lang.Override
	protected boolean isUpdateFromPopupOnFly() {
	}
}
