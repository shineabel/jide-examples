/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>DateComboBox</code> is a combobox which can be used to choose a <code>Date</code>.
 */
public class DateExComboBox extends ExComboBox implements DateModelListener {

	public static final String PROPERTY_SHOW_NONE_BUTTON = "showNoneButton";

	public static final String PROPERTY_SHOW_OK_BUTTON = "showOKButton";

	public static final String PROPERTY_SHOW_TODAY_BUTTON = "showTodayButton";

	public static final String PROPERTY_SHOW_WEEK_NUMBERS = "showWeekNumbers";

	/**
	 *  Constructs a new <code>DateComboBox</code>.
	 */
	public DateExComboBox() {
	}

	/**
	 *  Constructs a new <code>DateComboBox</code> with specified DateModel.
	 * 
	 *  @param model the DateModel.
	 */
	public DateExComboBox(DateModel model) {
	}

	/**
	 *  Gets the DateModel.
	 * 
	 *  @return the DateModel.
	 */
	public DateModel getDateModel() {
	}

	/**
	 *  Sets the DateModel.
	 * 
	 *  @param dateModel the date model
	 */
	public void setDateModel(DateModel dateModel) {
	}

	public void dateModelChanged(DateModelEvent e) {
	}

	/**
	 *  Creates the DateChoosrePanel. Here is the code we used to create it. You can override to if you want to subclass
	 *  DateChooserPanel in order to override methods on DateChooserPanel.
	 *  <p/>
	 *  <code><pre>
	 *  DateChooserPanel dateChooserPanel = new DateChooserPanel(getDateModel(),
	 *  isShowTodayButton(),
	 *  isShowNoneButton(), isShowWeekNumbers(), getLocale());
	 *  dateChooserPanel.setTimeDisplayed(isTimeDisplayed());
	 *  dateChooserPanel.setShowOKButton(isShowOKButton());
	 *  return dateChooserPanel;
	 *  </pre></code>
	 * 
	 *  @return an instance of DateChooserPanel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates a DateChooserPanel instance used by DateExComboBox.
	 * 
	 *  @return an instance of DateChooserPanel.
	 *  @since 3.3.3
	 */
	protected DateChooserPanel createDateChooserPanel() {
	}

	@java.lang.Override
	public boolean isPopupVolatile() {
	}

	/**
	 *  Gets the Date object that is represented in this component.
	 * 
	 *  @return the Date
	 */
	public java.util.Date getDate() {
	}

	/**
	 *  Sets the selected date. This method will not validate the date like {@link #setSelectedItem(Object,boolean)}
	 *  does.
	 * 
	 *  @param anObject  the new date
	 *  @param fireEvent true to fire event. False to not to fire event.
	 */
	public void setSelectedItemWithoutValidation(Object anObject, boolean fireEvent) {
	}

	@java.lang.Override
	protected boolean equals(Object object1, Object object2) {
	}

	/**
	 *  Sets the selected item. This method will valid to make sure the new value is a valid date using
	 *  getDateModel.isValidDate method.
	 * 
	 *  @param anObject  the new date
	 *  @param fireEvent true to fire event. False to not to fire event.
	 */
	@java.lang.Override
	public void setSelectedItem(Object anObject, boolean fireEvent) {
	}

	/**
	 *  Creates a new Calendar instance that will be used internally.
	 * 
	 *  @return a Calendar instance.
	 */
	public java.util.Calendar createCalendarInstance() {
	}

	protected void updateDateFromEditorComponent() {
	}

	/**
	 *  Gets the Calendar object that is represented in this component.
	 * 
	 *  @return the Date in Calendar
	 */
	public java.util.Calendar getCalendar() {
	}

	/**
	 *  Sets the Date.
	 * 
	 *  @param date the date
	 */
	public void setDate(java.util.Date date) {
	}

	/**
	 *  Sets the Date.
	 * 
	 *  @param calendar the calendar
	 */
	public void setCalendar(java.util.Calendar calendar) {
	}

	public String convertElementToString(Object value, Class clazz) {
	}

	@java.lang.Override
	public Object convertStringToElement(String text, Class clazz) {
	}

	/**
	 *  Gets the DateFormat that is used to renderer the label.
	 * 
	 *  @return the DateFormat
	 */
	public java.text.DateFormat getFormat() {
	}

	/**
	 *  Sets the DateFormat.
	 *  <p/>
	 *  <p/>
	 *  Please note, if you want to change the DateFormat, please make sure you call this method before you set the
	 *  Calendar value using {@link #setCalendar(java.util.Calendar)} method. Otherwise, the Calendar value you set will
	 *  be converted using the old format. Here is the right order to display time value in DateComboBox.
	 *  <code><pre>
	 *  DateComboBox dateBox = new DateComboBox();
	 *  dateBox.setTimeDisplayed(true);
	 *  dateBox.setFormat(DateFormat.getDateTimeInstance()); // call this before setCalendar.
	 *  dateBox.setCalendar(cal);
	 *  </pre></code>
	 * 
	 *  @param format the date format
	 */
	public void setFormat(java.text.DateFormat format) {
	}

	/**
	 *  Checks if today button is visible.
	 * 
	 *  @return true if today button is visible.
	 */
	public boolean isShowTodayButton() {
	}

	/**
	 *  Sets the today button visible.
	 * 
	 *  @param showTodayButton the flag
	 */
	public void setShowTodayButton(boolean showTodayButton) {
	}

	/**
	 *  Checks if none button is visible.
	 * 
	 *  @return true if none button is visible.
	 */
	public boolean isShowNoneButton() {
	}

	/**
	 *  Sets the none button visible.
	 * 
	 *  @param showNoneButton the flag
	 */
	public void setShowNoneButton(boolean showNoneButton) {
	}

	/**
	 *  Checks if OK button is visible.
	 * 
	 *  @return true if OK button is visible.
	 */
	public boolean isShowOKButton() {
	}

	/**
	 *  Sets the OK button visible. Even you set it to true, OK button will only be displayed when {@link
	 *  #setTimeDisplayed(boolean)} is also set to true.
	 * 
	 *  @param showOKButton the flag
	 */
	public void setShowOKButton(boolean showOKButton) {
	}

	/**
	 *  Checks if the week of year panel is visible.
	 * 
	 *  @return true if the week of year is visible.
	 */
	public boolean isShowWeekNumbers() {
	}

	/**
	 *  Sets the week of year panel visible.
	 * 
	 *  @param showWeekNumbers the flag
	 */
	public void setShowWeekNumbers(boolean showWeekNumbers) {
	}

	/**
	 *  Overrides to undelegate CTRL+PAGE_UP and CTRL+PAGE_DOWN
	 */
	public java.util.List getDelegateKeyStrokes() {
	}

	/**
	 *  Checks if the time is displayed.
	 * 
	 *  @return true or false.
	 */
	public boolean isTimeDisplayed() {
	}

	/**
	 *  Sets the timeDisplayed property. If this property is true, the DateChooserPanel will show a time spinner so that
	 *  user can change time.
	 * 
	 *  @param timeDisplayed the flag
	 */
	public void setTimeDisplayed(boolean timeDisplayed) {
	}

	/**
	 *  Gets the time format for time spinner on DateChooserPanel.
	 * 
	 *  @return the time format.
	 */
	public String getTimeFormat() {
	}

	/**
	 *  Sets the format for the time spinner on DateChooserPanel. The default value is "hh:mm a". Please refer to {@link
	 *  java.text.SimpleDateFormat} for the specification of format. Please also note this time format is not for what to
	 *  be displayed in the combobox itself. The format that controls what is displayed in the combobox is {@link
	 *  #setFormat(java.text.DateFormat)}.
	 * 
	 *  @param timeFormat the flag
	 */
	public void setTimeFormat(String timeFormat) {
	}

	@java.lang.Override
	public void customizePopup(JidePopup popup, PopupPanel panel) {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Checks if the invalid value is allowed.
	 * 
	 *  @return true or false.
	 */
	public boolean isInvalidValueAllowed() {
	}

	/**
	 *  Sets the flag if the invalid value is allowed to be entered into <code>DateComboBox</code>. If false (the default
	 *  value), user must type a valid date string in the correct format. Otherwise, the focus lost or after enter is
	 *  pressed, the invalid value will be reset. If true, the invalid string will be kept and set to the combobox using
	 *  setSelectedItem. Developer can use getSelectedItem to retrieve the value. getDate or getCalendar will still
	 *  return null as the value is not valid.
	 * 
	 *  @param invalidValueAllowed true or false.
	 */
	public void setInvalidValueAllowed(boolean invalidValueAllowed) {
	}
}
