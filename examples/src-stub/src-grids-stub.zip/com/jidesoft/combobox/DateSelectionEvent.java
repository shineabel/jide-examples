/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  An event that characterizes a change in the Date
 *  selection.
 *  <p/>
 *  The event itself carries no information about selection
 *  change. However you can always use getSource() to get
 *  DateSelectionModel and use method on DateSelectionModel
 *  to find out current selected date(s).
 */
public class DateSelectionEvent extends java.util.EventObject {

	public DateSelectionEvent(Object source) {
	}
}
