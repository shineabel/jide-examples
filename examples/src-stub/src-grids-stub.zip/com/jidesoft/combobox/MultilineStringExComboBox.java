/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>MultilineStringComboBox</code> is a combobox which can be used to type in a multiple line text using
 *  JTextArea.
 */
public class MultilineStringExComboBox extends ExComboBox {

	public MultilineStringExComboBox() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}
}
