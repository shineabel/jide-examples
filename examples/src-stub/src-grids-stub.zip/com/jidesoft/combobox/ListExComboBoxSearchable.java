/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>ListSearchable</code> is an concrete implementation of {@link com.jidesoft.swing.Searchable} that enables the
 *  search function in ListExComboBox. <p>It's very simple to use it. Assuming you have a JList, all you need to do is to
 *  call
 *  <code><pre>
 *  ListExComboBox ListExComboBox = ....;
 *  ListExComboBoxSearchable searchable = new ListExComboBoxSearchable(ListExComboBox);
 *  </pre></code>
 *  Now the ListExComboBox will have the search function.
 *  <p/>
 *  There is very little customization you need to do to ListExComboBoxSearchable. The only thing you might need is when
 *  the element in the ListExComboBox needs a special conversion to convert to string. If so, you can override
 *  convertElementToString() to provide you own algorithm to do the conversion.
 *  <code><pre>
 *  ListExComboBox ListExComboBox = ....;
 *  ListExComboBoxSearchable searchable = new ListExComboBoxSearchable(ListExComboBox) {
 *       protected String convertElementToString(Object object) {
 *           ...
 *       }
 *  };
 *  </pre></code>
 *  <p/>
 *  Additional customization can be done on the base Searchable class such as background and foreground color,
 *  keystrokes, case sensitivity.
 */
public class ListExComboBoxSearchable extends ExComboBoxSearchable {

	public ListExComboBoxSearchable(ListExComboBox ListExComboBox) {
	}

	public ListExComboBoxSearchable(MultiSelectListExComboBox ListExComboBox) {
	}

	protected java.awt.event.FocusListener createFocusListener() {
	}

	@java.lang.Override
	public void showPopup(String searchingText) {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}
}
