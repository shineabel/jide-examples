/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>AbstractFileComboBox</code> is the base class for FileChooserComboBox and FileNameChooserComboBox.
 */
public abstract class AbstractFileComboBox extends AbstractComboBox {

	/**
	 *  Creates a new <code>ColorComboBox</code>.
	 */
	public AbstractFileComboBox() {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	/**
	 *  Gets the current file filter. The file filter is used by the
	 *  file chooser to filter out files from the user's view.
	 * 
	 *  @return the current file filter.
	 */
	public javax.swing.filechooser.FileFilter getFileFilter() {
	}

	/**
	 *  Sets the current file filter. The file filter is used by the
	 *  file chooser to filter out files from the user's view. We will
	 *  pass this file filter to the JFileChooser that will be created
	 *  when the popup button of this combo box is clicked.
	 * 
	 *  @param fileFilter the file filter
	 */
	public void setFileFilter(javax.swing.filechooser.FileFilter fileFilter) {
	}

	/**
	 *  Customizes the JFileChooser created by the popup panel of this combobox.
	 *  We used this method to set FileFilter if it is not null. You can
	 *  override it to do more customization.
	 * 
	 *  @param fileChooser the JFileChooser to be customized.
	 */
	protected void customizeFileChooser(javax.swing.JFileChooser fileChooser) {
	}
}
