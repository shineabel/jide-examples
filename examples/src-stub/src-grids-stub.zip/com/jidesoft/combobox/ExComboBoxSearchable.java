/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  Abstract Searchable for {@link com.jidesoft.combobox.ExComboBox}es, provides the convertElementToString method and
 *  reset the popup if the combobox model changes
 */
public abstract class ExComboBoxSearchable extends ComboBoxSearchable {

	public ExComboBoxSearchable(ExComboBox comboBox) {
	}

	protected ExComboBox getComboBox() {
	}

	/**
	 *  Converts the element in to a string using the <code>ExComboBox</code>'s <code>Converter</code> and <code>ConverterContex</code>.
	 *  If the <code>Converter</code> is <code>null</code>, the object's <code>toString()</code> method is used,
	 *  or an empty string is returned if the object is <code>null</code>.
	 * 
	 *  @param object the object to be converted
	 *  @return Returns the string representing the element.
	 */
	@java.lang.Override
	protected String convertElementToString(Object object) {
	}

	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}
}
