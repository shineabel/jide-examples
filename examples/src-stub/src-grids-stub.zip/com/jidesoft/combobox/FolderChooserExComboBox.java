/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


public class FolderChooserExComboBox extends ExComboBox {

	public FolderChooserExComboBox() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}
}
