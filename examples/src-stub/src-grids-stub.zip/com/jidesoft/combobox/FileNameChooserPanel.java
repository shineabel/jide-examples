/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  FileNameChooserPanel is a popup panel that can choose file name.
 */
public class FileNameChooserPanel extends PopupPanel {

	/**
	 *  Creates a new FileNameChooserPanel.
	 */
	public FileNameChooserPanel() {
	}

	/**
	 *  Creates a new FileNameChooserPanel.
	 */
	public FileNameChooserPanel(String currentDirectoryPath) {
	}

	/**
	 *  Creates a new FileNameChooserPanel.
	 */
	public FileNameChooserPanel(java.io.File currentDirectory) {
	}

	protected void initComponents() {
	}

	/**
	 *  Gets the current directory when the file chooser opens.
	 * 
	 *  @return the current directory
	 */
	public java.io.File getCurrentDirectory() {
	}

	/**
	 *  Sets the current directory when the file chooser opens.
	 * 
	 *  @param currentDirectory the current directory
	 */
	public void setCurrentDirectory(java.io.File currentDirectory) {
	}

	/**
	 *  Gets the current directory path.
	 * 
	 *  @return the current directory path.
	 */
	public String getCurrentDirectoryPath() {
	}

	/**
	 *  Sets the current directory path when the file chooser opens. Different from {@link
	 *  #setCurrentDirectory(java.io.File)} which set the directory using file, this method uses a string. This method
	 *  will call {@link #setCurrentDirectory(java.io.File)} internally.
	 * 
	 *  @param currentDirectoryPath the current directory path.
	 */
	public void setCurrentDirectoryPath(String currentDirectoryPath) {
	}

	protected javax.swing.JComponent createFileChooserPanel() {
	}

	protected javax.swing.JFileChooser createFileChooser() {
	}

	@java.lang.Override
	public boolean needsButtons() {
	}
}
