/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>ListComboBox</code> is just like a normal JComboBox which you can choose a value from a drop-down list box.
 */
public class ListComboBox extends AbstractComboBox {

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getMaximumRowCount
	 *  @see #setMaximumRowCount
	 */
	protected int _maximumRowCount;

	/**
	 *  An array of boolean true and false.
	 */
	public static Object[] BOOLEAN_ARRAY;

	public ListComboBox() {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects an array of objects to insert into the combo box
	 */
	public ListComboBox(Object[] objects) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects a vector of objects to insert into the combo box
	 */
	public ListComboBox(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param model a combobox model
	 */
	public ListComboBox(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects an array of objects to insert into the combo box
	 *  @param clazz   the type of the objects in the array.
	 */
	public ListComboBox(Object[] objects, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects a vector of objects to insert into the combo box.
	 *  @param clazz   the type of the objects in the vector.
	 */
	public ListComboBox(java.util.Vector objects, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param model a combobox model.
	 *  @param clazz the type of the objects in the model.
	 */
	public ListComboBox(javax.swing.ComboBoxModel model, Class clazz) {
	}

	@java.lang.Override
	protected void initComponent(javax.swing.ComboBoxModel model) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates the ListChooserPanel. Subclass can override this method to create its own ListChooserPanel. Below is the
	 *  default implement of this method.
	 *  <pre><code>
	 *      ListChooserPanel listChooserPanel = new ListChooserPanel(dataModel, clazz, converter, converterContext) {
	 *          protected JList createList(ComboBoxModel model) {
	 *              JList list = ListComboBox.this.createList(model);
	 *              if (list == null) {
	 *                  return super.createList(model);
	 *              }
	 *              return list;
	 *          }
	 *          protected void setupList(final JList list) {
	 *              setHorizontalAlignment(ListComboBox.this.getHorizontalAlignment());
	 *              setVerticalAlignment(ListComboBox.this.getVerticalAlignment());
	 *              super.setupList(list);
	 *              list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
	 *                  public void valueChanged(ListSelectionEvent e) {
	 *                      if (!e.getValueIsAdjusting() && !Boolean.TRUE.equals(list.getClientProperty(SELECTED_BY_MOUSE_ROLLOVER)))
	 *  {
	 *                          int index = list.getSelectedIndex();
	 *                          if (index != -1) {
	 *                              Object item = dataModel.getElementAt(index);
	 *                              if (getEditor().getItem() != item) {
	 *                                  boolean needFireEvent = false;
	 *                                  if (selectedItemReminder != null && selectedItemReminder != OBJECT_UNINITIALIZED && dataModel instanceof DefaultComboBoxModel) {
	 *                                      needFireEvent = ((DefaultComboBoxModel) dataModel).getIndexOf(selectedItemReminder) < 0;
	 *                                  }
	 *                                  if (!needFireEvent) {
	 *                                      Object old = getSelectedObject();
	 *                                      boolean needFireItemChangeEventOnly = !JideSwingUtilities.equals(old, item);
	 *                                      setSelectedObject(item, false);
	 *                                      getEditor().setItem(item);
	 *                                      if (needFireItemChangeEventOnly) {
	 *                                          ListComboBox.this.fireItemStateChanged(new ItemEvent(ListComboBox.this, ItemEvent.ITEM_STATE_CHANGED, old, ItemEvent.DESELECTED));
	 *                                          selectedItemChanged(item);
	 *                                          ListComboBox.this.fireItemStateChanged(new ItemEvent(ListComboBox.this, ItemEvent.ITEM_STATE_CHANGED, item, ItemEvent.SELECTED));
	 *                                      }
	 *                                      getEditor().selectAll();
	 *                                  }
	 *                                  else {
	 *                                      setSelectedItem(item);
	 *                                  }
	 *                              }
	 *                          }
	 *                      }
	 *                  }
	 *              });
	 *              ListComboBox.this.setupList(list);
	 *          }
	 *      };
	 *  </code></pre>
	 * 
	 *  @param dataModel        the combobox model
	 *  @param clazz            the type of the element
	 *  @param converter        the converter
	 *  @param converterContext the converter context. Used only when converter is null.
	 *  @return ListChooserPanel.
	 */
	protected ListChooserPanel createListChooserPanel(javax.swing.ComboBoxModel dataModel, Class clazz, ObjectConverter converter, ConverterContext converterContext) {
	}

	@java.lang.Override
	protected java.util.List getDelegateKeyStrokes() {
	}

	/**
	 *  Creates the list. By default, we will return null, meaning the default JList created by ListChooserPanel will be
	 *  used. Subclass can override this method to create other types of list.
	 * 
	 *  @param model the list model.
	 *  @return the list.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JList createList(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Setups the JList for the tree used in the popup panel. You can override this method to customize the JList.
	 * 
	 *  @param list the list used by ListChooserPanel.
	 */
	protected void setupList(javax.swing.JList list) {
	}

	/**
	 *  Register extra key strokes such as UP, DOWN, PAGE UP, PAGE DOWN, CTRL-HOME, CTRL-END on the editor component.
	 * 
	 *  @param editorComponent the editor component.
	 *  @param component       the text field when the combobox is editable, the renderer component when not editable.
	 */
	protected void registerNavigationKeys(AbstractComboBox.EditorComponent editorComponent, javax.swing.JComponent component) {
	}

	/**
	 *  Sets the maximum number of rows the <code>JComboBox</code> displays. If the number of objects in the model is
	 *  greater than count, the combo box uses a scrollbar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the list before using a scrollbar
	 *               preferred: true description: The maximum number of rows the popup should have
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Returns the maximum number of items the combo box can display without a scrollbar.
	 * 
	 *  @return an integer specifying the maximum number of items that are displayed in the list before using a
	 *          scrollbar
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Selects the item at index <code>anIndex</code>.
	 * 
	 *  @param anIndex an integer specifying the list item to select, where 0 specifies the first item in the list and -1
	 *                 indicates no selection
	 *  @throws IllegalArgumentException if <code>anIndex</code> < -1 or <code>anIndex</code> is greater than or equal to
	 *                                   size description: The item at index is selected.
	 */
	public void setSelectedIndex(int anIndex) {
	}

	/**
	 *  Returns the first item in the list that matches the given item. The result is not always defined if the
	 *  <code>JComboBox</code> allows selected items that are not in the list. Returns -1 if there is no selected item or
	 *  if the user specified an item which is not in the list.
	 * 
	 *  @return an integer specifying the currently selected list item, where 0 specifies the first item in the list; or
	 *          -1 if no item is selected or if the currently selected item is not in the list
	 */
	public int getSelectedIndex() {
	}

	/**
	 *  Gets the underlying JList. It will return a not null value only when the list has ever been displayed. If you
	 *  want to customize the list, it's better to override {@link #createListChooserPanel(javax.swing.ComboBoxModel,Class,com.jidesoft.converter.ObjectConverter,com.jidesoft.converter.ConverterContext)}
	 *  method and create your own ListChooserPanel and JList.
	 *  <p/>
	 *  If you want to programatically set selected index on the list, you can use this method. However do not keep the
	 *  returned value and use it later because combobox may create a new JList if the popup is volatile.
	 *  <p/>
	 *  Please note, this method will show the popup automatically if the combobox itself is showing (isShowing returns
	 *  true). Otherwise, it could return null if the popup was never shown before.
	 * 
	 *  @return list
	 */
	public javax.swing.JList getList() {
	}

	@java.lang.Override
	protected javax.swing.JComponent getDelegateTarget() {
	}

	/**
	 *  Adds an item to the item list. This method works only if the <code>ListComboBox</code> uses a mutable data
	 *  model.
	 *  <p/>
	 *  <strong>Warning:</strong> Focus and keyboard navigation problems may arise if you add duplicate String objects. A
	 *  workaround is to add new objects instead of String objects and make sure that the toString() method is defined.
	 *  For example:
	 *  <pre>
	 *    comboBox.addItem(makeObj("Item 1"));
	 *    comboBox.addItem(makeObj("Item 1"));
	 *    ...
	 *    private Object makeObj(final String item)  {
	 *      return new Object() { public String toString() { return item; } };
	 *    }
	 *  </pre>
	 * 
	 *  @param anObject the Object to add to the list
	 *  @see MutableComboBoxModel
	 *  @see #insertItemAt(Object, int)
	 */
	public void addItem(Object anObject) {
	}

	/**
	 *  Inserts an item into the item list at a given index. This method works only if the <code>ListComboBox</code> uses
	 *  a mutable data model.
	 * 
	 *  @param anObject the <code>Object</code> to add to the list
	 *  @param index    an integer specifying the position at which to add the item
	 *  @see MutableComboBoxModel
	 */
	public void insertItemAt(Object anObject, int index) {
	}

	/**
	 *  Removes an item from the item list. This method works only if the <code>ListComboBox</code> uses a mutable data
	 *  model.
	 * 
	 *  @param anObject the object to remove from the item list
	 *  @see MutableComboBoxModel
	 *  @see #removeItemAt(int)
	 *  @see #removeAllItems()
	 */
	public void removeItem(Object anObject) {
	}

	/**
	 *  Removes the item at <code>anIndex</code> This method works only if the <code>ListComboBox</code> uses a mutable
	 *  data model.
	 * 
	 *  @param anIndex an int specifying the index of the item to remove, where 0 indicates the first item in the list
	 *  @see MutableComboBoxModel
	 */
	public void removeItemAt(int anIndex) {
	}

	/**
	 *  Removes all items from the item list.
	 */
	public void removeAllItems() {
	}

	protected class ListEditorComponent {


		/**
		 *  Constructs a new <code>TextField</code>.  A default model is created, the initial string is
		 *  <code>null</code>, and the number of columns is set to 0.
		 * 
		 *  @param clazz the type.
		 */
		public ListComboBox.ListEditorComponent(Class clazz) {
		}

		@java.lang.Override
		protected void registerKeys(javax.swing.JComponent textField) {
		}

		@java.lang.Override
		public java.awt.Dimension getPreferredSize() {
		}
	}

	protected class ListRendererComponent {


		/**
		 *  Constructs a new <code>TextField</code>.  A default model is created, the initial string is
		 *  <code>null</code>, and the number of columns is set to 0.
		 * 
		 *  @param clazz the type.
		 */
		public ListComboBox.ListRendererComponent(Class clazz) {
		}

		@java.lang.Override
		protected void registerKeys(javax.swing.JComponent component) {
		}

		@java.lang.Override
		public java.awt.Dimension getPreferredSize() {
		}
	}
}
