/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>FolderChooserComboBox</code> is a combination of text field and a button.
 *  You can type in folder name directly into the text field. or you can press the button
 *  which will popup a FolderChooser dialog to choose a folder.
 */
public class FolderChooserComboBox extends AbstractComboBox {

	/**
	 *  Creates a new <code>ColorComboBox</code>.
	 */
	public FolderChooserComboBox() {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	/**
	 *  Creates the popup panel. It simply return a FolderChooserPanel.
	 *  If you want to popup your own panel, you can override this method
	 *  in its subclass and return your own FolderChooserPanel.
	 * 
	 *  @return the popup panel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}
}
