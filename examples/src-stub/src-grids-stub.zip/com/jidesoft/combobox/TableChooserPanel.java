/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  TableChooserPanel is a PopupPanel that can choose a value from a table.
 */
public class TableChooserPanel extends PopupPanel implements java.awt.event.ItemListener {

	protected javax.swing.JTable _table;

	protected Class _class;

	protected boolean hasEntered;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseMotionListener mouseMotionListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseListener mouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead.
	 * 
	 *  @see #createTableMouseListener
	 */
	protected java.awt.event.MouseListener tableMouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead
	 * 
	 *  @see #createTableMouseMotionListener
	 */
	protected java.awt.event.MouseMotionListener tableMouseMotionListener;

	public TableChooserPanel() {
	}

	/**
	 *  Creates a new <code>ListChooserPanel</code>.
	 * 
	 *  @param model the model
	 *  @param clazz the class type
	 */
	public TableChooserPanel(javax.swing.table.TableModel model, Class clazz) {
	}

	protected void initComponents() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	/**
	 *  Configures the scrollable portion which holds the table within the combo box popup. This method is called when
	 *  the UI class is created.
	 */
	protected void customzieScroller(javax.swing.JScrollPane scroller) {
	}

	/**
	 *  Subclass can override this method to create a custom JTable. If you override, you need to install the Searchable
	 *  on the table by yourself.
	 * 
	 *  @return the table
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model) {
	}

	/**
	 *  Configures the table. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup.
	 * 
	 *  @param table
	 */
	protected void setupTable(javax.swing.JTable table) {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	/**
	 *  Gets the maximum number of rows the <code>JTable</code> displays
	 * 
	 *  @return the maximum number of rows the <code>JTable</code> displays.
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Sets the maximum number of rows the <code>JTable</code> displays. If the number of objects in the model is
	 *  greater than count, the table uses a scrollbar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the table before using a scrollbar
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Gets the JTable.
	 * 
	 *  @return the JTable.
	 */
	public javax.swing.JTable getTable() {
	}

	/**
	 *  Gets the value at the specific row index. By default, we will get the value at the valueColumnIndex. However you
	 *  can override this method to return a compound value from several columns in the table model in case the values in
	 *  a column is not unique.
	 * 
	 *  @param row the row index.
	 *  @return the value at the specific row index.
	 */
	protected Object getValueAtRowIndex(int row) {
	}

	@java.lang.Override
	public void setSelectedObject(Object selectedObject) {
	}

	protected int getDefaultColumnIndex() {
	}

	protected java.awt.event.MouseEvent convertMouseEvent(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Creates a listener that will watch for mouse-press and release events on the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseListener createMouseListener() {
	}

	/**
	 *  Creates the mouse motion listener which will be added to the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseMotionListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseMotionListener createMouseMotionListener() {
	}

	/**
	 *  Creates a mouse listener that watches for mouse events in the popup's list. If this method returns null then it
	 *  will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseListener</code> or null
	 */
	protected java.awt.event.MouseListener createTableMouseListener() {
	}

	/**
	 *  Creates a mouse motion listener that watches for mouse motion events in the popup's list. If this method returns
	 *  null then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseMotionListener</code> or null
	 */
	protected java.awt.event.MouseMotionListener createTableMouseMotionListener() {
	}

	/**
	 *  Creates a <code>PropertyChangeListener</code> which will be added to the combo box. If this method returns null
	 *  then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>PropertyChangeListener</code> or null
	 */
	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	/**
	 *  Adds the listeners to the table control.
	 */
	protected void installListListeners() {
	}

	/**
	 *  Sets the value column index. This value column index will be used to get the value from the table model and be
	 *  displayed at the editor part of the table combobox.
	 * 
	 *  @param valueColumnIndex the new value column index.
	 */
	public void setValueColumnIndex(int valueColumnIndex) {
	}

	/**
	 *  Returns the value column index. This value column index will be used to get the value from the table model and be
	 *  displayed at the editor part of the table combobox.
	 * 
	 *  @return value column index.
	 */
	public int getValueColumnIndex() {
	}
}
