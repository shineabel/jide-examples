/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  ListChooserPanel is a PopupPanel that can choose a value from a list.
 */
public class ListChooserPanel extends PopupPanel implements java.awt.event.ItemListener, javax.swing.event.ListDataListener {

	protected javax.swing.JList _list;

	protected Class _class;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseMotionListener mouseMotionListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseListener mouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 * 
	 *  @see #createKeyListener
	 */
	protected java.awt.event.KeyListener keyListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead.
	 * 
	 *  @see #createListSelectionListener
	 */
	protected javax.swing.event.ListSelectionListener listSelectionListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead.
	 * 
	 *  @see #createListMouseListener
	 */
	protected java.awt.event.MouseListener listMouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead
	 * 
	 *  @see #createListMouseMotionListener
	 */
	protected java.awt.event.MouseMotionListener listMouseMotionListener;

	public ListChooserPanel() {
	}

	/**
	 *  Creates a new <code>ListChooserPanel</code>.
	 * 
	 *  @param objects the objects
	 *  @param clazz   the class type
	 */
	public ListChooserPanel(Object[] objects, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListChooserPanel</code>.
	 * 
	 *  @param objects the objects
	 *  @param clazz   the class type
	 */
	public ListChooserPanel(java.util.Vector objects, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListChooserPanel</code>.
	 * 
	 *  @param model the combo box model
	 *  @param clazz the class type
	 */
	public ListChooserPanel(javax.swing.ComboBoxModel model, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListChooserPanel</code>.
	 * 
	 *  @param model                   the combo box model
	 *  @param clazz                   the class type
	 *  @param elementConverterContext the converter context
	 */
	public ListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext) {
	}

	/**
	 *  Creates a new <code>ListChooserPanel</code>.
	 * 
	 *  @param model                   the combo box model
	 *  @param clazz                   the class type
	 *  @param converter               the convereter
	 *  @param elementConverterContext the converter context
	 */
	public ListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ObjectConverter converter, ConverterContext elementConverterContext) {
	}

	@java.lang.Override
	public void removeAllListeners() {
	}

	protected void initComponents() {
	}

	protected boolean isAutoScroll() {
	}

	/**
	 *  Configures the scrollable portion which holds the list within the combo box popup. This method is called when the
	 *  UI class is created.
	 * 
	 *  @param scroller the scroll pane to customize
	 */
	protected void customizeScroller(javax.swing.JScrollPane scroller) {
	}

	/**
	 *  Subclass can override this method to create a custom JList. By default, we use ListChooserPanel.ListEx which is
	 *  basically a JList with some methods we override. You can subclass and return here if you would like to extend
	 *  more methods.
	 * 
	 *  @param comboBoxModel the combo box model used to create list
	 *  @return the list. A ListChooserPanel.ListEx instance by default.
	 */
	protected javax.swing.JList createList(javax.swing.ComboBoxModel comboBoxModel) {
	}

	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	protected void updateListSelectionWithoutFiringEvent() {
	}

	/**
	 *  Configures the list. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup.
	 * 
	 *  @param list the list to configure
	 */
	protected void setupList(javax.swing.JList list) {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	protected void updateListSelection(Object selectedObject, boolean shouldScroll) {
	}

	/**
	 *  Gets the maximum number of rows the <code>JList</code> displays
	 * 
	 *  @return the maximum number of rows the <code>JList</code> displays.
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Sets the maximum number of rows the <code>JList</code> displays. If the number of objects in the model is greater
	 *  than count, the list uses a scrollbar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the list before using a scrollbar
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Gets the maximum width of the ListChooserPanel
	 * 
	 *  @return the maximum width.
	 *  @since 3.4.2
	 */
	public int getMaximumWidth() {
	}

	/**
	 *  Sets the maximum width of the ListChooserPanel
	 * 
	 *  @param maximumWidth the maximum width
	 *  @since 3.4.2
	 */
	public void setMaximumWidth(int maximumWidth) {
	}

	/**
	 *  Returns the renderer used to display the selected item in the <code>JComboBox</code> field.
	 * 
	 *  @return the list cell renderer.
	 */
	public javax.swing.ListCellRenderer getRenderer() {
	}

	/**
	 *  Sets the renderer that paints the list items and the item selected from the list in the JComboBox field. The
	 *  renderer is used if the JComboBox is not editable. If it is editable, the editor is used to render and edit the
	 *  selected item.
	 *  <p/>
	 *  The default renderer displays a string or an icon. Other renderers can handle graphic images and composite
	 *  items.
	 *  <p/>
	 *  To display the selected item, <code>aRenderer.getListCellRendererComponent</code> is called, passing the list
	 *  object and an index of -1.
	 * 
	 *  @param renderer the <code>ListCellRenderer</code> that displays the selected item
	 */
	public void setRenderer(javax.swing.ListCellRenderer renderer) {
	}

	/**
	 *  Gets the converter context that used to convert the element in the list to/from string.
	 * 
	 *  @return the converter context.
	 */
	public ConverterContext getConverterContext() {
	}

	/**
	 *  Sets the converter context that used to convert the element in the list to/from string.
	 * 
	 *  @param converterContext the converter context
	 */
	public void setConverterContext(ConverterContext converterContext) {
	}

	/**
	 *  Gets the converter that will convert the element in the ListModel to String that can be displayed on the JList.
	 * 
	 *  @return the converter.
	 */
	public ObjectConverter getConverter() {
	}

	/**
	 *  Sets a new converter that will convert the element in the ListModel to String that can be displayed on the
	 *  JList.
	 * 
	 *  @param converter the converter
	 */
	public void setConverter(ObjectConverter converter) {
	}

	/**
	 *  Gets the JList.
	 * 
	 *  @return the JList.
	 */
	public javax.swing.JList getList() {
	}

	@java.lang.Override
	public void setSelectedObject(Object selectedObject) {
	}

	protected java.awt.event.MouseEvent convertMouseEvent(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Creates a listener that will watch for mouse-press and release events on the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseListener createMouseListener() {
	}

	/**
	 *  Creates the mouse motion listener which will be added to the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseMotionListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseMotionListener createMouseMotionListener() {
	}

	/**
	 *  Creates the key listener that will be added to the combo box. If this method returns null then it will not be
	 *  added to the combo box.
	 * 
	 *  @return a <code>KeyListener</code> or null
	 */
	protected java.awt.event.KeyListener createKeyListener() {
	}

	/**
	 *  Creates a list selection listener that watches for selection changes in the popup's list.  If this method returns
	 *  null then it will not be added to the popup list.
	 * 
	 *  @return an instance of a <code>ListSelectionListener</code> or null
	 */
	protected javax.swing.event.ListSelectionListener createListSelectionListener() {
	}

	/**
	 *  Creates a list data listener which will be added to the <code>ComboBoxModel</code>. If this method returns null
	 *  then it will not be added to the combo box model.
	 * 
	 *  @return an instance of a <code>ListDataListener</code> or null
	 */
	protected javax.swing.event.ListDataListener createListDataListener() {
	}

	/**
	 *  Creates a mouse listener that watches for mouse events in the popup's list. If this method returns null then it
	 *  will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseListener</code> or null
	 */
	protected java.awt.event.MouseListener createListMouseListener() {
	}

	/**
	 *  Creates a mouse motion listener that watches for mouse motion events in the popup's list. If this method returns
	 *  null then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseMotionListener</code> or null
	 */
	protected java.awt.event.MouseMotionListener createListMouseMotionListener() {
	}

	/**
	 *  Creates a <code>PropertyChangeListener</code> which will be added to the combo box. If this method returns null
	 *  then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>PropertyChangeListener</code> or null
	 */
	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	/**
	 *  Creates an <code>ItemListener</code> which will be added to the combo box. If this method returns null then it
	 *  will not be added to the combo box.
	 *  <p/>
	 *  Subclasses may override this method to return instances of their own ItemEvent handlers.
	 * 
	 *  @return an instance of an <code>ItemListener</code> or null
	 */
	protected java.awt.event.ItemListener createItemListener() {
	}

	/**
	 *  Creates the handler to handle mouse events and property change events
	 * 
	 *  @return the handler
	 *  @since 3.4.2
	 */
	protected ListChooserPanel.Handler createHandler() {
	}

	/**
	 *  Adds the listeners to the list control.
	 */
	protected void installListListeners() {
	}

	@java.lang.Override
	public java.awt.event.MouseMotionListener getMouseMotionListener() {
	}

	@java.lang.Override
	public java.awt.event.MouseListener getMouseListener() {
	}

	public int getHorizontalAlignment() {
	}

	public void setHorizontalAlignment(int horizontalAlignment) {
	}

	public int getVerticalAlignment() {
	}

	public void setVerticalAlignment(int verticalAlignment) {
	}

	protected class Handler {


		protected ListChooserPanel.Handler() {
		}

		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		public void propertyChange(java.beans.PropertyChangeEvent e) {
		}

		public void itemStateChanged(java.awt.event.ItemEvent e) {
		}
	}

	protected class ListEx {


		public ListChooserPanel.ListEx(javax.swing.ListModel dataModel) {
		}

		@java.lang.Override
		public String getResourceString(String key) {
		}

		@java.lang.Override
		public int getNextMatch(String prefix, int startIndex, javax.swing.text.Position.Bias bias) {
		}

		@java.lang.Override
		public void processMouseEvent(java.awt.event.MouseEvent e) {
		}

		public void superProcessMouseEvent(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public java.awt.Dimension getPreferredScrollableViewportSize() {
		}
	}
}
