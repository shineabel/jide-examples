/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  ComboBoxModelWrapperUtils is  a utility class that contains several useful methods for ComboBoxModelWrapper.
 */
public class ComboBoxModelWrapperUtils {

	public ComboBoxModelWrapperUtils() {
	}

	/**
	 *  Gets the actual row index at an outerModel whose class is innerModelClass.
	 * 
	 *  @param outerModel      the outermost outerModel.
	 *  @param row             the row of outermost outerModel
	 *  @param innerModelClass the class of the inner outerModel
	 *  @return the row index of inner outerModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualIndexAt(javax.swing.ComboBoxModel outerModel, int row, Class innerModelClass) {
	}

	/**
	 *  Gets the actual row index at an outerModel.
	 * 
	 *  @param outerModel the outermost outerModel.
	 *  @param row        the row of outermost outerModel
	 *  @return the row index of nested model which is not a list wrapper. If it can't find it, -1 will be returned.
	 */
	public static int getActualIndexAt(javax.swing.ComboBoxModel outerModel, int row) {
	}

	/**
	 *  Gets the row at the outermost model knowing the row index in an inner model
	 * 
	 *  @param outerModel
	 *  @param innerModel
	 *  @param rowInInnerModel
	 *  @return the row at the outermost model.
	 */
	public static int getIndexAt(javax.swing.ComboBoxModel outerModel, javax.swing.ComboBoxModel innerModel, int rowInInnerModel) {
	}

	/**
	 *  Gets the row at the outermost model knowing the row index in an inner model
	 * 
	 *  @param outerModel
	 *  @param rowInInnerModel
	 *  @return the row at the outermost model.
	 */
	public static int getIndexAt(javax.swing.ComboBoxModel outerModel, int rowInInnerModel) {
	}

	/**
	 *  Gets the list model whose class is targetModelClass.
	 * 
	 *  @param outerModel
	 *  @param targetModelClass
	 *  @return the list model whose class is targetModelClass.
	 */
	public static javax.swing.ComboBoxModel getActualComboBoxModel(javax.swing.ComboBoxModel outerModel, Class targetModelClass) {
	}
}
