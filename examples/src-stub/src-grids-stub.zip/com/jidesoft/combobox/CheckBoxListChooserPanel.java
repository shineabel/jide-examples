/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>CheckBoxListChooserPanel</code> is a PopupPanel that can choose a value from a CheckBoxList. It is similar to
 *  MultiSelectListChooserPanel except it is uses CheckBoxList to allow multiple selection.
 */
public class CheckBoxListChooserPanel extends MultiSelectListChooserPanel {

	public CheckBoxListChooserPanel() {
	}

	public CheckBoxListChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(Object[] objects, Class clazz) {
	}

	public CheckBoxListChooserPanel(Object[] objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(java.util.Vector objects, Class clazz) {
	}

	public CheckBoxListChooserPanel(java.util.Vector objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Subclass can override this method to create a custom JList.
	 * 
	 *  @param comboBoxModel the combobox model which is used to create a CheckBoxList.
	 *  @return the list
	 */
	@java.lang.Override
	protected javax.swing.JList createList(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Configures the list. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup. The Searchable is installed in this method. If you override, you
	 *  need to install the Searchable on the list by yourself.
	 * 
	 *  @param list the check box list
	 */
	@java.lang.Override
	protected void setupList(javax.swing.JList list) {
	}

	@java.lang.Override
	protected Object[] retrieveListSelection() {
	}

	protected void updateListSelectionWithoutFiringEvent() {
	}

	@java.lang.Override
	protected void updateListSelection(Object selectedObject, boolean shouldScroll) {
	}

	@java.lang.Override
	protected boolean isAutoScroll() {
	}

	/**
	 *  The CheckBoxList class to be created in CheckBoxListChooserPanel.
	 * 
	 *  @since 3.5.4
	 */
	public class CheckBoxListWithResourceProvider {


		public CheckBoxListChooserPanel.CheckBoxListWithResourceProvider(javax.swing.ListModel model) {
		}

		@java.lang.Override
		public String getResourceString(String key) {
		}

		@java.lang.Override
		public int getNextMatch(String prefix, int startIndex, javax.swing.text.Position.Bias bias) {
		}

		@java.lang.Override
		public void processMouseEvent(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public java.awt.Dimension getPreferredScrollableViewportSize() {
		}
	}
}
