/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>CheckBoxTreeExComboBox</code> is ComboBox which you can choose values from a check box tree.
 *  @since 3.4.1
 */
public class CheckBoxTreeExComboBox extends TreeExComboBox {

	public CheckBoxTreeExComboBox() {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeExComboBox</code>.
	 * 
	 *  @param objects the objects
	 */
	public CheckBoxTreeExComboBox(Object[] objects) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeExComboBox</code>.
	 * 
	 *  @param objects the objects
	 */
	public CheckBoxTreeExComboBox(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeExComboBox</code>.
	 * 
	 *  @param objects the objects
	 */
	public CheckBoxTreeExComboBox(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeExComboBox</code>.
	 * 
	 *  @param root the root node
	 */
	public CheckBoxTreeExComboBox(javax.swing.tree.TreeNode root) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeExComboBox</code>.
	 * 
	 *  @param root               the root node
	 *  @param asksAllowsChildren the flag indicating if allows children
	 */
	public CheckBoxTreeExComboBox(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeExComboBox</code>.
	 * 
	 *  @param model the tree model
	 */
	public CheckBoxTreeExComboBox(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	protected TreeChooserPanel createTreeChooserPanel(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Same as {@link #setSelectedItem(Object)} except you can choose to fire the ItemEvent or not.
	 * 
	 *  @param anObject  the new value
	 *  @param fireEvent true to fire event which is the same as {@link #setSelectedItem(Object)}. False if you don't want
	 *                   to fire event.
	 */
	@java.lang.Override
	public void setSelectedItem(Object anObject, boolean fireEvent) {
	}

	/**
	 *  Converts the element from object to string so that i can display in the text field of CheckBoxTreeExComboBox. Subclass can
	 *  override this method to provide one's own conversion.
	 * 
	 *  @param object the object
	 * 
	 *  @return the string representing the object.
	 */
	@java.lang.Override
	public String convertElementToString(Object object) {
	}
}
