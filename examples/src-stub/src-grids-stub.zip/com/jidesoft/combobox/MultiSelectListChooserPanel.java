/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>MultiSelectListChooserPanel</code> is a PopupPanel that can choose a value from a JList with allows multiple
 *  selection.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class MultiSelectListChooserPanel extends ListChooserPanel implements DefaultButtonProvider {

	protected javax.swing.ListModel _listModel;

	protected javax.swing.JButton _okButton;

	protected javax.swing.JButton _cancelButton;

	protected javax.swing.Action _okAction;

	protected javax.swing.Action _cancelAction;

	public MultiSelectListChooserPanel() {
	}

	public MultiSelectListChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>CheckBoxListChooserPanel</code>.
	 * 
	 *  @param objects an array of objects to insert into the combo box
	 *  @param clazz   the element type
	 */
	public MultiSelectListChooserPanel(Object[] objects, Class clazz) {
	}

	/**
	 *  @param objects      an array of objects to insert into the combo box
	 *  @param clazz        the element type
	 *  @param okAction     the OK action
	 *  @param cancelAction the cancel action
	 */
	public MultiSelectListChooserPanel(Object[] objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param objects a vector of the objects
	 *  @param clazz   the element type
	 */
	public MultiSelectListChooserPanel(java.util.Vector objects, Class clazz) {
	}

	public MultiSelectListChooserPanel(java.util.Vector objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param clazz the element type
	 */
	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz) {
	}

	/**
	 *  @param model        the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param clazz        the element type
	 *  @param okAction     the OK action
	 *  @param cancelAction the cancel action
	 */
	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param model                   the combobox model
	 *  @param clazz                   the element type
	 *  @param elementConverterContext the converter context for the elements.
	 */
	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext) {
	}

	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public void setOkAction(javax.swing.Action okAction) {
	}

	public javax.swing.Action getOkAction() {
	}

	public void setCancelAction(javax.swing.Action cancelAction) {
	}

	public javax.swing.Action getCancelAction() {
	}

	@java.lang.Override
	public javax.swing.JButton getDefaultButton() {
	}

	public java.awt.Component createButtonPanel(int alignment) {
	}

	protected void initComponents() {
	}

	/**
	 *  Subclass can override this method to create a custom JList. The Searchable is installed in this method. If you
	 *  override, you need to install the Searchable on the list by yourself.
	 * 
	 *  @param comboBoxModel the combobox model which is used to create a CheckBoxList.
	 *  @return the list
	 */
	protected javax.swing.JList createList(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Creates the list model for the list use based on the vector.
	 * 
	 *  @param vector the elements vector
	 *  @return the created list model.
	 * 
	 *  @since 3.2.1
	 */
	protected javax.swing.ListModel createListModel(java.util.Vector vector) {
	}

	protected java.util.Vector convertComboBoxModelToVector(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Configures the list. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup.
	 * 
	 *  @param list the check box list
	 */
	protected void setupList(javax.swing.JList list) {
	}

	protected Object[] retrieveListSelection() {
	}

	protected void updateListSelection(Object selectedObject, boolean shouldScroll) {
	}

	/**
	 *  Gets the selected object. In the case of <code>MultiSelectListChooserPanel</code>, the selected object is an
	 *  array of elements that are checked in the CheckBoxList. The return type is always Object[] regardless of the
	 *  actual data type.
	 * 
	 *  @return the selected object.
	 */
	@java.lang.Override
	public Object getSelectedObject() {
	}

	protected MultiSelectListChooserPanel.Handler createHandler() {
	}

	protected boolean isAutoScroll() {
	}

	/**
	 *  The list data listener when new entry(s) is/are inserted in the combo box model.
	 * 
	 *  @param e the event
	 *  @since 3.2.1
	 */
	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  The list data listener when old entry(s) is/are removed in the combo box model.
	 * 
	 *  @param e the event
	 *  @since 3.2.1
	 */
	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  The list data listener when entry(s) is/are inserted in the combo box model.
	 * 
	 *  @param e the event
	 *  @since 3.2.1
	 */
	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  Configure the list model with the combo box model of MultiSelectListChooserPanel.
	 * 
	 *  @param model the combo box model
	 *  @since 3.2.1
	 */
	protected void configureListModel(javax.swing.ComboBoxModel model) {
	}

	protected void prepareSelectedObject() {
	}

	/**
	 *  Checks if double mouse click will select the clicked item.
	 *  @return true or false.
	 *  @since 3.6.8
	 */
	public boolean isDoubleClickEnabled() {
	}

	/**
	 *  Sets the flag whether double clicking on an item will select the item.
	 *  @param doubleClickEnabled true or false.
	 *  @since 3.6.8
	 */
	public void setDoubleClickEnabled(boolean doubleClickEnabled) {
	}

	protected class Handler {


		protected MultiSelectListChooserPanel.Handler() {
		}

		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
		}
	}
}
