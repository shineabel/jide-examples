/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A popup panel for insets.
 */
public class InsetsChooserPanel extends ButtonPopupPanel {

	public InsetsChooserPanel() {
	}

	public InsetsChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Sets the selected insets to preview component. This method will be invoked as long as the insets are changed.
	 */
	protected void setPreviewComponentInsets() {
	}

	protected void initComponents() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in combobox.properties that begin with "InsetsChooser.".
	 * 
	 *  @param key the key
	 * 
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Creates the spinner model used by the spinners.
	 *  <p/>
	 *  By default, it will return new SpinnerNumberModel(6, 0, 100, 1). You could override this method to have your
	 *  customized spinner model.
	 * 
	 *  @return the spinner model
	 */
	protected javax.swing.SpinnerModel createSpinnerModel() {
	}

	/**
	 *  Creates the spinner in the panel.
	 * 
	 *  @param model the spinner model
	 * 
	 *  @return the spinner.
	 */
	protected javax.swing.JSpinner createSpinner(javax.swing.SpinnerModel model) {
	}

	/**
	 *  Creates the preview panel.
	 * 
	 *  @return the preview panel.
	 */
	protected javax.swing.JComponent createPreviewPanel() {
	}

	/**
	 *  Creates the preview component.
	 *  <p/>
	 *  You could override this method to return you own preview component if you want to customize the preview window.
	 *  You need override {@link #setPreviewComponentInsets()} to make the new insets take effect when the insets are
	 *  changed.
	 * 
	 *  @return the preview component.
	 * 
	 *  @see #setPreviewComponentInsets()
	 */
	protected javax.swing.JComponent createPreviewComponent() {
	}

	/**
	 *  Gets selected insets.
	 * 
	 *  @return the insets. null if the selected object is not an instance of Insets.
	 * 
	 *  @see #setSelectedInsets(java.awt.Insets)
	 */
	public java.awt.Insets getSelectedInsets() {
	}

	/**
	 *  Sets selected insets.
	 * 
	 *  @param insets the insets
	 */
	public void setSelectedInsets(java.awt.Insets insets) {
	}

	@java.lang.Override
	public Object getSelectedObject() {
	}

	@java.lang.Override
	protected void prepareSelectedObject() {
	}

	@java.lang.Override
	public void setSelectedObject(Object object) {
	}

	public static void main(String[] args) {
	}
}
