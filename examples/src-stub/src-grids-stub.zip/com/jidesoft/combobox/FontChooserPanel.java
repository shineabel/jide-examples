/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A popup panel for font.
 */
public class FontChooserPanel extends ButtonPopupPanel {

	protected javax.swing.JLabel _previewLabel;

	protected javax.swing.JComboBox _fontNameComboBox;

	protected javax.swing.JSpinner _sizeSpinner;

	protected javax.swing.JCheckBox _boldCheckBox;

	protected javax.swing.JCheckBox _italicCheckBox;

	protected javax.swing.ComboBoxModel _fontNameComboBoxModel;

	public FontChooserPanel() {
	}

	public FontChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	protected void installListeners() {
	}

	/**
	 *  Sets the selected font to preview label.
	 */
	protected void setPreviewLabelFont() {
	}

	/**
	 *  Creates the default combo box model.
	 *  <p/>
	 *  You could either override this method or invoke {@link #setFontNameComboBoxModel(javax.swing.ComboBoxModel)} to
	 *  customize it.
	 * 
	 *  @return the combo box model instance.
	 * 
	 *  @see #getFontNameComboBoxModel()
	 */
	protected javax.swing.DefaultComboBoxModel createFontNameComboBoxModel() {
	}

	/**
	 *  Gets the font name combo box model.
	 * 
	 *  @return the combo box model.
	 */
	public javax.swing.ComboBoxModel getFontNameComboBoxModel() {
	}

	/**
	 *  Sets the font name combo box model.
	 * 
	 *  @param fontNameComboBoxModel the combo box model
	 */
	public void setFontNameComboBoxModel(javax.swing.ComboBoxModel fontNameComboBoxModel) {
	}

	protected void initComponents() {
	}

	protected javax.swing.JComponent createFontChooserPanel() {
	}

	protected javax.swing.JComponent createPreviewPanel() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Gets the selected font.
	 * 
	 *  @return the selected font.
	 * 
	 *  @see #setSelectedFont(java.awt.Font)
	 */
	public java.awt.Font getSelectedFont() {
	}

	/**
	 *  Sets the selected font.
	 * 
	 *  @param font the selected font
	 * 
	 *  @see #getSelectedFont()
	 */
	public void setSelectedFont(java.awt.Font font) {
	}

	@java.lang.Override
	public Object getSelectedObject() {
	}

	@java.lang.Override
	protected void prepareSelectedObject() {
	}

	@java.lang.Override
	public void setSelectedObject(Object object) {
	}

	/**
	 *  Gets the preview text.
	 * 
	 *  @return the preview text
	 * 
	 *  @see #setPreviewText(String)
	 */
	public String getPreviewText() {
	}

	/**
	 *  Sets the preview text.
	 * 
	 *  @param previewText the preview text
	 * 
	 *  @see #getPreviewText()
	 */
	public void setPreviewText(String previewText) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in fontChooser.properties that begin with "FontChooser.".
	 * 
	 *  @param key the key
	 * 
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}
}
