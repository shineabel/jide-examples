/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>TreeSearchable</code> is an concrete implementation of {@link com.jidesoft.swing.Searchable} that enables the
 *  search function in TreeExComboBox. <p>It's very simple to use it. Assuming you have a TreeExComboBox, all you need to
 *  do is to call
 *  <code><pre>
 *  TreeExComboBox treeExComboBox = ....;
 *  TreeSearchable searchable = new TreeSearchable(treeExComboBox);
 *  </pre></code>
 *  Now the TreeExComboBox will have the search function.
 *  <p/>
 *  There is very little customization you need to do to TreeSearchable. The only thing you might need is when the
 *  element in the TreeExComboBox needs a special conversion to convert to string. If so, you can override
 *  convertElementToString() to provide you own algorithm to do the conversion.
 *  <code><pre>
 *  TreeExComboBox treeExComboBox = ....;
 *  TreeSearchable searchable = new TreeSearchable(treeExComboBox) {
 *       protected String convertElementToString(Object object) {
 *           ...
 *       }
 *  };
 *  </pre></code>
 *  <p/>
 *  Additional customization can be done on the base Searchable class such as background and foreground color,
 *  keystrokes, case sensitivity,
 */
public class TreeExComboBoxSearchable extends ExComboBoxSearchable implements javax.swing.event.TreeModelListener {

	public TreeExComboBoxSearchable(TreeExComboBox tree) {
	}

	/**
	 *  Checks if the searchable is recursive.
	 * 
	 *  @return true if searchable is recursive.
	 */
	public boolean isRecursive() {
	}

	/**
	 *  Sets the recursive attribute.
	 *  <p/>
	 *  If TreeSearchable is recursive, it will all tree nodes including those which are not visible to find the matching
	 *  node. Obviously, if your tree has unlimited number of tree nodes or a potential huge number of tree nodes (such
	 *  as a tree to represent file system), the recursive attribute should be false. To avoid this potential problem in
	 *  this case, we default it to false.
	 * 
	 *  @param recursive true or false
	 */
	public void setRecursive(boolean recursive) {
	}

	@java.lang.Override
	public void uninstallListeners() {
	}

	@java.lang.Override
	public void showPopup(String searchingText) {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}

	@java.lang.Override
	protected int getSelectedIndex() {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}

	/**
	 *  Recursively go through the tree to populate the tree paths into a list and cache them.
	 *  <p/>
	 *  Tree paths list is only used when the recursive attribute is set to true.
	 */
	protected void populateTreePaths() {
	}

	/**
	 *  Reset the cached tree paths list.
	 *  <p/>
	 *  Tree paths list is only used when recursive attribute true.
	 */
	protected void resetTreePathes() {
	}

	/**
	 *  Gets the cached tree paths list. If it has never been cached before, this method will create the cache.
	 *  <p/>
	 *  Tree paths list is only used when recursive attribute is true.
	 * 
	 *  @return the tree paths list.
	 */
	protected java.util.List getTreePathes() {
	}

	/**
	 *  Converts the element in TreeExComboBox to string. The element by default is TreePath. The returned value will be
	 *  <code>toString()</code> of the last path component in the TreePath.
	 * 
	 *  @param object the object. This is usually a TreePath.
	 * 
	 *  @return the string representing the TreePath in the TreeExComboBox.
	 */
	@java.lang.Override
	protected String convertElementToString(Object object) {
	}

	public void treeNodesChanged(javax.swing.event.TreeModelEvent e) {
	}

	public void treeNodesInserted(javax.swing.event.TreeModelEvent e) {
	}

	public void treeNodesRemoved(javax.swing.event.TreeModelEvent e) {
	}

	public void treeStructureChanged(javax.swing.event.TreeModelEvent e) {
	}

	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
