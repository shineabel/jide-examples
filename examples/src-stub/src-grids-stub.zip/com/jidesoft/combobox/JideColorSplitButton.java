/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>JideColorSplitButton</code> is a special split button which can be used to choose a color. This is a perfect
 *  example using split button which can make choosing color much easier.
 *  <p/>
 *  You can call {@link #addItemListener(java.awt.event.ItemListener)} to register your own ItemListener. ItemStateChange
 *  event will be fired whenever user clicks on the color button on the color chooser panel.
 */
public class JideColorSplitButton extends JideSplitButton {

	public ColorChooserPanel _colorChooserPanel;

	public java.awt.event.ItemListener _itemListener;

	/**
	 *  Creates a split button. Since the icon is not specified, no icon will be used.
	 */
	public JideColorSplitButton() {
	}

	/**
	 *  Creates a split button. The icon should leave the bottom part empty because that area will be painted as the last
	 *  selected color.
	 * 
	 *  @param icon
	 */
	public JideColorSplitButton(javax.swing.Icon icon) {
	}

	/**
	 *  Creates a split button using the specified icon and a rectangle which will be painted as the last selected color.
	 *  If rect is empty, no color will be painted. The x and y of rect is relative to the icon.
	 * 
	 *  @param icon
	 *  @param rect
	 */
	public JideColorSplitButton(javax.swing.Icon icon, java.awt.Rectangle rect) {
	}

	/**
	 *  By default, a ColorChooserPanel of PALETTE_COLOR_40 will be used. If you want a different palette, you can
	 *  override this method to provide your own <code>ColorChooserPanel</code>.
	 * 
	 *  @return a ColorChooserPanel.
	 */
	protected ColorChooserPanel createColorChooserPanel() {
	}

	/**
	 *  Gets the icon used by on the button part of the split button. It is the same icon instance you passed in the
	 *  constructor of {@link #JideColorSplitButton(javax.swing.Icon)}.
	 * 
	 *  @return the icon.
	 */
	public javax.swing.Icon getColorIcon() {
	}

	/**
	 *  Sets the icon used by the button part of split button.
	 * 
	 *  @param icon
	 */
	public void setColorIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Sets the last selected color. The last selected will be used to paint a rectangle on the button icon.
	 * 
	 *  @param color
	 */
	public void setLastSelectedColor(java.awt.Color color) {
	}

	/**
	 *  Gets the last selected color. Usually split button can use the button to set the last selected color. You can
	 *  call this method to get the last selected color.
	 * 
	 *  @return the last selected color.
	 */
	public java.awt.Color getLastSelectedColor() {
	}

	/**
	 *  Gets the selected color. It is the color that will be selected in ColorChooserPanel.
	 * 
	 *  @return the selected color.
	 */
	public java.awt.Color getSelectedColor() {
	}

	/**
	 *  Sets the selected color. It is the color that will be selected in ColorChooserPanel. Please note, it could be
	 *  different from last selected color which you can get it using {@link #getLastSelectedColor()}.
	 * 
	 *  @param selectedColor
	 */
	public void setSelectedColor(java.awt.Color selectedColor) {
	}
}
