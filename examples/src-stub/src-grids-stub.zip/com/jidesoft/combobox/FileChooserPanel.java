/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  FileChooserPanel is a popup panel that can choose File.
 */
public class FileChooserPanel extends PopupPanel {

	/**
	 *  Creates a new FileChooserPanel.
	 */
	public FileChooserPanel() {
	}

	/**
	 *  Creates a new FileChooserPanel.
	 * 
	 *  @param currentDirectoryPath current path
	 */
	public FileChooserPanel(String currentDirectoryPath) {
	}

	/**
	 *  Creates a new FileChooserPanel.
	 * 
	 *  @param currentDirectory current path
	 */
	public FileChooserPanel(java.io.File currentDirectory) {
	}

	protected void initComponents() {
	}

	/**
	 *  Gets the current directory when the file chooser opens.
	 * 
	 *  @return the current directory
	 */
	public java.io.File getCurrentDirectory() {
	}

	/**
	 *  Sets the current directory when the file chooser opens.
	 * 
	 *  @param currentDirectory the current directory
	 */
	public void setCurrentDirectory(java.io.File currentDirectory) {
	}

	/**
	 *  Gets the current directory path.
	 * 
	 *  @return the current directory path.
	 */
	public String getCurrentDirectoryPath() {
	}

	/**
	 *  Sets the current directory path when the file chooser opens. Different from {@link
	 *  #setCurrentDirectory(java.io.File)} which set the directory using file, this method uses a string. This method
	 *  will call {@link #setCurrentDirectory(java.io.File)} internally.
	 * 
	 *  @param currentDirectoryPath the current directory path.
	 */
	public void setCurrentDirectoryPath(String currentDirectoryPath) {
	}

	protected javax.swing.JComponent createFileChooserPanel() {
	}

	protected javax.swing.JFileChooser createFileChooser() {
	}

	/**
	 *  Always return false because JFileChooser has its own button defined.
	 *  <p/>
	 *  To disable the buttons in JFileChooser, please override {@link #createFileChooser()} and invoke {@link JFileChooser#setControlButtonsAreShown(boolean)}
	 * 
	 *  @return false.
	 */
	@java.lang.Override
	public boolean needsButtons() {
	}
}
