/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  MonthChooserPanel is a popup panel that can choose Date. User can click and select a Month. It also support various
 *  operations such as typing year directly, go to next or previous year. It also supports ItemListener. Whenever a Month
 *  is selected, itemStateChanged will be fired.
 */
public class MonthChooserPanel extends PopupPanel implements java.awt.event.ItemListener, java.awt.event.ActionListener, java.awt.event.MouseListener, java.awt.event.MouseWheelListener, DateModelListener {

	/**
	 *  Property of view only.
	 */
	public static final String VIEWONLY_PROPERTY = "viewonly";

	public static int NAVIGATION_BUTTON_HEIGHT;

	public static int NAVIGATION_BUTTON_WIDTH;

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 */
	public MonthChooserPanel() {
	}

	public MonthChooserPanel(DateModel dateModel) {
	}

	public MonthChooserPanel(boolean showNoneButton) {
	}

	public MonthChooserPanel(DateModel dateModel, boolean showNoneButton) {
	}

	public MonthChooserPanel(DateModel dateModel, boolean showNoneButton, java.util.Locale locale) {
	}

	/**
	 *  Gets the DateModel.
	 * 
	 *  @return DateModel.
	 */
	public DateModel getDateModel() {
	}

	/**
	 *  Sets the DateModel.
	 * 
	 *  @param dateModel the date model
	 */
	public void setDateModel(DateModel dateModel) {
	}

	/**
	 *  Adds DateModelListener to DateModel.
	 */
	protected void addModelListener() {
	}

	protected void removeModeListener() {
	}

	public void dateModelChanged(DateModelEvent e) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
	}

	public void enableMouseWheel() {
	}

	public void disableMouseWheel() {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	/**
	 *  Gets the selected date.
	 * 
	 *  @return the selected date.
	 */
	public java.util.Date getSelectedDate() {
	}

	/**
	 *  Gets the selected calendar.
	 * 
	 *  @return the selected calendar
	 */
	public java.util.Calendar getSelectedCalendar() {
	}

	/**
	 *  Sets the selected date.
	 * 
	 *  @param selectedDate the selected date
	 */
	public void setSelectedDate(java.util.Date selectedDate) {
	}

	/**
	 *  Gets a Calendar representing the month. By default, we use the date of the first day in each month.
	 * 
	 *  @return a Calendar representing the month
	 */
	protected java.util.Calendar getMonthCalendar() {
	}

	/**
	 *  Updates the calendar to represent the month. By default, we will set the calendar to the first date of each
	 *  month.
	 * 
	 *  @param calendar the calendar to represent to the month.
	 */
	protected void updateMonthCalendar(java.util.Calendar calendar) {
	}

	/**
	 *  Sets the selected calendar.
	 * 
	 *  @param selectedCalendar the selected calendar
	 */
	public void setSelectedCalendar(java.util.Calendar selectedCalendar) {
	}

	/**
	 *  This method will set the displayed year of MonthChooserPanel.
	 * 
	 *  @param year Year to be viewed
	 *  @return true if set successfully. Otherwise false.
	 */
	public boolean setDisplayedYear(int year) {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	protected java.awt.Component createMonthsPanel() {
	}

	protected java.awt.Component createMonthPanel() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JComponent createMonthLabel(int i) {
	}

	/**
	 *  Return the formatted text field used by the editor, or null if the editor doesn't descend from
	 *  JSpinner.DefaultEditor.
	 * 
	 *  @param spinner the spinner
	 *  @return the text field
	 */
	protected javax.swing.JTextField getTextField(javax.swing.JSpinner spinner) {
	}

	protected java.awt.Component createYearPanel() {
	}

	protected java.awt.Component createButtonPanel() {
	}

	protected void initCalendar() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	protected void initComponents() {
	}

	protected void updateCalendar() {
	}

	/**
	 *  If the DateChooserPanel is view-only.
	 * 
	 *  @return true if the DateChooserPanel is view-only
	 */
	public boolean isViewOnly() {
	}

	/**
	 *  Sets the view only attribute. If the DateChooserPanel is view-only, user will not be able to change the month or
	 *  year once it's set.
	 * 
	 *  @param viewOnly the flag
	 */
	public void setViewOnly(boolean viewOnly) {
	}

	protected void updateDayOfWeekLabel(javax.swing.JComponent dayOfWeekLabel, java.util.Calendar calendar) {
	}

	protected void updateMonthLabel(javax.swing.JComponent monthLabel, java.util.Calendar date, boolean isSelected, boolean isToday) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void updateYearLabel(javax.swing.JComponent yearLabel, java.util.Calendar calendar) {
	}

	protected javax.swing.JComponent createYearLabel() {
	}

	protected void registerKeyStrokes() {
	}

	protected void updateButtons() {
	}

	/**
	 *  Checks if none button is visible.
	 * 
	 *  @return true if none button is visible.
	 */
	public boolean isShowNoneButton() {
	}

	/**
	 *  Sets the none button visible.
	 * 
	 *  @param showNoneButton the flag
	 */
	public void setShowNoneButton(boolean showNoneButton) {
	}

	/**
	 *  Checks if this month button is visible.
	 * 
	 *  @return true if this month button is visible.
	 */
	public boolean isShowThisMonthButton() {
	}

	/**
	 *  Sets the this month button visible.
	 * 
	 *  @param showThisMonthButton the flag
	 */
	public void setShowThisMonthButton(boolean showThisMonthButton) {
	}

	protected boolean isDateSelected(java.util.Calendar calendar) {
	}

	protected boolean isToday(java.util.Calendar calendar) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in swing.properties that begin with "Date.".
	 * 
	 *  @param key the key to get resource string
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	protected void initDateFormat(java.util.Locale locale) {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale locale) {
	}

	/**
	 *  Checks if the month is out of the range of the DateModel. If true, it will call beep to notify user.
	 * 
	 *  @param calendar the calendar.
	 *  @return true if the calendar is out of the range. Otherwise false.
	 */
	protected boolean isMonthOutOfRange(java.util.Calendar calendar) {
	}

	public java.util.Calendar getDisplayedCalendar() {
	}

	public java.text.DateFormat getMonthFormatter() {
	}

	public void setMonthFormatter(java.text.DateFormat monthFormatter) {
	}
}
