/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>FileNameChooserComboBox</code> is a combination of text field and a button. You can type in file name directly
 *  into the text field. or you can press the button which will popup a FileChooser dialog to choose a file.
 */
public class FileNameChooserExComboBox extends FileChooserExComboBox {

	/**
	 *  Creates a new <code>ColorComboBox</code>.
	 */
	public FileNameChooserExComboBox() {
	}

	/**
	 *  Creates the popup panel. It simply return a FileNameChooserPanel. If you want to popup your own panel, you can
	 *  override this method in its subclass and return your own FileNameChooserPanel.
	 * 
	 *  @return the popup panel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}
}
