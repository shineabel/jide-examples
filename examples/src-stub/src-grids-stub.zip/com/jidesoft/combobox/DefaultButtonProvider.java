/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>DefaultButtonProvider</code> is an interface for default button.
 *  @since 3.4.0
 */
public interface DefaultButtonProvider {

	/**
	 *  Gets the default button
	 *  @return the default button
	 */
	public javax.swing.JButton getDefaultButton();
}
