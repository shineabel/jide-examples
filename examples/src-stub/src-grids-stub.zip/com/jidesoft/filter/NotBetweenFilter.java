/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is not between the
 *  two specified values.
 */
public class NotBetweenFilter extends BetweenFilter {

	public NotBetweenFilter() {
	}

	public NotBetweenFilter(Object value1, Object value2) {
	}

	public NotBetweenFilter(String name, Object value1, Object value2) {
	}

	@java.lang.Override
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Gets the operator. It will return " NOT BETWEEN " by default.
	 * 
	 *  @return the operator.
	 */
	@java.lang.Override
	public String getOperator() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 *  <p/>
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the range of this filter is larger than the input filter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
