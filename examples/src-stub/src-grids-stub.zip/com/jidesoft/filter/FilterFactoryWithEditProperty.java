/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  An extended interface to provide editable properties for ValueEditor.
 * 
 *  @since 3.3.6
 */
public interface FilterFactoryWithEditProperty extends FilterFactory {

	/**
	 *  Gets the expected editable properties in order to create the ValueEditor. For example, for EqualFilter for int, it will return
	 *  { true }. For EqualFilter for Object.class, it will return { false } as the customer normally does not type in new values.
	 * 
	 *  @return the expected data types in order to create the filter.
	 */
	public boolean[] getEditableProperties();
}
