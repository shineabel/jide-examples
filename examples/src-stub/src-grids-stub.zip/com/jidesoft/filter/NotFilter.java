/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  This filter will return the opposite value from {@link #isValueFiltered(Object)} method from the filter it contains.
 *  In the other word, it is a NOT logic.
 */
public class NotFilter extends AbstractFilter {

	public NotFilter(Filter filter) {
	}

	public boolean isValueFiltered(Object value) {
	}

	public Filter getFilter() {
	}

	public void setFilter(Filter filter) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the filter in input filter stricter than the filter in this filter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public Object clone() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	@java.lang.Override
	public boolean isFilterValid() {
	}
}
