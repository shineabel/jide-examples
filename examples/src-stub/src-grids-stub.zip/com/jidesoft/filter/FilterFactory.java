/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  <code>FilterFactory</code> is an interface responsible for creating filters through user interface. It can describe a
 *  filter using string through {@link #getConditionString(java.util.Locale)} method. It can also describe the data it
 *  expected using {@link #getExpectedDataTypes()}. Both methods make it possible for a user interface to present some
 *  appropriate input controls to users. Once the data needed by the filter is completed, then {@link
 *  #createFilter(Object...)} can be used to create the filter.
 */
public interface FilterFactory {

	/**
	 *  Creates the filter.
	 * 
	 *  @param objects the data needed by the filter in order to create it. For example, EqualFilter will need a value to
	 *                 compare the equality. BetweenFilter will need two values to form a range so that it can tell if
	 *                 the input value is falls into the range.
	 *  @return the Filter.
	 */
	public Filter createFilter(Object[] objects);

	/**
	 *  Gets the filter condition string. It is a localized string that will show to the users to tell them the purpose
	 *  of the filter.
	 * 
	 *  @param locale the Locale
	 *  @return the filter condition string.
	 */
	public String getConditionString(java.util.Locale locale);

	/**
	 *  Gets the <code>FilterFactory</code> name. This name is used in {@link com.jidesoft.filter.FilterFactoryManager#findFilterFactoryByName(Class,
	 *  String)} method.
	 * 
	 *  @return the <code>FilterFactory</code> name.
	 */
	public String getName();

	/**
	 *  Gets the expected data types in order to create the filter. For example, for EqualFilter for int, it will return
	 *  { int.class }. For BetweenFilter for Date, it will return { Date.class, Date.class } as it needs two Dates.
	 * 
	 *  @return the expected data types in order to create the filter.
	 */
	public Class[] getExpectedDataTypes();
}
