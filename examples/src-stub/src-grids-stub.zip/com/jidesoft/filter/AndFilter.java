/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  An filter which filters a value if any one of its filters filters away the value. In the other word, it is an AND
 *  logic.
 */
public class AndFilter extends MultipleFilters {

	public AndFilter() {
	}

	public AndFilter(Filter[] filters) {
	}

	/**
	 *  This method will call isValueFiltered from its filters. If one of the filters returns true, this method will
	 *  return true.
	 * 
	 *  @param value the value to be filtered
	 * 
	 *  @return true if one of the filters returns true. Otherwise false.
	 */
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 *  <p/>
	 *  Please be noted that it's a very loose comparison, we will compare the filters contained one by one only. Don't
	 *  expect it to be very concise.
	 * 
	 *  @param inputFilter the input filter
	 * 
	 *  @return true if all the filters contained in this filter are stricter than the input filter AND the number of
	 *          filters are larger or equal than the input filter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
