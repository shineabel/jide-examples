/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is within in the
 *  month as specified. It will return false if the Calendar or the Date in that month, regardless the year.
 */
public class MonthFilter extends DateOrCalendarFilter {

	/**
	 *  Creates a MonthFilter. The actual month will be set later using setMonth method.
	 */
	public MonthFilter() {
	}

	/**
	 *  Creates a MonthFilter for a particular month.
	 * 
	 *  @param month the month, starting from 0 for January. You can use the value defined in Calendar such as
	 *               Calendar.JANUARY, Calendar.FEBRUARY, etc.
	 */
	public MonthFilter(int month) {
	}

	public int getMonth() {
	}

	public void setMonth(int month) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the month of the two filters are same. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
