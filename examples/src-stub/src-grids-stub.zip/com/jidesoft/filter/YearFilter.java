/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is within in the
 *  year as specified. It will return false if the Calendar or the Date in that year, regardless others.
 * 
 *  @since 3.4.3
 */
public class YearFilter extends DateOrCalendarFilter {

	/**
	 *  Creates a YearFilter. The actual year will be set later using setYear method.
	 */
	public YearFilter() {
	}

	/**
	 *  Creates a YearFilter for a particular year.
	 * 
	 *  @param year the year
	 */
	public YearFilter(int year) {
	}

	/**
	 *  Gets the year.
	 * 
	 *  @return the year.
	 */
	public int getYear() {
	}

	/**
	 *  Sets the year.
	 * 
	 *  @param year the year
	 */
	public void setYear(int year) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the year of the two filters are same. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
