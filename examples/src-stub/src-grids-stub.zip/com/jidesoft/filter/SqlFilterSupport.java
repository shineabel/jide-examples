/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


public interface SqlFilterSupport {

	public String getOperator();
}
