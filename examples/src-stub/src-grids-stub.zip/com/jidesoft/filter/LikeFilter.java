/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A filter implements filtering a string based the LIKE condition as in SQL. The pattern is specified in the
 *  constructor. The patterns that you can choose from are: '%' allows you to match any string of any length (including
 *  zero length) and '_' allows you to match on a single character.
 *  <p/>
 *  Please note, in Oracle, the SQL supports defining escape character but this is not supported in this LikeFilter.
 *  However if you need, you can override convertFromPatternToRegex to convert your own regular expression based on the
 *  input pattern.
 */
public class LikeFilter extends RegexFilter implements SqlFilterSupport {

	public LikeFilter() {
	}

	public LikeFilter(String pattern) {
	}

	/**
	 *  Converts the SQL Like compatible pattern to the pattern used in Java Pattern class.
	 * 
	 *  @param pattern the input pattern.
	 *  @return the pattern string used by {@link java.util.regex.Pattern}.
	 */
	@java.lang.Override
	protected String convertFromPatternToRegex(String pattern) {
	}

	/**
	 *  Gets the operator. It will return " LIKE " by default.
	 * 
	 *  @return the operator.
	 */
	public String getOperator() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
