/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  The utility class dealing with filters.
 * 
 *  @since 3.4.5
 */
public class FilterUtils {

	public FilterUtils() {
	}

	/**
	 *  Creates a filter from the filter preference string.
	 * 
	 * 
	 *  @param preference       the preference string
	 *  @param type             the class type the filter will work on
	 *  @param converterContext the converter context to help converting the string back to the value
	 *  @return the new Filter instance.
	 */
	public static Filter setFilterPreference(String preference, Class type, ConverterContext converterContext) {
	}

	/**
	 *  Gets the filter preference string from the filter
	 * 
	 * 
	 *  @param filter           the filter
	 *  @param type             the class type the filter works on
	 *  @param converterContext the converter context to help converting the string back to the value
	 *  @return the preference string.
	 */
	public static String getFilterPreference(Filter filter, Class type, ConverterContext converterContext) {
	}
}
