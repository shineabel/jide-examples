/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  <code>CustomFilterEditor</code> is a panel for an end user to create a Filter using a user interface.
 */
public class CustomFilterEditor extends javax.swing.JPanel implements com.jidesoft.grid.FilterEditor {

	protected javax.swing.JComponent _conditionComboBox;

	protected ValueEditor _valueEditor1;

	protected ValueEditor _valueEditor2;

	protected javax.swing.JLabel _conditionLabel;

	protected javax.swing.JLabel _matchLabel;

	protected boolean _singleLineMode;

	public CustomFilterEditor(FilterFactoryManager filterManager) {
	}

	public CustomFilterEditor(FilterFactoryManager filterManager, Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	protected void initComponents() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Creates the ValueEditor.
	 * 
	 *  @param type             the type.
	 *  @param converterContext the ConverterContext.
	 *  @param possibleValues   the possible values.
	 *  @return a new instance of the ValueEditor.
	 */
	protected ValueEditor createValueEditor(Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Gets the possible values.
	 * 
	 *  @return the possible values.
	 */
	public Object[] getPossibleValues() {
	}

	/**
	 *  Gets the data type of this filter editor.
	 * 
	 *  @return the data type of this filter editor.
	 */
	public Class getType() {
	}

	public void reset(FilterFactoryManager filterManager, Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Creates the condition combobox.
	 * 
	 *  @return the condition combobox.
	 */
	protected javax.swing.JComponent createConditionComboBox() {
	}

	/**
	 *  Get valid filter value by the input value and the expected class. In normal cases, the input value itself should be returned. In some cases, if the input is not convertible to the target class,
	 *  null will be returned.
	 * 
	 *  @param expectedClass the target value class
	 *  @param value         the input value
	 *  @return the valid value. null if no valid value found.
	 */
	protected Object getValidValueForClass(Class expectedClass, Object value) {
	}

	@java.lang.Override
	public Filter[] getFilters() {
	}

	@java.lang.Override
	public void setFilters(Filter[] filters) {
	}

	/**
	 *  Gets the filter.
	 * 
	 *  @return the filter.
	 */
	public Filter getFilter() {
	}

	/**
	 *  Sets the filter.
	 * 
	 *  @param filter the filter.
	 */
	public void setFilter(Filter filter) {
	}

	protected String getResourceString(String key) {
	}

	public boolean isSingleLineMode() {
	}

	public void setSingleLineMode(boolean singleLineMode) {
	}

	/**
	 *  Sets the flag indicating if the ValueEditor should be put vertically under the condition combo box.
	 *  <p/>
	 *  By default, the value is false to keep consistent behavior with older releases.
	 * 
	 *  @param verticalLayout the flag
	 *  @since 3.4.5
	 */
	public void setVerticalLayout(boolean verticalLayout) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Gets the flag indicating if the ValueEditor should be put vertically under the condition combo box.
	 * 
	 *  @return true if it should layout vertically. Otherwise false.
	 *  @since 3.4.5
	 */
	public boolean isVerticalLayout() {
	}

	/**
	 *  Gets the current ObjectGrouper instance.
	 * 
	 *  @return the grouper.
	 *  @since 3.4.7
	 */
	public ObjectGrouper getObjectGrouper() {
	}

	/**
	 *  Sets the current ObjectGrouper instance.
	 * 
	 *  @param objectGrouper the grouper
	 *  @since 3.4.7
	 */
	public void setObjectGrouper(ObjectGrouper objectGrouper) {
	}
}
