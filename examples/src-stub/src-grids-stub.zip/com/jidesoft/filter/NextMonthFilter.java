/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is within the next
 *  month of today's date.
 */
public class NextMonthFilter extends DateOrCalendarFilter {

	public NextMonthFilter() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
