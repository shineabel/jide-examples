/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is not in a
 *  collection of the specified values.
 */
public class NotInFilter extends InFilter {

	public NotInFilter() {
	}

	public NotInFilter(Object[] values) {
	}

	public NotInFilter(String name, Object[] values) {
	}

	@java.lang.Override
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Gets the operator. It will return " NOT IN " by default.
	 * 
	 *  @return the operator.
	 */
	@java.lang.Override
	public String getOperator() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if all the possible values contained in the input filter are also contained in this filter.
	 *          Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
