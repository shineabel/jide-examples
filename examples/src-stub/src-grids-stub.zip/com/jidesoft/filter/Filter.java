/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  Filter is used to filter some values away by checking the value in {@link #isValueFiltered(Object)}. If {@link
 *  #isValueFiltered(Object)} returns true, the value should be filtered. Otherwise, it should return false.
 *  <p/>
 *  In addition, you can give the filter a name by implementing {@link #getName}. You can also enable or disable a
 *  filter. If a filter is disabled, no matter what value isValueFiltered returns, it should never be considered.
 *  <p/>
 *  {@link AbstractFilter} implements this interface to provide basic support a Filter needs such as name,
 *  enabled/disabled, and listener support.
 */
public interface Filter extends java.io.Serializable, Cloneable {

	/**
	 *  A constant for ALL for filters. If you want to display it on screen, please use
	 *  GridResource.getResourceBundle(locale).getString("Filter.all") to get the localized string
	 */
	public static final String ALL = "(All)";

	/**
	 *  A constant for null value for filters. If you want to display it on screen, please use
	 *  GridResource.getResourceBundle(locale).getString("Filter.null") to get the localized string
	 */
	public static final String NULL = "(Empty)";

	/**
	 *  A constant for ALL for filters. If you want to display it on screen, please use
	 *  GridResource.getResourceBundle(locale).getString("Filter.custom") to get the localized string
	 */
	public static final String CUSTOM = "(Custom...)";

	public static final String SEPARATOR = "\t";

	/**
	 *  Gets the name of the filter.
	 * 
	 *  @return the name of the filter.
	 */
	public String getName();

	/**
	 *  Sets the name of the filter.
	 * 
	 *  @param name the name of the filter.
	 */
	public void setName(String name);

	/**
	 *  Checks to see if the value should be filtered away (or rejected).
	 * 
	 *  @param value the value to filter
	 *  @return true if the value should be filtered away (or rejected). Otherwise false.
	 */
	public boolean isValueFiltered(Object value);

	/**
	 *  Checks if the filter is enabled. If a filter is not enabled, isValueFiltered() will never be called.
	 * 
	 *  @return true if the filter is enabled. Otherwise false.
	 */
	public boolean isEnabled();

	/**
	 *  Sets the filter enabled or disabled.
	 * 
	 *  @param enabled true to enabled the filter; false to disable it.
	 */
	public void setEnabled(boolean enabled);

	/**
	 *  Gets the FilterFactory. If the Filter is created through a FilterFactory, this method will return that
	 *  FilterFactory. Otherwise it will return null.
	 * 
	 *  @return the FilterFactory that creates the Filter. Otherwise it will return null.
	 */
	public FilterFactory getFilterFactory();

	/**
	 *  Sets the FilterFactory that creates this Filter.
	 * 
	 *  @param filterFactory the FilterFactory that creates this Filter.
	 */
	public void setFilterFactory(FilterFactory filterFactory);

	/**
	 *  Gets the FilterFactory name. If the Filter is created through a FilterFactory, this method will return that
	 *  FilterFactory name. Otherwise it will return null.
	 * 
	 *  @return the FilterFactory name that creates the Filter. Otherwise it will return null.
	 */
	public String getFilterFactoryName();

	/**
	 *  Sets the FilterFactory name that creates this Filter.
	 * 
	 *  @param name the FilterFactory that creates this Filter.
	 */
	public void setFilterFactoryName(String name);

	/**
	 *  Adds a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterListener
	 */
	public void addFilterListener(com.jidesoft.grid.FilterListener l);

	/**
	 *  Removes a listener from the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterListener
	 */
	public void removeFilterListener(com.jidesoft.grid.FilterListener l);

	/**
	 *  Checks if this filter is stricter than the input filter. Stricter means that every data satisfying the input
	 *  filter must also satisfy this filter.
	 *  <p/>
	 *  Sometimes it's really hard to say if one filter is stricter than another or not. Please return true only if you
	 *  are very sure and return false in any other cases. The reason to do that is, if you return incorrect false, the
	 *  only hit you will get is just performance due to unnecessary filter applying. However, if you return incorrect
	 *  true, the hit will be very serious that you would not get expected rows showing up.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if this filter stricter than the input filter. Otherwise false.
	 */
	public boolean stricterThan(Filter inputFilter);

	/**
	 *  Gets the preference while persisting this filter.
	 * 
	 *  @param clazz            the class type to convert the values inside the filter to string
	 *  @param converterContext the converter context to convert the values inside the filter to string
	 *  @return the preference string.
	 *  @since 3.4.4
	 */
	public String getPreference(Class clazz, ConverterContext converterContext);

	/**
	 *  Sets the preference to load the preference string back to this filter.
	 * 
	 *  @param prefString       the preference string
	 *  @param clazz            the class type to convert the values inside the filter to string
	 *  @param converterContext the converter context to convert the values inside the filter to string
	 *  @return the object array to be passed into the FilterFactoryManager if necessary.
	 *  @since 3.4.4
	 */
	public Object[] setPreference(String prefString, Class clazz, ConverterContext converterContext);

	/**
	 *  Creates and returns a copy of the filter.
	 * 
	 *  @return a cloned copy of the filter.
	 * 
	 *  @throws CloneNotSupportedException if the cloning of the filter is not supported.
	 */
	public Object clone();
}
