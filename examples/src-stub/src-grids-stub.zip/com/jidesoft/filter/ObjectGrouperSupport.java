/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  The interface to let the filters support ObjectGrouper.
 * 
 *  @since 3.4.7
 */
public interface ObjectGrouperSupport {

	/**
	 *  Gets the current ObjectGrouper instance.
	 * 
	 *  @return the grouper.
	 */
	public ObjectGrouper getObjectGrouper();

	/**
	 *  Sets the current ObjectGrouper instance.
	 * 
	 *  @param objectGrouper the grouper
	 */
	public void setObjectGrouper(ObjectGrouper objectGrouper);

	/**
	 *  Gets the name of object grouper.
	 * 
	 *  @return the grouper name.
	 */
	public String getObjectGrouperName();

	/**
	 *  Sets the name of object grouper.
	 * 
	 *  @param grouperName the grouper name
	 */
	public void setObjectGrouperName(String grouperName);
}
