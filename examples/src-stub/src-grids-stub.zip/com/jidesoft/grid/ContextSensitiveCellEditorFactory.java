/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Interfaces used by CellEditorManager to create a cell editor using factory pattern. Different from {@link
 *  com.jidesoft.grid.CellEditorFactory}, this interface takes an EditorContext in the create method.
 */
public interface ContextSensitiveCellEditorFactory extends CellEditorFactory {

	public javax.swing.CellEditor create(EditorContext context);
}
