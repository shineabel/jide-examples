/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default implementation of SummaryCalculator for GroupTable. It implemented {@link
 *  #addValue(javax.swing.table.TableModel, Row, int, Object)} and call {@link #addValue(Object)} as the default
 *  implementation. However you can subclass it and override {@link #addValue(javax.swing.table.TableModel, Row, int,
 *  Object)} to provide another implementation if your implementation of the summary value needs to know the values from
 *  other cells.
 */
public class DefaultGroupTableSummaryCalculator extends DefaultSummaryCalculator implements GroupTableSummaryCalculator {

	public DefaultGroupTableSummaryCalculator() {
	}

	@java.lang.Override
	public void addValue(javax.swing.table.TableModel model, Row row, int columnIndex, Object value) {
	}
}
