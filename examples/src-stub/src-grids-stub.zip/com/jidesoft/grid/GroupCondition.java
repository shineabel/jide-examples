/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public interface GroupCondition {

	/**
	 *  Checks if a row in the table model satisfies the condition specified by this <code>GroupCondition</code>.
	 * 
	 *  @param model the table model.
	 *  @param row   the row index.
	 *  @return true if the row in the table model satisfies the group condition. Otherwise false.
	 */
	public boolean satisfies(javax.swing.table.TableModel model, int row);

	/**
	 *  Checks if the specified condition is contained in this condition.
	 * 
	 *  @param c the condition to check.
	 *  @return true if this condition is a super set of the condition c. Otherwise false.
	 */
	public boolean contains(GroupCondition c);

	/**
	 *  Configure the condition that immediately contains this condition.
	 * 
	 *  @param condition the condition to be configured.
	 *  @return the parent condition. Null if the condition is a top level condition.
	 */
	public GroupCondition configureParentCondition(GroupCondition condition);

	/**
	 *  Gets the number of conditions.
	 * 
	 *  @return the number of conditions.
	 */
	public int getNumberOfConditions();

	/**
	 *  Gets the condition value.
	 * 
	 *  @param index the index of the condition.
	 *  @return the value of the condition.
	 */
	public Object getConditionValue(int index);
}
