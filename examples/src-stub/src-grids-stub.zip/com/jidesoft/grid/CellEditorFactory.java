/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Interfaces used by CellEditorManager to create a cell editor using the factory pattern.
 *  The purpose of this factory is to make sure a new instance of CellEditor is created
 *  every time when asking CellEditorManager for one.
 */
public interface CellEditorFactory {

	public javax.swing.CellEditor create();
}
