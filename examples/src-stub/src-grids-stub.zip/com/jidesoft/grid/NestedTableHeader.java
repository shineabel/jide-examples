/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A table header supporting nested table columns.
 */
public class NestedTableHeader extends AutoFilterTableHeader {

	protected java.util.Vector _columnGroups;

	public static final String PROPERTY_ORIGINAL_TABLE_HEADER_VISIBLE = "originalTableHeaderVisible";

	public NestedTableHeader(javax.swing.table.TableColumnModel model) {
	}

	/**
	 *  The constructor that takes table.
	 * 
	 *  @param table the table
	 *  @since 3.1.0
	 */
	public NestedTableHeader(javax.swing.JTable table) {
	}

	@java.lang.Override
	public java.awt.Rectangle getHeaderRect(int column) {
	}

	public String getActualUIClassID() {
	}

	/**
	 *  Returns a string that specifies the name of the UIDelegate class that paints this component.
	 * 
	 *  @return the string "TableHeader.nestedTableHeaderUIDelegate"
	 * 
	 *  @since 3.1.0
	 */
	public String getUIDelegateClassID() {
	}

	@java.lang.Override
	protected void tableModelChanged(javax.swing.JTable table) {
	}

	/**
	 *  Gets all the TableColumnGroups added to <code>NestedtableHeader</code> as an array.
	 * 
	 *  @return the all the TableColumnGroups as an array.
	 */
	public javax.swing.table.TableColumn[] getTableColumnGroups() {
	}

	/**
	 *  Adds a column group to table header. You only need to add the outermost table column group to table header.
	 * 
	 *  @param group TableColumnGroup to be added.
	 *  @see #getTableColumnGroups()
	 */
	public void addColumnGroup(TableColumnGroup group) {
	}

	/**
	 *  Removes a column group to table header.
	 * 
	 *  @param group TableColumnGroup to be removed.
	 */
	public void removeColumnGroup(TableColumnGroup group) {
	}

	/**
	 *  Removes all column groups.
	 */
	public void clearColumnGroups() {
	}

	/**
	 *  Gets the parent of the table column.
	 * 
	 *  @param column the TableColumn.
	 *  @return the parent of the table column.
	 */
	public Object getParent(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Returns the index of the row that <code>point</code> lies in.
	 * 
	 *  @param p the point
	 *  @return the row index. -1 if it lies out of bounds.
	 */
	public int rowAtPoint(java.awt.Point p) {
	}

	/**
	 *  Gets an enumeration of table column groups.
	 * 
	 *  @param column the TableColumn.
	 *  @return the enumeration of the ancestors of table column.
	 */
	public java.util.Enumeration getColumnGroups(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Gets the starts row index for the column.
	 * 
	 *  @param column the TableColumn instance.
	 *  @return the table column group vector of all the column's ancestors
	 * 
	 *  @since 3.2.0
	 */
	public int getRowAt(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Gets the level of the TableColumn.
	 * 
	 *  @param column the TableColumn
	 *  @return the level.
	 */
	public int getLevel(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Checks if the original table header is visible.
	 * 
	 *  @return true if visible. Otherwise false.
	 */
	public boolean isOriginalTableHeaderVisible() {
	}

	/**
	 *  Shows or hides the original table header visible. It is true by default. If you need hide the original table
	 *  header and only show the nested table header above it, you can call this method and set it to false.
	 * 
	 *  @param originalTableHeaderVisible true or false.
	 */
	public void setOriginalTableHeaderVisible(boolean originalTableHeaderVisible) {
	}

	/**
	 *  Check if the mouse point is on the original table header
	 * 
	 *  @param point mouse point
	 *  @return false if the point is on the group columns. Otherwise true.
	 */
	public boolean isMouseOnOriginalTableHeader(java.awt.Point point) {
	}

	/**
	 *  Get the corresponding TableColumnGroup in the designated row and column.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return TableColumnGroup instance if it is a group. null if it is just a TableColumn or other objects.
	 */
	public TableColumnGroup getTableColumnGroup(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the row count since it has nested table header.
	 * 
	 *  @return the row count.
	 */
	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	/**
	 *  Gets the cell span of the nested table header.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the cell span for the specified cell.
	 */
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public java.awt.Rectangle originalGetCellRect(int row, int column) {
	}

	public java.awt.Rectangle getCellRect(int row, int column) {
	}

	public int getActualHeaderY() {
	}

	@java.lang.Override
	public int columnAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public int originalColumnAtPoint(java.awt.Point point) {
	}

	/**
	 *  Gets the header value at the specified cell.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the header value at the specified cell.
	 */
	public Object getHeaderValueAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the margin between TableColumn's.
	 * 
	 *  @return the margin.
	 * 
	 *  @see #setMargin(int)
	 */
	public int getMargin() {
	}

	/**
	 *  Sets the margin between TableColumn's.
	 *  <p/>
	 *  By default, the value is 0.
	 * 
	 *  @param margin the margin
	 */
	public void setMargin(int margin) {
	}

	@java.lang.Override
	public javax.swing.JToolTip createToolTip() {
	}
}
