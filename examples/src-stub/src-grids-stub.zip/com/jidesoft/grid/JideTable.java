/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>JideTable</code> is an extended version of <code>JTable</code>.
 *  <p/>
 *  There are several features we added to <code>JideTable</code>.
 *  <p/>
 *  First, we added CellEditorListener support. You can add a {@link JideCellEditorListener} to the table.
 *  <code>JideCellEditorListener</code> extends <code>CellEditorListener</code> and added additional methods such as
 *  {@link JideCellEditorListener#editingStarting(javax.swing.event.ChangeEvent)}, {@link
 *  JideCellEditorListener#editingStopping(javax.swing.event.ChangeEvent)} and {@link
 *  JideCellEditorListener#editingStopped(javax.swing.event.ChangeEvent)}. You can do things like preventing cell from
 *  starting edit or preventing cell from stopping edit.
 *  <p/>
 *  The second feature is to support Validator. You can add a Validator to the table. The validating() method in the
 *  listener will be called before cell stops editing. If the validation failed, the cell editor won't be removed.
 *  <p/>
 *  The third feature added to JideTable is the support of the listener for row height changes when rows have various
 *  height. You can add a listener by calling <code>getRowHeights().addRowHeightChangeListener(listener)</code>. A {@link
 *  RowHeightChangeEvent} will be fired whenever {@link #setRowHeight(int, int)} is called.
 *  <p/>
 *  The fourth feature is rowAutoResizes. By default, JTable's row height is determined explicitly. It wouldn't consider
 *  the cell content preferred height. There is a problem here if a cell renderer can support multiple lines. So we added
 *  a new attribute called rowAutoResizes. By default, it's false which is exactly the same behavior as JTable. If you
 *  set to true, the table row will resize automatically when cell renderer's preferred height changes. Please note there
 *  is a performance hit if you turned it on as it has to check all cells to find out the preferred row height. So only
 *  use it when it's really necessary.
 *  <p/>
 *  In the future, we will add more features to <code>JideTable</code> as long as we think the feature should be part of
 *  the base table class.
 *  <p/>
 *  Please be noted that, JideTable could NOT support the sorter provided in JTable. The reason is that, JTable contains
 *  many private method and fields in that area, which prevents us to inherit its behavior. For sorting feature in
 *  JideTable, please use {@link com.jidesoft.grid.SortableTable} instead. There might be some odd behaviors if you
 *  invoke JTable#setAutoCreateRowSorter(true).
 */
@java.lang.SuppressWarnings("serial")
public class JideTable extends javax.swing.JTable implements TableAdapter, IndexChangeListener {

	protected transient CellChangeEvent _cellChangeEvent;

	/**
	 *  @deprecated renamed to PROPERTY_ROW_AUTO_RESIZES
	 */
	@java.lang.Deprecated
	public static final String ROW_AUTO_RESIZES_PROPERTY = "rowAutoResizes";

	public static final String PROPERTY_ROW_AUTO_RESIZES = "rowAutoResizes";

	public static final String PROPERTY_NON_CONTIGUOUS_CELL_SELECTION = "nonContiguousCellSelection";

	public static final String PROPERTY_TABLE_SELECTION_MODEL = "tableSelectionModel";

	public static final String PROPERTY_SCROLL_ROW_WHEN_ROW_HEIGHT_CHANGES = "scrollRowWhenRowHeightChanges";

	/**
	 *  @deprecated replaced by {@link #PROPERTY_LOAD_SELECTION_ON_TABLE_DATA_CHANGES}
	 */
	@java.lang.Deprecated
	public static final String PROPERTY_CLEAR_SELECTION_ON_TABLE_DATA_CHANGES = "clearSelectionOnTableDataChanges";

	public static final String PROPERTY_LOAD_SELECTION_ON_TABLE_DATA_CHANGES = "loadSelectionOnTableDataChanges";

	public static final String PROPERTY_EDITOR_AUTO_COMPLETION_MODE = "editorAutoCompletionMode";

	public static final String PROPERTY_FILLS_RIGHT = "fillsRight";

	public static final String PROPERTY_FILLS_BOTTOM = "fillsBottom";

	public static final String PROPERTY_FILLS_GRIDS = "fillsGrids";

	/**
	 *  This client property only takes effect when {@link #isRowAutoResizes()} returns true.
	 *  <p/>
	 *  By default, it's lazy load which won't hit the performance. However, if you want to refresh the table's prefererd
	 *  height without performance concern, please set this client property to Boolean.FALSE
	 */
	public static final String CLIENT_PROPERTY_LAZY_CALCULATE_ROW_HEIGHT = "lazyCalculateRowHeight";

	public static final String ACTION_NAME_CANCEL_EDITING = "cancelEditing";

	/**
	 *  An enhanced auto resize mode. In this mode, if a JideTable is inside a JScrollPane and the width cannot fill the
	 *  JViewport, JideTable will have the blank area filled like normal table header and cells.
	 */
	public static final int AUTO_RESIZE_FILL = 256;

	/**
	 *  @deprecated please use AUTO_RESIZE_FILL | AUTO_RESIZE_NEXT_COLUMN instead.
	 */
	@java.lang.Deprecated
	public static final int AUTO_RESIZE_NEXT_COLUMN_FILL = 257;

	/**
	 *  @deprecated please use AUTO_RESIZE_FILL | AUTO_RESIZE_SUBSEQUENT_COLUMNS instead.
	 */
	@java.lang.Deprecated
	public static final int AUTO_RESIZE_SUBSEQUENT_COLUMNS_FILL = 258;

	/**
	 *  @deprecated please use AUTO_RESIZE_FILL | AUTO_RESIZE_LAST_COLUMN instead.
	 */
	@java.lang.Deprecated
	public static final int AUTO_RESIZE_LAST_COLUMN_FILL = 259;

	/**
	 *  @deprecated please use AUTO_RESIZE_FILL | AUTO_RESIZE_ALL_COLUMNS instead.
	 */
	@java.lang.Deprecated
	public static final int AUTO_RESIZE_ALL_COLUMNS_FILL = 260;

	/**
	 *  An integer specifying the number of clicks needed to start editing. Even if <code>clickCountToStart</code> is
	 *  defined as zero, it will not initiate until a click occurs.
	 */
	protected int _clickCountToStart;

	protected java.awt.event.MouseMotionListener _headerDraggingMouseMotionListener;

	public static final int EDITOR_AUTO_COMPLETION_MODE_NONE = 0;

	public static final int EDITOR_AUTO_COMPLETION_MODE_COLUMN = 1;

	public static final int EDITOR_AUTO_COMPLETION_MODE_ROW = 2;

	public static final int EDITOR_AUTO_COMPLETION_MODE_TABLE = 3;

	protected RowHeights _rowHeights;

	protected boolean _batchProcessing;

	protected java.beans.PropertyChangeListener _rolloverEditorRemover;

	protected javax.swing.event.CellEditorListener _rolloverCellEditorListener;

	protected transient javax.swing.table.TableCellEditor _rolloverCellEditor;

	protected transient java.awt.Component _rolloverEditorComp;

	protected transient int _rolloverRow;

	protected transient int _rolloverColumn;

	protected TableColumnAutoResizer _columnAutoResizer;

	protected TableRowResizer _rowResizer;

	protected TableColumnResizer _columnResizer;

	public JideTable() {
	}

	public JideTable(int numRows, int numColumns) {
	}

	public JideTable(javax.swing.table.TableModel dm) {
	}

	public JideTable(Object[][] rowData, Object[] columnNames) {
	}

	public JideTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public JideTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public JideTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	/**
	 *  Leaves it here for backward compatible reason.
	 */
	protected void initTable() {
	}

	/**
	 *  <code>JideTable</code> will use its own transfer handler called <code>JideTableTransferHandler</code> which could
	 *  import data from clipboard. If you dont' like this behavior, you could call this method to reset the transfer
	 *  handler to the default one created by JTable which doesn't allow import.
	 */
	public void resetTransferHandler() {
	}

	public void setModel(javax.swing.table.TableModel dataModel) {
	}

	/**
	 *  Sets the table's auto resize mode when the table is resized.
	 *  <p/>
	 *  Comparing to JTable, JideTable provides one more option - AUTO_RESIZE_FILL. It has two effects. First of all, it
	 *  will stretch the last column of the table header area so that the empty area looks like an empty table column
	 *  header. The second effect is it will fill the area under the empty table column header with table background or
	 *  the stripes if you are using {@link com.jidesoft.grid.RowStripeTableStyleProvider}. Most likely you will combine
	 *  it with AUTO_RESIZE_OFF flag and call setAutoResizeMode(AUTO_RESIZE_FILL | AUTO_RESIZE_OFF). However you could
	 *  use AUTO_RESIZE_FILL | AUTO_RESIZE_NEXT_COLUMN or with any other auto resize modes.
	 *  <p/>
	 *  Prior to 2.10.1, we changed the return value of getAutoResizeMode to return the exact value you set using
	 *  setAutoResizeMode. However it has some side effects that we can't overcome. So starting from 2.10.1,
	 *  getAutoResizeMode will return the mode without AUTO_RESIZE_FILL. If you want to check if AUTO_RESIZE_FILL is set,
	 *  you can call {@link #isAutoResizeFillMode()}.
	 * 
	 *  @param mode the auto resize mode
	 *  @see #getAutoResizeMode
	 *  @see #doLayout
	 */
	@java.lang.Override
	public void setAutoResizeMode(int mode) {
	}

	/**
	 *  Get the flag indicating if empty area of the table need be filled.
	 *  <p/>
	 *  By default, this flag is false. You could invoke {@link #setAutoResizeMode(int)} to change its value. If you want
	 *  this flag to return true, just call setAutoResizeMode( mode | AUTO_RESIZE_FILL) where the mode is one of the four
	 *  existing auto resize modes defined in JTable.
	 * 
	 *  @return true if the empty area is to be filled. Otherwise false.
	 *  @since 2.10.1
	 */
	public boolean isAutoResizeFillMode() {
	}

	public String getActualUIClassID() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Checks if nested table header is used. If you want to use nested table header, you need to make sure you call
	 *  {@link #setNestedTableHeader(boolean)} and pass in true.
	 * 
	 *  @return true if nested table header is used. Otherwise false.
	 */
	public boolean isNestedTableHeader() {
	}

	/**
	 *  Sets if nested table header is allowed.
	 * 
	 *  @param nestedTableHeader true or false.
	 */
	public void setNestedTableHeader(boolean nestedTableHeader) {
	}

	/**
	 *  Creates the table header. If the nested table header is allowed, it will return an instance of NestedTableHeader.
	 *  Otherwise, it will return the JTableHeader.
	 * 
	 *  @return table header
	 */
	@java.lang.Override
	protected javax.swing.table.JTableHeader createDefaultTableHeader() {
	}

	/**
	 *  Paint fill header in the right side of the table header if needed.
	 * 
	 *  @param g the Graphics instance
	 */
	protected void paintFillHeader(java.awt.Graphics g) {
	}

	/**
	 *  Gets the TableHeader's tooltip at the location of mouse event.
	 * 
	 *  @param event the mouse event.
	 *  @return the tooltip for the column where the mouse is over.
	 */
	public String getTableHeaderToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Gets the TableHeader's tooltip for a particular model column index
	 * 
	 *  @param modelIndex the model column index.
	 *  @return the tooltip for the model column index where the mouse is over.
	 */
	public String getTableHeaderToolTipText(int modelIndex) {
	}

	@java.lang.Override
	public boolean processKeyBinding(javax.swing.KeyStroke ks, java.awt.event.KeyEvent e, int condition, boolean pressed) {
	}

	@java.lang.Override
	public void setTableHeader(javax.swing.table.JTableHeader tableHeader) {
	}

	@java.lang.Override
	public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int row, int column) {
	}

	/**
	 *  Creates the AutoCompletion for the cell editor to use.
	 * 
	 *  @param textComponent      the text component
	 *  @param autoCompletionList the auto completion list
	 *  @return the AutoCompletion list.
	 *  @since 3.4.4
	 */
	protected AutoCompletion createCellAutoCompletion(javax.swing.text.JTextComponent textComponent, Object[] autoCompletionList) {
	}

	/**
	 *  Get the displayed string of the specified value in designated row and column.
	 * 
	 *  @param value  the cell value
	 *  @param row    the row of the cell
	 *  @param column the column of the cell
	 *  @return the string to be displayed in the cell on rendering.
	 */
	protected String convertElementToString(Object value, int row, int column) {
	}

	/**
	 *  Gets the text component from the editor component. We need it in order to make it focus and select all the text
	 *  if {@link #isAutoSelectTextWhenStartsEditing()} is true.
	 *  <p/>
	 *  Please note, this method will only return JTextComponent if the component is JTextComponent, JComboBox,
	 *  AbstractComboBox or JSpinner. For all other types of components, it will return null. If you have a custom cell
	 *  editor component which also has JTextComponent in it, you can make the editor component implementing the {@link
	 *  TextComponentProvider} interface to return a JTextComponent.
	 * 
	 *  @param component the component.
	 *  @return text component inside the editor component.
	 */
	public javax.swing.text.JTextComponent getTextComponentForEditorComponent(java.awt.Component component) {
	}

	/**
	 *  Calls <code>fireEditingStarting</code> and <code>fireEditingStarted</code>, and returns true or false based on
	 *  the return value of <code>fireEditingStarting</code>.
	 * 
	 *  @param editor the editor
	 *  @param row    the editing row
	 *  @param column the editing column
	 *  @return true if editing started. Otherwise false.
	 */
	protected boolean startCellEditing(javax.swing.CellEditor editor, int row, int column) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  created lazily.
	 * 
	 *  @param source the source of the event
	 *  @param row    the row index
	 *  @param column the column index
	 *  @return true or false. If all listeners return true in <code>editingStarting()</code>, it will return true. If
	 *  one of the listener returns false, it will return false.
	 */
	protected boolean fireEditingStarting(Object source, int row, int column) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  created lazily.
	 * 
	 *  @param source the source of the event
	 *  @param row    the row index
	 *  @param column the column index
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireEditingStarted(Object source, int row, int column) {
	}

	/**
	 *  Adds a <code>JideCellEditorListener</code> to the listener list.
	 * 
	 *  @param l the new listener to be added
	 */
	public void addCellEditorListener(JideCellEditorListener l) {
	}

	/**
	 *  Removes a <code>JideCellEditorListener</code> from the listener list.
	 * 
	 *  @param l the listener to be removed
	 */
	public void removeCellEditorListener(JideCellEditorListener l) {
	}

	/**
	 *  Returns an array of all the <code>JideCellEditorListener</code>s added to this <code>JideTable</code> with
	 *  addCellEditorListener().
	 * 
	 *  @return all of the <code>CellEditorListener</code>s added or an empty array if no listeners have been added
	 */
	public javax.swing.event.CellEditorListener[] getCellEditorListeners() {
	}

	/**
	 *  Adds a <code>Validator</code> to the listener list.
	 * 
	 *  @param l the new listener to be added
	 */
	public void addValidator(Validator l) {
	}

	/**
	 *  Removes a <code>Validator</code> from the listener list.
	 * 
	 *  @param l the listener to be removed
	 */
	public void removeValidator(Validator l) {
	}

	/**
	 *  Returns an array of all the <code>Validator</code>s added to this AbstractCellEditor with
	 *  addValidationListener().
	 * 
	 *  @return all of the <code>Validator</code>s added or an empty array if no listeners have been added
	 */
	public Validator[] getValidator() {
	}

	public ValidationResult validate(int rowIndex, int columnIndex, Object oldValue, Object newValue) {
	}

	/**
	 *  Adds a <code>RowValidator</code> to the listener list.
	 * 
	 *  @param l the new listener to be added
	 */
	public void addRowValidator(RowValidator l) {
	}

	/**
	 *  Removes a <code>RowValidator</code> from the listener list.
	 * 
	 *  @param l the listener to be removed
	 */
	public void removeRowValidator(RowValidator l) {
	}

	/**
	 *  Returns an array of all the <code>RowValidator</code>s added to this AbstractCellEditor with
	 *  addValidationListener().
	 * 
	 *  @return all of the <code>RowValidator</code>s added or an empty array if no listeners have been added
	 */
	public RowValidator[] getRowValidator() {
	}

	/**
	 *  Validates a row. It will use RowValidators added using {@link #addRowValidator(com.jidesoft.validation.RowValidator)}
	 *  to do the validation.
	 * 
	 *  @param rowIndex the row index.
	 *  @return ValidationResult
	 */
	public ValidationResult validateRow(int rowIndex) {
	}

	@java.lang.Override
	public void editingStopped(javax.swing.event.ChangeEvent e) {
	}

	@java.lang.Override
	public void editingCanceled(javax.swing.event.ChangeEvent e) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  created lazily.
	 * 
	 *  @param source the source of the event
	 *  @param row    the row index
	 *  @param column the column index
	 *  @return true or false. If all listeners return true in <code>editingStarting()</code>, it will return true. If
	 *  one of the listener returns false, it will return false.
	 */
	protected boolean fireEditingStopping(Object source, int row, int column) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  created lazily.
	 * 
	 *  @param source the source of the event
	 *  @param row    the row index
	 *  @param column the column index
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireEditingStopped(Object source, int row, int column) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  created lazily.
	 * 
	 *  @param source the source of the event
	 *  @param row    the row index
	 *  @param column the column index
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireEditingCanceled(Object source, int row, int column) {
	}

	public synchronized RowHeights getRowHeights() {
	}

	protected RowHeights createRowHeights() {
	}

	public synchronized void setRowHeights(RowHeights rowHeights) {
	}

	/**
	 *  Checks the flag whether a row is scrolled to visible when its height changes.
	 * 
	 *  @return the scrollRowWhenRowHeightChanges flag.
	 */
	public boolean isScrollRowWhenRowHeightChanges() {
	}

	/**
	 *  Sets the flag if the row should be scrolled to visible when the row height changes.
	 * 
	 *  @param scrollRowWhenRowHeightChanges true or false.
	 */
	public void setScrollRowWhenRowHeightChanges(boolean scrollRowWhenRowHeightChanges) {
	}

	/**
	 *  Creates the <code>RowHeightChangeListener</code> which will automatically scroll the row then row height changes
	 *  so that it is outside the visible area.
	 * 
	 *  @return a <code>RowHeightChangeListener</code>.
	 */
	protected RowHeightChangeListener createRowAutoScrollingListener() {
	}

	/**
	 *  Scroll the row till the row is visible. If possible, it will try to make the row after it and the row before it
	 *  visible too. By default, we will call {@link com.jidesoft.grid.TableUtils#ensureRowVisible(javax.swing.JTable,
	 *  int)} method. It will only scroll vertically to the exact location so that the row is fully visible.
	 *  <p/>
	 *  This method is called automatically when row height changes. If {@link #isScrollRowWhenRowHeightChanges()} is
	 *  true, the row will automatically be scrolled to show the whole row when the height for that row changes. You can
	 *  subclass it to scroll the table in a different way.
	 * 
	 *  @param row the row whose height changes.
	 */
	public void scrollRowToVisible(int row) {
	}

	/**
	 *  Sets the height, in pixels, of all cells to <code>rowHeight</code>, re-validates, and repaints. The height of the
	 *  cells will be equal to the row height minus the row margin.
	 * 
	 *  @param rowHeight new row height
	 *  @throws IllegalArgumentException if <code>rowHeight</code> is less than 1 description: The height of the
	 *                                   specified row.
	 *  @see #getRowHeight
	 */
	@java.lang.Override
	public void setRowHeight(int rowHeight) {
	}

	/**
	 *  Checks if it is in batch processing. If yes, we should delay doLayout call to the end.
	 * 
	 *  @return true or false.
	 */
	protected boolean isBatchProcessing() {
	}

	/**
	 *  Sets to batch processing. This method should be used only when you want to expand or collapse several rows and
	 *  you only want to doLayout once at the end.
	 * 
	 *  @param batchProcessing true or false.
	 */
	protected void setBatchProcessing(boolean batchProcessing) {
	}

	/**
	 *  Sets the height for <code>row</code> to <code>rowHeight</code>, re-validates, and repaints. The height of the
	 *  cells in this row will be equal to the row height minus the row margin.
	 * 
	 *  @param row       the row whose height is being changed
	 *  @param rowHeight new row height, in pixels
	 *  @throws IllegalArgumentException if <code>rowHeight</code> is less than 1 description: The height in pixels of
	 *                                   the cells in <code>row</code>
	 */
	@java.lang.Override
	public void setRowHeight(int row, int rowHeight) {
	}

	/**
	 *  @param firstRow the first row to be calculated
	 *  @param lastRow  the last row to be calculated
	 *  @deprecated replaced by #calculateRowHeight. This method will not be invoked while setRowAutoResizes(true).
	 *  Please override #calculateRowHeight instead to calculate row height.
	 */
	@java.lang.Deprecated
	protected void calculateAutoResizedRowHeights(int firstRow, int lastRow) {
	}

	/**
	 *  @deprecated replaced by #calculateRowHeight. This method will not be invoked while setRowAutoResizes(true).
	 *  Please override #calculateRowHeight instead to calculate row height.
	 */
	@java.lang.Deprecated
	protected void calculateAutoResizedRowHeights() {
	}

	/**
	 *  The method calculates the height for the row based on the content in the row.
	 *  <p/>
	 *  The method will not change the row height of the designated row.
	 * 
	 *  @param row the row to be calculated
	 *  @return new height appropriate for the row.
	 */
	protected int calculateRowHeight(int row) {
	}

	/**
	 *  The method will check if the new height is different with current height. The method is called by {@link
	 *  com.jidesoft.grid.TableUtils#autoResizeRow(javax.swing.JTable, int, int)}.
	 * 
	 *  @param row       the row to be checked
	 *  @param newHeight new height of the row, most likely from {@link #calculateRowHeight(int)}
	 *  @return True if current row height is not the same with the new height. Otherwise false.
	 */
	protected boolean isRowHeightChanged(int row, int newHeight) {
	}

	@java.lang.Override
	public int getRowHeight(int row) {
	}

	/**
	 *  Returns the index of the row that <code>point</code> lies in, or -1 if the result is not in the range [0,
	 *  <code>getRowCount()</code>-1].
	 * 
	 *  @param point the location of interest
	 *  @return the index of the row that <code>point</code> lies in, or -1 if the result is not in the range [0,
	 *  <code>getRowCount()</code>-1]
	 *  @see #columnAtPoint
	 */
	@java.lang.Override
	public int rowAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public java.awt.Rectangle getCellRect(int row, int column, boolean includeSpacing) {
	}

	/**
	 *  In TreeTable and HierarchicalTable case, the cell rect for cell editor should consider the +/- icon size so the
	 *  cell editor doesn't cover the +/- icon. In order to do it, we introduce EditorCellRect concept. By default, it is
	 *  same as getCellRect(rowIndex, columnIndex, false). TreeTable and HierarchicalTable will override it to provide a
	 *  different rect for cell editor.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index
	 *  @return the cell rect for the cell editor.
	 */
	public java.awt.Rectangle getEditorCellRect(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void createDefaultColumnsFromModel() {
	}

	/**
	 *  Set if you want to keep row heights after table events, such as sorting and filtering.
	 *  <p/>
	 *  See {@link #isKeepRowHeights()}
	 * 
	 *  @param keepRowHeights the flag that if the table will keep the row heights
	 */
	public void setKeepRowHeights(boolean keepRowHeights) {
	}

	/**
	 *  Get if you want to keep row heights after table events, such as sorting and filtering.
	 *  <p/>
	 *  If you set this flag to true, you could keep row heights after sorting and filtering. However, it will hit the
	 *  performance a little bit. So if you have a large table and don't care about the row heights, you could set this
	 *  flag to false.
	 *  <p/>
	 *  The default value is true.
	 * 
	 *  @return the flag that if the table will keep the row heights.
	 */
	public boolean isKeepRowHeights() {
	}

	/**
	 *  Gets the flag indicating if JideTable should load selection if it receives a table model event which indicates a
	 *  table data changed event is fired from its original table model.
	 * 
	 *  @return true if selection should be loaded. Otherwise false.
	 *  @see #setLoadSelectionOnTableDataChanged(boolean)
	 */
	public boolean isLoadSelectionOnTableDataChanged() {
	}

	/**
	 *  Sets the flag indicating if JideTable should load selection if it receives a table model event which indicates a
	 *  table data changed event is fired from its original table model.
	 *  <p/>
	 *  By default, the flag is false to improve performance. It should work for most scenario since firing table data
	 *  changed event means the table contents are refreshed and no selection needs to be kept. However, if you don't
	 *  mind about the performance and want to simplify the event you fire from original table model, please set this
	 *  flag to true.
	 * 
	 *  @param loadSelectionOnTableDataChanged the flag
	 */
	public void setLoadSelectionOnTableDataChanged(boolean loadSelectionOnTableDataChanged) {
	}

	/**
	 *  Gets the flag indicating if the area right to the JideTable in the viewport will be filled.
	 * 
	 *  @return true if the area to be filled. Otherwise false.
	 *  @see #setFillsRight(boolean)
	 *  @since 3.3.0
	 */
	public boolean isFillsRight() {
	}

	/**
	 *  Sets the flag indicating if the area right to the JideTable in the viewport will be filled.
	 *  <p/>
	 *  By default the value is true. This flag takes effect only if {@link #getAutoResizeMode()} includes {@link
	 *  #AUTO_RESIZE_FILL}
	 * 
	 *  @param fillsRight the flag
	 *  @since 3.3.0
	 */
	public void setFillsRight(boolean fillsRight) {
	}

	/**
	 *  Gets the flag indicating if the area below the JideTable in the viewport will be filled.
	 * 
	 *  @return true if the area to be filled. Otherwise false.
	 *  @see #setFillsBottom(boolean)
	 *  @since 3.3.0
	 */
	public boolean isFillsBottom() {
	}

	/**
	 *  Sets the flag indicating if the area below the JideTable in the viewport will be filled.
	 *  <p/>
	 *  By default the value is true. This flag takes effect only if {@link #getAutoResizeMode()} includes {@link
	 *  #AUTO_RESIZE_FILL}
	 * 
	 *  @param fillsBottom the flag
	 *  @since 3.3.0
	 */
	public void setFillsBottom(boolean fillsBottom) {
	}

	/**
	 *  Gets the flag indicating if the area below the JideTable in the viewport will be filled with grids.
	 * 
	 *  @return true if the are to be filled. Otherwise false.
	 *  @see #setFillsGrids(boolean)
	 *  @since 3.3.0
	 */
	public boolean isFillsGrids() {
	}

	/**
	 *  Gets the flag indicating if the area bottom to the JideTable in the viewport will be filled with grids.
	 *  <p/>
	 *  By default, it returns {@link #isFillsBottom()} && {@link #isFillsGrids()}.
	 * 
	 *  @return true if the are to be filled. Otherwise false.
	 *  @see #setFillsGrids(boolean)
	 *  @since 3.3.0
	 */
	protected boolean isFillsGridsBottom() {
	}

	/**
	 *  Gets the flag indicating if the area right to the JideTable in the viewport will be filled with grids.
	 *  <p/>
	 *  By default, it returns {@link #isFillsRight()}.
	 * 
	 *  @return true if the are to be filled. Otherwise false.
	 *  @see #setFillsGrids(boolean)
	 *  @since 3.3.0
	 */
	protected boolean isFillsGridsRight() {
	}

	/**
	 *  Sets the flag indicating if the area below the JideTable in the viewport will be filled with grids.
	 *  <p/>
	 *  By default the value is true. This flag takes effect only if {@link #getAutoResizeMode()} includes {@link
	 *  #AUTO_RESIZE_FILL} and {@link #setFillsBottom(boolean)} returns true
	 * 
	 *  @param fillsGrids the flag
	 *  @since 3.3.0
	 */
	public void setFillsGrids(boolean fillsGrids) {
	}

	/**
	 *  Gets the flag indicating if the area right to the JideTable in the viewport will be filled.
	 * 
	 *  @return true if the are to be filled. Otherwise false.
	 *  @see #setFillsRight(boolean)
	 *  @deprecated replaced by {@link #isFillsRight()}
	 */
	@java.lang.Deprecated
	public boolean isFillRight() {
	}

	/**
	 *  Sets the flag indicating if the area right to the JideTable in the viewport will be filled.
	 *  <p/>
	 *  By default the value is true. This flag takes effect only if {@link #getAutoResizeMode()} includes {@link
	 *  #AUTO_RESIZE_FILL}
	 * 
	 *  @param fillRight the flag
	 *  @deprecated replaced by {@link #setFillsRight(boolean)}
	 */
	@java.lang.Deprecated
	public void setFillRight(boolean fillRight) {
	}

	/**
	 *  Gets the flag indicating if the area below the JideTable in the viewport will be filled.
	 * 
	 *  @return true if the are to be filled. Otherwise false.
	 *  @see #setFillsBottom(boolean)
	 *  @deprecated replaced by {@link #isFillsBottom()}
	 */
	@java.lang.Deprecated
	public boolean isFillBottom() {
	}

	/**
	 *  Sets the flag indicating if the area below the JideTable in the viewport will be filled.
	 *  <p/>
	 *  By default the value is true. This flag takes effect only if {@link #getAutoResizeMode()} includes {@link
	 *  #AUTO_RESIZE_FILL}
	 * 
	 *  @param fillBottom the flag
	 *  @deprecated replaced by {@link #setFillsBottom(boolean)}
	 */
	@java.lang.Deprecated
	public void setFillBottom(boolean fillBottom) {
	}

	/**
	 *  Gets the flag indicating if the area below the JideTable in the viewport will be filled with grids.
	 * 
	 *  @return true if the are to be filled. Otherwise false.
	 *  @see #setFillsGrids(boolean)
	 *  @deprecated replaced by {@link #isFillsGrids()}
	 */
	@java.lang.Deprecated
	public boolean isFillGrids() {
	}

	/**
	 *  Sets the flag indicating if the area below the JideTable in the viewport will be filled with grids.
	 *  <p/>
	 *  By default the value is true. This flag takes effect only if {@link #getAutoResizeMode()} includes {@link
	 *  #AUTO_RESIZE_FILL} and {@link #setFillsBottom(boolean)} returns true
	 * 
	 *  @param fillGrids the flag
	 *  @deprecated replaced by {@link #setFillsGrids(boolean)}
	 */
	@java.lang.Deprecated
	public void setFillGrids(boolean fillGrids) {
	}

	/**
	 *  Gets the flag that indicates if the cell editing should be kept when table model is changed.
	 * 
	 *  @return true if editing should be kept. Otherwise false.
	 *  @see #setAdjustEditorLocationOnModelChanged
	 *  @since 3.4.8
	 */
	public boolean isAdjustEditorLocationOnModelChanged() {
	}

	/**
	 *  Sets the flag that indicates if the cell editing should be kept when table model is changed.
	 *  <p/>
	 *  By default, the value is false to keep backward compatibility.
	 * 
	 *  @param keepEditing the flag
	 *  @since 3.4.8
	 */
	public void setAdjustEditorLocationOnModelChanged(boolean keepEditing) {
	}

	/**
	 *  To save row heights and selections before you do some big work, like firing table data change event.
	 *  <p/>
	 *  Please always make a pair call with {@link #loadTableRowSettings(boolean)}.
	 * 
	 *  @param invokeOutside always TRUE if you want to call this method explicitly. We will call this method with FALSE
	 *                       internally.
	 */
	protected void saveTableRowSettings(boolean invokeOutside) {
	}

	/**
	 *  To load row heights and selections after you do some big work, like firing table data change event.
	 *  <p/>
	 *  Please always make a pair call with {@link #saveTableRowSettings(boolean)}.
	 * 
	 *  @param invokeOutside always TRUE if you want to call this method explicitly. We will call this method with FALSE
	 *                       internally.
	 */
	protected void loadTableRowSettings(boolean invokeOutside) {
	}

	/**
	 *  Called whenever the table model wrapper is going to have some change. So far we have index changing and index
	 *  changed events.
	 * 
	 *  @param event the table model wrapper event
	 */
	public void indexChanged(IndexChangeEvent event) {
	}

	/**
	 *  Invoked when this table's <code>TableModel</code> generates a <code>TableModelEvent</code>. The
	 *  <code>TableModelEvent</code> should be constructed in the coordinate system of the model; the appropriate mapping
	 *  to the view coordinate system is performed by this <code>JTable</code> when it receives the event.
	 *  <p/>
	 *  Application code will not use these methods explicitly, they are used internally by <code>JTable</code>.
	 */
	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	protected void tableStructureChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	protected javax.swing.ListSelectionModel createDefaultSelectionModel() {
	}

	/**
	 *  Checks if row automatically resizes with the cells preferred heights.
	 * 
	 *  @return true if it automatically resizes. Otherwise, false.
	 */
	public boolean isRowAutoResizes() {
	}

	/**
	 *  Sets the rowAutoResizes attribute.
	 * 
	 *  @param rowAutoResizes true to enable rowAutoResizes. Otherwise false.
	 */
	public void setRowAutoResizes(boolean rowAutoResizes) {
	}

	/**
	 *  JideTable allows you to have multiple lines in table header. However this feature is turned off by default. If
	 *  you want to have this feature, you can do this.
	 *  <pre><code>
	 *  JideTable table = new JideTable(model){
	 *      protected void initTable() {
	 *          super.initTable();
	 *          setSortTableHeaderRenderer();
	 *      }
	 *  <p/>
	 *      protected JTableHeader createDefaultTableHeader() {
	 *          return new JTableHeader(columnModel);
	 *      }
	 *  };
	 *  </code></pre>
	 *  Now if you have a column name that has "\n" in it, it will split the text into multiple lines.
	 * 
	 *  @deprecated replaced by StyledLabel based header renderer.
	 */
	@java.lang.Deprecated
	protected void setSortTableHeaderRenderer() {
	}

	/**
	 *  Creates the header renderer. By default SortTableHeaderRenderer will be used. Subclass can override this method
	 *  to create their own header renderer.
	 * 
	 *  @return the header renderer.
	 *  @deprecated replaced by StyledLabel based header renderer.
	 */
	@java.lang.Deprecated
	protected SortTableHeaderRenderer createSortHeaderRenderer() {
	}

	/**
	 *  Checks if the table selection model allows non-contiguous cell selection.
	 * 
	 *  @return true if the table selection model allows non-contiguous cell selection. If so, you can call {@link
	 *  #getTableSelectionModel()} to get the selection model and add listener to it. If false, getTableSelectionModel()
	 *  will return null.
	 */
	public boolean isNonContiguousCellSelection() {
	}

	/**
	 *  Sets the attribute of nonContiguousCellSelection. By default it's false.
	 * 
	 *  @param nonContiguousCellSelection true to enable non-contiguous cell selection.
	 */
	public void setNonContiguousCellSelection(boolean nonContiguousCellSelection) {
	}

	@java.lang.Override
	public void setRowSelectionAllowed(boolean rowSelectionAllowed) {
	}

	@java.lang.Override
	public void setColumnSelectionAllowed(boolean columnSelectionAllowed) {
	}

	/**
	 *  Creates a default TableSelectionModel.
	 */
	public void createDefaultTableSelectionModel() {
	}

	/**
	 *  Sets a new TableSelectionModel.
	 * 
	 *  @param tableSelectionModel the new TableSelectionModel.
	 */
	public void setTableSelectionModel(TableSelectionModel tableSelectionModel) {
	}

	/**
	 *  Gets the table selection model. It will return a valid value only when {@link #isNonContiguousCellSelection()}
	 *  return true.
	 * 
	 *  @return the TableSelectionModel.
	 */
	public TableSelectionModel getTableSelectionModel() {
	}

	@java.lang.Override
	public int[] getSelectedRows() {
	}

	@java.lang.Override
	public int[] getSelectedColumns() {
	}

	@java.lang.Override
	public int getSelectedRow() {
	}

	@java.lang.Override
	public int getSelectedColumn() {
	}

	@java.lang.Override
	public int getSelectedRowCount() {
	}

	@java.lang.Override
	public int getSelectedColumnCount() {
	}

	@java.lang.Override
	public boolean isRowSelected(int row) {
	}

	@java.lang.Override
	public boolean isColumnSelected(int column) {
	}

	/**
	 *  Subclass can override this method to determine if the cell should be painted as selected when selected. It is
	 *  just an effect on the view. The cell is still selected in the selection model.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index
	 *  @return true to paint the cell as selected when it is selected. False to not paint.
	 *  @since 3.3.7
	 */
	protected boolean shouldCellBePaintedAsSelected(int row, int column) {
	}

	/**
	 *  Subclass can override this method to determine if the cell should be painted as focused cell when it is a focused
	 *  cell. It is just an effect on the view. The cell is the anchor cell in the selection model.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index
	 *  @return true to paint the cell as focused when it is the focused cell. False to not paint.
	 *  @since 3.3.7
	 */
	protected boolean shouldCellBePaintedAsFocused(int row, int column) {
	}

	@java.lang.Override
	public boolean isCellSelected(int row, int column) {
	}

	/**
	 *  Get the flag indicating if JideTable should calculate row heights if column width is changed.
	 *  <p/>
	 *  This flag will only take effect when {@link #isRowAutoResizes()} returns true.
	 *  <p/>
	 *  The default value of this flag is true.
	 * 
	 *  @return true if JideTable will calculate row heights if column width is changed. Otherwise false.
	 */
	public boolean isCalculateRowHeightsOnWidthChange() {
	}

	/**
	 *  Set the flag indicating if JideTable should calculate row heights if column width is changed.
	 * 
	 *  @param calculateRowHeightsOnWidthChange the flag
	 */
	public void setCalculateRowHeightsOnWidthChange(boolean calculateRowHeightsOnWidthChange) {
	}

	/**
	 *  Get the flag indicating if JideTable should always request focus for cell editor.
	 *  <p/>
	 *  The default value for this flag is false, which improves the performance.
	 *  <p/>
	 *  If you want the cell editor get focus immediately so that Add-ons like IntelliHint can take effect right after
	 *  you press a key to start editing.
	 * 
	 *  @return the flag.
	 */
	public boolean isAlwaysRequestFocusForEditor() {
	}

	/**
	 *  Set the flag indicating if JideTable should always request focus for cell editor.
	 * 
	 *  @param alwaysRequestFocusForEditor the flag
	 */
	public void setAlwaysRequestFocusForEditor(boolean alwaysRequestFocusForEditor) {
	}

	/**
	 *  Get the flag indicating if JideTable should clear properties for table column orders.
	 *  <p/>
	 *  By default, the value is true. However, for some special table like AggregateTable, we do need keep the status
	 *  even if table structure change event is fired. In that case, we will set it to false.
	 * 
	 *  @return the flag
	 */
	public boolean isClearPropertyAtStructureChange() {
	}

	/**
	 *  Set the flag indicating if JideTable should clear properties for table column orders.
	 * 
	 *  @param clearPropertyAtStructureChange the flag
	 */
	public void setClearPropertyAtStructureChange(boolean clearPropertyAtStructureChange) {
	}

	/**
	 *  Paints the cell underlay. The cell underlay paints under the cell content. In the other word, this method is
	 *  called first, then the cell renderer paints the cell content. At last, paintCellOverlay is called. Please note,
	 *  if the cell renderer component has a background and is opaque, the cell content will full cover the cell
	 *  underlay. So if you want to use the cell underlay, please make sure the renderer component is not opaque.
	 * 
	 *  @param g         the Graphics
	 *  @param component the component
	 *  @param row       the row index
	 *  @param column    the column index
	 *  @param cellRect  the cell rectangle of the cell at the specified row index and column index.
	 */
	public void paintCellUnderlay(java.awt.Graphics g, java.awt.Component component, int row, int column, java.awt.Rectangle cellRect) {
	}

	/**
	 *  Paints the cell overlay. The cell overlay paints after the cell content is painted. In the other word, the
	 *  paintCellUnderlay method is called first, then the cell renderer paints the cell content. At last, this method is
	 *  called.
	 * 
	 *  @param g         the Graphics
	 *  @param component the component
	 *  @param row       the row index
	 *  @param column    the column index
	 *  @param cellRect  the cell rectangle of the cell at the specified row index and column index.
	 */
	public void paintCellOverlay(java.awt.Graphics g, java.awt.Component component, int row, int column, java.awt.Rectangle cellRect) {
	}

	/**
	 *  Get the flag indicating if the cell will be painted with normal text color even the table is disabled. JTable
	 *  doesn't respect enabled flag. There is a bug reported on it at http://bugs.sun.com/view_bug.do?bug_id=4113508 but
	 *  Sun probably will not fix it. We fixed in JideTable. However if you prefer to keep the old JTable behavior, you
	 *  can call {@link #setEnableIgnored(boolean)} and set it to true.
	 *  <p/>
	 *  The default value is false.
	 * 
	 *  @return the flag.
	 */
	public boolean isEnableIgnored() {
	}

	/**
	 *  Set the flag indicating if the cell will be painted with the normal text color even the table is disabled.
	 * 
	 *  @param enableIgnored the flag
	 */
	public void setEnableIgnored(boolean enableIgnored) {
	}

	/**
	 *  Checks if there is a rollover cell editor created by {@link #rolloverCellAt(int, int)}.
	 * 
	 *  @return true if having rollover editor.
	 */
	public boolean isRollover() {
	}

	/**
	 *  Gets the cell editor created by {@link #rolloverCellAt(int, int)}.
	 * 
	 *  @return the cell editor.
	 */
	public javax.swing.table.TableCellEditor getRolloverCellEditor() {
	}

	/**
	 *  Gets the row index that has the rollover cell editor.
	 * 
	 *  @return the row index.
	 */
	public int getRolloverRow() {
	}

	/**
	 *  Gets the column index that has the rollover cell editor.
	 * 
	 *  @return the column index.
	 */
	public int getRolloverColumn() {
	}

	/**
	 *  Makes the cell enters editing mode without forcing the other cell editor, if any, to stop editing.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return true if the action is successful.
	 */
	public boolean rolloverCellAt(int row, int column) {
	}

	/**
	 *  Removes the rollover cell editor created by {@link #rolloverCellAt(int, int)}.
	 */
	public void removeRolloverEditor() {
	}

	@java.lang.Override
	public boolean editCellAt(int row, int column, java.util.EventObject e) {
	}

	/**
	 *  Checks if the key event is a valid keystroke to start cell editing. Subclass can override it. Here is the default
	 *  implementation. <code>
	 *  <pre>
	 *  if (keyEvent.getKeyCode() == KeyEvent.VK_ESCAPE || keyEvent.getKeyCode() == KeyEvent.VK_DELETE ||
	 *  keyEvent.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
	 *      return false;
	 *  }
	 *  else if(keyEvent.getKeyCode() == KeyEvent.VK_F2) {
	 *      return true;
	 *  }
	 *  else if(keyEvent.getKeyCode() >= KeyEvent.VK_F1 && keyEvent.getKeyCode() <= KeyEvent.VK_F24) {
	 *      return false;
	 *  }
	 * 
	 *  return true;
	 *  </pre>
	 *  </code>
	 * 
	 *  @param keyEvent the key event
	 *  @return true if it is a valid key. Otherwise false.
	 */
	protected boolean isValidCellEditingKey(java.awt.event.KeyEvent keyEvent) {
	}

	/**
	 *  Clear the selections permanently without being restored later on.
	 */
	public void clearSelectionPermanently() {
	}

	@java.lang.Override
	public void clearSelection() {
	}

	@java.lang.Override
	public void setRowSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void setColumnSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void addRowSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void addColumnSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void removeRowSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void removeColumnSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void changeSelection(int rowIndex, int columnIndex, boolean toggle, boolean extend) {
	}

	@java.lang.Override
	public void columnSelectionChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Gets the dirty region from the first row, first column and last row, last column.
	 * 
	 *  @param firstRow    the first row
	 *  @param firstColumn the first column
	 *  @param lastRow     the last row
	 *  @param lastColumn  the last column
	 *  @return the dirty region that covers the first cell and the last cell.
	 *  @since 3.3.7
	 */
	protected java.awt.Rectangle getDirtyRegion(int firstRow, int firstColumn, int lastRow, int lastColumn) {
	}

	/**
	 *  Overrides this method to skip the column that is being added when the column was hidden earlier by {@link
	 *  TableColumnChooser#hideColumn(javax.swing.JTable, int)} method.
	 * 
	 *  @param column the TableColumn to be added.
	 */
	@java.lang.Override
	public void addColumn(javax.swing.table.TableColumn column) {
	}

	@java.lang.Override
	public void removeColumn(javax.swing.table.TableColumn aColumn) {
	}

	/**
	 *  Usually you don't need to call this method. But if you use non-contiguous cell selection feature and use your own
	 *  TableColumnModel that is created by JTable, you should call this method in TableColumnModel's moveColumn
	 *  implementation so that the selection can be adjusted when column is moved.
	 * 
	 *  @param column       the column index
	 *  @param targetColumn the target column index.
	 */
	public void adjustSelectionWhenColumnMoved(int column, int targetColumn) {
	}

	public void releaseRendererComponent(javax.swing.table.TableCellRenderer renderer, int row, int column, java.awt.Component component) {
	}

	@java.lang.Override
	public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellRenderer getDefaultRenderer(Class columnClass) {
	}

	@java.lang.Override
	public java.awt.Color getSelectionBackground() {
	}

	/**
	 *  Checks if the column is auto-resizable. If the column is auto-resizable, user can double click on the grid line
	 *  on table header and the table column will automatically resize to fit in the content of all the cells in that
	 *  column.
	 * 
	 *  @return true if the column is auto-resizable.
	 */
	public boolean isColumnAutoResizable() {
	}

	/**
	 *  Enable or disable the column auto-resizable. Please note, you need to call this method again if you change your
	 *  table header as this method call will install a listener on the table header if resizable is true.
	 * 
	 *  @param resizable true to make column auto-resizable.
	 */
	public void setColumnAutoResizable(boolean resizable) {
	}

	/**
	 *  Checks if the column is resizable by dragging the vertical grid line.
	 * 
	 *  @return true if the column is resizable by dragging the vertical grid line.
	 */
	public boolean isColumnResizable() {
	}

	/**
	 *  Enable or disable the column resizable. If column is resizable, user can drag the vertical grid line to resize
	 *  the column.
	 * 
	 *  @param resizable true to make column resizable.
	 */
	public void setColumnResizable(boolean resizable) {
	}

	/**
	 *  Checks if the row is resizable by dragging the horizontal grid line.
	 * 
	 *  @return true if the row is resizable by dragging the horizontal grid line.
	 */
	public boolean isRowResizable() {
	}

	/**
	 *  Enable or disable the row resizable. If row is resizable, user can drag the horizontal grid line to resize the
	 *  row.
	 * 
	 *  @param resizable true to make row resizable.
	 */
	public void setRowResizable(boolean resizable) {
	}

	@java.lang.Override
	public void selectAll() {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Checks if the table is printing.
	 * 
	 *  @return true if the table is printing.
	 */
	public boolean isTablePrinting() {
	}

	/**
	 *  Sets the table as printing. If the table is printing, prepareRenderer method will not consider the cell
	 *  selection.
	 * 
	 *  @param tablePrinting true to indicate the table is being printed.
	 */
	public void setTablePrinting(boolean tablePrinting) {
	}

	/**
	 *  Is the table has various row height on each row. There is no setter for this property. The only way to change it
	 *  is to override to return a different value. We did this way because we don't think a table should by nature
	 *  either has various row heights or the same row heights. So you should know beforehand if the table has the same
	 *  or different row heights thus overriding is a better way.
	 *  <p/>
	 *  For example, in the case of HierarchicalTable, we override it to always return true.
	 * 
	 *  @return true if {@link #isRowAutoResizes()} is true.
	 */
	public boolean isVariousRowHeights() {
	}

	/**
	 *  Sets variousRowHeights. Calling the method will change the heights of visible rows immediately if necessary. If
	 *  variousRowHeights is false, all rows will have the same row height. This is used when user tries to resize a row
	 *  when setRowResizable(true) is called. If variousRowHeights is false, we will make all rows the same height after
	 *  user resizes a row.
	 * 
	 *  @param variousRowHeights true or false
	 */
	public void setVariousRowHeights(boolean variousRowHeights) {
	}

	/**
	 *  Creates default TransferHandler.
	 * 
	 *  @return the default TransferHandler instance.
	 *  @since 3.3.4
	 */
	protected javax.swing.TransferHandler createDefaultTransferHandler() {
	}

	/**
	 *  Returns the selectInsertedRows flag. If true, the newly inserted rows, if it is just above the existing selected
	 *  row, will be selected automatically. By default, this is true.
	 * 
	 *  @return true or false.
	 */
	public boolean isSelectInsertedRows() {
	}

	/**
	 *  Sets the selectInsertedRow flag. If true, the newly inserted row, if it is just above the existing selected row,
	 *  will be selected automatically. By default, this is true.
	 * 
	 *  @param selectInsertedRows true or false.
	 */
	public void setSelectInsertedRows(boolean selectInsertedRows) {
	}

	/**
	 *  Checks if the selection should be cleared when tableDataChanged event is received. It will clear the selections
	 *  even if the event is caused by sorting/filtering/grouping, etc.
	 * 
	 *  @return true if the selection is cleared when the tableDataChanged event is received. Otherwise, false. Default
	 *  is false.
	 *  @deprecated replaced by {@link #isLoadSelectionOnTableDataChanged()}.
	 */
	@java.lang.Deprecated
	public boolean isClearSelectionOnTableDataChanges() {
	}

	/**
	 *  Sets the clearSelectionOnTableDataChanges attribute.
	 * 
	 *  @param clearSelectionOnTableDataChanges true to clear selection when table data changed event is received.
	 *  @deprecated replaced by {@link #setLoadSelectionOnTableDataChanged(boolean)}.
	 */
	@java.lang.Deprecated
	public void setClearSelectionOnTableDataChanges(boolean clearSelectionOnTableDataChanges) {
	}

	@java.lang.Override
	public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Specifies the number of clicks needed to start editing.
	 * 
	 *  @param count an int specifying the number of clicks needed to start editing
	 *  @see #getClickCountToStart
	 */
	public void setClickCountToStart(int count) {
	}

	/**
	 *  Returns the number of clicks needed to start editing.
	 * 
	 *  @return the number of clicks needed to start editing
	 */
	public int getClickCountToStart() {
	}

	/**
	 *  Gets the GridColorProvider to provide the grid line colors.
	 * 
	 *  @return the GridColorProvider.
	 */
	public GridColorProvider getGridColorProvider() {
	}

	/**
	 *  Sets a GridColorProvider to provide the grid line colors.
	 * 
	 *  @param gridColorProvider the GridColorProvider.
	 */
	public void setGridColorProvider(GridColorProvider gridColorProvider) {
	}

	/**
	 *  Gets the grid line color for each row.
	 * 
	 *  @param row the row index.
	 *  @return the color for that row. Null if using the default grid color.
	 */
	public java.awt.Color getGridColor(int row) {
	}

	/**
	 *  Gets the grid line color for each column.
	 * 
	 *  @param column the column index.
	 *  @return the color for that row. Null if using the default grid color.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public java.awt.Color getVerticalGridColor(int column) {
	}

	public TableColumnWidthKeeper getTableColumnWidthKeeper() {
	}

	public void setTableColumnWidthKeeper(TableColumnWidthKeeper tableColumnWidthKeeper) {
	}

	@java.lang.Override
	public void setPreferredSize(java.awt.Dimension preferredSize) {
	}

	/**
	 *  Checks if the navigation key stroke will start cell editing. By default the navigation key strokes are tab and
	 *  enter keys.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoStartCellEditing() {
	}

	/**
	 *  Sets the flag if the navigation key stroke will start cell editing.
	 * 
	 *  @param autoStartCellEditing true or false.
	 */
	public void setAutoStartCellEditing(boolean autoStartCellEditing) {
	}

	/**
	 *  Checks if the key stroke will trigger the cell editing. By default, we allow tab key and enter key to start cell
	 *  editing automatically if {@link #isAutoStartCellEditing()} is true.
	 * 
	 *  @param ks the key stroke
	 *  @return true or false.
	 */
	protected boolean isAutoStartCellEditingKey(javax.swing.KeyStroke ks) {
	}

	@java.lang.Override
	public void addNotify() {
	}

	@java.lang.Override
	public void removeNotify() {
	}

	/**
	 *  Override to regain focus on JTable when the AbstractComboBox's popup panel has focus. This special case is
	 *  skipped by removeEditor method in JTable.
	 */
	@java.lang.Override
	public void removeEditor() {
	}

	/**
	 *  Checks if the text in the cell editor will be selected when cell starts editing. For example, if the cell editor
	 *  is a JTextField, we will select the text when user presses any key to start cell editing. It will work if the
	 *  cell editor component is JTextComponent, JComboBox, AbstractComboBox or JSpinner. For all other custom cell
	 *  editors, you would need to override {@link #getTextComponentForEditorComponent(java.awt.Component)} to return the
	 *  JTextComponent that you would like the text to be selected.
	 *  <p/>
	 *  Default is true.
	 * 
	 *  @return true to select the cell content when starts cell editing. Otherwise false.
	 */
	public boolean isAutoSelectTextWhenStartsEditing() {
	}

	/**
	 *  Sets the flag if the text in the cell editor will be selected when starts editing. For example, if the cell
	 *  editor is a JTextField, we will select the text when user presses any key to start cell editing. It will work if
	 *  the cell editor component is JTextComponent, JComboBox, AbstractComboBox or JSpinner. For all other custom cell
	 *  editors, you would need to override {@link #getTextComponentForEditorComponent(java.awt.Component)} to return the
	 *  JTextComponent that you would like the text to be selected.
	 *  <p/>
	 *  Default is true.
	 * 
	 *  @param autoSelectTextWhenStartsEditing true or false.
	 */
	public void setAutoSelectTextWhenStartsEditing(boolean autoSelectTextWhenStartsEditing) {
	}

	/**
	 *  Overrides this methods so that it is available for pre-JDK6 environment. For JDK6, this method will call
	 *  super.convertRowIndexToView(modelRowIndex). For pre-JDK, it will simply return modelRowIndex. We do so because we
	 *  want to make sure we still get the correct row index in case user uses the JTable's built-in sorting feature in
	 *  JDK. In fact, since we have sorting feature already in JIDE Grids and is faster and a lot of more flexible than
	 *  JTable's built-in sorting, we suggest you to use our sorting instead.
	 *  <p/>
	 *  Please note, this method has nothing to do with our sorting and filtering if you want to convert the row index.
	 *  The correct way to convert row index is TableModelWrapperUtils's getRowAt method.
	 * 
	 *  @param modelRowIndex the model row index.
	 *  @return the view row index.
	 */
	public int convertRowIndexToView(int modelRowIndex) {
	}

	/**
	 *  Overrides this methods so that it is available for pre-JDK6 environment. For JDK6, this method will call
	 *  super.convertRowIndexToModel(modelRowIndex). For pre-JDK, it will simply return viewRowIndex. We do so because we
	 *  want to make sure we still get the correct row index in case user uses the JTable's built-in sorting feature in
	 *  JDK. In fact, since we have sorting feature already in JIDE Grids and is faster and a lot of more flexible than
	 *  JTable's built-in sorting, we suggest you to use our sorting instead.
	 *  <p/>
	 *  Please note, this method has nothing to do with our sorting and filtering if you want to convert the row index.
	 *  The correct way to convert row index is TableModelWrapperUtils's getActualRowAt method.
	 * 
	 *  @param viewRowIndex the view row index.
	 *  @return the model row index.
	 */
	public int convertRowIndexToModel(int viewRowIndex) {
	}

	/**
	 *  A boolean flag to determine if the rect should always be calculated when painting the grid line and cells. If
	 *  false, it will calculate the rect for the first column once and then add the column width to determine the next
	 *  column cell rect. It returns false in JideTable but subclass can return true (such as in TreeTable and
	 *  HierarchicalTable case).
	 * 
	 *  @return false by default.
	 */
	public boolean alwaysCalculateCellRect() {
	}

	/**
	 *  Checks if the table cell content will be painted.
	 * 
	 *  @return true if the table cell content will be painted. Otherwise false.
	 */
	public boolean isCellContentVisible() {
	}

	/**
	 *  Sets the cell content visible or invisible. The reason we need this method is because we want to prevent the cell
	 *  from being displayed in certain cases. For example, when the table is being scrolled, we don't want the cells
	 *  being displayed when they are quickly scrolled over. Only when the scroll is done, we show the cells.
	 * 
	 *  @param cellContentVisible true or false.
	 */
	public void setCellContentVisible(boolean cellContentVisible) {
	}

	public void configureEnclosingScrollPaneExplicitly() {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Gets the editor auto-completion mode for the cell.
	 *  <p/>
	 *  By default, it simply returns {@link #getEditorAutoCompletionMode()}. However, if you don't want to have auto
	 *  completion for some columns/rows/cells, you could override this method to customize the behavior.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return the editor auto-completion mode.
	 *  @since 3.1.1
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected int getEditorAutoCompletionMode(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the editor auto-completion mode.
	 * 
	 *  @return the editor auto-completion mode.
	 */
	public int getEditorAutoCompletionMode() {
	}

	/**
	 *  Sets the editor auto-completion mode. JideTable has a feature to enable the cell editor auto-completion. When it
	 *  is turned on, typing a cell editor that has a text field will automatically complete the rest of the values based
	 *  on the existing values from the same column (or the same row, or the whole table).
	 * 
	 *  @param editorAutoCompletionMode the editor auto-completion mode.
	 */
	public void setEditorAutoCompletionMode(int editorAutoCompletionMode) {
	}

	/**
	 *  Check if the cell is a focused cell inside the table.
	 * 
	 *  @param rowIndex    the row index of the cell
	 *  @param columnIndex the column index of the cell
	 *  @return true if the cell is focused. Otherwise false.
	 */
	protected boolean isCellFocused(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Object getValueAt(int row, int column) {
	}

	/**
	 *  Gets the undo manager.
	 * 
	 *  @return the undo manager
	 *  @since 3.3.4
	 */
	public javax.swing.undo.UndoManager getUndoManager() {
	}

	/**
	 *  Adds the undoable edit listener.
	 * 
	 *  @param listener the listener
	 *  @since 3.3.4
	 */
	public void addUndoableEditListener(javax.swing.event.UndoableEditListener listener) {
	}

	/**
	 *  Removes the undoable edit listener.
	 * 
	 *  @param listener the listener
	 *  @since 3.3.4
	 */
	public void removeUndoableEditListener(javax.swing.event.UndoableEditListener listener) {
	}

	/**
	 *  Adds an undoable edit to JideTable for further undo/redo.
	 * 
	 *  @param edit the UndoableEdit
	 *  @since 3.3.4
	 */
	public void addUndo(javax.swing.undo.UndoableEdit edit) {
	}

	/**
	 *  Adds a hidden row.
	 *  <p/>
	 *  The hidden row feature is added to hide a row or several rows assuming all visible rows have the same row
	 *  height.
	 *  <p/>
	 *  The hidden row feature will only take effect if both {@link #isVariousRowHeights()} and {@link
	 *  #isRowAutoResizes()} returns false.
	 * 
	 *  @param row the visual row index
	 *  @return true if successfully added. Otherwise false.
	 *  @see #isVariousRowHeights()
	 *  @see #isRowAutoResizes()
	 *  @since 3.5.16
	 */
	public boolean addHiddenRow(int row) {
	}

	/**
	 *  Removes the hidden row.
	 * 
	 *  @param row the visual row index
	 *  @see #addHiddenRow(int)
	 *  @since 3.5.16
	 */
	public void removeHiddenRow(int row) {
	}

	/**
	 *  Sets the hidden rows.
	 * 
	 *  @param hiddenRows the hidden row indices in numerical order from small to large.
	 *  @see #addHiddenRow(int)
	 *  @since 3.5.16
	 */
	public void setHiddenRows(int[] hiddenRows) {
	}

	/**
	 *  Clears all hidden rows which means show all rows.
	 * 
	 *  @see #addHiddenRow(int)
	 *  @since 3.5.16
	 */
	public void clearHiddenRows() {
	}

	/**
	 *  Gets all hidden rows in array.
	 *  <p/>
	 *  It will return an empty array if either {@link #isRowAutoResizes()} or {@link #isVariousRowHeights()} returns
	 *  true.
	 * 
	 *  @return the array of all hidden rows.
	 *  @see #addHiddenRow(int)
	 *  @since 3.5.16
	 */
	public int[] getHiddenRows() {
	}

	/**
	 *  Gets if the visual row index is hidden.
	 *  <p/>
	 *  It will return false anyway if either {@link #isRowAutoResizes()} or {@link #isVariousRowHeights()} returns
	 *  true.
	 * 
	 *  @param row the visual row index
	 *  @return true if the row is hidden. Otherwise false.
	 *  @see #addHiddenRow(int)
	 *  @since 3.5.16
	 */
	public boolean isRowHidden(int row) {
	}

	public boolean isDisableUneditableCells() {
	}

	public void setDisableUneditableCells(boolean disableUneditableCells) {
	}

	/**
	 *  An interface that can be implemented on a CellEditor's editor component. We used it to get the JTextComponent
	 *  from the editor component and make it having focus and/or select all the text when the cell starts editing.
	 *  {@link JideTable#getTextComponentForEditorComponent(java.awt.Component)} is the only method that uses this
	 *  interface.
	 */
	public static interface class TextComponentProvider {


		/**
		 *  Gets the text component from the cell editor component.
		 * 
		 *  @return a JTextComponent if any. Or null if there is no JTextComponent inside the cell editor component.
		 */
		public javax.swing.text.JTextComponent getTextComponent() {
		}
	}

	/**
	 *  The transfer handler for JDK5 and lower version just for backward compatibility concern.
	 */
	protected static class NonContiguousTransferHandler {


		protected JideTable.NonContiguousTransferHandler() {
		}

		public java.awt.datatransfer.Transferable createTransferableFromOutside(javax.swing.JComponent c) {
		}

		/**
		 *  Create a Transferable to use as the source for a data transfer.
		 * 
		 *  @param c The component holding the data to be transferred.  This argument is provided to enable sharing of
		 *           TransferHandlers by multiple components.
		 *  @return The representation of the data to be transferred.
		 */
		@java.lang.Override
		protected java.awt.datatransfer.Transferable createTransferable(javax.swing.JComponent c) {
		}

		protected String convertElementToString(javax.swing.JTable table, int rowIndex, int columnIndex, Object value) {
		}

		@java.lang.Override
		public int getSourceActions(javax.swing.JComponent c) {
		}
	}
}
