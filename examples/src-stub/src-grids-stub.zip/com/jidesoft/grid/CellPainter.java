/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A CellPainter interface which is used to paint the cell overlay and the cell underlay.
 */
public interface CellPainter {

	/**
	 *  Paints the cell. We didn't translate the Graphics so you can paint outside the cell boundary if you didn't limit
	 *  the paint code to be within the provided cell rect. On the other hand, you could use this feature to paint
	 *  anything anywhere on the table although it is suppose to be only for the cell.
	 * 
	 *  @param g         the Graphics
	 *  @param component the component which is usually the table itself.
	 *  @param row       the row index of the cell
	 *  @param column    the column index of the cell
	 *  @param cellRect  the cell rect. It is the cell rect relatively to the table.
	 *  @param value     the value of the cell
	 */
	public void paint(java.awt.Graphics g, java.awt.Component component, int row, int column, java.awt.Rectangle cellRect, Object value);
}
