/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The table model used by DualTable.
 * 
 *  @since 3.5.2
 */
public class ListTableModelAdapter extends javax.swing.table.AbstractTableModel implements javax.swing.event.ListDataListener, ContextSensitiveTableModel {

	public ListTableModelAdapter(javax.swing.ListModel listModel, TableModelAdapter tableModelAdapter) {
	}

	public javax.swing.ListModel getListModel() {
	}

	public void setListModel(javax.swing.ListModel listModel) {
	}

	public TableModelAdapter getTableModelAdapter() {
	}

	public void setTableModelAdapter(TableModelAdapter tableModelAdapter) {
	}

	@java.lang.Override
	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int columnIndex) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}
}
