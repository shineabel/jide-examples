/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>StyleModel</code> provides a way to use <code>CellStyle</code> along with any <code>TableModel</code>. Below is
 *  a typical way of using it.
 *  <code><pre>
 *  class StyleTableModel extends AbstractTableModel implements StyleModel {
 *      // all other table model related methods
 *  <p/>
 *      static CellStyle _cellStyle;
 *  <p/>
 *      public CellStyle getCellStyleAt(int row, int column) {
 *          // The code below will make all cell center alignment and create stripes in the table.
 *  <p/>
 *          _cellStyle.setHorizontalAlignment(SwingConstants.CENTER);
 *  <p/>
 *          if (row % 2 == 0) {
 *              _cellStyle.setBackground(BACKGROUND1);
 *          }
 *          else {
 *              _cellStyle.setBackground(BACKGROUND2);
 *          }
 *          return _cellStyle;
 *      }
 *  <p/>
 *      public boolean isCellStyleOn() {
 *          return true;
 *      }
 *  }
 *  </pre></code>
 *  All you need to do is to return a desired <code>CellStyle</code> at {@link #getCellStyleAt(int, int)} method. If the
 *  styles are static (not change with value change) such as stripe pattern or grid pattern, all you need is to use the
 *  row and column index that are passed in. See the example above. It will create a stripe pattern. <br> If the styles
 *  are dynamically changing with the cell value, you call <code>getValueAt(row, column)</code> to get the value and
 *  return different style based on the cell value. For example, if the value is negative, returns red foreground cell
 *  style.
 *  <p/>
 *  You need to be aware of the performance. Since <code>getCellStyleAt()<code> will be called for every table repaint,
 *  you should make this method as efficient as possible. A typical way is to use the same <code>CellStyle</code>
 *  instance again and again by setting different value. Again, see the example code above. Or if the table only used
 *  several predefined styles, you can define them all as static final fields and return them accordingly.
 *  <p/>
 *  In the case you want to turn off the whole style thing or you know that <code>getCellStyleAt()</code> will return
 *  null in all cases, it will be better to return false in <code>isCellStyleOn()</code> method because if it's false,
 *  the code in <code>CellStyleTable</code> won't even bother calling <code>getCellStyleAt()</code>.
 */
public interface StyleModel {

	/**
	 *  Gets the cell style at the specified row and column.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return CellStyle object.
	 */
	public CellStyle getCellStyleAt(int rowIndex, int columnIndex);

	/**
	 *  Checks if the style is on. The CellStyleTable will ignore all the CellStyles defined in this model if this method
	 *  returns false.
	 * 
	 *  @return true if style is on. Otherwise false.
	 */
	public boolean isCellStyleOn();
}
