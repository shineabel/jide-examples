/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An editor for cell styles.
 */
public class CellStyleEditor extends javax.swing.JPanel {

	protected javax.swing.JRadioButton _fontStyleRadioButton;

	protected javax.swing.JRadioButton _fontRadioButton;

	public static String PROPERTY_STYLE;

	public CellStyleEditor() {
	}

	/**
	 *  Sets the flag indicating if the editor should automatically update the CellStyle on user actions.
	 *  <p/>
	 *  By default, the value is false to improve the performance.
	 * 
	 *  @param autoUpdate the flag
	 *  @since 3.4.5
	 */
	public void setAutoUpdate(boolean autoUpdate) {
	}

	/**
	 *  Gets the flag indicating if the editor should automatically update the CellStyle on user actions.
	 * 
	 *  @return true if the editor should automatically update the CellStyle on user actions. Otherwise false.
	 *  @since 3.4.5
	 */
	public boolean isAutoUpdate() {
	}

	protected void installComponents() {
	}

	public void loadData() {
	}

	public void saveData() {
	}

	public CellStyle getStyle() {
	}

	public void setStyle(CellStyle style) {
	}

	protected String getResourceString(String key) {
	}

	public static void main(String[] args) {
	}
}
