/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell renderer that based on ListExComboBox. It use EnumConverter. Please read the javadoc of {@link
 *  com.jidesoft.grid.EnumCellEditor} for more information and code example.
 * 
 *  @deprecated Please use ContextSensitiveCellRenderer instead because in the case of cell renderer, there is no need to
 *              use a renderer based on ExComboBox since it is not editable anyway.
 */
@java.lang.Deprecated
public class EnumCellRenderer extends com.jidesoft.combobox.ListExComboBox implements javax.swing.table.TableCellRenderer {

	public EnumCellRenderer(EnumConverter enumConverter) {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	public EditorContext getContext() {
	}
}
