/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Color. It uses ColorExComboBox to provide an editor for Color. You can override {@link
 *  #createColorComboBox()} method to provide your own ColorExComboBox.
 */
public class ColorCellEditor extends ExComboBoxCellEditor {

	/**
	 *  Creates a ColorCellEditor.
	 */
	public ColorCellEditor() {
	}

	/**
	 *  Creates the color combobox used by this cell editor.
	 * 
	 *  @return the color combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates the color combobox used by this cell editor.
	 * 
	 *  @return the color combobox.
	 */
	protected com.jidesoft.combobox.ColorExComboBox createColorComboBox() {
	}

	@java.lang.Override
	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}
}
