/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellStyleProvider is an interface to allow user to customize the CellStyle for any table model.
 */
public interface TableStyleProvider {

	/**
	 *  Gets the cell style at the specified cell.
	 * 
	 *  @param table       the table.
	 *  @param rowIndex    the row index as in the table
	 *  @param columnIndex the column index as in the table
	 *  @return the cell style at the specified cell.
	 */
	public CellStyle getCellStyleAt(javax.swing.JTable table, int rowIndex, int columnIndex);
}
