/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A CellEditor that uses a JSlider.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class SliderCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Constructor
	 */
	public SliderCellEditor() {
	}

	public SliderCellEditor(int min, int max) {
	}

	/**
	 *  Gets the value of the cell editor.
	 * 
	 *  @return the value in this cell editor.
	 */
	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	/**
	 *  Get the JSlider component.
	 * 
	 *  @return the JSlider component used in the cell editor.
	 */
	public javax.swing.JSlider getSlider() {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	@java.lang.Override
	public boolean stopCellEditing() {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}
}
