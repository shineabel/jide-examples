/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The interface to define if a column is draggable.
 *  <p/>
 *  Non-draggable means that this column itself cannot be dragged and other columns cannot be dragged past this column.
 *  <p/>
 *  This interface would take effect only if {@link javax.swing.table.JTableHeader#getReorderingAllowed()} returns true.
 * 
 *  @since 3.2.4
 */
public interface ColumnDraggableSupport {

	/**
	 *  Checks if the column is draggable.
	 * 
	 *  @param columnIndex the column index
	 *  @return true if the column is draggable. Otherwise false.
	 */
	public boolean isColumnDraggable(int columnIndex);
}
