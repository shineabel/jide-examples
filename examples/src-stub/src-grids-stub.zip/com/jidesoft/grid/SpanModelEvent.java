/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class SpanModelEvent extends java.util.EventObject {

	/**
	 *  Identifies the addition of a new span.
	 */
	public static final int ADD = 1;

	/**
	 *  Identifies the removal of a span.
	 */
	public static final int REMOVE = -1;

	/**
	 *  Identifies the update of a span.
	 */
	public static final int UPDATE = 0;

	protected int _type;

	protected CellSpan _cellSpan;

	/**
	 *  All spans in the table has changed, listeners should discard any state that was based on the cell span and
	 *  re-query the <code>SpanModel</code> to get the new cell span and repaint the whole table. The <code>JTable</code>
	 *  will repaint the entire visible region on receiving this event, querying the model for the cell spans that are
	 *  visible. The structure of the table, i.e., the column names, types and order have not changed.
	 * 
	 *  @param source the source
	 */
	public SpanModelEvent(SpanModel source) {
	}

	public SpanModelEvent(SpanModel source, CellSpan cellSpan, int type) {
	}

	/**
	 *  Gets the cell span.
	 * 
	 *  @return the cell span. It could be null, meaning all cell spans have been changed.
	 */
	public CellSpan getCellSpan() {
	}

	/**
	 *  Returns the type of event - one of: INSERT, UPDATE and DELETE.
	 * 
	 *  @return the type.
	 */
	public int getType() {
	}
}
