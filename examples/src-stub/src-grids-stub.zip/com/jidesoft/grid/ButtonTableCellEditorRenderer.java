/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A table cell editor/renderer that can display a hyperlink as cell. You can call {@link
 *  #setActionListener(java.awt.event.ActionListener)} to set the action listener which will be triggered when the
 *  hyperlink is clicked.
 */
public class ButtonTableCellEditorRenderer extends AbstractTableCellEditorRenderer implements CellRolloverSupport {

	public ButtonTableCellEditorRenderer() {
	}

	public ButtonTableCellEditorRenderer(ConverterContext context) {
	}

	public java.awt.event.ActionListener getActionListener() {
	}

	public void setActionListener(java.awt.event.ActionListener actionListener) {
	}

	@java.lang.Override
	public java.awt.Component createTableCellEditorRendererComponent(javax.swing.JTable table, int row, int column) {
	}

	@java.lang.Override
	public void configureTableCellEditorRendererComponent(javax.swing.JTable table, java.awt.Component editorRendererComponent, boolean forRenderer, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	@java.lang.Override
	public Object getCellEditorValue() {
	}

	@java.lang.Override
	public boolean isRollover(javax.swing.JTable table, java.awt.event.MouseEvent e, int row, int column) {
	}
}
