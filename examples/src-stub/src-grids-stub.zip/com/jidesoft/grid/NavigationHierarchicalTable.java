/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>NavigationHierarchicalTable</code> is a special HierarchicalTable that is designed for the navigation purpose. It has the
 *  following features.
 *  <pre>
 *  <ul>
 *      <li>It has a special row rollover effect.</li>
 *      <li>The row selection covers the whole row instead of each cell has selection individually
 *  in
 *  the case of
 *  HierarchicalTable.</li>
 *      <li>The selection highlight is different when focused and not focused.</li>
 *  </ul>
 *  </pre>
 *  The selection and rollover effect is painted inside the paintComponent methods of the <code>NavigationHierarchicalTable</code>
 *  after the original table content is painted.
 * 
 *  @since 3.4.7
 */
public class NavigationHierarchicalTable extends HierarchicalTable {

	public NavigationHierarchicalTable() {
	}

	public NavigationHierarchicalTable(javax.swing.table.TableModel model) {
	}

	public NavigationHierarchicalTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public NavigationHierarchicalTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public NavigationHierarchicalTable(int numRows, int numColumns) {
	}

	public NavigationHierarchicalTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public NavigationHierarchicalTable(Object[][] rowData, Object[] columnNames) {
	}

	/**
	 *  Creates the <code>NavigationHelper</code> which is a helper class that paints the rollover and the selection
	 *  effect.
	 *  <p/>
	 *  By default, it creates a NavigationHierarchicalTableHelper instance.
	 * 
	 *  @return a new NavigationHelper.
	 */
	protected NavigationComponentHelper createNavigationHelper() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Gets the rollover row that currently has rollover effect.
	 * 
	 *  @return the row that has the rollover effect.
	 */
	public int getNavigationRolloverRow() {
	}

	/**
	 *  Sets the rollover row.
	 * 
	 *  @param navigationRolloverRow the row to show the rollover effect.
	 */
	public void setNavigationRolloverRow(int navigationRolloverRow) {
	}

	/**
	 *  The navigation HierarchicalTable helper class.
	 */
	public class NavigationHierarchicalTableHelper {


		public NavigationHierarchicalTable.NavigationHierarchicalTableHelper() {
		}

		@java.lang.Override
		public java.awt.Rectangle getRowBounds(int row) {
		}

		@java.lang.Override
		public int rowAtPoint(java.awt.Point p) {
		}

		@java.lang.Override
		public int[] getSelectedRows() {
		}
	}
}
