/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>Searchable</code> is a class that can make JList, JTable and JComboBox searchable. However, when the data is
 *  abundant, it is still annoying to look for a single word in hundreds of thousands of records. Hence,
 *  <code>ShrinkSearchableSupport</code> is requested, which means once you type a new letter in the searchable, the
 *  JList, JTable and JComboBox will refresh its display based on the new string input.
 *  <p/>
 *  <code>ShrinkSearchableSupport</code> is a base abstract class. <code>ListShrinkSearchableSupport</code>,
 *  <code>TableShrinkSearchableSupport</code>, <code>ComboBoxShrinkSearchableSupport</code> are implementations to make
 *  JList, JTable, JComboBox searchable to be able to shrink on searching respectively. For each implementation, there
 *  are five methods need to be implemented.
 *  <p/>
 *  As this is an abstract class, please refer to to javadoc of {@link com.jidesoft.grid.ListShrinkSearchableSupport} to
 *  find out how to use it with JList respectively.
 *  <p/>
 *  Last but not the least, only one Searchable is allowed on a component. If you install another one, it will remove the
 *  first one and then install the new one.
 */
public abstract class ShrinkSearchableSupport implements java.beans.PropertyChangeListener {

	protected final Searchable _searchable;

	/**
	 *  The client property for ShrinkSearchableSupport instance. When ShrinkSearchableSupport is installed on a component, this client property
	 *  has the ShrinkSearchableSupport.
	 * 
	 *  @since 3.3.4
	 */
	public static final String CLIENT_PROPERTY_SHRINK_SEARCHABLE_SUPPORT = "ShrinkSearchableSupport";

	public ShrinkSearchableSupport(Searchable searchable) {
	}

	/**
	 *  Property change listener registered for the component's model
	 * 
	 *  @param evt the property change event
	 * 
	 *  @since 3.2.3
	 */
	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Checks if the filterable model should be reinstalled if the model is changed.
	 *  <p/>
	 *  To keep the backward compatibility, it returns false by default.
	 *  <p/>
	 *  To avoid potential infinite loop, the recommended implementation for this method is
	 *  <code><pre>
	 *  return event.getNewValue() != _filterableListModel.
	 *  </pre></code>
	 * 
	 *  @param event the property change event
	 * 
	 *  @return true if a new filterable model should be installed. Otherwise false.
	 * 
	 *  @since 3.2.3
	 */
	protected boolean needReinstallFilterableModel(java.beans.PropertyChangeEvent event) {
	}

	/**
	 *  Handle the SearchableEvent fired from Searchable.
	 *  <p/>
	 *  Basically it will only handle <code>SEARCHABLE_CHANGE</code> and <code>SEARCHABLE_END</code> events. In these two
	 *  case, it will invoke <code>updateFilterModel</code> to shrink the model.
	 * 
	 *  @param e the event
	 */
	public void searchableEventFired(SearchableEvent e) {
	}

	protected boolean isRestoreSelection(int actualIndex, int viewIndex) {
	}

	/**
	 *  Convert the element to string. This method will be invoked inside applyFilter while creating the filter instance
	 *  so that the conversion in ShrinkSearchSupport could be consistent with that in Searchable it wraps.
	 *  <p/>
	 *  By default, this method will invoke _searchable#convertElementToString() only. You can override it if you need
	 *  customize it.
	 * 
	 *  @param object the object to be converted
	 * 
	 *  @return the string to be displayed.
	 */
	protected String convertElementToString(Object object) {
	}

	/**
	 *  Get actual index from the visual index. This method will be invoked before we invoke <code>applyFilter</code> so
	 *  that we can get the current selection information hence we are able to set the selection back after the filter is
	 *  applied.
	 * 
	 *  @param visualIndex the visual index
	 * 
	 *  @return the actual index
	 */
	protected abstract int getActualIndexAt(int visualIndex) {
	}

	/**
	 *  Get visual index from the actual index. This method will be invoked after we invoke <code>applyFilter</code> so
	 *  that we can set the selection back.
	 * 
	 *  @param actualIndex the actual index
	 * 
	 *  @return the visual index
	 */
	protected abstract int getVisualIndexAt(int actualIndex) {
	}

	/**
	 *  Install a filterable model for the component where Searchable installed in.
	 */
	public abstract void installFilterableModel() {
	}

	/**
	 *  Uninstall the filterable model installed by <code>installFilterableModel</code>.
	 *  <p/>
	 *  If you are extending this class to create your customized ShrinkSearchableSupport class, please make sure you
	 *  will invoke _searchable.getComponent().removePropertyChangeListener("model", this); to remove the property change
	 *  listener. Otherwise the filterable model may not be removed.
	 */
	public abstract void uninstallFilterableModel() {
	}

	/**
	 *  Update the filterable model, usually applying filter, based on the latest Searchable searching text.
	 *  <p/>
	 *  If you want to override this method, please be noted that you probably need make your
	 *  filter#convertElementToString to invoke {@link #convertElementToString(Object)}. Below is one sample
	 *  implementation while creating the filter.
	 *  <code><pre>
	 *  WildcardFilter wildcardFilter = new WildcardFilter(searchingText) {
	 *      protected String convertElementToString(Object value) {
	 *          String stringValue = TableShrinkSearchableSupport.this.convertElementToString(value);
	 *          return stringValue != null ? stringValue : super.convertElementToString(value);
	 *      }
	 *  };
	 *  </pre></code>
	 * 
	 *  @param searchingText current searching text
	 */
	protected abstract void applyFilter(String searchingText) {
	}
}
