/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The <code>SpanModel</code> interface specifies the methods the <code>JTable</code> will use to implement cell span.
 *  <p/>
 */
public interface SpanModel {

	/**
	 *  Gets the cell span at the specified row and column. To avoid creating many instances of CellSpan, you can return
	 *  the same instance by changing its values only. For example, the code below is a good example.
	 *  <p/>
	 *  <code><pre>
	 *  private final CellSpan span = new CellSpan(0,0,1,1);
	 *  public CellSpan getCellSpanAt(int row, int col) {
	 *      span.setRow(...);
	 *      span.setColumn(...);
	 *      span.setRowSpan(...);
	 *      span.setColumnSpan(...);
	 *      return span;
	 *  }
	 *  </pre></code>
	 *  For performance consideration, if the cell span has 1 row span and 1 column span, it is better to return null
	 *  instead of new CellSpan(row, column, 1, 1).
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return CellSpan object.
	 */
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex);

	/**
	 *  Checks if the span is on. The CellSpanTable will ignore all the CellSpans defined in this model if this method
	 *  returns false.
	 *  <p/>
	 *  Since 3.5.12, please fire table data changed event if the returned value of this method is changed. Otherwise
	 *  the CellSpanTable might still use the cached value to improve performance.
	 * 
	 *  @return true if span is on. Otherwise false.
	 */
	public boolean isCellSpanOn();
}
