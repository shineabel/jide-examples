/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public abstract class AbstractGroupRow extends AbstractExpandableRow implements GroupCondition {

	public AbstractGroupRow() {
	}

	public Object getValueAt(int columnIndex) {
	}
}
