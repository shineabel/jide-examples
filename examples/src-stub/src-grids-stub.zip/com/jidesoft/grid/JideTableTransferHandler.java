/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default TransferHandler for JideTable which supports import data by default.
 *  <p/>
 *  This transfer handler does not support drag to insert column feature, i.e., DropMode.INSERT_COLS and DropMode.ON_OR_INSERT_COLS.
 * 
 *  @since 3.3.4
 */
public class JideTableTransferHandler extends javax.swing.TransferHandler {

	public JideTableTransferHandler(String property) {
	}

	public JideTableTransferHandler() {
	}

	/**
	 *  Create a Transferable to use as the source for a data transfer.
	 * 
	 *  @param c The component holding the data to be transferred.  This argument is provided to enable sharing of
	 *           TransferHandlers by multiple components.
	 * 
	 *  @return The representation of the data to be transferred.
	 */
	protected java.awt.datatransfer.Transferable createTransferable(javax.swing.JComponent c) {
	}

	protected boolean isValidSelection(javax.swing.JTable table, int[] rows, int[] cols) {
	}

	@java.lang.Override
	public boolean importData(javax.swing.JComponent comp, java.awt.datatransfer.Transferable t) {
	}

	public boolean canImport(javax.swing.JComponent c, java.awt.datatransfer.DataFlavor[] flavors) {
	}

	/**
	 *  Imports from the string.
	 * 
	 *  @param c       the component
	 *  @param str     the string
	 *  @param isLocal the flag indicating if it's imported from inside or outside of the same window/frame/dialog of the table
	 *  @return true if string is imported. Otherwise false.
	 */
	protected boolean importString(javax.swing.JComponent c, String str, boolean isLocal) {
	}

	protected void adjustSelection(javax.swing.JTable table, int[] rows, int[] cols, int selectedRowCount, int selectedColCount, int upperMostRow, int leftMostCol) {
	}

	/**
	 *  Inserts a row in the designated row index at the table.
	 *  <p/>
	 *  The method {@link #importString(javax.swing.JComponent, String, boolean)} relies on this method to insert a new row if
	 *  necessary.
	 *  <p/>
	 *  To implement DnD behavior for a non-DefaultTableModel, please implement this method to insert a row.
	 * 
	 *  @param table    the table
	 *  @param rowIndex the row index
	 *  @param rowData  the row data
	 *  @return true if row inserted correctly. Otherwise false.
	 *  @deprecated no longer get invoked.
	 */
	@java.lang.Deprecated
	protected boolean insertRow(javax.swing.JTable table, int rowIndex, java.util.Vector rowData) {
	}

	/**
	 *  Deletes a row in the designated row index at the table.
	 *  <p/>
	 *  To implement DnD behavior for a non-DefaultTableModel, please implement this method to remove the row.
	 * 
	 *  @param table    the table
	 *  @param rowIndex the row index
	 *  @return true if row deleted correctly. Otherwise false.
	 *  @deprecated no longer get invoked
	 */
	@java.lang.Deprecated
	protected boolean removeRow(javax.swing.JTable table, int rowIndex) {
	}

	/**
	 *  Converts the element to string.
	 * 
	 *  @param table       the table
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @param value       the value to convert
	 * 
	 *  @return the converted string.
	 */
	protected String convertElementToString(javax.swing.JTable table, int rowIndex, int columnIndex, Object value) {
	}

	/**
	 *  Converts the string to element.
	 * 
	 *  @param table       the table
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @param text        the string to convert
	 * 
	 *  @return the converted element.
	 */
	protected Object convertStringToElement(javax.swing.JTable table, int rowIndex, int columnIndex, String text) {
	}

	protected int[] getSelectedRows(javax.swing.JTable table) {
	}

	protected int[] getSelectedColumns(javax.swing.JTable table) {
	}

	public int getSourceActions(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected void exportDone(javax.swing.JComponent c, java.awt.datatransfer.Transferable data, int action) {
	}

	protected void cleanup(javax.swing.JComponent c, boolean remove) {
	}

	protected void cleanUpFields() {
	}

	protected boolean isCellSelection(javax.swing.JTable table) {
	}

	/**
	 *  Gets the flag indicating if importing data is accepted in this TransferHandler.
	 * 
	 *  @return true if importing data is accepted. Otherwise false.
	 * 
	 *  @see #setAcceptImport(boolean)
	 */
	public boolean isAcceptImport() {
	}

	/**
	 *  Sets the flag indicating if importing data is accepted in this TransferHandler.
	 *  <p/>
	 *  By default, the flag is false to avoid accepting data importing.
	 * 
	 *  @param acceptImport the flag
	 */
	public void setAcceptImport(boolean acceptImport) {
	}
}
