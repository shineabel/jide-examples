/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for FolderName.
 */
public class FolderNameCellEditor extends ExComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FolderNameCellEditor.
	 */
	public FolderNameCellEditor() {
	}

	/**
	 *  Creates FolderNameChooserExComboBox used by this cell editor.
	 * 
	 *  @return FolderNameChooserExComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}
}
