/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A special table header for SortableTable which draws arrows and index to indicate the sorting order.
 *  <p/>
 *  <code>SortableTableHeader</code> introduced a very useful feature called <code>TableHeaderCellDecorator</code> which
 *  provides a way for users to paint over the margin of any table header's cells. <code>SortableTableHeader</code> uses
 *  it to paint the sort arrow and sort order index.
 */
public class SortableTableHeader extends CellStyleTableHeader {

	public static final String PROPERTY_SHOW_SORT_ARROW = "showSortArrow";

	public SortableTableHeader(javax.swing.table.TableColumnModel cm) {
	}

	/**
	 *  The constructor which takes JTable.
	 * 
	 *  @param table the JTable
	 *  @since 3.1.0
	 */
	public SortableTableHeader(javax.swing.JTable table) {
	}

	/**
	 *  Returns a string that specifies the name of the L&F class that renders this component.
	 * 
	 *  @return the string "SortableTableHeaderUI"
	 */
	@java.lang.Override
	public String getActualUIClassID() {
	}

	/**
	 *  Returns a string that specifies the name of the UIDelegate class that paints this component.
	 * 
	 *  @return the string "TableHeader.sortableTableHeaderUIDelegate"
	 */
	public String getUIDelegateClassID() {
	}

	/**
	 *  Overrides to paint the sort arrows on table header.
	 * 
	 *  @param g the Graphics object
	 */
	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Paints the sort arrows.
	 * 
	 *  @param g the Graphics object
	 *  @deprecated replaced by {@link SortableTableHeaderCellDecorator}
	 */
	@java.lang.Deprecated
	protected void paintSortArrows(java.awt.Graphics g) {
	}

	/**
	 *  Paints the sort arrow.
	 * 
	 *  @param c         table header
	 *  @param table     the sortable table.
	 *  @param g         Graphics
	 *  @param rect      the bounds of the table column header
	 *  @param index     the sorting index
	 *  @param ascending the sorting direction.
	 *  @deprecated replaced by {@link SortableTableHeaderCellDecorator}
	 */
	@java.lang.Deprecated
	protected void paintSortArrow(javax.swing.JComponent c, SortableTable table, java.awt.Graphics g, java.awt.Rectangle rect, int index, boolean ascending) {
	}

	/**
	 *  Create the sort arrow icon. Subclass can override it to create your own sort arrow. Although the name is
	 *  createSortIcon, you could cache the icon internally and don't create it every time when this method is called.
	 * 
	 *  @param table     the sortable table.
	 *  @param ascending true or false. True is ascending.
	 *  @return the sort arrow icon.
	 */
	protected javax.swing.Icon createSortIcon(SortableTable table, boolean ascending) {
	}

	/**
	 *  Checks if the sort arrow is visible on the table header.
	 *  <p/>
	 *  Moved from {@link AutoFilterTableHeader} since 3.1.0.
	 * 
	 *  @return true or false.
	 * 
	 *  @since 3.1.0
	 */
	public boolean isShowSortArrow() {
	}

	/**
	 *  Sets the flag if the sort arrow is shown on the header.
	 *  <p/>
	 *  Moved from {@link AutoFilterTableHeader} since 3.1.0.
	 * 
	 *  @param showSortArrow true to show the sort arrow. False to not show it.
	 *  @since 3.1.0
	 */
	public void setShowSortArrow(boolean showSortArrow) {
	}

	/**
	 *  Gets the TableHeaderCellDecorator instance to paint the sort icon and index.
	 * 
	 *  @return the SortableTableHeaderCellDecorator instance.
	 * 
	 *  @since 3.1.0
	 */
	public TableHeaderCellDecorator getSortableTableHeaderCellDecorator() {
	}

	/**
	 *  Creates a TableHeaderCellDecorator instance to paint the sort icon and index.
	 * 
	 *  @return a SortableTableHeaderCellDecorator instance.
	 * 
	 *  @since 3.1.0
	 */
	protected TableHeaderCellDecorator createSortableTableHeaderCellDecorator() {
	}
}
