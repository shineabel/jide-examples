/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A CheckBoxListSelectionModel which contains All, Custom and other special table filter items.
 * 
 *  @since 3.3.5
 */
public class CustomValueFilterListSelectionModel extends CheckBoxListSelectionModel {

	/**
	 *  The constructor.
	 * 
	 *  @param indexAfterCustomFilter the index after custom filter
	 *  @param indexFirstValueItem    the index of the first regular value item
	 */
	public CustomValueFilterListSelectionModel(int indexAfterCustomFilter, int indexFirstValueItem) {
	}

	@java.lang.Override
	public boolean isSelectedIndex(int index) {
	}

	@java.lang.Override
	public void setSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public int getMinSelectionIndex() {
	}

	@java.lang.Override
	public int getMaxSelectionIndex() {
	}

	@java.lang.Override
	public void addSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void removeSelectionInterval(int index0, int index1) {
	}
}
