/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>SpanTableModel</code> interface combines <code>TableModel</code> and <code>SpanModel</code>.
 */
public interface SpanTableModel extends javax.swing.table.TableModel, SpanModel {
}
