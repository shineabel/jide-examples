/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class DefaultContextSensitiveTableModel extends javax.swing.table.DefaultTableModel implements ContextSensitiveTableModel {

	public DefaultContextSensitiveTableModel() {
	}

	public DefaultContextSensitiveTableModel(int rowCount, int columnCount) {
	}

	public DefaultContextSensitiveTableModel(java.util.Vector columnNames, int rowCount) {
	}

	public DefaultContextSensitiveTableModel(Object[] columnNames, int rowCount) {
	}

	public DefaultContextSensitiveTableModel(java.util.Vector data, java.util.Vector columnNames) {
	}

	public DefaultContextSensitiveTableModel(Object[][] data, Object[] columnNames) {
	}

	public ConverterContext getConverterContextAt(int row, int column) {
	}

	public EditorContext getEditorContextAt(int row, int column) {
	}

	public Class getCellClassAt(int row, int column) {
	}

	public void addRows(java.util.Vector[] rowDatas) {
	}
}
