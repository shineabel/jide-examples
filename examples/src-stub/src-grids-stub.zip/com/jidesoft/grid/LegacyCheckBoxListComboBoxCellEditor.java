/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose multiple value from a list. It used CheckBoxListComboBox
 *  as the editor.
 */
public class LegacyCheckBoxListComboBoxCellEditor extends AbstractComboBoxCellEditor {

	public LegacyCheckBoxListComboBoxCellEditor() {
	}

	/**
	 *  Creates a <code>CheckBoxListComboBoxCellEditor</code> that contains the elements in the specified array.  By
	 *  default the first item in the array (and therefore the data model) becomes selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 */
	public LegacyCheckBoxListComboBoxCellEditor(Object[] data) {
	}

	/**
	 *  Creates a <code>CheckBoxListComboBoxCellEditor</code> that contains the elements in the specified Vector.  By
	 *  default the first item in the Vector (and therefore the data model) becomes selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 */
	public LegacyCheckBoxListComboBoxCellEditor(java.util.Vector data) {
	}

	/**
	 *  Creates a <code>CheckBoxListComboBoxCellEditor</code> that takes it's items from an existing
	 *  <code>ComboBoxModel</code>.  Since the <code>ComboBoxModel</code> is provided, a combo box created using this
	 *  constructor does not create a default combo box model and may impact how the insert, remove and add methods
	 *  behave.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 */
	public LegacyCheckBoxListComboBoxCellEditor(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Creates a <code>CheckBoxListComboBoxCellEditor</code> that contains the elements in the specified array.  By
	 *  default the first item in the array (and therefore the data model) becomes selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 *  @param type the array type of element in the data array as the CheckBoxListComboBoxCellEditor is used to select
	 *              multiple items.
	 */
	public LegacyCheckBoxListComboBoxCellEditor(Object[] data, Class type) {
	}

	/**
	 *  Creates a <code>CheckBoxListComboBoxCellEditor</code> that contains the elements in the specified Vector.  By
	 *  default the first item in the Vector (and therefore the data model) becomes selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 *  @param type the array type of element in the data array as the CheckBoxListComboBoxCellEditor is used to select
	 *              multiple items.
	 */
	public LegacyCheckBoxListComboBoxCellEditor(java.util.Vector data, Class type) {
	}

	/**
	 *  Creates a <code>CheckBoxListComboBoxCellEditor</code> that takes it's items from an existing
	 *  <code>ComboBoxModel</code>.  Since the <code>ComboBoxModel</code> is provided, a combo box created using this
	 *  constructor does not create a default combo box model and may impact how the insert, remove and add methods
	 *  behave.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param type  the array type of element in the data array as the CheckBoxListComboBoxCellEditor is used to select
	 *               multiple items.
	 */
	public LegacyCheckBoxListComboBoxCellEditor(javax.swing.ComboBoxModel model, Class type) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Updates the model for the combobox.
	 * 
	 *  @param model the model for the combobox.
	 */
	public void setComboBoxModel(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Updates the data type for the combobox.
	 * 
	 *  @param type the type for the combobox.
	 */
	public void setComboBoxType(Class type) {
	}

	/**
	 *  Creates the checkbox list combobox.
	 * 
	 *  @param model the combobox model
	 *  @param type  the element type
	 *  @return the list combobox.
	 */
	protected com.jidesoft.combobox.CheckBoxListComboBox createCheckBoxListComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	/**
	 *  Sets possible value set for the cell editor.
	 * 
	 *  @param data the possible value set
	 */
	public void setPossibleValues(Object[] data) {
	}

	@java.lang.Override
	public void setConverterContext(ConverterContext context) {
	}
}
