/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to indicate an object that can have parent in a tree-like data structure.
 */
public interface Node {

	public static final String PROPERTY_ADJUSTING = "adjusting";

	/**
	 *  Gets the number of level counting from the first level. If the expandable doesn't have any parent, the level will
	 *  be 0.
	 * 
	 *  @return the number of level above
	 */
	public int getLevel();

	/**
	 *  Gets the parent of this expandable.
	 * 
	 *  @return the parent
	 */
	public Expandable getParent();

	/**
	 *  Sets the parent of this expandable.
	 * 
	 *  @param parent
	 */
	public void setParent(Expandable parent);

	/**
	 *  Gets previous sibling of current node.
	 * 
	 *  @return previous sibling if exists.
	 */
	public Node getPreviousSibling();

	/**
	 *  Gets next sibling of current node.
	 * 
	 *  @return next sibling if exists.
	 */
	public Node getNextSibling();
}
