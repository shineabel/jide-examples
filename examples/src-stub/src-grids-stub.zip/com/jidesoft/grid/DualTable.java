/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>DualTable</code> is a pane that contains two JTables and a bunch of buttons. The table on the left contains all
 *  the rows. The table on the right contains the rows that are selected.
 *  <p/>
 *  <code>DualTable</code> uses {@link DualListModel} which is the model of this component. With the help of
 *  DualListModel, it provides three kinds of selection modes. This mode controls what to display in the right table when
 *  rows are selected. {@link DualListModel#REMOVE_SELECTION} mode means the left table will remove the rows if they are
 *  selected to the right table. This mode can prevent user from selecting the selected row again if it is not allowed in
 *  certain cases. {@link DualListModel#DISABLE_SELECTION} mode means the selected rows will be shown as disabled. User
 *  cannot select them anymore but they can still see them in the right table to show user a complete unchanged table.
 *  {@link DualListModel#KEEP_SELECTION} mode will not change the right table at all when rows are selected. This is the
 *  only mode which can result duplicated rows to be selected. If that's what you want in your situation, this mode is
 *  the one you should use. You could disable the duplicate selection option by invoking {link #setAllowDuplicates(false)}.
 *  <p/>
 *  <code>DualTable</code> also uses {@link com.jidesoft.grid.TableModelAdapter} to get some necessary information which
 *  cannot be prvided by {@link com.jidesoft.list.DualListModel}, such as column class, column count and column name.
 *  <p/>
 *  <code>DualTable</code> extends {@link JideSplitPane}, which makes users conveniently resize the width of either table.
 *  <p/>
 * 
 *  @see DualListModel
 *  @see AbstractDualListModel
 *  @see DefaultDualListModel
 *  @see com.jidesoft.grid.TableModelAdapter
 *  @see com.jidesoft.grid.ListTableModelAdapter
 */
public class DualTable extends JideSplitPane {

	public static final String COMMAND_MOVE_LEFT = "moveLeft";

	public static final String COMMAND_MOVE_RIGHT = "moveRight";

	public static final String COMMAND_MOVE_ALL_LEFT = "moveAllLeft";

	public static final String COMMAND_MOVE_ALL_RIGHT = "moveAllRight";

	public static final String COMMAND_MOVE_UP = "moveUp";

	public static final String COMMAND_MOVE_DOWN = "moveDown";

	public static final String COMMAND_MOVE_TO_TOP = "moveToTop";

	public static final String COMMAND_MOVE_TO_BOTTOM = "moveToBottom";

	protected com.jidesoft.list.DualListModel _model;

	protected TableModelAdapter _tableModelAdapter;

	public javax.swing.JComponent _originalTablePane;

	public javax.swing.JComponent _selectedTablePane;

	public final String CLIENT_PROPERTY_ALWAYS_DISABLED = "DualTable.alwaysDisabled";

	protected com.jidesoft.list.DefaultListModelWrapper _selectedListModel;

	protected com.jidesoft.list.DefaultListModelWrapper _originalListModel;

	protected javax.swing.table.TableModel _selectedTableModel;

	protected javax.swing.table.TableModel _originalTableModel;

	/**
	 *  Constructs a <code>JList</code> that displays the elements in the specified array.  This constructor just
	 *  delegates to the <code>DualListModel</code> constructor.
	 * 
	 *  @param listData          the array of Objects to be loaded into the data _model
	 *  @param tableModelAdapter the table model adapter
	 */
	public DualTable(Object[] listData, TableModelAdapter tableModelAdapter) {
	}

	/**
	 *  Constructs a <code>DualTable</code> that displays the elements in the specified <code>List</code>.  This
	 *  constructor just delegates to the <code>DualListModel</code> constructor.
	 * 
	 *  @param listData          the <code>List</code> to be loaded into the data _model
	 *  @param tableModelAdapter the table model adapter
	 */
	public DualTable(java.util.List listData, TableModelAdapter tableModelAdapter) {
	}

	/**
	 *  Constructs a <code>DualTable</code> that displays the elements in the specified, non-<code>null</code> model. All
	 *  <code>DualTable</code> constructors delegate to this one.
	 * 
	 *  @param model             the data model for this list
	 *  @param tableModelAdapter the table model adapter
	 *  @throws NullPointerException if <code>model</code> is <code>null</code>
	 */
	public DualTable(com.jidesoft.list.DualListModel model, TableModelAdapter tableModelAdapter) {
	}

	/**
	 *  Creates the JList. By default, we will create JList and set the name to "DualTable.leftList" or
	 *  "DualTable.rightList" depending on the parameter "left" value.
	 * 
	 *  @param model         the list model
	 *  @param originalTable true if the JList is for the original list. False if the JList is for the selected list.
	 *  @return a JList.
	 */
	protected javax.swing.JTable createTable(javax.swing.ListModel model, boolean originalTable) {
	}

	/**
	 *  Creates the table model.
	 *  <p/>
	 *  By default, it returns new ListTableModelAdapter(model, adapter). You could override this method to customize
	 *  the table model.
	 * 
	 *  @param model           the list model
	 *  @param adapter         the adapter
	 *  @param isOriginalTable the flag indicating if this is for the original table or the selected table
	 *  @return the created table model.
	 *  @since 3.5.2
	 */
	protected ListTableModelAdapter createTableModel(javax.swing.ListModel model, TableModelAdapter adapter, boolean isOriginalTable) {
	}

	/**
	 *  Customizes the JList.
	 * 
	 *  @param table         the JList. It could be either the original JList or the selected JList.
	 *  @param originalTable true if the JList is for the original list. False if the JList is for the selected list.
	 */
	protected void setupTable(javax.swing.JTable table, boolean originalTable) {
	}

	/**
	 *  Get the original JList.
	 * 
	 *  @return the original JList.
	 */
	public javax.swing.JTable getOriginalTable() {
	}

	/**
	 *  Get the selected JList.
	 * 
	 *  @return the selected JList.
	 */
	public javax.swing.JTable getSelectedTable() {
	}

	/**
	 *  Gets the component containing the original JList.
	 * 
	 *  @return the component containing the original JList.
	 */
	public javax.swing.JComponent getOriginalTablePane() {
	}

	/**
	 *  Gets the component containing the selected JList.
	 * 
	 *  @return the component containing the selected JList.
	 */
	public javax.swing.JComponent getSelectedTablePane() {
	}

	/**
	 *  Adds ButtonPanel to DualTable.
	 * 
	 *  @param container   the container between the two JLists.
	 *  @param buttonPanel the button panel
	 */
	protected void addButtonPanel(java.awt.Container container, java.awt.Component buttonPanel) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	protected java.awt.Container createButtonPanel() {
	}

	/**
	 *  Creates the button. Our default code is
	 *  <code><pre>
	 *  protected AbstractButton createButton(Action action) {
	 *      AbstractButton button = new JideButton(action);
	 *      action.addPropertyChangeListener(new PropertyChangeListener() {
	 *          public void propertyChange(PropertyChangeEvent evt) {
	 *              if ("disabledIcon".equals(evt.getPropertyName())) {
	 *                  button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *              }
	 *          }
	 *      });
	 *      button.setName("" + action.getValue(Action.ACTION_COMMAND_KEY));
	 *      button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *      button.setRequestFocusEnabled(false);
	 *      return button;
	 *  }
	 *  </pre></code>
	 * 
	 *  @param action the action for the button.
	 *  @return a button.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	/**
	 *  Enables (or disables) an action.
	 *  @param command one of the String commands defined in DualList that start with "COMMAND_MOVE_".
	 *  @param enabled true to enable the action, false to disable it.
	 */
	public void enableAction(String command, boolean enabled) {
	}

	/**
	 *  Gets the action associated with the buttons.
	 * 
	 *  @param command one of the String commands defined in DualList that start with "COMMAND_MOVE_".
	 *  @return the action.
	 */
	public javax.swing.Action getAction(String command) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Gets the selected indices. The index in the array is the index as in the original list.
	 * 
	 *  @return the selected indices.
	 *  @see DualListModel#getSelectedIndices()
	 */
	public int[] getSelectedIndices() {
	}

	@java.lang.SuppressWarnings("unchecked")
	public int[] getUnselectedIndices() {
	}

	protected void installKeyboardAction() {
	}

	/**
	 *  Gets the DualListModel.
	 * 
	 *  @return the DualListModel.
	 */
	public com.jidesoft.list.DualListModel getModel() {
	}

	/**
	 *  Sets the DualListModel.
	 * 
	 *  @param model a new DualListModel.
	 */
	public void setModel(com.jidesoft.list.DualListModel model) {
	}

	/**
	 *  Gets the selected values from the DualTable.
	 * 
	 *  @return the selected values.
	 */
	public Object[] getSelectedValues() {
	}

	/**
	 *  Returns the values that are not selected in <code>DaulList</code>
	 * 
	 *  @return the unselected values
	 */
	public Object[] getUnselectedValues() {
	}

	/**
	 *  Checks if the index is selected.
	 * 
	 *  @param index the index.
	 *  @return true or false.
	 */
	public boolean isSelectedIndex(int index) {
	}

	/**
	 *  Removes all the selections.
	 */
	public void clearSelection() {
	}

	/**
	 *  Change the selection to be the set union of the current selection and the indices between index0 and index1
	 *  inclusive.  If this represents a change to the current selection, then notify each ListSelectionListener. Note
	 *  that index0 doesn't have to be less than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 */
	public void addSelectionInteval(int index0, int index1) {
	}

	/**
	 *  Change the selection to be the set difference of the current selection and the indices between index0 and index1
	 *  inclusive.  If this represents a change to the current selection, then notify each ListSelectionListener.  Note
	 *  that index0 doesn't have to be less than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 */
	public void removeSelectionInteval(int index0, int index1) {
	}

	/**
	 *  Checks if there is any selection.
	 * 
	 *  @return true means no selection. Otherwise false.
	 */
	public boolean isSelectionEmpty() {
	}

	/**
	 *  Gets the selection mode from DualListModel.
	 * 
	 *  @return the selection mode.
	 *  @see DualListModel#getSelectionMode()
	 */
	public int getSelectionMode() {
	}

	/**
	 *  Sets the selection mode to <code>DualListModel</code>.
	 * 
	 *  @param selectionMode the new selection mode.
	 *  @see DualListModel#setSelectionMode(int)
	 */
	public void setSelectionMode(int selectionMode) {
	}

	/**
	 *  Sets the button visible or invisible.
	 * 
	 *  @param command the name defined in DualTable. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @param visible true to show the button and false to hide.
	 */
	public void setButtonVisible(String command, boolean visible) {
	}

	/**
	 *  Checks if the button is visible.
	 * 
	 *  @param command the name defined in DualTable. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @return true or false.
	 */
	public boolean isButtonVisible(String command) {
	}

	/**
	 *  Sets the button to always disabled.
	 * 
	 *  @param command the name defined in DualTable. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @param enabled false to always disable the button.
	 */
	public void setButtonEnabled(String command, boolean enabled) {
	}

	/**
	 *  Checks if the button is always disabled.
	 * 
	 *  @param command the name defined in DualTable. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @return false if the button is always disabled. Otherwise true. Note that this method still could return true
	 *          when the button isEnabled() return false.
	 */
	public boolean isButtonEnabled(String command) {
	}

	/**
	 *  Moves the selected items in the right list to the left list.
	 */
	public void moveLeft() {
	}

	/**
	 *  Moves the selected items in the left list to the right list.
	 */
	public void moveRight() {
	}

	/**
	 *  Moves all items from the right list to the left list.
	 */
	public void moveAllLeft() {
	}

	/**
	 *  Moves all items from the left list to the right list.
	 */
	public void moveAllRight() {
	}

	/**
	 *  Moves the selected items in the right list up by one.
	 */
	public void moveUp() {
	}

	/**
	 *  Moves the selected items in the right list down by one.
	 */
	public void moveDown() {
	}

	/**
	 *  Moves the selected items in the right list to the top.
	 */
	public void moveToTop() {
	}

	/**
	 *  Moves the selected items in the right list to the bottom.
	 */
	public void moveToBottom() {
	}

	/**
	 *  Get the flag if duplicate selection is allowed in the DualTable.
	 * 
	 *  @return true if duplicate selection is allowed. Otherwise false.
	 *  @see #setAllowDuplicates(boolean)
	 */
	public boolean isAllowDuplicates() {
	}

	/**
	 *  Set the flag if duplicate selection is allowed in the DualTable.
	 *  <p/>
	 *  This flag will only take effective if {@link #getSelectionMode} returns {@link DualListModel#KEEP_SELECTION}
	 *  <p/>
	 *  By default the flag is true to keep the consistent behavior with DualList.
	 * 
	 *  @param allowDuplicates the flag
	 *  @see #setSelectionMode(int)
	 */
	public void setAllowDuplicates(boolean allowDuplicates) {
	}

	/**
	 *  Gets the flag indicating if double click to select is enabled.
	 * 
	 *  @return true if double click is enabled. Otherwise false.
	 *  @see #setDoubleClickEnabled(boolean)
	 *  @since 3.2.3
	 */
	public boolean isDoubleClickEnabled() {
	}

	/**
	 *  Sets the flag indicating if double click to select is enabled.
	 *  <p/>
	 *  By default, the flag is true.
	 * 
	 *  @param doubleClickEnabled the flag
	 *  @since 3.2.3
	 */
	public void setDoubleClickEnabled(boolean doubleClickEnabled) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. For example,
	 *  you can customize the icons by overriding this method. The key for the icons will be in the format of
	 *  "DualTable.moveLeft.icon" and "DualTable.moveLeft.disabledIcon" for the move left button. There are a total of
	 *  eight buttons. Once you override, you can return a full qualified path to the icon resource such as
	 *  "/com/yourcompany/icons/moveLeft.png". Note that the icon must be in the class path so that we can access it as
	 *  resource.
	 * 
	 *  @param key the key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Performs the action.
	 * 
	 *  @param command the command
	 */
	protected void performAction(String command) {
	}
}
