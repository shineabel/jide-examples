/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CsvTableScrollPaneUtils</code> is a class that has methods to export TableScrollPane's content to Character
 *  Separated Values file format.
 *  <p/>
 *  The export feature will not consider the cell contents conversion but you can use ValueConverter to format the
 *  value if you want. It will also optionally consider table header as part of the export. You could also choose any
 *  character including comma as the separator.
 *  <p/>
 *  It does NOT support cell span and will LOSE the collapsed rows in TreeTable scenario because of
 *  the CSV format limitation.
 */
public class CsvTableScrollPaneUtils {

	public CsvTableScrollPaneUtils() {
	}

	/**
	 *  Exports the TableScrollPane to an CSV file.
	 * 
	 *  @param scrollPane the scrollPane to be exported.
	 *  @param fileName   the CSV file name. It should be the full path to the file.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, String fileName) {
	}

	/**
	 *  Exports the scrollPane to an CSV file.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, String fileName, boolean includeTableHeader) {
	}

	/**
	 *  Exports the scrollPane to an CSV file.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter) {
	}

	/**
	 *  Exports the scrollPane to an CSV file.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the scrollPane to an CSV file.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param firstRow           the first row to be exported
	 *  @param firstColumn        the first row to be exported
	 *  @param numberOfRows       number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns    number of columns to be exported. -1 means all columns.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the scrollPane to an CSV file.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param firstRow           the first row to be exported
	 *  @param firstColumn        the first row to be exported
	 *  @param numberOfRows       number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns    number of columns to be exported. -1 means all columns.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @param separator          the character used to separate the cells. By default, it is a comma.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter, char separator) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane the scrollPane to be exported.
	 *  @param out        the output stream
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param out                the output stream
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out, boolean includeTableHeader) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param out                the output stream
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out, boolean includeTableHeader, ValueConverter cellValueConverter) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane         the scrollPane to be exported.
	 *  @param out                the output stream
	 *  @param includeTableHeader whether to include the scrollPane header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane          the scrollPane to be exported.
	 *  @param out                 the output stream
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param includeTableHeader  whether to include the scrollPane header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane          the scrollPane to be exported.
	 *  @param out                 the output stream
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param includeTableHeader  whether to include the scrollPane header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @param separator           the character used to separate the cells. By default, it is a comma.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter, char separator) {
	}

	/**
	 *  Exports the scrollPane to a CSV file output steam.
	 * 
	 *  @param scrollPane          the scrollPane to be exported.
	 *  @param out                 the output stream
	 *  @param config              a collection of the parameters that could be configured during the export process.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 *  @since 3.3.8
	 */
	public static boolean export(TableScrollPane scrollPane, java.io.OutputStream out, CsvTableUtils.CsvTableExportConfig config) {
	}
}
