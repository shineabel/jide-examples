/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A class representing a column in the table model.
 */
public class Field implements java.io.Serializable {

	protected ConverterContext _converterContext;

	protected EditorContext _editorContext;

	protected int _sortOrder;

	public static final int SORT_ORDER_ASCENDING = 1;

	public static final int SORT_ORDER_DESCENDING = -1;

	public static final int SORT_ORDER_UNSORTED = 0;

	public static final String PROPERTY_NAME = "name";

	public static final String PROPERTY_TITLE = "title";

	public static final String PROPERTY_DESCRIPTION = "description";

	public static final String PROPERTY_ICON = "icon";

	public static final String PROPERTY_TYPE = "type";

	public static final String PROPERTY_CONVERTER_CONTEXT = "converterContext";

	public static final String PROPERTY_EDITOR_CONTEXT = "editorContext";

	public static final String PROPERTY_FILTERABLE = "filterable";

	public static final String PROPERTY_SORTABLE = "sortable";

	public static final String PROPERTY_EXPANDABLE = "expandable";

	public static final String PROPERTY_VISIBLE = "visible";

	public static final String PROPERTY_CUSTOMIZABLE = "customizable";

	public static final String PROPERTY_SELECTED_POSSIBLE_VALUES = "selectedPossibleValues";

	public static final String PROPERTY_DESELECTED_POSSIBLE_VALUES = "deselectedPossibleValues";

	public static final String PROPERTY_FILTER = "filter";

	public static final String PROPERTY_SORT_ORDER = "sortOrder";

	public static final String PROPERTY_PREFER_SELECTED_VALUES = "preferSelecetedValues";

	protected java.beans.PropertyChangeSupport changeSupport;

	protected javax.swing.table.TableModel _tableModel;

	protected int _modelIndex;

	protected boolean _isConverterContextSet;

	protected boolean _isEditorContextSet;

	public static final String PROPERTY_ASCENDING = "ascending";

	public Field() {
	}

	public Field(String name) {
	}

	public Field(String name, Class type) {
	}

	public Field(String name, String title, Class type) {
	}

	public String getName() {
	}

	public void setName(String name) {
	}

	public String getTitle() {
	}

	public void setTitle(String title) {
	}

	public String getDescription() {
	}

	public void setDescription(String description) {
	}

	/**
	 *  Gets the icon. The icon is displayed before the title in the pivot table's field areas.
	 * 
	 *  @return the icon.
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets the icon.
	 *  <p/>
	 *  This is a bounded property. Property change event will be fired if the icon is changed.
	 * 
	 *  @param icon the new icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	public Class getType() {
	}

	public void setType(Class type) {
	}

	public ConverterContext getConverterContext() {
	}

	public void setConverterContext(ConverterContext converterContext) {
	}

	public EditorContext getEditorContext() {
	}

	public void setEditorContext(EditorContext editorContext) {
	}

	/**
	 *  Gets the comparator context. Default is null. You need to call <code>setComparatorContext</code> to set one if
	 *  you want to use a different comparator for this PivotField which will be used by pivot table to sort.
	 * 
	 *  @return the comparator context.
	 */
	public ComparatorContext getComparatorContext() {
	}

	/**
	 *  Sets the comparator context.
	 * 
	 *  @param comparatorContext the comparator context.
	 */
	public void setComparatorContext(ComparatorContext comparatorContext) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(String)
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name.
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	/**
	 *  Gets the preferred width.
	 * 
	 *  @return the preferred width.
	 */
	public int getPreferredWidth() {
	}

	/**
	 *  Sets the preferred width.
	 * 
	 *  @param preferredWidth the new preferred width.
	 */
	public void setPreferredWidth(int preferredWidth) {
	}

	/**
	 *  Sets the selected possible values for this field.
	 *  <p/>
	 *  Sets this field will invoke {@link #setFilteredPossibleValues(Object[])} to set that field to null.
	 * 
	 *  @param selectedPossibleValues new selected possible values.
	 */
	public void setSelectedPossibleValues(Object[] selectedPossibleValues) {
	}

	/**
	 *  Returns the selected possible values of the field. This is used to filter the table model. It returns null if
	 *  "(All)" is selected, empty array if nothing is selected and otherwise the selected values.
	 * 
	 *  @return the selected possible values.
	 */
	public Object[] getSelectedPossibleValues() {
	}

	/**
	 *  Sets the filtered possible values for this field.
	 *  <p/>
	 *  Sets this field will invoke {@link #setSelectedPossibleValues(Object[])} to set that field to null.
	 * 
	 *  @param filteredPossibleValues new filtered possible values.
	 */
	public void setFilteredPossibleValues(Object[] filteredPossibleValues) {
	}

	/**
	 *  Returns the filtered possible values of the field. This is used to filter the table model. It returns null if
	 *  "(All)" is selected, otherwise the filtered values.
	 * 
	 *  @return the filtered possible values.
	 */
	public Object[] getFilteredPossibleValues() {
	}

	/**
	 *  Get the flag indicating if selected possible values will be used or filtered possible values.
	 *  <p/>
	 *  The default value is changed to false. In this way, if you input a new record to the PivotTablePane, the new
	 *  record will stay. If you want the new record to be filtered away, please try to set this flag to true.
	 * 
	 *  @see #setSelectedPossibleValues(Object[])
	 *  @see #setFilteredPossibleValues(Object[])
	 *  @return true if the selected possible values will be used. Otherwise false.
	 */
	public boolean isPreferSelectedPossibleValues() {
	}

	/**
	 *  Set the flag indicating if selected possible values will be used or filtered possible values.
	 * 
	 *  @see #isPreferSelectedPossibleValues()
	 *  @param preferSelectedPossibleValues the flag
	 */
	public void setPreferSelectedPossibleValues(boolean preferSelectedPossibleValues) {
	}

	/**
	 *  Checks if null value is allowed in the filter.
	 * 
	 *  @return true or false.
	 */
	public boolean isNullValueAllowed() {
	}

	/**
	 *  Sets if the null value is allowed. If true, an "<empty>" row will appear in the drop down list of the field.
	 *  Otherwise, we will not show it.
	 * 
	 *  @param nullValueAllowed true or false.
	 */
	public void setNullValueAllowed(boolean nullValueAllowed) {
	}

	/**
	 *  Checks if the custom filter is allowed in the drop down list.
	 * 
	 *  @return true or false.
	 */
	public boolean isCustomFilterAllowed() {
	}

	/**
	 *  Sets the flag if the custom filter is allowed. If true, an "<Custom...>" row will appear in the drop down list of
	 *  the field. Otherwise, we will not show it.
	 * 
	 *  @param isCustomFilterAllowed true or false.
	 */
	public void setCustomFilterAllowed(boolean isCustomFilterAllowed) {
	}

	/**
	 *  Checks if the field settings can be customized by end users. If true, it means user can right click to see "Field
	 *  Settings" menu item on the popup menu. Clicking on it will show a dialog to allow them to customize the setting
	 *  of this field.
	 * 
	 *  @return true if the field settings can be customized by end user.
	 */
	public boolean isCustomizable() {
	}

	/**
	 *  Sets the flag if the field settings can be customized by end users. If true, it means user can right click to see
	 *  "Field Settings" menu item on the popup menu. Clicking on it will show a dialog to allow them to customize the
	 *  setting of this field.
	 * 
	 *  @param customizable true or false.
	 */
	public void setCustomizable(boolean customizable) {
	}

	/**
	 *  Checks if the field can be filtered. If true, it means a filter button will be shown on the field box to allow
	 *  user to select the value to be filtered.
	 * 
	 *  @return true or false.
	 */
	public boolean isFilterable() {
	}

	/**
	 *  Sets the flag if the field can be filtered. If true, it means a filter button will be shown on the field box to
	 *  allow user to select the value to be filtered.
	 * 
	 *  @param filterable true or false.
	 */
	public void setFilterable(boolean filterable) {
	}

	/**
	 *  Checks if the field can be expanded in the header tables. If true, it means a +/- icon will be displayed in the
	 *  cell to allow user to click on it to expand/collapse it.
	 * 
	 *  @return true or false.
	 */
	public boolean isExpandable() {
	}

	/**
	 *  Sets the flag if the field can be expanded in the header tables. If true, it means a +/- icon will be displayed
	 *  in the cell to allow user to click on it to expand/collapse it.
	 * 
	 *  @param expandable true or false.
	 */
	public void setExpandable(boolean expandable) {
	}

	/**
	 *  Checks if the field can be sorted by the user. If true, it means user can click on the field to toggle the
	 *  sorting order. If false, user will not be able to do it. However developer can still set the sort order to
	 *  ascending or descending using code.
	 * 
	 *  @return true or false.
	 */
	public boolean isSortable() {
	}

	/**
	 *  Sets the flag if the field can be sorted by the user. If true, it means user can click on the field to toggle the
	 *  sorting order. If false, user will not be able to do it. However developer can still set the sort order to
	 *  ascending or descending using code.
	 * 
	 *  @param sortable true or false.
	 */
	public void setSortable(boolean sortable) {
	}

	/**
	 *  Checks if the field is visible. If true, it means the field will appear in filter chooser is unassigned.
	 * 
	 *  @return true or false.
	 */
	public boolean isVisible() {
	}

	/**
	 *  Sets the flag if the field is visible. If true, it means the field will appear in filter chooser is unassigned.
	 * 
	 *  @param visible true or false.
	 */
	public void setVisible(boolean visible) {
	}

	/**
	 *  Gets the actual filter that is in effect. This method will consider {@link #getFilter()}, {@link #getSelectedPossibleValues()}
	 *  and {@link #getFilteredPossibleValues()} to construct a filter that is in effect.
	 * 
	 *  @return the filter in effect.
	 *  @since 3.4.8
	 */
	public com.jidesoft.filter.Filter getActualFilter() {
	}

	/**
	 *  Gets the Filter that will be applied to the PivotDataSource.
	 * 
	 *  @return the Filter.
	 */
	public com.jidesoft.filter.Filter getFilter() {
	}

	/**
	 *  Sets the Filter that will be applied to the PivotDataSource.
	 * 
	 *  @param filter the Filter.
	 */
	public void setFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Gets the field sort order.
	 * 
	 *  @return true or false.
	 */
	public int getSortOrder() {
	}

	/**
	 *  Sets the sort order.
	 * 
	 *  @param sortOrder the sort order. It can be {@link #SORT_ORDER_ASCENDING}, {@link #SORT_ORDER_DESCENDING}, or
	 *                   {@link #SORT_ORDER_UNSORTED}.
	 */
	public void setSortOrder(int sortOrder) {
	}

	/**
	 *  Updates the table model and model index.
	 * 
	 *  @param tableModel the table model.
	 *  @param modelIndex the model index.
	 */
	public void updateFromTableModel(javax.swing.table.TableModel tableModel, int modelIndex) {
	}

	/**
	 *  Gets the table model. There is no setter for it. The table model is the one that pass in through the constructor
	 *  of PivotField.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.table.TableModel getTableModel() {
	}

	/**
	 *  Gets the column index in the table model. There is no setter for it. The model index is the one that pass in
	 *  through the constructor of PivotField.
	 * 
	 *  @return the column index.
	 */
	public int getModelIndex() {
	}

	/**
	 *  Gets the sort order.
	 * 
	 *  @return the sort order. True if ascending. False is descending. There is no unsorted option.
	 */
	public boolean isAscending() {
	}

	/**
	 *  Toggles the sort order.
	 */
	public void toggleAscending() {
	}

	/**
	 *  Sets the sort order. This method will call setSorted(true).
	 * 
	 *  @param ascending true or false.
	 */
	public void setAscending(boolean ascending) {
	}

	/**
	 *  Gets the flag indicating if this field is duplicated from another field.
	 * 
	 *  @return true if this field is duplicated. Otherwise false.
	 *  @since 3.3.8
	 */
	public boolean isDuplicated() {
	}

	/**
	 *  Sets the flag indicating if this field is duplicated from another field.
	 * 
	 *  @param duplicated the flag
	 *  @since 3.3.8
	 */
	public void setDuplicated(boolean duplicated) {
	}
}
