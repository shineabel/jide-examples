/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableFlashable</code> makes the <code>CellStyleTable</code> cells flashing as long as the
 *  <code>StyleModel</code>'s <code>getCellStyleAt</code> method return a {@link FlashCellStyle}.
 *  <p/>
 *  Here is a sample.
 *  <code><pre>
 *  TableFlashable flasher = new TableFlashable(_table, new FlashCellStyle[]{_flashCellStyle}, new
 *  int[]{0, 2});
 *  flasher.startFlashing();
 *  </pre></code>
 *  All flashing happened at the same pace so that it looks better when there are many cell flashing. The flash interval
 *  is determined by {@link #setInterval(int)} method. The flash style can be defined at using <code>setFlashStyle</code>
 *  of <code>FlashCellStyle</code>. Since the same <code>CellStyle</code> class is used, you can flash background,
 *  foreground, font, border, or even alignments.
 *  <p/>
 *  For performance consideration, you should predefine several <code>FlashCellStyle</code>'s and use them in
 *  <code>StyleModel</code>. You also need to pass the <code>FlashCellStyle</code> as an array to the constructor of
 *  <code>TableFlashable</code>.
 *  <p/>
 *  We also all your set specify which columns to flash if the flashing cells only appear at certain columns.
 */
public class TableFlashable extends Flashable {

	public static final int ALL_VISIBLE_CELLS = 0;

	public static final int ONLY_FLASH_CELLS = 1;

	public TableFlashable(CellStyleTable table, FlashCellStyle[] flashCellStyles) {
	}

	public TableFlashable(CellStyleTable table, FlashCellStyle[] flashCellStyles, int[] columns) {
	}

	/**
	 *  Gets the flash area.
	 * 
	 *  @return the flash area. It could be either {@link #ALL_VISIBLE_CELLS} or {@link #ONLY_FLASH_CELLS}.
	 */
	public int getFlashArea() {
	}

	/**
	 *  Sets the flash area. This give you a fine tuning over the performance. If you choose {@link #ALL_VISIBLE_CELLS},
	 *  we will repaint all visible cells of the possible columns (set using {@link #setPossibleFlashColumns(int[])}. If
	 *  the visible table cells are not many, this could have a better performance than {@link #ONLY_FLASH_CELLS}. If you
	 *  choose {@link #ONLY_FLASH_CELLS}, we will look at <code>StyleModel</code>s and see if <code>getCellStyleAt</code>
	 *  returns a <code>FlashCellStyle</code> and only repaint those cells. So compare with the two options, one might
	 *  paint cells that are not flashing. The other will take time to examine <code>StyleModel</code>. In
	 *  TableFlasherDemo, the two always have the same performance. You can decide which one to use based on the actual
	 *  situation in your application. In general, if your StyleModel's getCellStyleAt is expensive, try to use {@link
	 *  #ALL_VISIBLE_CELLS}. If your TableModel's getValueAt method is expensive, try to use {@link #ONLY_FLASH_CELLS}.
	 * 
	 *  @param flashArea the new flash area. It could be either {@link #ALL_VISIBLE_CELLS} or {@link #ONLY_FLASH_CELLS}.
	 */
	public void setFlashArea(int flashArea) {
	}

	/**
	 *  Gets the FlashCellStyles used by the StyleModel.
	 * 
	 *  @return the FlashCellStyles in use.
	 */
	public FlashCellStyle[] getFlashCellStyles() {
	}

	/**
	 *  Sets the FlashCellStyles in use.
	 * 
	 *  @param flashCellStyles the new FlashCellStyles.
	 */
	public void setFlashCellStyles(FlashCellStyle[] flashCellStyles) {
	}

	/**
	 *  @return the possible flash columns.
	 *  @deprecated replaced by {@link #getPossibleFlashColumns()}.
	 */
	@java.lang.Deprecated
	public int[] getPosisbleFlashColumns() {
	}

	/**
	 *  Gets the possible flash columns.
	 * 
	 *  @return the possible flash columns.
	 */
	public int[] getPossibleFlashColumns() {
	}

	/**
	 *  @param possibleFlashColumns the possible flash columns
	 *  @deprecated replaced by {@link #setPossibleFlashColumns(int[])}.
	 */
	@java.lang.Deprecated
	public void setPosisbleFlashColumns(int[] possibleFlashColumns) {
	}

	/**
	 *  Sets the possible flash columns.
	 * 
	 *  @param possibleFlashColumns the possible flash columns
	 */
	public void setPossibleFlashColumns(int[] possibleFlashColumns) {
	}

	@java.lang.Override
	public void flash() {
	}

	@java.lang.Override
	public void clearFlashing() {
	}
}
