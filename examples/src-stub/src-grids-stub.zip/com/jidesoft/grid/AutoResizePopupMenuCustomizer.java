/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>TableHeaderPopupMenuCustomizer</code> to auto resize a column or all columns. To use it, you can use the code
 *  like this.
 *  <code><pre>
 *  TableHeaderPopupMenuInstaller installer = new TableHeaderPopupMenuInstaller(aggregateTable)
 *  installer.addTableHeaderPopupMenuCustomizer(new AutoResizePopupMenuCustomizer());
 *  </pre></code>
 */
public class AutoResizePopupMenuCustomizer implements TableHeaderPopupMenuCustomizer {

	/**
	 *  CONTEXT_MENU_... are the possible menu names displayed in the menu. You can use these string as name to locate
	 *  the existing menu items.
	 * 
	 *  @see #customizePopupMenu(javax.swing.table.JTableHeader, javax.swing.JPopupMenu, int)
	 */
	public static final String CONTEXT_MENU_AUTO_RESIZE = "TableColumnChooser.autoResize";

	public static final String CONTEXT_MENU_AUTO_RESIZE_ALL = "TableColumnChooser.autoResizeAll";

	public AutoResizePopupMenuCustomizer() {
	}

	/**
	 *  Checks if we only consider the visible rows when resizing.
	 * 
	 *  @return true or false.
	 */
	public boolean isConsiderVisibleRowsOnly() {
	}

	/**
	 *  Sets the flag whether it should resize based on the visible rows only. This is to mimic the auto-resize behave in
	 *  Vista Explorer. It is helpful for the performance when there are a huge number of rows in the table.
	 * 
	 *  @param considerVisibleRowsOnly true if you want to the auto-resize to consider the visible rows only. False to
	 *                                 not consider.
	 */
	public void setConsiderVisibleRowsOnly(boolean considerVisibleRowsOnly) {
	}

	/**
	 *  Checks if we consider the table header when resizing.
	 * 
	 *  @return true or false.
	 */
	public boolean isConsiderTableHeader() {
	}

	/**
	 *  Sets the flag whether the table header is considered when resizing.
	 * 
	 *  @param considerTableHeader true if you want to the auto-resize to consider the table header preferred width.
	 *                             False to not consider.
	 */
	public void setConsiderTableHeader(boolean considerTableHeader) {
	}

	/**
	 *  Gets the minimum width of the columns.
	 * 
	 *  @return the minimum width.
	 */
	public int[] getMinimumWidth() {
	}

	/**
	 *  Sets the minimum width of each column. This is used when auto resizing the columns so that it will never go below
	 *  the specified minimum width.
	 * 
	 *  @param minimumWidth the new minimum width.
	 */
	public void setMinimumWidth(int[] minimumWidth) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "TableColumnChooser.".
	 * 
	 *  @param key the resource string key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  The method generates the context menu items by clickingColumn. After the process, the popup will contain all the
	 *  generated menu items. You can override the method to add some new menu items or delete some existing menu items
	 *  as you wish. You can use CONTEXT_MENU_... as the name to find the existing menu items.
	 *  <code><pre>
	 *       for (int i = 0; i < popup.getComponentCount(); i++) {
	 *           if (CONTEXT_MENU_AUTO_RESIZE.equals(popup.getComponent(i).getName())) {
	 *               popup.remove(popup.getComponent(i));
	 *           }
	 *       }
	 *  </pre></code>
	 * 
	 *  @param header         the table header
	 *  @param popup          the popup menu to be displayed
	 *  @param clickingColumn the column index clicked
	 */
	public void customizePopupMenu(javax.swing.table.JTableHeader header, javax.swing.JPopupMenu popup, int clickingColumn) {
	}

	/**
	 *  Gets the column name of the clicking column. By default, we use TableColumn#getHeaderValue but you can override
	 *  it to return a customized column name. This column name will be displayed on the "Auto Resize Column" menu item
	 *  if it is not null or empty.
	 * 
	 *  @param header         the table header.
	 *  @param clickingColumn the clicking column.
	 *  @return the column name of the clicking column.
	 */
	protected String getColumnName(javax.swing.table.JTableHeader header, int clickingColumn) {
	}
}
