/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The default wrapped row class used by ColumnTableModelWrapper.
 * 
 *  @since 3.4.1
 */
public class DefaultWrappedRow implements ExpandableRow, WrappedRow {

	/**
	 *  The constructor.
	 * 
	 *  @param wrapperModel the column wrapper table model
	 *  @param originalRow  the original row
	 */
	public DefaultWrappedRow(ColumnTableModelWrapper wrapperModel, ExpandableRow originalRow) {
	}

	public ExpandableRow getOriginalRow() {
	}

	@java.lang.Override
	public boolean isCellEditable(int columnIndex) {
	}

	@java.lang.Override
	public Object getValueAt(int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int columnIndex) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int columnIndex) {
	}

	@java.lang.Override
	public void cellUpdated(int columnIndex) {
	}

	@java.lang.Override
	public void rowUpdated() {
	}

	@java.lang.Override
	public int getLevel() {
	}

	@java.lang.Override
	public Expandable getParent() {
	}

	@java.lang.Override
	public void setParent(Expandable parent) {
	}

	@java.lang.Override
	public Node getPreviousSibling() {
	}

	@java.lang.Override
	public Node getNextSibling() {
	}

	@java.lang.Override
	public void notifyCellUpdated(Object child, int columnIndex) {
	}

	@java.lang.Override
	public boolean isExpanded() {
	}

	@java.lang.Override
	public void setExpanded(boolean expanded) {
	}

	@java.lang.Override
	public boolean isExpandable() {
	}

	@java.lang.Override
	public void setExpandable(boolean expandable) {
	}

	@java.lang.Override
	public boolean hasChildren() {
	}

	@java.lang.Override
	public void removeAllChildren() {
	}

	@java.lang.Override
	public int getChildrenCount() {
	}

	@java.lang.Override
	public int getAllVisibleChildrenCount() {
	}

	@java.lang.Override
	public java.util.List getChildren() {
	}

	@java.lang.Override
	public void setChildren(java.util.List children) {
	}

	@java.lang.Override
	public Object addChild(Object child) {
	}

	@java.lang.Override
	public Object addChild(int index, Object child) {
	}

	@java.lang.Override
	public void addChildren(int index, java.util.List children) {
	}

	@java.lang.Override
	public boolean removeChild(Object child) {
	}

	@java.lang.Override
	public boolean removeChildren(java.util.List children) {
	}

	@java.lang.Override
	public boolean moveUpChild(Object child) {
	}

	@java.lang.Override
	public boolean moveDownChild(Object child) {
	}

	@java.lang.Override
	public int getChildIndex(Object child) {
	}

	@java.lang.Override
	public Object getChildAt(int index) {
	}

	@java.lang.Override
	public int getNumberOfVisibleExpandable() {
	}

	@java.lang.Override
	public void notifyChildInserted(Object child, int childIndex) {
	}

	@java.lang.Override
	public void notifyChildrenInserted(java.util.List children, int firstIndex) {
	}

	@java.lang.Override
	public void notifyChildDeleted(Object child) {
	}

	@java.lang.Override
	public void notifyChildrenDeleted(java.util.List children) {
	}

	@java.lang.Override
	public void notifyChildUpdated(Object child) {
	}

	@java.lang.Override
	public void notifyChildrenUpdated(java.util.List children) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
