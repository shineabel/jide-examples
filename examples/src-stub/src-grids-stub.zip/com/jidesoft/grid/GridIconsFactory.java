/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A helper class to contain icons for JIDE Grids product.
 */
public class GridIconsFactory {

	public GridIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}

	public static class PropertyPane {


		public static final String CATEGORIED = "icons/category.gif";

		public static final String SORT = "icons/sort.gif";

		public static final String DESCRIPTION = "icons/description.gif";

		public static final String EXPAND = "icons/expand.gif";

		public static final String COLLAPSE = "icons/collapse.gif";

		public GridIconsFactory.PropertyPane() {
		}
	}

	public static class Table {


		public static final String FILTER = "icons/filter.png";

		public GridIconsFactory.Table() {
		}
	}
}
