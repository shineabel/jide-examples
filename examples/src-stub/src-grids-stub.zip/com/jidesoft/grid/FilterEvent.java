/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An <code>AWTEvent</code> that adds support for <code>Filter</code> objects as the event source.
 */
public class FilterEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>Filter</code> events.
	 */
	public static final int FILTER_EVENT_FIRST = 6999;

	/**
	 *  The last number in the range of IDs used for <code>Filter</code> events.
	 */
	public static final int FILTER_EVENT_LAST = 7002;

	/**
	 *  This event is delivered when the <code>Filter</code> is enabled.
	 */
	public static final int FILTER_ENABLED = 6999;

	/**
	 *  This event is delivered when the <code>Filter</code> is disabled.
	 */
	public static final int FILTER_DISABLED = 7000;

	/**
	 *  This event is delivered when the <code>Filter</code>'s name is changed.
	 */
	public static final int FILTER_NAME_CHANGED = 7001;

	/**
	 *  This event is delivered when the <code>Filter</code>'s filtering criteria is changed.
	 */
	public static final int FILTER_CONTENT_CHANGED = 7002;

	/**
	 *  Constructs an <code>FilterEvent</code> object.
	 * 
	 *  @param source the <code>Filter</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public FilterEvent(Object source, int id) {
	}
}
