/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell renderer that based on ListComboBox. It use EnumConverter. Please read the javadoc of {@link
 *  EnumCellEditor} for more information and code example.
 */
public class LegacyEnumCellRenderer extends com.jidesoft.combobox.ListComboBox implements javax.swing.table.TableCellRenderer {

	public LegacyEnumCellRenderer(EnumConverter enumConverter) {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	public EditorContext getContext() {
	}
}
