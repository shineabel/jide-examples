/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A GroupRow with summary values and information
 * 
 *  @since 3.6.0
 */
public class SummaryGroupRow extends DefaultGroupRow {

	public SummaryGroupRow() {
	}

	@java.lang.Override
	public Object getValueAt(int columnIndex) {
	}

	protected void addValueRecursively(TreeTableModel treeTableModel, SummaryCalculator calculator, ExpandableRow row, int columnIndex) {
	}

	protected boolean shouldShowSummary(TreeTableModel treeTableModel, int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int columnIndex) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int columnIndex) {
	}

	@java.lang.Override
	public void setExpanded(boolean expanded) {
	}

	public void invalidateSummaryCache() {
	}
}
