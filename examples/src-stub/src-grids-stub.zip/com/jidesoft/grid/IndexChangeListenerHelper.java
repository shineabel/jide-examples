/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default listener for index changing. It's used as default table model wrapper listener
 *  and default list model wrapper listener
 *  @since 3.4.4
 */
public class IndexChangeListenerHelper implements IndexChangeListener, java.io.Serializable {

	public IndexChangeListenerHelper(IndexChangeEventGenerator listenerGenerator) {
	}

	/**
	 *  Called whenever the model wrapper is going to have some change. So far we have index changing and index
	 *  changed events.
	 *  <p/>
	 *  Please make sure you will NOT call super.ModelWrapperIndexChanged(), otherwise you will get into a endless
	 *  loop.
	 * 
	 *  @param event the model wrapper event
	 */
	public void indexChanged(IndexChangeEvent event) {
	}

	public int fireIndexChangeEvent(Object source, int eventType, int eventSerialNumber, boolean forceProcess, boolean actualIndexChanged) {
	}

	public int getEventSerialNumber() {
	}

	public void setEventSerialNumber(int eventSerialNumber) {
	}
}
