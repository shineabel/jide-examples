/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The cell renderer for the drop down of <code>AutoFilterBox</code> and <code>QuickFilterPane</code>'s JLists.
 */
public class FilterListCellRenderer extends javax.swing.DefaultListCellRenderer implements javax.swing.SwingConstants {

	public static EditorContext CONTEXT_SENSITIVE_CONTEXT;

	/**
	 *  Creates a context sensitive cell renderer.
	 */
	public FilterListCellRenderer() {
	}

	public FilterListCellRenderer(Class clazz) {
	}

	/**
	 *  Creates a context sensitive cell renderer using the converter context.
	 * 
	 *  @param context converter context
	 */
	public FilterListCellRenderer(ConverterContext context) {
	}

	/**
	 *  Creates a context sensitive cell renderer using specified type and the converter context.
	 * 
	 *  @param clazz   type
	 *  @param context converter context
	 */
	public FilterListCellRenderer(Class clazz, ConverterContext context) {
	}

	@java.lang.Override
	public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	}

	public String convertElementToString(javax.swing.JList list, Object value) {
	}

	public String convertElementToString(java.util.Locale locale, Object value) {
	}

	/**
	 *  Sets the converter context.
	 * 
	 *  @param context converter context
	 */
	public void setConverterContext(ConverterContext context) {
	}

	/**
	 *  Gets the converter context.
	 * 
	 *  @return converter context
	 */
	public ConverterContext getConverterContext() {
	}

	/**
	 *  Sets the editor context.
	 * 
	 *  @param context editor context
	 *  @since 3.1.0
	 */
	public void setEditorContext(EditorContext context) {
	}

	/**
	 *  Gets the editor context.
	 * 
	 *  @return editor context
	 *  @since 3.1.0
	 */
	public EditorContext getEditorContext() {
	}

	/**
	 *  Sets the table.
	 * 
	 *  @param table table
	 *  @since 3.1.0
	 */
	public void setTable(javax.swing.JTable table) {
	}

	/**
	 *  Gets the table.
	 * 
	 *  @return the table
	 *  @since 3.1.0
	 */
	public javax.swing.JTable getTable() {
	}

	/**
	 *  Sets the column index in the table.
	 * 
	 *  @param columnIndex table column index
	 *  @since 3.1.0
	 */
	public void setColumnIndex(int columnIndex) {
	}

	/**
	 *  Gets the column index in the table.
	 * 
	 *  @return the table column index
	 *  @since 3.1.0
	 */
	public int getColumnIndex() {
	}

	public Class getType() {
	}

	public void setType(Class clazz) {
	}
}
