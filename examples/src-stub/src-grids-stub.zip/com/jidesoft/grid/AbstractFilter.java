/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This abstract class provides default implementations for most of the methods in the <code>Filter</code> interface. It
 *  takes care of the management of listeners and provides some conveniences for generating <code>FilterEvent</code> and
 *  dispatching them to the listeners. To create a concrete <code>Filter</code> as a subclass of
 *  <code>AbstractTableModel</code> you need only provide implementations for the following one methods:
 *  <pre>
 *   public boolean isValueFiltered();
 *   </pre>
 * 
 *  @deprecated The class is moved to com.jidesoft.filter. Please update your code to use this one under
 *              com.jidesoft.filter instead.
 */
@java.lang.Deprecated
public abstract class AbstractFilter extends com.jidesoft.filter.AbstractFilter {

	protected AbstractFilter() {
	}

	protected AbstractFilter(String name) {
	}
}
