/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A table cell editor/renderer that can display a hyperlink as cell. You can call {@link
 *  #setActionListener(java.awt.event.ActionListener)} to set the action listener which will be triggered when the
 *  hyperlink is clicked. To make it working, you not only need to set it as the renderer and editor for the cell, but
 *  also need to call RolloverTableUtils.install method to enable the auto cell editing feature when mouse rollover.
 * 
 *  @see RolloverTableUtils
 */
public class HyperlinkTableCellEditorRenderer extends ButtonTableCellEditorRenderer {

	public HyperlinkTableCellEditorRenderer() {
	}

	public HyperlinkTableCellEditorRenderer(ConverterContext context) {
	}

	@java.lang.Override
	public java.awt.Component createTableCellEditorRendererComponent(javax.swing.JTable table, int row, int column) {
	}
}
