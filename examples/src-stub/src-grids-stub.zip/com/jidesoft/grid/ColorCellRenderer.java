/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellRenderer for Color.
 */
public class ColorCellRenderer extends ContextSensitiveCellRenderer {

	public static final String PROPERTY_COLOR_VALUE_VISIBLE = "colorValueVisible";

	public static final String PROPERTY_COLOR_ICON_VISIBLE = "colorIconVisible";

	public ColorCellRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Checks if the color value is displayed.
	 * 
	 *  @return true if the color value is displayed.
	 */
	public boolean isColorValueVisible() {
	}

	/**
	 *  Show or hide the color value. The color value is the text that is displayed after the color icon.
	 *  <p/>
	 *  Please note, you shouldn't call setColorValueVisible(false) and setColorIconVisible(false). If you do that, we
	 *  will display both color value and color icon.
	 * 
	 *  @param colorValueVisible true if the color value is visible
	 */
	public void setColorValueVisible(boolean colorValueVisible) {
	}

	/**
	 *  Checks if the color icon is displayed.
	 * 
	 *  @return true if the color icon is displayed.
	 */
	public boolean isColorIconVisible() {
	}

	/**
	 *  Show or hide the color icon. The color icon is at the beginning of the ColorComboBox where a color rectangle is
	 *  painted.
	 *  <p/>
	 *  Please note, you shouldn't call setColorValueVisible(false) and setColorIconVisible(false). If you do that, we
	 *  will display both color value and color icon.
	 * 
	 *  @param colorIconVisible true if the color value is visible
	 */
	public void setColorIconVisible(boolean colorIconVisible) {
	}

	/**
	 *  Get the flag if ColorComboBox should still draw a cross in the color label
	 *  <p/>
	 *  The default value now is false. But if you want to switch back to the original UI, you can set this flag to
	 *  false.
	 * 
	 *  @return true if you want to switch back to the original cross back ground.
	 */
	public boolean isCrossBackGroundStyle() {
	}

	/**
	 *  Set the flag if ColorComboBox should still draw a cross in the color label
	 *  <p/>
	 *  The default value now is false. But if you want to switch back to the original UI, you can set this flag to
	 *  false.
	 * 
	 *  @param crossBackGroundStyle true if you want to switch back to the original cross back ground
	 */
	public void setCrossBackGroundStyle(boolean crossBackGroundStyle) {
	}

	/**
	 *  The color label component to paint the selected color.
	 */
	public class ColorIcon {


		public ColorCellRenderer.ColorIcon() {
		}

		public java.awt.Color getColor() {
		}

		public void setColor(java.awt.Color color) {
		}

		@java.lang.Override
		public void paintIcon(java.awt.Component c, java.awt.Graphics g, int x, int y) {
		}

		@java.lang.Override
		public int getIconWidth() {
		}

		@java.lang.Override
		public int getIconHeight() {
		}
	}
}
