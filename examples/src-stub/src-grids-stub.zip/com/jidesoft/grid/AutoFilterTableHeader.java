/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AutoFilterTableHeader</code> implements auto-filter feature. Each column header has a combobox-like control to
 *  allow user selecting certain values to be filtered from the list. The list contains the possible values for that
 *  column as well as other customized items. Each item represents a <code>Filter</code> class that will be added to
 *  <code>FilterableTableModel</code> when selected.
 *  <p/>
 *  <code>AutoFilterTableHeader</code> works with any <code>FilterableTableModel</code>. If the table passed to the
 *  constructor of AutoFilterTableHeader already defined a FilterableTableModel, it will use that FilterableTableModel.
 *  Otherwise, it will create a new FilterableTableModel, wrapping the current table's table model and reset the table's
 *  table model to the newly created FilterableTableModel.
 *  <p/>
 *  There are three kinds of Filters AutoFilterTableHeader will use. They are {@link
 *  com.jidesoft.grid.SingleValueFilter}, {@link com.jidesoft.grid.MultipleValuesFilter} and {@link
 *  com.jidesoft.grid.DynamicTableFilter}. When {@link #isAllowMultipleValues()} returns false and user selects a value
 *  from AutoFilterTableHeader's drop down value list, SingleValueFilter will be created and added to that column as the
 *  filter. DynamicTableFilter could also be used in this case when you call {@link
 *  com.jidesoft.grid.AutoFilterBox#addDynamicTableFilter(DynamicTableFilter)}. This method call will add new custom
 *  filter to the header which will appear as a new item under "All" item in the drop down value list. If {@link
 *  #isAllowMultipleValues()} returns true, MultipleValuesFilter will be the only filter that is used to allow multiple
 *  values as the filter values.
 *  <p/>
 *  <code>AutoFilterTableHeader</code> also detects filters added outside AutoFilterTableHeader. For example, if
 *  isAllowMultipleValues returns false, you can add a SingleValueFilter to the column, or if isAllowMultipleValues
 *  returns true, you can add a MultipleValuesFilter. After you did it, AutoFilterTableHeader will automatically update
 *  the display to show a filter name or filter name to indicate the column has a filter.
 */
public class AutoFilterTableHeader extends EditableTableHeader implements FilterableTableModelListener, java.beans.PropertyChangeListener {

	protected IFilterableTableModel _filterableTableModel;

	protected boolean _autoFilterEnabled;

	public static final String PROPERTY_ACCEPT_TEXT_INPUT = "acceptTextInput";

	public static final String PROPERTY_USE_NATIVE_CELL_RENDERER = "useNativeCellRenderer";

	public static final String PROPERTY_AUTO_FILTER_ENABLED = "autoFilterEnabled";

	public static final String PROPERTY_FILTER_FACTORY_MANAGER = "filterFactoryManager";

	/**
	 *  Set this client property to choose a specific editor.
	 *  If this client property is set to {@link AutoFilterTableHeader#CUSTOM_FILTER_EDITOR_TYPE_TABLE_CUSTOM_FILTER_EDITOR}, TableCustomFIlterEditor will be used.
	 *  Otherwise, CustomFilterEditor will be used
	 *  @since 3.4.3
	 */
	public static final String CLIENT_PROPERTY_CUSTOM_FILTER_EDITOR_TYPE = "customFilterEditorType";

	public static final String CUSTOM_FILTER_EDITOR_TYPE_TABLE_CUSTOM_FILTER_EDITOR = "TableCustomFilterEditor";

	/**
	 *  The constructor.
	 * 
	 *  @param columnModel the column model
	 *  @since 3.1.0
	 */
	protected AutoFilterTableHeader(javax.swing.table.TableColumnModel columnModel) {
	}

	/**
	 *  Creates <code>AutoFilterTableHeader</code>. By default, rollover is enabled.
	 * 
	 *  @param table the table to install this <code>AutoFilterTableHeader</code>. The table model of this table could be
	 *               <code>FilterableTableModel</code> or if it is a TableModelWrapper, it could have a nested
	 *               <code>FilterableTableModel</code>. In either case, we will use the <code>FilterableTableModel</code>
	 *               and add filters to it. If there is no <code>FilterableTableModel</code>, we will create one and wrap
	 *               it around the table model returned from <code>table.getModel()</code>. If so, after creating the
	 *               <code>AutoFilterTableHeader</code>, <code>table.getModel()</code> will return a
	 *               <code>FilterableTableModel</code>. <code>FilterableTableModel</code>'s <code>getActualModel()</code>
	 *               will be the old tableModel.
	 */
	public AutoFilterTableHeader(javax.swing.JTable table) {
	}

	/**
	 *  Creates a TableHeaderCellDecorator instance to paint the filter button and icon.
	 * 
	 *  @return a FilterableTableHeaderCellDecorator instance.
	 *  @since 3.1.0
	 */
	protected TableHeaderCellDecorator createFilterableTableHeaderCellDecorator() {
	}

	/**
	 *  Gets the TableHeaderCellDecorator instance to paint the filter button and icon.
	 * 
	 *  @return a FilterableTableHeaderCellDecorator instance.
	 */
	public TableHeaderCellDecorator getFilterableTableHeaderCellDecorator() {
	}

	@java.lang.Override
	public void setTable(javax.swing.JTable table) {
	}

	/**
	 *  Returns a string that specifies the name of the UIDelegate class that paints this component.
	 * 
	 *  @return the string "TableHeader.autoFilterTableHeaderUIDelegate"
	 *  @since 3.1.0
	 */
	public String getUIDelegateClassID() {
	}

	public String getActualUIClassID() {
	}

	/**
	 *  Gets the header renderer for auto filter feature.
	 * 
	 *  @return default renderer if {@link #isUseNativeHeaderRenderer()} returns true. Otherwise returns {@link
	 *          AutoFilterTableHeaderRenderer}
	 *  @since 3.1.0
	 */
	public javax.swing.table.TableCellRenderer getAutoFilterTableHeaderRenderer() {
	}

	/**
	 *  Overrides to create an <code>AutoFilterTableHeaderRenderer</code>. Below is the default code in case you need to
	 *  override it to you create your own renderer.
	 *  <code><pre>
	 *  if (isAutoFilterEnabled() && !isUseNativeHeaderRenderer()) {
	 *      return new AutoFilterTableHeaderRenderer(){
	 *          protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	 *              super.customizeAutoFilterBox(autoFilterBox);
	 *              AutoFilterTableHeader.this.customizeAutoFilterBox(autoFilterBox);
	 *              autoFilterBox.applyComponentOrientation(AutoFilterTableHeader.this.getComponentOrientation());
	 *          }
	 *      };
	 *  }
	 *  else {
	 *      return super.createDefaultRenderer();
	 *  }
	 *  </pre></code>
	 * 
	 *  @return an <code>AutoFilterTableHeaderRenderer</code>.
	 */
	@java.lang.Override
	protected javax.swing.table.TableCellRenderer createDefaultRenderer() {
	}

	/**
	 *  Overrides to create an <code>AutoFilterTableHeaderEditor</code>. Below is the default code in case you need to
	 *  override it to you create your own editor.
	 *  <code><pre>
	 *  if (isAutoFilterEnabled()) {
	 *     return new AutoFilterTableHeaderEditor() {
	 *         protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	 *             autoFilterBox.applyComponentOrientation(AutoFilterTableHeader.this.getComponentOrientation());
	 *             super.customizeAutoFilterBox(autoFilterBox);
	 *             AutoFilterTableHeader.this.customizeAutoFilterBox(autoFilterBox);
	 *         }
	 *      };
	 *  }
	 *  else {
	 *      return null;
	 *  }
	 *  </pre></code>
	 * 
	 *  @return an <code>AutoFilterTableHeaderEditor</code>.
	 */
	@java.lang.Override
	protected javax.swing.table.TableCellEditor createDefaultEditor() {
	}

	@java.lang.Override
	public boolean isCellEditable(int columnIndex) {
	}

	@java.lang.Override
	public void editingStopped(javax.swing.event.ChangeEvent e) {
	}

	/**
	 *  Customizes the <code>AutoFilterBox</code>.
	 *  <p/>
	 *  Please be noted that this method will only be invoked if {@link #isUseNativeHeaderRenderer()} returns false.
	 * 
	 *  @param autoFilterBox the AutoFilterBox created by {@link AutoFilterTableHeaderRenderer} or {@link
	 *                       AutoFilterTableHeaderEditor}.
	 */
	protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	}

	/**
	 *  Initializes the table.
	 * 
	 *  @param table the table which is passed in as parameter of the constructor {@link
	 *               #AutoFilterTableHeader(javax.swing.JTable)}.
	 */
	protected void initTable(javax.swing.JTable table) {
	}

	@java.lang.Override
	public void columnMarginChanged(javax.swing.event.ChangeEvent e) {
	}

	/**
	 *  This method will be called when TableModel on JTable is changed.
	 * 
	 *  @param table the table
	 */
	protected void tableModelChanged(javax.swing.JTable table) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	public void filterableTableModelChanged(FilterableTableModelEvent event) {
	}

	/**
	 *  Creates the <code>FilterableTableModel</code> to be used by {@link AutoFilterTableHeader}. It returns null by
	 *  default. You can override it to create your own <code>FilterableTableModel</code>.
	 * 
	 *  @param model the table model.
	 *  @return the <code>FilterableTableModel</code>.
	 */
	protected IFilterableTableModel createFilterableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Creates the <code>FilterableTableModel</code>.
	 * 
	 *  @param model the table model.
	 *  @return the <code>FilterableTableModel</code>.
	 */
	protected IFilterableTableModel createDefaultFilterableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the <code>FilterableTableModel</code> used by this <code>AutoFilterTableHeader</code>.
	 *  <p/>
	 *  Please be noted that, this method could return null since 3.1.0 when isAutoFilterEnabled() returns false.
	 * 
	 *  @return the <code>FilterableTableModel</code>.
	 */
	public IFilterableTableModel getFilterableTableModel() {
	}

	/**
	 *  Clears all filters created by the <code>AutoFilterTableHeader</code>. Please note, this method only clears all the
	 *  filters created by AutoFilterTableHeader but does NOT refresh the data. It will NOT clear any filter that is NOT
	 *  created by AutoFilterTableHeader. You still need to call <code>AutoFilterTableHeader#getFilterableTableModel().refresh()</code>
	 *  after this call to refresh the table.
	 */
	public void clearFilters() {
	}

	/**
	 *  Gets the flag indicating if auto filter feature is enabled for the entire header.
	 *  <p/>
	 *  By default, the flag is false.
	 * 
	 *  @return true if auto filter feature is enabled. Otherwise false.
	 */
	public boolean isAutoFilterEnabled() {
	}

	/**
	 *  Sets the flag indicating if auto filter feature is enabled for the entire header.
	 * 
	 *  @param autoFilterEnabled the flag
	 */
	public void setAutoFilterEnabled(boolean autoFilterEnabled) {
	}

	/**
	 *  Checks if the filter name is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterName() {
	}

	/**
	 *  Sets the flag if the filter name is shown on the title.
	 * 
	 *  @param showFilterName true to show the filter name. False to not show it.
	 */
	public void setShowFilterName(boolean showFilterName) {
	}

	/**
	 *  Checks if the filter name is displayed as tooltip on the table header.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowFilterNameAsToolTip() {
	}

	/**
	 *  Sets the flag if the filter name is displayed as tooltip on the table header.
	 * 
	 *  @param showFilterNameAsToolTip true to show the filter name as tooltip. False to not show it.
	 */
	public void setShowFilterNameAsToolTip(boolean showFilterNameAsToolTip) {
	}

	/**
	 *  Checks if the filter icon is visible on the box as part of the title.
	 * 
	 *  @return true or false.
	 *  @see #setShowFilterIcon(boolean)
	 */
	public boolean isShowFilterIcon() {
	}

	/**
	 *  Sets the flag if the filter icon is shown on the title.
	 *  <p/>
	 *  Please be noted that if {@link #isUseNativeHeaderRenderer()} returns true, it means that the filter icon will
	 *  always be painted on the header. If {@link #isUseNativeHeaderRenderer()} returns false, it means that if there is
	 *  a filter, if a filter icon should be painted on the header.
	 *  <p/>
	 *  Right now, we support show the icon directly while the header value is an instance of Icon. If you set the header
	 *  value to icon and {@link #isUseNativeHeaderRenderer()} returns false, this flag will not be respected.
	 * 
	 *  @param showFilterIcon true to show the filter icon. False to not show it.
	 */
	public void setShowFilterIcon(boolean showFilterIcon) {
	}

	/**
	 *  Sets the flag if the sort arrow is shown on the header.
	 * 
	 *  @param showSortArrow true to show the sort arrow. False to not show it.
	 */
	public void setShowSortArrow(boolean showSortArrow) {
	}

	/**
	 *  Checks if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will be to
	 *  use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 *  <p/>
	 *  Please be noted that the column index is in view level since the interface is provided in AutoFilterTableHeader.
	 *  Make sure you will convert it to model level while overriding this method.
	 * 
	 *  @param columnIndex the visual column index.
	 *  @return true or false.
	 */
	public boolean isAllowMultipleValues(int columnIndex) {
	}

	/**
	 *  Checks if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will be to
	 *  use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 * 
	 *  @return true or false.
	 */
	public boolean isAllowMultipleValues() {
	}

	/**
	 *  Set the flag if the <code>AutoFilterTableHeader</code> allows multiple values as the filter. The difference will
	 *  be to use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 *  <p/>
	 *  Please note, call this method will clear all filters that were added before.
	 * 
	 *  @param allowMultipleValues true to allow multiple value filters. False to disallow it. Default is false.
	 */
	public void setAllowMultipleValues(boolean allowMultipleValues) {
	}

	/**
	 *  Get the flag indicating if selected possible values will be used or filtered possible values.
	 *  <p/>
	 *  This flag is valid only if {@link #isAllowMultipleValues()} return true.
	 *  <p/>
	 *  The default value is false which is different from the behavior before 2.9.0. In this way, if you input a new
	 *  record to the target table, the new record will stay. If you want the new record to be filtered away, please try
	 *  to set this flag to true.
	 * 
	 *  @return true if the selected possible values will be used. Otherwise false.
	 *  @see #isAllowMultipleValues()
	 */
	public boolean isPreferSelectedValues() {
	}

	/**
	 *  Set the flag indicating if selected possible values will be used or filtered possible values.
	 * 
	 *  @param preferSelectedPossibleValues the flag
	 *  @see #isPreferSelectedValues()
	 */
	public void setPreferSelectedValues(boolean preferSelectedPossibleValues) {
	}

	@java.lang.Override
	protected boolean isAutoRequestFocus() {
	}

	/**
	 *  Gets the FilterableTableModel used by the AutoFilterBox. By default, we will return {@link
	 *  #getFilterableTableModel()} which means all AutoFilterBoxes will use the same filter table model. If for whatever
	 *  reason you need to use different instances for different AutoFilterBox, you can create a new FilterableTableModel
	 *  and return.
	 * 
	 *  @param box the AutoFilterBox who will use the IFilterableTableModel returned from this method.
	 *  @return IFilterableTableModel.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected IFilterableTableModel getFilterableTableModel(AutoFilterBox box) {
	}

	/**
	 *  Gets the flag indicating if this header accepts text input.
	 *  <p/>
	 *  Please be noted that this method will always return false if {@link #isUseNativeHeaderRenderer()} returns true.
	 * 
	 *  @return true if text input is accepted. Otherwise false.
	 *  @see #setAcceptTextInput(boolean)
	 */
	public boolean isAcceptTextInput() {
	}

	/**
	 *  Sets the flag indicating if the header accepts text input.
	 *  <p/>
	 *  Please be noted that this method will take effect only if {@link #isUseNativeHeaderRenderer()} returns false.
	 *  <p/>
	 *  By default, the value is false to minimize the height of the header. You could set it to true if you want to let
	 *  your customer to input text in this header. However, the height of the header would be bigger.
	 * 
	 *  @param acceptTextInput the flag
	 */
	public void setAcceptTextInput(boolean acceptTextInput) {
	}

	/**
	 *  Gets the flag indicating if the native header renderer will be used.
	 * 
	 *  @return true if the native header renderer will be used. false if AutoFilterBox will be used.
	 *  @see #setUseNativeHeaderRenderer(boolean)
	 *  @since 3.1.0
	 */
	public boolean isUseNativeHeaderRenderer() {
	}

	/**
	 *  Sets the flag indicating if the native header renderer will be used.
	 *  <p/>
	 *  By default, the flag is false to keep backward compatibility. setting this flag to true would make the
	 *  AutoFilterTableHeader use the same header renderer as system default. However, it will break the backward
	 *  compatibility if you ever tried to override AutoFilterBox. If you have any backward compatibility concern, please
	 *  set this flag to false.
	 * 
	 *  @param useNativeHeaderRenderer the flag
	 *  @since 3.1.0
	 */
	public void setUseNativeHeaderRenderer(boolean useNativeHeaderRenderer) {
	}

	@java.lang.Override
	public boolean isRolloverEnabled() {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Get formatted column name based on current filters for header and tooltip text.
	 * 
	 *  @param columnIndex the view column index in the header
	 *  @return the text after formatted. null if no need to display a tooltip text or change the column name.
	 *  @since 3.1.0
	 */
	public String getFormattedColumnName(int columnIndex) {
	}

	/**
	 *  Formats the string when the filter name is displayed. By default, we will display the column name first, followed
	 *  by ": " then the filter name.
	 * 
	 *  @param modelIndex the model column index
	 *  @param columnName the name for the column.
	 *  @param filters    the filters on the column
	 *  @return the string after formatted.
	 *  @since 3.1.0
	 */
	protected String formatColumnTitle(int modelIndex, String columnName, com.jidesoft.filter.Filter[] filters) {
	}

	/**
	 *  Gets the filter icon to be painted in the AutoFilterTableHeader if {@link #isUseNativeHeaderRenderer()} returns true.
	 * 
	 *  @param columnIndex        the column index
	 *  @param mouseOverPaintArea if the mouse is currently over this column
	 *  @param hasFilter          if the column currently has filter
	 *  @return the image icon to be painted.
	 *  @since 3.4.1
	 */
	protected javax.swing.ImageIcon getFilterIcon(int columnIndex, boolean mouseOverPaintArea, boolean hasFilter) {
	}
}
