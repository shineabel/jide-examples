/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose values from a tree. It used CheckBoxTreeExComboBox as the editor.
 *  <p/>
 *  To let the CheckBoxTreeComboBoxCellEditor work well with a custom class other than String.class, please first register an
 *  ObjectConverter for that class and register a CheckBoxTreeComboBoxCellEditor for the class with the following code. While
 *  constructing the tree nodes, please make sure ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject()
 *  is an instance of the custom class.
 *  <code><pre>
 *       CellEditorManager.registerEditor(ConnectItem.class, new CellEditorFactory() {
 *           public CellEditor create() {
 *               return new CheckBoxTreeComboBoxCellEditor(getDefaultTreeModel()) {
 *                   protected TreeExComboBox createTreeComboBox() {
 *                       CheckBoxTreeComboBoxCellEditor treeComboBox = new CheckBoxTreeComboBoxCellEditor() {
 *                           protected TreeChooserPanel createTreeChooserPanel(TreeModel model) {
 *                               TreeChooserPanel panel = super.createTreeChooserPanel(model);
 *                               panel.setSearchUserObjectToSelect(true);
 *                               return panel;
 *                           }
 *                       };
 *                       treeComboBox.setEditable(false);
 *                       treeComboBox.setType(YourCustomClass.class);
 *                       return treeComboBox;
 *                   }
 *               };
 *           }
 *       }, new EditorContext("Tree"));
 *  </pre></code>
 */
public class CheckBoxTreeComboBoxCellEditor extends ExComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	public CheckBoxTreeComboBoxCellEditor() {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public CheckBoxTreeComboBoxCellEditor(Object[] objects) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public CheckBoxTreeComboBoxCellEditor(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public CheckBoxTreeComboBoxCellEditor(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeComboBoxCellEditor</code>.
	 * 
	 *  @param root the tree root node
	 */
	public CheckBoxTreeComboBoxCellEditor(javax.swing.tree.TreeNode root) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeComboBoxCellEditor</code>.
	 * 
	 *  @param root               the tree root node
	 *  @param asksAllowsChildren the flag indicating if allows children
	 */
	public CheckBoxTreeComboBoxCellEditor(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	/**
	 *  Creates a new <code>CheckBoxTreeComboBoxCellEditor</code>.
	 * 
	 *  @param model the tree model
	 */
	public CheckBoxTreeComboBoxCellEditor(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}
}
