/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>TableHeaderPopupMenuCustomizer</code> for <code>AggregateTable</code>. To use it, you can use the code like
 *  this.
 *  <code><pre>
 *  TableHeaderPopupMenuInstaller installer = new TableHeaderPopupMenuInstaller(aggregateTable)
 *  installer.addTableHeaderPopupMenuCustomizer(new AggregateTablePopupMenuCustomizer());
 *  </pre></code>
 *  The <code>AggregateTablePopupMenuCustomizer</code> will add the "Group", "Ungroup", "Expand" and "Collapse" etc menu
 *  items to the popup menu.
 */
public class GroupTablePopupMenuCustomizer implements TableHeaderPopupMenuCustomizer {

	/**
	 *  CONTEXT_MENU_... are the possible menu names displayed in the menu. You can use these string as name to locate
	 *  the existing menu items.
	 * 
	 *  @see #customizePopupMenu(javax.swing.table.JTableHeader, javax.swing.JPopupMenu, int)
	 */
	public static final String CONTEXT_MENU_UNGROUP = "GroupTable.ungroup";

	public static final String CONTEXT_MENU_GROUP = "GroupTable.group";

	public static final String CONTEXT_MENU_SUMMARY = "GroupTable.summary";

	public static final String CONTEXT_MENU_EXPAND = "GroupTable.expandColumn";

	public static final String CONTEXT_MENU_COLLAPSE = "GroupTable.collapseColumn";

	public static final String CONTEXT_MENU_EXPAND_ALL = "GroupTable.expandAll";

	public static final String CONTEXT_MENU_COLLAPSE_ALL = "GroupTable.collapseAll";

	public GroupTablePopupMenuCustomizer() {
	}

	/**
	 *  Gets the grouped columns. By default, all columns are groupable but you can use {@link
	 *  #setGroupableColumns(int[])} to set the columns.
	 * 
	 *  @return the groupable columns.
	 */
	public int[] getGroupableColumns() {
	}

	/**
	 *  Sets the groupable columns. Only columns included in the array is allowed to be grouped.
	 * 
	 *  @param groupableColumns the groupable columns
	 */
	public void setGroupableColumns(int[] groupableColumns) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "GroupTable.".
	 * 
	 *  @param key the resource string key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  The method generates the context menu items by clickingColumn. After the process, the popup will contain all the
	 *  generated menu items. You can override the method to add some new menu items or delete some existing menu items
	 *  as you wish. You can use CONTEXT_MENU_... as the name to find the existing menu items.
	 *  <code><pre>
	 *       for (int i = 0; i < popup.getComponentCount(); i++) {
	 *           if (CONTEXT_MENU_UNGROUP.equals(popup.getComponent(i).getName())) {
	 *               popup.remove(popup.getComponent(i));
	 *           }
	 *       }
	 *  </pre></code>
	 * 
	 *  @param header         the table header
	 *  @param popup          the popup menu to be displayed
	 *  @param clickingColumn the column index clicked
	 */
	public void customizePopupMenu(javax.swing.table.JTableHeader header, javax.swing.JPopupMenu popup, int clickingColumn) {
	}
}
