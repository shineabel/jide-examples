/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface used to calculate the summary for the group table. It extends the {@link SummaryCalculator}.
 *  <p/>
 *  This interface added extra parameters (such as TableModel and Row) to addValue methods in case the summary
 *  calculation needs to know about it. However in our default implementation, these extra parameters are not used.
 */
public interface GroupTableSummaryCalculator extends SummaryCalculator {

	/**
	 *  Adds a value for calculation. Different from {@link #addValue(Object)} which only takes the value as parameter,
	 *  this method provides TableModel, Row and the column index of the cell as in the DefaultGroupTableModel.
	 * 
	 *  @param model       the table model. It should be the DefaultGroupTableModel in the case of GroupTable.
	 *  @param row
	 *  @param columnIndex
	 *  @param value       the value
	 */
	public void addValue(javax.swing.table.TableModel model, Row row, int columnIndex, Object value);
}
