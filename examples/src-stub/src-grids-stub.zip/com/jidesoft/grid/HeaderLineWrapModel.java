/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The table model interface to provide line wrap properties for its table header.
 * 
 *  @since 3.3.4
 */
public interface HeaderLineWrapModel {

	/**
	 *  Gets the preferred row count for the column.
	 * 
	 *  @param column the column index
	 *  @return the preferred row count.
	 */
	public int getPreferredRows(int column);

	/**
	 *  Gets the maximum row count for the column.
	 * 
	 *  @param column the column index
	 *  @return the maximum row count.
	 */
	public int getMaximumRows(int column);

	/**
	 *  Gets the minimum row count for the column.
	 * 
	 *  @param column the column index
	 *  @return the minimum row count.
	 */
	public int getMinimumRows(int column);

	/**
	 *  Gets the preferred width the column. -1 if you don't care.
	 * 
	 *  @param column the column index
	 *  @return the preferred width.
	 */
	public int getPreferredWidth(int column);
}
