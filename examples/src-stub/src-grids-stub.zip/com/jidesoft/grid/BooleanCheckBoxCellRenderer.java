/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellRenderer for Boolean. There are two ways to display a boolean in JTable - using JCheckBox or JComboBox. This
 *  class is the implementation using JCheckBox. By default, it will use the default cell renderer which uses a text to
 *  indicate true or false. If you want to use JCheckBox, you just need to specify the EditorContext as {@link
 *  BooleanCheckBoxCellEditor#CONTEXT}.
 *  <p/>
 *  The check box is center aligned by default. If you want to make it left aligned, you can use the code below to change
 *  it.
 *  <code><pre>
 *  CellRendererManager.initDefaultRenderer();
 *  BooleanCheckBoxCellRenderer renderer = new BooleanCheckBoxCellRenderer();
 *  renderer.setHorizontalAlignment(SwingConstants.LEFT);
 *  CellRendererManager.registerRenderer(Boolean.class, renderer, BooleanCheckBoxCellEditor.CONTEXT);
 *  CellRendererManager.registerRenderer(boolean.class, renderer, BooleanCheckBoxCellEditor.CONTEXT);
 *  </code></pre>
 */
public class BooleanCheckBoxCellRenderer extends javax.swing.JCheckBox implements javax.swing.table.TableCellRenderer {

	public static final EditorContext CONTEXT;

	public BooleanCheckBoxCellRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}
}
