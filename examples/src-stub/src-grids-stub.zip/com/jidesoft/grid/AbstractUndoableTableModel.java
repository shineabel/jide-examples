/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Abstract undoable table model that extends AbstractTableModel.
 * 
 *  @since 3.3.4
 */
public abstract class AbstractUndoableTableModel extends javax.swing.table.AbstractTableModel implements TableUndoableSupport {

	/**
	 *  The Constructor.
	 */
	public AbstractUndoableTableModel() {
	}

	/**
	 *  Returns true. This is the default implementation for all cells since it's an undoable model.
	 * 
	 *  @param  rowIndex  the row being queried
	 *  @param  columnIndex the column being queried
	 *  @return true by default.
	 */
	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	/**
	 *  To support undoable, this method is made final. Please use {@link #updateCellImpl(Object, int, int)} to change the
	 *  cell value without firing an event.
	 * 
	 *  @param aValue      value to assign to cell
	 *  @param rowIndex    row of cell
	 *  @param columnIndex column of cell
	 */
	@java.lang.Override
	public final void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void fireTableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	public javax.swing.undo.UndoManager getUndoManager() {
	}

	@java.lang.Override
	public javax.swing.undo.UndoableEditSupport getUndoableEditSupport() {
	}

	@java.lang.Override
	public void beginCompoundEdit(boolean isUndoRedo) {
	}

	@java.lang.Override
	public void endCompoundEdit() {
	}

	@java.lang.Override
	public void undoableInsertRow(int rowIndex, java.util.Vector rowData) {
	}

	@java.lang.Override
	public void undoableRemoveRow(int rowIndex) {
	}

	@java.lang.Override
	public void undoableUpdateRow(int rowIndex, java.util.Vector newRowData) {
	}

	@java.lang.Override
	public void undoableUpdateCell(int rowIndex, int columnIndex, Object value) {
	}

	/**
	 *  Inserts a row in this table model. Data operation only without any event being fired or any UndoableEdit being added.
	 * 
	 *  @param rowIndex the row index
	 *  @param rowData  the row data
	 *  @return true if the implementation succeeds. Otherwise false.
	 */
	public abstract boolean insertRowImpl(int rowIndex, java.util.Vector rowData) {
	}

	/**
	 *  Removes a row in this table model. Data operation only without any event being fired or any UndoableEdit being added.
	 * 
	 *  @param rowIndex the row index
	 *  @return true if the implementation succeeds. Otherwise false.
	 */
	public abstract boolean removeRowImpl(int rowIndex) {
	}

	/**
	 *  Updates a cell in this table model. Data operation only without any event being fired or any UndoableEdit being added.
	 * 
	 * 
	 *  @param value       the cell value
	 *  @param rowIndex    the row index
	 *  @param columnIndex the row index
	 *  @return true if the implementation succeeds. Otherwise false.
	 */
	public abstract boolean updateCellImpl(Object value, int rowIndex, int columnIndex) {
	}
}
