/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>HierarchicalPanel</code> is a special panel that is used as container for child component in HierarchicalTable.
 *  There are several versions of <code>HierarchicalPanel</code> and they are all extending
 *  <code>HierarchicalPanel</code>.
 *  <p/>
 *  Note: future version of this panel will be resizable. In current version, when _component preferred size changed, the
 *  size of this panel will be changed automatically. In the future, we will make this an option. If the size of this
 *  panel doesn't change with _component, user will still be able to resize the bottom border to make it bigger or
 *  smaller.
 *  <p/>
 *  <p/>
 *  Note: This class is part of HierarchicalTable component. In current release, HierarchicalTable is still in beta.
 *  Please feel free to try it, give us suggestions and feedback. However we reserve the right to change the public APIs
 *  if it's necessary.
 * 
 *  @see TreeLikeHierarchicalPanel
 *  @see HierarchicalTable
 */
public class HierarchicalPanel extends javax.swing.JPanel {

	/**
	 *  Creates an empty HierarchicalPanel. To add component to it, using {@link #setComponent(java.awt.Component)}
	 *  method.
	 */
	public HierarchicalPanel() {
	}

	/**
	 *  Creates a HierarchicalPanel. The HierarchicalPanel will use BorderLayout. The component passed from the
	 *  constructor will be added to the CENTER of the BorderLayout. An empty border with a default left margin will be
	 *  used. If you want to specify your own border, you can use constructor {@link
	 *  #HierarchicalPanel(Component,Border)}.
	 * 
	 *  @param component
	 */
	public HierarchicalPanel(java.awt.Component component) {
	}

	/**
	 *  Creates a HierarchicalPanel. The HierarchicalPanel will use BorderLayout. The component passed from the
	 *  constructor will be added to the CENTER of the BorderLayout. The border passed in will be used as the border of
	 *  this HierarchicalPanel.
	 * 
	 *  @param component
	 *  @param border
	 */
	public HierarchicalPanel(java.awt.Component component, javax.swing.border.Border border) {
	}

	/**
	 *  Changes the component of this panel.
	 * 
	 *  @param component
	 */
	public void setComponent(java.awt.Component component) {
	}

	/**
	 *  Initializes the layout, sets border, adds listeners etc.
	 */
	protected void initComponents() {
	}

	protected void setDefaultBorder() {
	}

	@java.lang.Override
	public void setComponentOrientation(java.awt.ComponentOrientation o) {
	}

	/**
	 *  Checks if tab and shift-tab key is enabled to traversal focus among components.
	 * 
	 *  @return true if tab key is enabled. By default, it returns true.
	 */
	public boolean isTabKeyEnabled() {
	}

	/**
	 *  Enables the tab and shift-tab key to traversal focus among components in child component of HierarchicalTable.
	 * 
	 *  @param tabKeyEnabled
	 */
	public void setTabKeyEnabled(boolean tabKeyEnabled) {
	}

	/**
	 *  Overrides to provide TAB and CTRL-TAB as traversal keys so that it won't be affected by JTable.
	 * 
	 *  @param id
	 *  @return focusTraversalKeys.
	 */
	@java.lang.Override
	public java.util.Set getFocusTraversalKeys(int id) {
	}
}
