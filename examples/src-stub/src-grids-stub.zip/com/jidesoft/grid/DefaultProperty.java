/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default implementation of <code>Property</code>.
 */
public class DefaultProperty extends Property {

	public DefaultProperty() {
	}

	@java.lang.Override
	public void setValue(Object value) {
	}

	@java.lang.Override
	public Object getValue() {
	}
}
