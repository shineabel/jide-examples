/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>JTable</code> uses cell renderer and cell editor for cell rendering and editing respectively. For the same
 *  cell, the renderer component is usually difference from the editor component. For example, most cell renderer
 *  components are JLabel. But to edit a cell, JTextField is usually used as the cell editor component. However, in some
 *  cases, maybe we want the same component to be used for both the renderer component and editor component. That's why
 *  we introduced <code>TableCellEditorRenderer</code> so that you can use the same component for both renderer and
 *  editor.
 *  <p/>
 *  Why do we want the same component use the same component as both editor and renderer? There are at least two reasons.
 *  <ul> <li>To better indicate the cell is editable: JTable renderers the cell using JLabel by default. Editable cells
 *  have no visual difference from non-editable cells. Users have to click or double click on the cell to figure out if
 *  the cell is editable. So some users will prefer to have a different way to renderer the cell to indicate it is
 *  editable. JIDE Grids provides cell style which is one way to make it happen as you can use CellStyle to make the
 *  editable cells having white background and non-editable cells gray background. Another way is to this EditorRenderer
 *  approach and use editors such as JTextField or JComboBox/ExComboBox as the renderer. If users see a drop down button
 *  on the cell, they know the cell will be editable without clicking on it.</li><li>To interactive with mouse events on
 *  the cell level: As you know already, JTable paints the cell, not place a real component on the cell. That's why it
 *  was called cell renderer. When you moves your mouse over a cell, the mouse events will not interactive with the cell
 *  renderer component. For example, if you use as JButton as cell renderer and JButton has a rollover effect, it will
 *  not work in JTable. Clicking on the button-based cell renderer will not trigger the button action either. Because of
 *  this, it was always a challenge to implement hyperlink type of features in JTable. The cell editor, on the other
 *  hand, is a real component that is placed on the cell. So it will interactive with mouse events. This is a hint. To
 *  implement hyperlink, we can use this EditorRenderer so that the renderer and the editor use the same hyperlink
 *  button. We can add a mouse listener to JTable. When JTable is over a cell, we automatically and silently enter cell
 *  editing mode. Since the renderer and the editor are the same, user won't even notice the cell is in editing mode when
 *  rollover.</li> </ul>
 *  <p/>
 *  This interface introduced two new methods. The first one is <code>createTableCellEditorRendererComponent</code>. This
 *  method should always create a new component. It should create the component and doesn't set the value to the
 *  component as we also have <code>configureTableCellEditorRendererComponent</code> that should set the value and do
 *  more customization if needed, i.e. add a listener. Please make sure you check the component first so that you don't
 *  add the same listener multiple times. This method could be called multiple times.
 *  <p/>
 * 
 *  @see AbstractTableCellEditorRenderer
 *  @see RolloverTableUtils
 */
public interface TableCellEditorRenderer extends javax.swing.table.TableCellRenderer, javax.swing.table.TableCellEditor {

	/**
	 *  @param table  the <code>JTable</code> that is asking the renderer to draw; can be <code>null</code>
	 *  @param row    the row index of the cell being drawn.
	 *  @param column the column index of the cell being drawn
	 *  @return the component for both rendering and editing.
	 */
	public java.awt.Component createTableCellEditorRendererComponent(javax.swing.JTable table, int row, int column);

	/**
	 *  @param editorRendererComponent the component that was created by createTableCellEditorRendererComponent.
	 *  @param table                   the <code>JTable</code> that is asking the renderer to draw; can be
	 *                                 <code>null</code>
	 *  @param forRenderer             true if this component is created for rendering purpose. False if it is for
	 *                                 editing purpose.
	 *  @param value                   the value of the cell to be rendered.  It is up to the specific renderer to
	 *                                 interpret and draw the value.  For example, if <code>value</code> is the string
	 *                                 "true", it could be rendered as a string or it could be rendered as a check box
	 *                                 that is checked.  <code>null</code> is a valid value
	 *  @param isSelected              true if the cell is to be rendered with the selection highlighted; otherwise
	 *                                 false
	 *  @param hasFocus                whether the cell has focus. This parameter should always be true for editing
	 *                                 purpose but could be true or false for rendering purpose.
	 *  @param row                     the row index of the cell being drawn.
	 *  @param column                  the column index of the cell being drawn
	 */
	public void configureTableCellEditorRendererComponent(javax.swing.JTable table, java.awt.Component editorRendererComponent, boolean forRenderer, Object value, boolean isSelected, boolean hasFocus, int row, int column);
}
