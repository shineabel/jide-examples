/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class DefaultGroupableTableModel extends javax.swing.table.DefaultTableModel implements ContextSensitiveTableModel, GroupableTableModel {

	public DefaultGroupableTableModel() {
	}

	public DefaultGroupableTableModel(int rowCount, int columnCount) {
	}

	public DefaultGroupableTableModel(java.util.Vector columnNames, int rowCount) {
	}

	public DefaultGroupableTableModel(Object[] columnNames, int rowCount) {
	}

	public DefaultGroupableTableModel(java.util.Vector data, java.util.Vector columnNames) {
	}

	public DefaultGroupableTableModel(Object[][] data, Object[] columnNames) {
	}

	public ConverterContext getConverterContextAt(int row, int column) {
	}

	public EditorContext getEditorContextAt(int row, int column) {
	}

	public Class getCellClassAt(int row, int column) {
	}

	public GrouperContext getGrouperContext(int columnIndex) {
	}
}
