/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>GroupTableSearchable</code> is a special Searchable that implements {@link com.jidesoft.swing.Searchable} that
 *  enables the search function in GroupTable.
 *  <p/>
 *  The only special attribute of GroupTableSearchable is to get and set selected index correctly since GroupTable changes
 *  its table model all the time whie grouping/ungrouping.
 */
public class GroupTableSearchable extends TreeTableSearchable {

	public GroupTableSearchable(javax.swing.JTable table) {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}
}
