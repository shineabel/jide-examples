/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Font. It uses FontComboBox to provide an editor for Font. You can override {@link
 *  #createFontComboBox()} method to provide your own FontComboBox.
 */
public class FontCellEditor extends ExComboBoxCellEditor {

	/**
	 *  Creates a FontCellEditor.
	 */
	public FontCellEditor() {
	}

	/**
	 *  Creates the combobox used by this cell editor.
	 * 
	 *  @return the font combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates the font combobox used by this cell editor.
	 * 
	 *  @return the font combobox.
	 */
	protected com.jidesoft.combobox.FontExComboBox createFontComboBox() {
	}
}
