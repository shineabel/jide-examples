/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ListShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make <code>ListSearchable</code>
 *  shrinkable while searching.
 */
public class ListShrinkSearchableSupport extends ShrinkSearchableSupport {

	protected com.jidesoft.list.FilterableListModel _filterableListModel;

	public ListShrinkSearchableSupport(Searchable searchable) {
	}

	@java.lang.Override
	protected boolean needReinstallFilterableModel(java.beans.PropertyChangeEvent event) {
	}

	public void installFilterableModel() {
	}

	/**
	 *  Creates the FilterableListModel.
	 * 
	 *  @param model the original model
	 *  @return the FilterableListModel.
	 *  @since 3.6.1
	 */
	protected com.jidesoft.list.FilterableListModel createFilterableListModel(javax.swing.ListModel model) {
	}

	public void uninstallFilterableModel() {
	}

	protected void applyFilter(String searchingText) {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
