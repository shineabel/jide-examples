/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TableModel used by SortableTable.
 */
public class SortableTableModel extends DefaultTableModelWrapper implements ISortableTableModel {

	protected SortItemSupport _sortItemSupport;

	/**
	 *  Creates a SortableTableModel from any table model.
	 * 
	 *  @param model the table model.
	 */
	public SortableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the visual row.
	 * 
	 *  @param actualRow the actual row in actual model.
	 *  @return the row on UI. -1 if cannot find the row.
	 */
	public int getSortedRowAt(int actualRow) {
	}

	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Should we optimize more to avoid unnecessary resorting on table model change events. By default, this method
	 *  simply returns true.
	 *  <p/>
	 *  This method will only take effect if {@link #isOptimized()} returns true and {@link #isAutoResort()} returns
	 *  true.
	 * 
	 *  @param firstRow the first row which is updated.
	 *  @param lastRow  the last row which is updated
	 *  @return true or false. If it returns false, we will simply call resort to sort all the rows. If true, we will
	 *          look at each row instead. Obviously it is a trade-off. If there are many rows that are to be updated, it
	 *          could be faster to resort the entire table instead of adding/removing the remain row indices on fly.
	 */
	protected boolean shouldOptimize(int firstRow, int lastRow) {
	}

	protected boolean isInSortRanges(int rowIndex) {
	}

	/**
	 *  Sorts the table model. Subclass can override to provide an optimized way to sort the table. The sorting column
	 *  information can be get using getSortingColumns().
	 */
	protected void sort() {
	}

	/**
	 *  Gets the row index range that will be sorted. It will be a one dimension int array with the first value to be the
	 *  low row index of the range and the second value to be the high row index of the range. The low row index is
	 *  included in the range and the high row index is not included in the range. By default, we will return new
	 *  int[]{0, _indexes.length} which is from the first row to the last row, the whole range. If your last row is a
	 *  summary row so you don't want it to be sorted, you can return new int[]{0, _indexes.length - 1}. Or if you want
	 *  the row at index 3 to always stay there, you can return new int[]{0, 3, 4, _indexes.length}.
	 * 
	 *  @return the sort ranges.
	 */
	protected int[] getSortRanges() {
	}

	/**
	 *  Inserts a row to current _indexes.
	 *  <p/>
	 *  Before insert the actual row, the _indexes as already adjusted for all inserted rows to compare accurately.
	 * 
	 *  @param row the actual row to insert
	 *  @return the visual row index to insert the actual row
	 */
	protected int insert(int row) {
	}

	protected int[] append(int firstRow, int lastRow) {
	}

	/**
	 *  Searches the specified array of rows for the specified value using binary search. The array <strong>must</strong>
	 *  be sorted prior to making this call.  If it is not sorted, the results are undefined.  If the array contains
	 *  multiple elements with the specified value, there is no guarantee which one will be found. <br> Subclass can
	 *  override this method to implement their own algorithm to do the search. When doing comparison in the algorithm,
	 *  use the compare(int, int) method defined in this class. The original indexes are sorted in a way that
	 *  compare(indexes[n], indexes[n + 1]) will always return 1 or 0. So if you compare(indexes[n], row) and it returns
	 *  -1, you knows the row index should be greater than n.
	 * 
	 *  @param indexes the array of row to be searched.
	 *  @param row     the index of the row to be searched for.
	 *  @return index of the search key, if it is contained in the list; otherwise, <tt>(-(<i>insertion point</i>) -
	 *          1)</tt>.  The <i>insertion point</i> is defined as the point at which the key would be inserted into the
	 *          list: the index of the first element greater than the key, or <tt>list.size()</tt>, if all elements in
	 *          the list are less than the specified key.  Note that this guarantees that the return value will be &gt;=
	 *          0 if and only if the key is found.
	 */
	protected int search(int[] indexes, int row) {
	}

	/**
	 *  Sorts the rows.
	 *  <p/>
	 *  Subclass can override this method to implement their own algorithm to sort. When doing comparison in the
	 *  algorithm, use the compare(int, int) method defined in this class.
	 * 
	 *  @param from an int array of row indices to be sorted
	 *  @param to   an int array of row indices to store the result after sorting
	 *  @param low  the start index of the row in the array to be sorted
	 *  @param high the end index of the row in the array to be sorted
	 */
	protected void sort(int[] from, int[] to, int low, int high) {
	}

	/**
	 *  For performance, all comparators for each column should be cached first.
	 */
	protected void cacheComparators() {
	}

	/**
	 *  Gets the master sort columns.
	 * 
	 *  @return the master sort columns.
	 */
	public int[] getMasterSortColumns() {
	}

	/**
	 *  Sets the master sort column. If the master sort columns are set, the row order will only be changed when the
	 *  master sort columns have the same value. This is used when there are cell spans in certain column and you don't
	 *  want the sorting to mess up the cell span as those rows will have to stay together.
	 * 
	 *  @param masterSortColumns the new master sort columns.
	 */
	public void setMasterSortColumns(int[] masterSortColumns) {
	}

	public int getMasterSortColumnIndex(int column) {
	}

	/**
	 *  Compares two rows to decide the order. It will consider the ascending or descending and return different value so
	 *  the return has different meaning comparing to that of Comparator.compare(o1, o2). <br>If it returns -1, it means
	 *  keep the current order. If it returns 1, it means the order should be swapped. If it returns 0, it means the
	 *  order doesn't matter. It could be either the table model is not sorted so the order doesn't matter or the two
	 *  rows have the same order.
	 *  <p/>
	 *  Please be noted that row1 and row2 are the index in the table model this table model wraps. A common mistake is
	 *  that row1 and row2 were used as the row index in this table model itself, which will causes unexpected issues.
	 * 
	 *  @param row1 index of the first row to be compared
	 *  @param row2 index of the second row to be compared
	 *  @return If it returns -1, it means keep the current order. If it returns 1, it means the order should be swapped.
	 *          If it returns 0, it means the order doesn't matter. It could be either the table model is not sorted so
	 *          the order doesn't matter or the two rows have the same order.
	 */
	protected int compare(int row1, int row2) {
	}

	/**
	 *  Compares the two cell values at the two rows.
	 * 
	 *  @param row1   index of the first row to be compared
	 *  @param row2   index of the second row to be compared
	 *  @param column the column index of both rows.
	 *  @return If it returns 1, it means the first value is greater than the second value. If it returns -1, it means
	 *          the second value is greater than the first value. If it returns 0, it means the two values are the same.
	 *          If it returns Integer.MAX_VALUE, the first value is always appear after the second value, regarding of
	 *          the order is ascending or descending. If it returns Integer.MIN_VALUE, the first value is always appear
	 *          before the second value, regarding of the order is ascending or descending.
	 */
	public int compare(int row1, int row2, int column) {
	}

	/**
	 *  Compares its two arguments for order. Returns a negative integer, zero, or a positive integer as the first
	 *  argument is less than, equal to, or greater than the second. By default, we will compareTo method if both objects
	 *  are Comparable (if String, we will use compareToIgnore method on String). Otherwise, we will use Comparator to do
	 *  the comparison. If you want to always use Comparator to compare even when the objects are Comparable, you can use
	 *  {@link #setAlwaysUseComparators(boolean)} and set it to true. Subclass can override it to provide your own way to
	 *  compare.
	 * 
	 *  @param o1     the first object to be compared
	 *  @param o2     the second object to be compared
	 *  @param column the column index where the objects are
	 *  @return a negative integer, zero, or a positive integer as the first argument is less than, equal to, or greater
	 *          than the second. 0 if there is an exception.
	 */
	protected int compare(Object o1, Object o2, int column) {
	}

	/**
	 *  Gets the column comparator. Subclass can override it to return a comparator for a particular column. By default,
	 *  SortableTableModel will look up for a comparator from ObjectComparatorManager based on getColumnClass return
	 *  value and getColumnComparatorContext return value. Please note, for the performance reason, if both objects are
	 *  Comparable of the same type, we will use Comparable#compareTo method to compare the two objects. Then we will use
	 *  the Comparator. If you want to always use Comparator to compare, you can call {@link
	 *  #setAlwaysUseComparators(boolean)} and set it to true.
	 * 
	 *  @param columnIndex the column index.
	 *  @return the comparator for the specified column.
	 */
	protected java.util.Comparator getComparator(int columnIndex) {
	}

	/**
	 *  Gets the column comparator context. Subclass can override it to return a comparator context. By default it will
	 *  return null. It should only be used when the column class for two columns are the same but you want to compare
	 *  them differently. First you need to register two different comparators using {@link ObjectComparatorManager}
	 *  using different comparator context in {@link ObjectComparatorManager#registerComparator(Class,
	 *  java.util.Comparator, com.jidesoft.comparator.ComparatorContext)} method. Then return the corresponding context
	 *  when overriding this method.
	 *  <p/>
	 *  In 1.9.2.04 release, we also add a setter for this. You can call {@link #setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}
	 *  to provide a ColumnComparatorContextProvider. This provider will return a ComparatorContext for each column. This
	 *  will be helpful when it's hard to override SortableTableModel.
	 * 
	 *  @param column the column index
	 *  @return the comparator context for the column.
	 */
	public ComparatorContext getColumnComparatorContext(int column) {
	}

	/**
	 *  Get the flag indicating if the sorting columns should be reset while firing table structure change events.
	 *  <p/>
	 *  By default, the flag is true. If you don't want this behavior, please turn it to false.
	 * 
	 *  @return true if the sorting columns should be reset while firing table structure change events.
	 */
	public boolean isResetOnTableStructureChangeEvent() {
	}

	/**
	 *  Set the flag indicating if the sorting columns should be reset while firing table structure change events.
	 * 
	 *  @param resetOnTableStructureChangeEvent
	 *          the flag
	 *  @see #isResetOnTableStructureChangeEvent()
	 */
	public void setResetOnTableStructureChangeEvent(boolean resetOnTableStructureChangeEvent) {
	}

	@java.lang.Override
	public void fireTableStructureChanged() {
	}

	@java.lang.Override
	public void fireTableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Gets the ColumnComparatorContextProvider.
	 * 
	 *  @return the ColumnComparatorContextProvider.
	 */
	public SortableTableModel.ColumnComparatorContextProvider getColumnComparatorContextProvider() {
	}

	/**
	 *  Sets the <code>ColumnComparatorContextProvider</code>. This provider will provide a
	 *  <code>ComparatorContext</code> for each column. If this table model has several columns that have the same types
	 *  in getColumnClass method but you want to use different comparators to compare and sort them, you would need to
	 *  register several comparators on <code>ObjectComparatorManager</code> using different
	 *  <code>ComparatorContext</code>. Then you can this provider to return different contexts so that
	 *  <code>SortableTableModel</code> can find the correct comparator registered on
	 *  <code>ObjectComparatorManager</code>. If you call this method with a non-null provider, we will automatically
	 *  call {@link #setAlwaysUseComparators(boolean)} and set it to true.
	 * 
	 *  @param columnComparatorContextProvider
	 *          the columnComparatorContextProvider
	 */
	public void setColumnComparatorContextProvider(SortableTableModel.ColumnComparatorContextProvider columnComparatorContextProvider) {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to clear up any soring columns.
	 * 
	 *  @param indexes the new index array.
	 */
	@java.lang.Override
	public synchronized void setIndexes(int[] indexes) {
	}

	/**
	 *  Gets a list of menu items for the specified column. It has "Sort Ascending", "Sort Descending", and "Unsort".
	 * 
	 *  @param column the column
	 *  @return the list of menu items
	 */
	public javax.swing.JMenuItem[] getPopupMenuItems(int column) {
	}

	/**
	 *  Gets the sortable table model. If model is a TableModelWrapper, it will get the actual model until it finds the
	 *  first sortable table model.
	 * 
	 *  @param model the table model
	 *  @return sortable table model.
	 */
	public static ISortableTableModel getSortableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Checks if the sortable table model is in optimized mode.
	 * 
	 *  @return the optimized flag.
	 */
	public boolean isOptimized() {
	}

	/**
	 *  If optimized flag is true and the table is already sorted, SortableTableModel will do incremental sorting when
	 *  data is only partially changed. If the flag is false, SortableTableModel will resort completely whenever data
	 *  changed. <br>Default is true.
	 * 
	 *  @param optimized true or false.
	 */
	public void setOptimized(boolean optimized) {
	}

	/**
	 *  Checks if the table is automatically resorted when data changes.
	 * 
	 *  @return true if autoResort. Otherwise false.
	 */
	public boolean isAutoResort() {
	}

	/**
	 *  AutoResort is a feature that automatically resort the table when table data changes. This is the default behavior
	 *  and useful in most cases. However there are cases when the data changes frequently, resort will make it very hard
	 *  for user to read the value. So in these cases, you can set autoResort to false. Then you will need to provide a
	 *  button to call {@link #resort} to resort the table.
	 *  <p/>
	 *  Note: this flag is only used when optimized flag is true. If optimized is false, autoResort is always true.
	 * 
	 *  @param autoResort true or false.
	 */
	public void setAutoResort(boolean autoResort) {
	}

	/**
	 *  Sort the column, equals to sortColumn(column, false).
	 * 
	 *  @param column column to be sorted
	 */
	public void sortColumn(int column) {
	}

	/**
	 *  If reset is true, it will remove all existing sort-by columns and only sorts by <code>column</code>. If reset is
	 *  false, it will keep existing sort-by columns and add the <code>column</code> as a new sort-by column.
	 * 
	 *  @param column the column index.
	 *  @param reset  true to reset all existing sorting columns before sorting the new column.
	 */
	public void sortColumn(int column, boolean reset) {
	}

	/**
	 *  Unsorts the column.
	 * 
	 *  @param column column to be removed from sort-by columns
	 */
	public void unsortColumn(int column) {
	}

	/**
	 *  Reverses the sort order of the column. The column must be one of sorted column, or else the method will do
	 *  nothing
	 * 
	 *  @param column the column index.
	 */
	public void reverseColumnSortOrder(int column) {
	}

	/**
	 *  Sorts a column.
	 * 
	 *  @param column    the column index.
	 *  @param reset     true to reset all existing sorting columns before sorting the new column.
	 *  @param ascending true to sort ascending. False to sort descending.
	 */
	public void sortColumn(int column, boolean reset, boolean ascending) {
	}

	/**
	 *  Checks if the column is sorted.
	 * 
	 *  @param column the column index.
	 *  @return true if the column is sorted.
	 */
	public boolean isColumnSorted(int column) {
	}

	/**
	 *  Checks if the column is sorted ascendingly.
	 * 
	 *  @param column the column index.
	 *  @return true if column is ascendingly sorted. If it's not sorted or sorted but descending, it will return false.
	 */
	public boolean isColumnAscending(int column) {
	}

	/**
	 *  Resets. No columns will be sorted. Nothing will be done if the model was not sorted.
	 */
	public void reset() {
	}

	/**
	 *  Gets the sorting columns. It's a ArrayList. The element in the list is SortItem which has the column index and
	 *  sorting direction.
	 * 
	 *  @return an ArrayList of sorting columns.
	 */
	public java.util.List getSortingColumns() {
	}

	/**
	 *  Sets the soring columns. It will do a sort action automatically.
	 * 
	 *  @param list a list of SortItems.
	 */
	public void setSortingColumns(java.util.List list) {
	}

	/**
	 *  In the case of sort by multiple columns, this method will return the rank of this column within all sorted
	 *  columns.
	 * 
	 *  @param column the column index.
	 *  @return the rank of this column within all sorted columns. -1 is the column is not sorted. 0 means the first rank
	 *          and so on.
	 */
	public int getColumnSortRank(int column) {
	}

	/**
	 *  Does this table allow sort by multiple columns.
	 * 
	 *  @return true if this table allows sort by multiple columns
	 */
	public boolean isMultiColumnSortable() {
	}

	/**
	 *  Set the value if this table allows sort by multiple columns.
	 * 
	 *  @param multiColumnSortable pass in true if this you want this table allows sort by multiple columns
	 */
	public void setMultiColumnSortable(boolean multiColumnSortable) {
	}

	/**
	 *  Check if a certain column is sortable.
	 * 
	 *  @param column the column index.
	 *  @return true if this table column is sortable.
	 *  @see #setColumnSortable(int, boolean)
	 */
	public boolean isColumnSortable(int column) {
	}

	/**
	 *  Sets a column sortable or not sortable. Please note, you will have to set it again if the table model structure
	 *  is changed. By default, all columns are sortable.
	 * 
	 *  @param column   the column index.
	 *  @param sortable true to make the column sortable.
	 */
	public void setColumnSortable(int column, boolean sortable) {
	}

	/**
	 *  Checks if the sortable table model is sortable.
	 * 
	 *  @return true or false.
	 */
	public boolean isSortable() {
	}

	/**
	 *  Sets the table model sortable. If the model is not sortable, {@link #toggleSortOrder(int, boolean)} will have no
	 *  effect.
	 * 
	 *  @param sortable true or false.
	 */
	public void setSortable(boolean sortable) {
	}

	/**
	 *  Resort the table. When autoResort is false, the table will be out of order after data changes. The method will
	 *  resort the table while keeping the sorting columns.
	 */
	public void resort() {
	}

	/**
	 *  Adds the specified listener to receive SortEvents pane events from this SortableTableModel.
	 * 
	 *  @param l the SortListener
	 */
	public void addSortListener(SortListener l) {
	}

	/**
	 *  Removes the specified SortListener so that it no longer receives SortEvents from this SortableTableModel .
	 * 
	 *  @param l the SortableTableModel listener
	 */
	public void removeSortListener(SortListener l) {
	}

	/**
	 *  Returns an array of all the <code>SortListener</code>s added to this <code>SortableTableModel</code> with
	 *  <code>addSortListener</code>.
	 * 
	 *  @return all of the <code>SortListener</code>s added or an empty array if no listeners have been added
	 *  @see #addSortListener
	 */
	public SortListener[] getSortListeners() {
	}

	/**
	 *  Fires sort event.
	 */
	public void fireSortEvent() {
	}

	/**
	 *  Fires sort event.
	 */
	public void fireSortingEvent() {
	}

	/**
	 *  Gets the sort priority.
	 * 
	 *  @return the sort priority. It could be either {@link ISortableTableModel#SORT_PRIORITY_FILO} (the default) or
	 *          {@link ISortableTableModel#SORT_PRIORITY_FIFO}.
	 */
	public int getSortPriority() {
	}

	/**
	 *  Sets the sort priority. This property only has effect when multiple columns are sorted. When sort priority is
	 *  FILO (first-in-last-out), the first sorted column has the smallest sort rank (with a number "1" on its column
	 *  header). If there are more columns being sorted, their sort tank are getting higher based on the the order when
	 *  they are sorted. Oppositely, when sort priority is FIFO (first-in-first-out), the first sorted column has the
	 *  sort rank 1. But the moment a new column is sorted, it will get sort rank 1 and push the previous sorted column's
	 *  sort rank to 2. And so on. If you view it as a queue, you will see it's either a FILO queue or FIFO queue. That's
	 *  why we call it FIFO or FILO.
	 * 
	 *  @param sortPriority must be one the following value: SORT_PRIORITY_FILO (the default), or SORT_PRIORITY_FIFO
	 */
	public void setSortPriority(int sortPriority) {
	}

	/**
	 *  Gets the maximum columns can be sorted at once. If user tries to sort another columns when maximum count is met,
	 *  depending on the value of {@link #getSortPriority()}, the behavior is different. If sort priority is FILO,
	 *  nothing will happen when user tries to sort one column. If FIFO, it will push the column with the largest sort
	 *  rank out.
	 * 
	 *  @return the maximum sorted column number.
	 */
	public int getMaximumSortColumns() {
	}

	/**
	 *  Set the maximum number of columns that can be sorted at once.
	 * 
	 *  @param maximumSortColumns the maximum number of columns that can be sorted at once.
	 */
	public void setMaximumSortColumns(int maximumSortColumns) {
	}

	/**
	 *  Gets the SortOrderHandler.
	 * 
	 *  @return the SortOrderHandler.
	 */
	public SortableTableModel.SortOrderHandler getSortOrderHandler() {
	}

	/**
	 *  Sets the SortOrderHandler.
	 * 
	 *  @param sortOrderHandler a new SortOrderHandler.
	 *  @see #toggleSortOrder(int, boolean)
	 */
	public void setSortOrderHandler(SortableTableModel.SortOrderHandler sortOrderHandler) {
	}

	/**
	 *  Toggles the sort order on the specified column. By default, it will sort the column if not sorted. If sorted
	 *  ascending, it will change to descending. If descending, it will unsort.
	 *  <p/>
	 *  <p>See default implementation below.
	 *  <pre><code>
	 *   if (isMultiColumnSortable() && extend) {
	 *       if (!isColumnSorted(column))
	 *           sortColumn(column, false, true);
	 *       else if (isColumnAscending(column))
	 *           reverseColumnSortOrder(column);
	 *       else
	 *           unsortColumn(column);
	 *   }
	 *   else {
	 *       if (!isColumnSorted(column))
	 *           sortColumn(column, true, true);
	 *       else if (isColumnAscending(column))
	 *           reverseColumnSortOrder(column);
	 *       else
	 *           reset();
	 *   }
	 *   </code></pre>
	 *  <p/>
	 *  If you want a different behavior, you can use {@link #setSortOrderHandler(com.jidesoft.grid.SortableTableModel.SortOrderHandler)}
	 *  and provide your own way to toggle the sort order.
	 * 
	 *  @param column the column index.
	 *  @param extend if true, extend the current sort to add more sorted columns.
	 */
	public void toggleSortOrder(int column, boolean extend) {
	}

	/**
	 *  Returns if the SortableTableModel could improve performance by just reversing the current indices.
	 *  <p/>
	 *  It returns false by default to keep generic so that your customization sorting would not be broken. However, if
	 *  you are just using the default sorting behavior and want to speed up the sorting while switching between
	 *  ascending and descending, you could override this method with the following sample code to improve the
	 *  performance.
	 *  <code><pre>
	 *     return _sortItemSupport.getSortOrderHandler() == null && onlyColumnSorted && getSortingColumns().size() == 1
	 *  && getSortingColumns().get(0).getColumn() == column && getSortingColumns().get(0).isAscending() != ascending &&
	 *  _indexes != null;
	 *  </pre></code>
	 * 
	 *  @param column           current sorting column
	 *  @param onlyColumnSorted the flag if the column is the only column sorted before
	 *  @param ascending        the flag if the column is sorted in ascending or descending order
	 *  @return false by default.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected boolean shouldReverseIndices(int column, boolean onlyColumnSorted, boolean ascending) {
	}

	/**
	 *  Checks if the alwaysUseComparators flag value.
	 * 
	 *  @return true if alwaysUseComparators is true. Otherwise false.
	 */
	public boolean isAlwaysUseComparators() {
	}

	/**
	 *  Sets the alwaysUseComparators flag. By default, we will check if the two values are Comparable. If they both are,
	 *  we will use {@link Comparable#compareTo(Object)} to compare. This is the default preferred way because this gives
	 *  developer a finer control of the comparison result. People also sometimes forgot to implement getColumnClass and
	 *  getColumnComparatorContext. If so, a wrong comparator could be used. If this flag is set to true, we will always
	 *  use Comparators to compare which you means you must implement getColumnClass and optionally implement
	 *  getColumnComparatorContext or use {@link #setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}
	 *  so that the correct comparator will be used for each column.
	 * 
	 *  @param alwaysUseComparators true or false.
	 */
	public void setAlwaysUseComparators(boolean alwaysUseComparators) {
	}

	/**
	 *  If sorting is paused, keep rows in same relative positions Inserts/Deletes shift rows without re-ordering.
	 * 
	 *  @param pause TRUE = Sorting is Paused;  FALSE = Sorting is Active
	 */
	public void setSortingPaused(boolean pause) {
	}

	public boolean isSortingPaused() {
	}

	/**
	 *  An interface used by {@link SortableTableModel#setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}.
	 */
	public static interface class ColumnComparatorContextProvider {


		public ComparatorContext getColumnComparatorContext(SortableTableModel tableModel, int column) {
		}
	}

	/**
	 *  A handler to handle the toggling of sort order. Usually the first click on the table header will sort that column
	 *  ascendingly. Clicking again will sort it descendingly. The third click will unsort. However there are cases that
	 *  you want a different behavior. For example, you might not want the unsorted state on the third click. In those
	 *  cases, you can use {@link SortOrderHandler} and {@link SortableTableModel#setSortOrderHandler(com.jidesoft.grid.SortableTableModel.SortOrderHandler)}
	 *  to provide your own way to toggle the sort order.
	 */
	public static interface class SortOrderHandler {

	}
}
