/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An expandable row used at the root for TreeTableModel.
 */
public class RootExpandableRow extends DefaultExpandableRow {

	public RootExpandableRow(IExpandableTreeTableModel treeTableModel) {
	}

	public Object getValueAt(int columnIndex) {
	}

	@java.lang.Override
	public int getLevel() {
	}

	@java.lang.Override
	public boolean isExpandable() {
	}

	@java.lang.Override
	public boolean isExpanded() {
	}

	@java.lang.Override
	public Expandable getParent() {
	}

	@java.lang.Override
	public Node getPreviousSibling() {
	}

	@java.lang.Override
	public Node getNextSibling() {
	}

	@java.lang.Override
	public void notifyChildInserted(Object child, int childIndex) {
	}

	@java.lang.Override
	public void notifyChildrenInserted(java.util.List children, int firstVisualIndex) {
	}

	@java.lang.Override
	public void notifyChildDeleted(Object child) {
	}

	@java.lang.Override
	public void notifyChildrenDeleted(java.util.List children) {
	}

	@java.lang.Override
	public void notifyChildUpdated(Object child) {
	}

	@java.lang.Override
	public void notifyChildrenUpdated(java.util.List children) {
	}

	@java.lang.Override
	public void notifyCellUpdated(Object child, int columnIndex) {
	}

	@java.lang.Override
	public IExpandableTreeTableModel getExpandableTreeTableModel() {
	}

	/**
	 *  Invalidates summary cache.
	 * 
	 *  @since 3.6.0
	 */
	public void invalidateSummaryCache() {
	}
}
