/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A filter for <code>FilterableTreeTableModel</code>. The value passed in to this filter's isValueFiltered method is
 *  the Row object. To use it, you should call {@link com.jidesoft.grid.FilterableTableModel#addFilter(Filter)} method
 *  which will add the filter to {@link com.jidesoft.grid.FilterableTableModel#ANY_COLUMNS}. Please note, you must add
 *  <code>TableRowFilter</code> to ANY_COLUMNS. Otherwise it won't work.
 */
public interface TableRowFilter extends com.jidesoft.filter.Filter {
}
