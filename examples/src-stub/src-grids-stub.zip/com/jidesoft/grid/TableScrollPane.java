/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableScrollPane</code> is a special <code>JideScrollPane</code> that supports header and footer columns or
 *  rows. <code>JScrollPane</code> supports adding a component to top area and west area. <code>JideScrollPane</code>
 *  added the support to east area and bottom area. <code>TableScrollPane</code> further enhances it to handle the
 *  special case of table to allow you easily add header column(s), footer column(s), and footer to your table.
 *  <p/>
 *  To use it, you need to create a <code>MultiTableModel</code> instance first. Defining <code>MultiTableModel</code> is
 *  the same as defining TableModel except you can specify which columns are header and footer.
 *  <p/>
 *  After you create <code>MultiTableModel</code>, just pass it in to the constructor of TableScrollPane. You have an
 *  option to specify if the table is sortable. You also have an option to specify a table model for footer row. The
 *  table created from footer table model will appear at the bottom of the table and scroll horizontally along with the
 *  table above. The footer table model must have the same column count as the MultiTableModel excluding header and
 *  footer columns.
 *  <p/>
 *  Even though header columns and footer columns are added as separate components, they will work just like in one
 *  table. For example, row selection is synchronized. Tab key or left/right arrows will navigate across all three
 *  tables. If you scroll vertically, all three tables will scroll together. If you resize columns in any table, even the
 *  last column of the header column table and the first column of footer column table.
 *  <p/>
 *  <b>Note for users of TableScrollPane before v1.8.6:</b>In 1.8.6 release, there is a design change in TableScrollPane.
 *  The old constructor that takes six table models as parameter is removed. The new constructors only accept one or two
 *  MultiTableModels. If you use six table model constructor, you need to refactor your code to remove the usage of it.
 * 
 *  @see com.jidesoft.swing.JideScrollPane
 *  @see MultiTableModel
 */
public class TableScrollPane extends JideScrollPane implements TableAdapter {

	protected MultiTableModel _originalTableModel;

	protected MultiTableModel _originalFooterTableModel;

	protected MultiTableModel _originalHeaderTableModel;

	protected javax.swing.JTable _mainTable;

	protected javax.swing.JTable _rowHeaderTable;

	protected javax.swing.JTable _rowFooterTable;

	protected javax.swing.JTable _columnFooterTable;

	protected javax.swing.JTable _rowHeaderColumnFooterTable;

	protected javax.swing.JTable _rowFooterColumnFooterTable;

	protected javax.swing.JTable _columnHeaderTable;

	protected javax.swing.JTable _rowHeaderColumnHeaderTable;

	protected javax.swing.JTable _rowFooterColumnHeaderTable;

	/**
	 *  The client property name of all the tables created by TableScrollPane. The six possible values are defined below.
	 *  The value can be retrieved by table.getClientProperty(TableScrollPane.TABLE_KEY);
	 */
	public static final String TABLE_KEY = "TableScrollPane.TableKey";

	public static final String TABLESCROLLPANE_KEY = "TableScrollPane.Parent";

	public static final String MAIN_TABLE = "TableScrollPane.MainTable";

	public static final String ROWHEADER_TABLE = "TableScrollPane.RowHeaderTable";

	public static final String ROWFOOTER_TABLE = "TableScrollPane.RowFooterTable";

	public static final String COLUMNFOOTER_TABLE = "TableScrollPane.ColumnFooterTable";

	public static final String ROWHEADER_COLUMNFOOTER_TABLE = "TableScrollPane.RowHeaderColumnFooterTable";

	public static final String ROWFOOTER_COLUMNFOOTER_TABLE = "TableScrollPane.RowFooterColumnFooterTable";

	public static final String COLUMNHEADER_TABLE = "TableScrollPane.ColumnHeaderTable";

	public static final String ROWHEADER_COLUMNHEADER_TABLE = "TableScrollPane.RowHeaderColumnHeaderTable";

	public static final String ROWFOOTER_COLUMNHEADER_TABLE = "TableScrollPane.RowFooterColumnHeaderTable";

	public static final String PROPERTY_TABLE_MODEL = "tableModel";

	/**
	 *  By default we will try to automatically update footer table when main table column is added, removed or moved. If
	 *  you want to handle the update yourself and don't want this auto-update to happen, you can call
	 *  getMainTable().putClientProperty(TableScrollPane.AUTO_UPDATE_FOOTER_TABLE_COLUMNS, Boolean.FALSE).
	 */
	public static final String AUTO_UPDATE_FOOTER_TABLE_COLUMNS = "TableScrollPane.AutoUpdateFooterTableColumns";

	/**
	 *  True if row selection is allowed in this table scroll pane.
	 */
	protected boolean _rowSelectionAllowed;

	/**
	 *  True if column selection is allowed in this table.
	 */
	protected boolean _columnSelectionAllowed;

	/**
	 *  True if non-contiguous selection is allowed in this table.
	 */
	protected boolean _nonContiguousCellSelectionAllowed;

	/**
	 *  Creates an empty <code>TableScrollPane</code>. You can call {@link #setTableModel(com.jidesoft.grid.MultiTableModel)}
	 *  to set a non-empty table model later.
	 */
	public TableScrollPane() {
	}

	/**
	 *  Creates a <code>TableScrollPane</code>. The tables will not be sortable.
	 * 
	 *  @param tableModel the MultiTableModel. This is the main table model that will be used to create up to three
	 *                    tables in TableScrollPane.
	 */
	public TableScrollPane(MultiTableModel tableModel) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a footer table. The tables will not be sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create upto three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a  footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create upto three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a header table and a footer table. The tables will not be sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableScrollPane.
	 *  @param headerTableModel the header table model. It will be used to create a header table below the normal table
	 *                          header. It must have the same column count as the MultiTableModel's non-header and
	 *                          non-footer column count.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a header table and a footer table. You can specify if the tables are
	 *  sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableScrollPane.
	 *  @param headerTableModel the header table model. It will be used to create a header table below the normal table
	 *                          header. It must have the same column count as the MultiTableModel's non-header and
	 *                          non-footer column count.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> without footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel the MultiTableModel. This is the main table model that will be used to create up to three
	 *                    tables in TableScrollPane.
	 *  @param sortable   if the tables will be sortable.
	 */
	public TableScrollPane(MultiTableModel tableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create upto three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 *  @param sync             if the tables will be synced. Usually you should call with sync set to true. However if
	 *                          you want to synchronize more tables which are not just in one TableScrollPane, you can
	 *                          set to false first, then call {@link com.jidesoft.grid.TableUtils#synchronizeTables(javax.swing.JTable[])}
	 *                          later.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable, boolean sync) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a header table and a footer table. You can specify if the tables are
	 *  sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableScrollPane.
	 *  @param headerTableModel the header table model. It will be used to create a header table below the normal table
	 *                          header. It must have the same column count as the MultiTableModel's non-header and
	 *                          non-footer column count.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 *  @param sync             if the tables will be synced. Usually you should call with sync set to true. However if
	 *                          you want to synchronize more tables which are not just in one TableScrollPane, you can
	 *                          set to false first, then call {@link com.jidesoft.grid.TableUtils#synchronizeTables(javax.swing.JTable[])}
	 *                          later.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel, boolean sortable, boolean sync) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableScrollPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 *  @param tableIndex       the table index of the TableScrollPane. This is only useful when using it inside a
	 *                          TableSplitPane.
	 *  @param sync             if the tables will be synced. Usually you should call with sync set to true. However if
	 *                          you want to synchronize more tables which are not just in one TableScrollPane, you can
	 *                          set to false first, then call {@link com.jidesoft.grid.TableUtils#synchronizeTables(javax.swing.JTable[])}
	 *                          later.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable, int tableIndex, boolean sync) {
	}

	/**
	 *  Creates a <code>TableScrollPane</code> with a header table and a footer table. You can specify if the tables are
	 *  sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableScrollPane.
	 *  @param headerTableModel the header table model. It will be used to create a header table below the normal table
	 *                          header. It must have the same column count as the MultiTableModel's non-header and
	 *                          non-footer column count.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 *  @param tableIndex       the table index of the TableScrollPane. This is only useful when using it inside a
	 *                          TableSplitPane.
	 *  @param sync             if the tables will be synced. Usually you should call with sync set to true. However if
	 *                          you want to synchronize more tables which are not just in one TableScrollPane, you can
	 *                          set to false first, then call {@link com.jidesoft.grid.TableUtils#synchronizeTables(javax.swing.JTable[])}
	 *                          later.
	 */
	public TableScrollPane(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel, boolean sortable, int tableIndex, boolean sync) {
	}

	/**
	 *  Sets the model. It will only work if the dataModel is an instance of MultiTableModel.
	 * 
	 *  @param dataModel the new data source for this table
	 */
	@java.lang.Override
	public void setModel(javax.swing.table.TableModel dataModel) {
	}

	/**
	 *  Sets the original table model and recreates all child tables.
	 * 
	 *  @param tableModel the new MultiTableModel
	 */
	public void setTableModel(MultiTableModel tableModel) {
	}

	/**
	 *  Creates a SortableTableModel or SortableTreeTableModel for the MultiTableModel if isSortable() is true.
	 *  Otherwise, tableModel itself will be returned.
	 *  <p/>
	 *  See below for the default code.
	 *  <code><pre>
	 *  TableModel actualTableModel;
	 *  if (tableModel instanceof TreeTableModel && sortable) {
	 *      actualTableModel = new SortableTreeTableModel(tableModel);
	 *  }
	 *  else if (!(tableModel instanceof ISortableTableModel) && sortable) {
	 *      actualTableModel = new SortableTableModel(tableModel);
	 *  }
	 *  else {
	 *      actualTableModel = tableModel;
	 *  }
	 *  return actualTableModel;
	 *  </pre></code>
	 * 
	 *  @param tableModel the MultiTableModel
	 *  @param sortable   true or false. If true, the tableModel should be wrapped into a SortableTableModel or
	 *                    SortableTreeTableModel.
	 *  @return a SortableTableModel or SortableTreeTableModel for the MultiTableModel if isSortable() is true.
	 */
	protected javax.swing.table.TableModel createSortableTableModel(MultiTableModel tableModel, boolean sortable) {
	}

	/**
	 *  Gets the original table model that is passed in constructors. It is the same as {@link #getModel()}.
	 * 
	 *  @return the original table model.
	 */
	public MultiTableModel getTableModel() {
	}

	/**
	 *  Gets the original table model that is passed in constructors. It is the same as {@link #getTableModel()}.
	 * 
	 *  @return the original table model.
	 */
	public MultiTableModel getModel() {
	}

	/**
	 *  Sets the footer table model.
	 * 
	 *  @param footerTableModel the footer table model
	 */
	public void setFooterTableModel(MultiTableModel footerTableModel) {
	}

	/**
	 *  Sets the header table model.
	 * 
	 *  @param headerTableModel the header table model
	 *  @since 3.2.3
	 */
	public void setHeaderTableModel(MultiTableModel headerTableModel) {
	}

	public MultiTableModel getFooterTableModel() {
	}

	public boolean isSortable() {
	}

	public void setSortable(boolean sortable) {
	}

	/**
	 *  Customizes the table created by TableScrollPane. All tables has client property setup to identify. You can call
	 *  getClientProperty(TABLE_KEY) to find what table it is. The values are defined as {@link #MAIN_TABLE}, {@link
	 *  #ROWHEADER_TABLE}, {@link #ROWFOOTER_TABLE}, {@link #COLUMNFOOTER_TABLE}, {@link #ROWHEADER_COLUMNFOOTER_TABLE},
	 *  and {@link #ROWFOOTER_COLUMNFOOTER_TABLE}.
	 * 
	 *  @param table the child table
	 */
	protected void customizeTable(javax.swing.JTable table) {
	}

	/**
	 *  The main table. This is a table created from MultiTableModel's non-header and non-footer columns.
	 * 
	 *  @return the main table.
	 */
	public javax.swing.JTable getMainTable() {
	}

	/**
	 *  The row header table. This is a table created from MultiTableModel's header columns.
	 * 
	 *  @return the row header table.
	 */
	public javax.swing.JTable getRowHeaderTable() {
	}

	/**
	 *  The row footer table. This is a table created from MultiTableModel's footer columns.
	 * 
	 *  @return the row footer table.
	 */
	public javax.swing.JTable getRowFooterTable() {
	}

	/**
	 *  The column footer table. This is a table created from footerTableModel, the second parameter of TableScrollPane's
	 *  constructor.
	 * 
	 *  @return the column footer table.
	 */
	public javax.swing.JTable getColumnFooterTable() {
	}

	/**
	 *  Gets the row header of the column footer table.
	 * 
	 *  @return the row header of column footer table.
	 */
	public javax.swing.JTable getRowHeaderColumnFooterTable() {
	}

	/**
	 *  Gets the row footer of the column footer table.
	 * 
	 *  @return the row header of column footer table.
	 */
	public javax.swing.JTable getRowFooterColumnFooterTable() {
	}

	public javax.swing.JTable getColumnHeaderTable() {
	}

	public javax.swing.JTable getRowHeaderColumnHeaderTable() {
	}

	public javax.swing.JTable getRowFooterColumnHeaderTable() {
	}

	/**
	 *  @param model      the table model
	 *  @param sortable   if the table is sortable
	 *  @param type       the table type
	 *  @param tableIndex the table index
	 *  @return the created table.
	 *  @deprecated We added a footer parameter to the createTable method. This method was left here for backward
	 *  compatible reason. Please change your code to override {@link #createTable(javax.swing.table.TableModel, boolean,
	 *  int)}  instead.
	 */
	@java.lang.Deprecated
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable, int type, int tableIndex) {
	}

	/**
	 *  Creates the table. <code>TableScrollPane</code> will use this method to create all table instances.
	 *  <p/>
	 *  Please be noted that it is highly NOT recommended to override this method although you could do that. The reason
	 *  is that we did some client property registrations and some default setting here. So if you override this method
	 *  without taking care of that part, you will find the behavior of your new TableScrollPane is not as you are
	 *  actually expecting.
	 *  <p/>
	 *  If you want to create an instance with different table class, please try override {@link
	 *  #createTable(javax.swing.table.TableModel, boolean, int)} or {@link #createTable(javax.swing.table.TableModel,
	 *  boolean)}. If you will create different table classes for header table and main table, you would have to override
	 *  the first one, which has type as one of its three parameters. If you will create the same table class for every
	 *  table in your TableScrollPane, you could just override the second one with only two parameters.
	 *  <p/>
	 *  If you want to configure the tables which ares already created, please override {@link #getTableCustomizer()} to
	 *  create your own table customizer. You can refer our <code>TableScrollPaneDemo</code> for the details.
	 *  <p/>
	 *  Below is the default client property registrations and settings in this method. If you decided to override this
	 *  one, please also consider add those lines in.
	 *  <pre><code>
	 *  String tableKey = null;
	 *  switch (type) {
	 *      case MultiTableModel.REGULAR_COLUMN:
	 *          tableKey = columnFooter ? COLUMNFOOTER_TABLE : MAIN_TABLE;
	 *          break;
	 *      case MultiTableModel.HEADER_COLUMN:
	 *         tableKey = columnFooter ? ROWHEADER_COLUMNFOOTER_TABLE : ROWHEADER_TABLE;
	 *          break;
	 *      case MultiTableModel.FOOTER_COLUMN:
	 *          tableKey = columnFooter ? ROWFOOTER_COLUMNFOOTER_TABLE : ROWFOOTER_TABLE;
	 *          break;
	 *  }
	 *  table.putClientProperty(TABLE_KEY, tableKey);
	 *  table.putClientProperty(TableSplitPane.TABLE_INDEX, tableIndex);
	 *  table.putClientProperty(TABLESCROLLPANE_KEY, this);
	 *  table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	 *  if (table instanceof SortableTable) {
	 *      ((SortableTable) table).setSortable(sortable);
	 *  }
	 *  return table;
	 *  </code></pre>
	 * 
	 *  @param model        the table model.
	 *  @param sortable     if the table is sortable.
	 *  @param type         the valid values are {@link com.jidesoft.grid.MultiTableModel#REGULAR_COLUMN}, {@link
	 *                      com.jidesoft.grid.MultiTableModel#HEADER_COLUMN} and {@link com.jidesoft.grid.MultiTableModel#FOOTER_COLUMN}
	 *  @param columnFooter true if the table is for a column footer. Otherwise false.
	 *  @param tableIndex   the index of the table. THe value is returned from {@link com.jidesoft.grid.MultiTableModel#getTableIndex(int)}
	 *                      method.
	 *  @return the table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable, int type, boolean columnFooter, int tableIndex) {
	}

	/**
	 *  Creates the table. Please consider override this method if you want to have your other tables implementing more
	 *  than just SortableTable. However, if you just want to configure the table it creates, please consider override
	 *  {@link #getTableCustomizer()}.
	 *  <p/>
	 *  The default implementation of this method is like below:
	 *  <code><pre>
	 *  return createTable(model, sortable);
	 *  </pre></code>
	 *  <p/>
	 *  As you can see at that method, it will return a SortableTable by default. If you want to use another table such
	 *  as TreeTable, you can override this method and use parameters type and table Index to determine it is row header
	 *  table, then return a TreeTable instead.
	 * 
	 *  @param model    the table model
	 *  @param sortable true or false.
	 *  @param type     the valid values are {@link com.jidesoft.grid.MultiTableModel#REGULAR_COLUMN}, {@link
	 *                  com.jidesoft.grid.MultiTableModel#HEADER_COLUMN} and {@link com.jidesoft.grid.MultiTableModel#FOOTER_COLUMN}
	 *  @return a table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable, int type) {
	}

	/**
	 *  Creates the table. You can override this method or {@link #createTable(javax.swing.table.TableModel, boolean,
	 *  int, boolean, int)} if you just want to configure the table with no intention to create your own table.
	 *  <p/>
	 *  The default implementation is like below:
	 *  <code><pre>
	 *  return new SortableTable(model);
	 *  </pre></code>
	 *  <p/>
	 *  As you can see, it will return a SortableTable by default.
	 * 
	 *  @param model    the table model
	 *  @param sortable true or false.
	 *  @return a table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model, boolean sortable) {
	}

	public boolean isEditing() {
	}

	public javax.swing.JTable getEditingTable() {
	}

	/**
	 *  Gets all child tables in an array. The order is getMainTable(), getRowHeaderTable(), getRowFooterTable(),
	 *  getColumnFooterTable(), getRowHeaderColumnFooterTable, and getRowFooterColumnFooterTable. To tell which table is
	 *  which, you can use table.getClientProperty(TableScrollPane.TABLE_KEY) which will tell you the type of the table.
	 *  For example, if it returns TableScrollPane.MAIN_TABLE, it means the table is the main table.
	 * 
	 *  @return an array of all child tables.
	 */
	public javax.swing.JTable[] getAllChildTables() {
	}

	public javax.swing.table.TableCellEditor getCellEditor() {
	}

	/**
	 *  Removes extra columns from TableColumnModel that doesn't match with the type and tableIndex.
	 * 
	 *  @param table      the table
	 *  @param type       the table type such as REGULAR_COLUMN, FOOTER_COLUMN or HEADER_COLUMN.
	 *  @param tableIndex the table index
	 */
	protected void removeExtraColumns(javax.swing.JTable table, int type, int tableIndex) {
	}

	/**
	 *  Calls this method when getColumnType value changed in MultiTableModel.
	 */
	public void refreshColumns() {
	}

	/**
	 *  Resizes the row header table to fix the gap between the main table, if any.
	 */
	public void resizeRowHeaderTableToFit() {
	}

	/**
	 *  Gets the table customizer. It will use when create the tables used by this TableScrollPane.
	 * 
	 *  @return the table customizer.
	 */
	public TableCustomizer getTableCustomizer() {
	}

	/**
	 *  Sets the table customizer. It will use when create the tables used by this TableScrollPane.
	 * 
	 *  @param tableCustomizer the new table customizer.
	 */
	public void setTableCustomizer(TableCustomizer tableCustomizer) {
	}

	/**
	 *  Sets whether the rows in this model can be selected.
	 * 
	 *  @param rowSelectionAllowed true if this model will allow row selection
	 *  @see #getRowSelectionAllowed
	 */
	public void setRowSelectionAllowed(boolean rowSelectionAllowed) {
	}

	/**
	 *  Returns true if rows can be selected.
	 * 
	 *  @return true if rows can be selected, otherwise false
	 *  @see #setRowSelectionAllowed(boolean)
	 */
	public boolean getRowSelectionAllowed() {
	}

	/**
	 *  Sets whether the columns in this model can be selected.
	 * 
	 *  @param columnSelectionAllowed true if this model will allow column selection
	 *  @see #getColumnSelectionAllowed
	 */
	public void setColumnSelectionAllowed(boolean columnSelectionAllowed) {
	}

	/**
	 *  Returns true if columns can be selected.
	 * 
	 *  @return true if columns can be selected, otherwise false
	 *  @see #setColumnSelectionAllowed(boolean)
	 */
	public boolean getColumnSelectionAllowed() {
	}

	/**
	 *  Sets whether this table allows both a column selection and a row selection to exist simultaneously. When set, the
	 *  table treats the intersection of the row and column selection models as the selected cells. Override
	 *  <code>isCellSelected</code> to change this default behavior. This method is equivalent to setting both the
	 *  <code>rowSelectionAllowed</code> property and <code>columnSelectionAllowed</code> property of the
	 *  <code>columnModel</code> to the supplied value.
	 * 
	 *  @param cellSelectionEnabled true if simultaneous row and column selection is allowed
	 *  @see #getCellSelectionEnabled
	 */
	public void setCellSelectionEnabled(boolean cellSelectionEnabled) {
	}

	/**
	 *  Returns true if both row and column selection models are enabled. Equivalent to <code>getRowSelectionAllowed() &&
	 *  getColumnSelectionAllowed()</code>.
	 * 
	 *  @return true if both row and column selection models are enabled
	 *  @see #setCellSelectionEnabled(boolean)
	 */
	public boolean getCellSelectionEnabled() {
	}

	/**
	 *  Sets whether non-contiguous cell selection in this model can be selected. Please note, non-contiguous cell
	 *  selection is a feature in JideTable so you have to use JideTable or its subclasses in order to use this option.
	 *  Also please note, due to limitation of TableScrollPane, only one table can be selected at a time. In the other
	 *  words, you can't select a few cells in header table and a few cells in the main table.
	 * 
	 *  @param nonContiguousCellSelectionAllowed true if this model will allow non-contiguous cell selection
	 *  @see #isNonContiguousCellSelectionAllowed
	 */
	public void setNonContiguousCellSelectionAllowed(boolean nonContiguousCellSelectionAllowed) {
	}

	/**
	 *  Returns true if non-contiguous cell selection can be selected.
	 * 
	 *  @return true if -contiguous cell selection is enabled, otherwise false
	 *  @see #setNonContiguousCellSelectionAllowed(boolean)
	 */
	public boolean isNonContiguousCellSelectionAllowed() {
	}

	protected void resynchronizeTablesSelection() {
	}

	/**
	 *  Gets the total row count of TableScrollPane.
	 * 
	 *  @return the total row count of TableScrollPane.
	 */
	public int getRowCount() {
	}

	/**
	 *  Gets the total column count of TableScrollPane.
	 * 
	 *  @return the total column count of TableScrollPane.
	 */
	public int getColumnCount() {
	}

	/**
	 *  Get the flag indicating if the TableScrollPane allow select multiple rows in different tables, including main
	 *  table and column footer table for example.
	 *  <p/>
	 *  The default setting is false, which means that if you select one row in main table, the current selection in
	 *  column footer table will be automatically cleared. You can set this flag to true if you don't like this
	 *  behavior.
	 * 
	 *  @return the flag
	 */
	public boolean isAllowMultiSelectionInDifferentTable() {
	}

	/**
	 *  Set the flag indicating if the TableScrollPane allow select multiple rows in different tables, including main
	 *  table and column footer table for example.
	 * 
	 *  @param allowMultiSelectionInDifferentTable true if allow multiple selection. Otherwise false.
	 */
	public void setAllowMultiSelectionInDifferentTable(boolean allowMultiSelectionInDifferentTable) {
	}

	/**
	 *  Gets the table as the specified column index.
	 * 
	 *  @param column the column index related to TableScrollPane.
	 *  @return a TablePosition. The table field in TablePosition is the child table and the column field is the
	 *  converted column index relative to the child table. The row field is always -1. Because the row index is not
	 *  specified, the table could only be the main table, the row header table or the row footer table. It will never be
	 *  one of the column footer tables.
	 */
	public TableScrollPane.TablePosition getTableAtColumn(int column) {
	}

	/**
	 *  Gets the table as the specified row index.
	 * 
	 *  @param row the row index related to TableScrollPane.
	 *  @return a TablePosition. The table field in TablePosition is the child table and the row field is the converted
	 *  row index relative to the child table. The column field is always -1. Because the column index is not specified,
	 *  the table could only be the main table or the column footer table. It will never be the row header tables or the
	 *  row footer table.
	 */
	public TableScrollPane.TablePosition getTableAtRow(int row) {
	}

	/**
	 *  Gets the table as the specified row and column index.
	 * 
	 *  @param row    the row index related to TableScrollPane.
	 *  @param column the column index related to TableScrollPane.
	 *  @return a TablePosition. The table field in TablePosition is the child table, the column field is the converted
	 *  column index relative to the child table and the row field is the converted row index relative to the child
	 *  table.
	 */
	public TableScrollPane.TablePosition getTableAtCell(int row, int column) {
	}

	/**
	 *  Returns the name of the column appearing in the view at column position <code>column</code>.
	 * 
	 *  @param column the column in the view being queried
	 *  @return the name of the column at position <code>column</code> in the view where the first column is column 0
	 */
	public String getColumnName(int column) {
	}

	/**
	 *  Returns the type of the column appearing in the view at column position <code>column</code>.
	 * 
	 *  @param column the column in the view being queried
	 *  @return the type of the column at position <code>column</code> in the view where the first column is column 0
	 */
	public Class getColumnClass(int column) {
	}

	/**
	 *  Returns the cell value at <code>row</code> and <code>column</code>.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return the Object at the specified cell
	 */
	public Object getValueAt(int row, int column) {
	}

	/**
	 *  Sets the value for the cell in the table model at <code>row</code> and <code>column</code>.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 *  <p/>
	 *  <code>aValue</code> is the new value.
	 * 
	 *  @param aValue the new value
	 *  @param row    the row of the cell to be changed
	 *  @param column the column of the cell to be changed
	 *  @see #getValueAt(int, int)
	 */
	public void setValueAt(Object aValue, int row, int column) {
	}

	/**
	 *  Returns true if the cell at <code>row</code> and <code>column</code> is editable.  Otherwise, invoking
	 *  <code>setValueAt</code> on the cell will have no effect.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return true if the cell is editable
	 *  @see #setValueAt(Object, int, int)
	 */
	public boolean isCellEditable(int row, int column) {
	}

	/**
	 *  Returns the index of the first selected row, -1 if no row is selected.
	 * 
	 *  @return the index of the first selected row
	 */
	public int getSelectedRow() {
	}

	/**
	 *  Returns the index of the first selected column, -1 if no column is selected.
	 * 
	 *  @return the index of the first selected column
	 */
	public int getSelectedColumn() {
	}

	/**
	 *  Returns the indices of all selected rows.
	 * 
	 *  @return an array of integers containing the indices of all selected rows, or an empty array if no row is selected
	 *  @see #getSelectedRow
	 */
	public int[] getSelectedRows() {
	}

	/**
	 *  Convert the view column index in the entire TableScrollPane to model index.
	 * 
	 *  @param modelIndex the model column index
	 *  @return the view index
	 */
	public int convertColumnIndexToView(int modelIndex) {
	}

	/**
	 *  Convert the view column index in the entire TableScrollPane to model index.
	 * 
	 *  @param viewIndex the view column index counting from 0 including row header table, main table and row footer
	 *                   table
	 *  @return the model index.
	 */
	public int convertColumnIndexToModel(int viewIndex) {
	}

	/**
	 *  Returns the indices of all selected columns.
	 * 
	 *  @return an array of integers containing the indices of all selected columns, or an empty array if no column is
	 *  selected
	 *  @see #getSelectedColumn
	 */
	public int[] getSelectedColumns() {
	}

	/**
	 *  Returns the number of selected rows.
	 * 
	 *  @return the number of selected rows, 0 if no rows are selected
	 */
	public int getSelectedRowCount() {
	}

	/**
	 *  Returns the number of selected columns.
	 * 
	 *  @return the number of selected columns, 0 if no columns are selected
	 */
	public int getSelectedColumnCount() {
	}

	/**
	 *  Returns true if the specified index is in the valid range of rows, and the row at that index is selected.
	 * 
	 *  @return true if <code>row</code> is a valid index and the row at that index is selected (where 0 is the first
	 *  row)
	 */
	public boolean isRowSelected(int row) {
	}

	/**
	 *  Returns true if the specified index is in the valid range of columns, and the column at that index is selected.
	 * 
	 *  @param column the column in the column model
	 *  @return true if <code>column</code> is a valid index and the column at that index is selected (where 0 is the
	 *  first column)
	 */
	public boolean isColumnSelected(int column) {
	}

	/**
	 *  Returns true if the specified indices are in the valid range of rows and columns and the cell at the specified
	 *  position is selected.
	 * 
	 *  @param row    the row being queried
	 *  @param column the column being queried
	 *  @return true if <code>row</code> and <code>column</code> are valid indices and the cell at index <code>(row,
	 *  column)</code> is selected, where the first row and first column are at index 0
	 */
	public boolean isCellSelected(int row, int column) {
	}

	/**
	 *  Deselects all selected columns and rows.
	 */
	public void clearSelection() {
	}

	public void changeSelection(int rowIndex, int columnIndex, boolean toggle, boolean extend) {
	}

	/**
	 *  A convenience method that displays a printing dialog, and then prints this <code>JTable</code> in mode
	 *  <code>PrintMode.FIT_WIDTH</code>, with no header or footer text. A modal progress dialog, with an abort option,
	 *  will be shown for the duration of printing.
	 *  <p/>
	 *  Note: In headless mode, no dialogs are shown and printing occurs on the default printer.
	 * 
	 *  @return true, unless printing is cancelled by the user
	 *  @throws SecurityException               if this thread is not allowed to initiate a print job request
	 *  @throws java.awt.print.PrinterException if an error in the print system causes the job to be aborted
	 *  @see #print(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat, boolean,
	 *  javax.print.attribute.PrintRequestAttributeSet, boolean, javax.print.PrintService)
	 *  @see #getPrintable(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat)
	 *  @since 3.3.0
	 */
	public boolean print() {
	}

	/**
	 *  A convenience method that displays a printing dialog, and then prints this <code>JTable</code> in the given
	 *  printing mode, with no header or footer text. A modal progress dialog, with an abort option, will be shown for
	 *  the duration of printing.
	 *  <p/>
	 *  Note: In headless mode, no dialogs are shown and printing occurs on the default printer.
	 * 
	 *  @param printMode the printing mode that the printable should use
	 *  @return true, unless printing is cancelled by the user
	 *  @throws SecurityException if this thread is not allowed to initiate a print job request
	 *  @throws PrinterException  if an error in the print system causes the job to be aborted
	 *  @see #print(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat, boolean,
	 *  javax.print.attribute.PrintRequestAttributeSet, boolean, javax.print.PrintService)
	 *  @see #getPrintable(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat)
	 *  @since 3.3.0
	 */
	public boolean print(javax.swing.JTable.PrintMode printMode) {
	}

	/**
	 *  A convenience method that displays a printing dialog, and then prints this <code>JTable</code> in the given
	 *  printing mode, with the specified header and footer text. A modal progress dialog, with an abort option, will be
	 *  shown for the duration of printing.
	 *  <p/>
	 *  Note: In headless mode, no dialogs are shown and printing occurs on the default printer.
	 * 
	 *  @param printMode    the printing mode that the printable should use
	 *  @param headerFormat a <code>MessageFormat</code> specifying the text to be used in printing a header, or null for
	 *                      none
	 *  @param footerFormat a <code>MessageFormat</code> specifying the text to be used in printing a footer, or null for
	 *                      none
	 *  @return true, unless printing is cancelled by the user
	 *  @throws SecurityException if this thread is not allowed to initiate a print job request
	 *  @throws PrinterException  if an error in the print system causes the job to be aborted
	 *  @see #print(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat, boolean,
	 *  javax.print.attribute.PrintRequestAttributeSet, boolean, javax.print.PrintService)
	 *  @see #getPrintable(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat)
	 *  @since 3.3.0
	 */
	public boolean print(javax.swing.JTable.PrintMode printMode, java.text.MessageFormat headerFormat, java.text.MessageFormat footerFormat) {
	}

	/**
	 *  Prints this table with the default printer specified as the print service.
	 * 
	 *  @param printMode       the printing mode that the printable should use
	 *  @param headerFormat    a <code>MessageFormat</code> specifying the text to be used in printing a header, or
	 *                         <code>null</code> for none
	 *  @param footerFormat    a <code>MessageFormat</code> specifying the text to be used in printing a footer, or
	 *                         <code>null</code> for none
	 *  @param showPrintDialog whether or not to display a print dialog
	 *  @param attr            a <code>PrintRequestAttributeSet</code> specifying any printing attributes, or
	 *                         <code>null</code> for none
	 *  @param interactive     whether or not to print in an interactive mode
	 *  @return true, unless printing is cancelled by the user
	 *  @throws HeadlessException if the method is asked to show a printing dialog or run interactively, and
	 *                            <code>GraphicsEnvironment.isHeadless</code> returns <code>true</code>
	 *  @throws SecurityException if this thread is not allowed to initiate a print job request
	 *  @throws PrinterException  if an error in the print system causes the job to be aborted
	 *  @see #print(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat, boolean,
	 *  javax.print.attribute.PrintRequestAttributeSet, boolean, javax.print.PrintService)
	 *  @see #getPrintable(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat)
	 *  @since 3.3.0
	 */
	public boolean print(javax.swing.JTable.PrintMode printMode, java.text.MessageFormat headerFormat, java.text.MessageFormat footerFormat, boolean showPrintDialog, javax.print.attribute.PrintRequestAttributeSet attr, boolean interactive) {
	}

	/**
	 *  Prints this <code>JTable</code>. Takes steps that the majority of developers would take in order to print a
	 *  <code>JTable</code>. In short, it prepares the table, calls <code>getPrintable</code> to fetch an appropriate
	 *  <code>Printable</code>, and then sends it to the printer.
	 *  <p/>
	 *  A <code>boolean</code> parameter allows you to specify whether or not a printing dialog is displayed to the user.
	 *  When it is, the user may use the dialog to change the destination printer or printing attributes, or even to
	 *  cancel the print. Another two parameters allow for a <code>PrintService</code> and printing attributes to be
	 *  specified. These parameters can be used either to provide initial values for the print dialog, or to specify
	 *  values when the dialog is not shown.
	 *  <p/>
	 *  A second <code>boolean</code> parameter allows you to specify whether or not to perform printing in an
	 *  interactive mode. If <code>true</code>, a modal progress dialog, with an abort option, is displayed for the
	 *  duration of printing . This dialog also prevents any user action which may affect the table. However, it can not
	 *  prevent the table from being modified by code (for example, another thread that posts updates using
	 *  <code>SwingUtilities.invokeLater</code>). It is therefore the responsibility of the developer to ensure that no
	 *  other code modifies the table in any way during printing (invalid modifications include changes in: size,
	 *  renderers, or underlying data). Printing behavior is undefined when the table is changed during printing.
	 *  <p/>
	 *  If <code>false</code> is specified for this parameter, no dialog will be displayed and printing will begin
	 *  immediately on the event-dispatch thread. This blocks any other events, including repaints, from being processed
	 *  until printing is complete. Although this effectively prevents the table from being changed, it doesn't provide a
	 *  good user experience. For this reason, specifying <code>false</code> is only recommended when printing from an
	 *  application with no visible GUI.
	 *  <p/>
	 *  Note: Attempting to show the printing dialog or run interactively, while in headless mode, will result in a
	 *  <code>HeadlessException</code>.
	 *  <p/>
	 *  Before fetching the printable, this method will gracefully terminate editing, if necessary, to prevent an editor
	 *  from showing in the printed result. Additionally, <code>JTable</code> will prepare its renderers during printing
	 *  such that selection and focus are not indicated. As far as customizing further how the table looks in the
	 *  printout, developers can provide custom renderers or paint code that conditionalize on the value of {@link
	 *  javax.swing.JComponent#isPaintingForPrint()}.
	 *  <p/>
	 *  See {@link #getPrintable} for more description on how the table is printed.
	 * 
	 *  @param printMode       the printing mode that the printable should use
	 *  @param headerFormat    a <code>MessageFormat</code> specifying the text to be used in printing a header, or
	 *                         <code>null</code> for none
	 *  @param footerFormat    a <code>MessageFormat</code> specifying the text to be used in printing a footer, or
	 *                         <code>null</code> for none
	 *  @param showPrintDialog whether or not to display a print dialog
	 *  @param attr            a <code>PrintRequestAttributeSet</code> specifying any printing attributes, or
	 *                         <code>null</code> for none
	 *  @param interactive     whether or not to print in an interactive mode
	 *  @param service         the destination <code>PrintService</code>, or <code>null</code> to use the default
	 *                         printer
	 *  @return true, unless printing is cancelled by the user
	 *  @throws HeadlessException if the method is asked to show a printing dialog or run interactively, and
	 *                            <code>GraphicsEnvironment.isHeadless</code> returns <code>true</code>
	 *  @throws SecurityException if a security manager exists and its {@link java.lang.SecurityManager#checkPrintJobAccess}
	 *                            method disallows this thread from creating a print job request
	 *  @throws PrinterException  if an error in the print system causes the job to be aborted
	 *  @see #getPrintable(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat)
	 *  @since 3.3.0
	 */
	public boolean print(javax.swing.JTable.PrintMode printMode, java.text.MessageFormat headerFormat, java.text.MessageFormat footerFormat, boolean showPrintDialog, javax.print.attribute.PrintRequestAttributeSet attr, boolean interactive, javax.print.PrintService service) {
	}

	/**
	 *  Return a <code>Printable</code> for use in printing this JTable.
	 *  <p/>
	 *  This method is meant for those wishing to customize the default <code>Printable</code> implementation used by
	 *  <code>JTable</code>'s <code>print</code> methods. Developers wanting simply to print the table should use one of
	 *  those methods directly.
	 *  <p/>
	 *  The <code>Printable</code> can be requested in one of two printing modes. In both modes, it spreads table rows
	 *  naturally in sequence across multiple pages, fitting as many rows as possible per page.
	 *  <code>PrintMode.NORMAL</code> specifies that the table be printed at its current size. In this mode, there may be
	 *  a need to spread columns across pages in a similar manner to that of the rows. When the need arises, columns are
	 *  distributed in an order consistent with the table's <code>ComponentOrientation</code>.
	 *  <code>PrintMode.FIT_WIDTH</code> specifies that the output be scaled smaller, if necessary, to fit the table's
	 *  entire width (and thereby all columns) on each page. Width and height are scaled equally, maintaining the aspect
	 *  ratio of the output.
	 *  <p/>
	 *  The <code>Printable</code> heads the portion of table on each page with the appropriate section from the table's
	 *  <code>JTableHeader</code>, if it has one.
	 *  <p/>
	 *  Header and footer text can be added to the output by providing <code>MessageFormat</code> arguments. The printing
	 *  code requests Strings from the formats, providing a single item which may be included in the formatted string: an
	 *  <code>Integer</code> representing the current page number.
	 *  <p/>
	 *  You are encouraged to read the documentation for <code>MessageFormat</code> as some characters, such as
	 *  single-quote, are special and need to be escaped.
	 *  <p/>
	 *  Here's an example of creating a <code>MessageFormat</code> that can be used to print "Duke's Table: Page - " and
	 *  the current page number:
	 *  <p/>
	 *  <pre>
	 *      // notice the escaping of the single quote
	 *      // notice how the page number is included with "{0}"
	 *      MessageFormat format = new MessageFormat("Duke''s Table: Page - {0}");
	 *  </pre>
	 *  <p/>
	 *  The <code>Printable</code> constrains what it draws to the printable area of each page that it prints. Under
	 *  certain circumstances, it may find it impossible to fit all of a page's content into that area. In these cases
	 *  the output may be clipped, but the implementation makes an effort to do something reasonable. Here are a few
	 *  situations where this is known to occur, and how they may be handled by this particular implementation: <ul>
	 *  <li>In any mode, when the header or footer text is too wide to fit completely in the printable area -- print as
	 *  much of the text as possible starting from the beginning, as determined by the table's
	 *  <code>ComponentOrientation</code>. <li>In any mode, when a row is too tall to fit in the printable area -- print
	 *  the upper-most portion of the row and paint no lower border on the table. <li>In <code>PrintMode.NORMAL</code>
	 *  when a column is too wide to fit in the printable area -- print the center portion of the column and leave the
	 *  left and right borders off the table. </ul>
	 *  <p/>
	 *  It is entirely valid for this <code>Printable</code> to be wrapped inside another in order to create complex
	 *  reports and documents. You may even request that different pages be rendered into different sized printable
	 *  areas. The implementation must be prepared to handle this (possibly by doing its layout calculations on the fly).
	 *  However, providing different heights to each page will likely not work well with <code>PrintMode.NORMAL</code>
	 *  when it has to spread columns across pages.
	 *  <p/>
	 *  As far as customizing how the table looks in the printed result, <code>JTable</code> itself will take care of
	 *  hiding the selection and focus during printing. For additional customizations, your renderers or painting code
	 *  can customize the look based on the value of {@link javax.swing.JComponent#isPaintingForPrint()}
	 *  <p/>
	 *  Also, <i>before</i> calling this method you may wish to <i>first</i> modify the state of the table, such as to
	 *  cancel cell editing or have the user size the table appropriately. However, you must not modify the state of the
	 *  table <i>after</i> this <code>Printable</code> has been fetched (invalid modifications include changes in size or
	 *  underlying data). The behavior of the returned <code>Printable</code> is undefined once the table has been
	 *  changed.
	 * 
	 *  @param printMode    the printing mode that the printable should use
	 *  @param headerFormat a <code>MessageFormat</code> specifying the text to be used in printing a header, or null for
	 *                      none
	 *  @param footerFormat a <code>MessageFormat</code> specifying the text to be used in printing a footer, or null for
	 *                      none
	 *  @return a <code>Printable</code> for printing this JTable
	 *  @see #print(javax.swing.JTable.PrintMode, java.text.MessageFormat, java.text.MessageFormat, boolean,
	 *  javax.print.attribute.PrintRequestAttributeSet, boolean, javax.print.PrintService)
	 *  @see Printable
	 *  @see PrinterJob
	 *  @since 3.3.0
	 */
	public java.awt.print.Printable getPrintable(javax.swing.JTable.PrintMode printMode, java.text.MessageFormat headerFormat, java.text.MessageFormat footerFormat) {
	}

	/**
	 *  A class that define a table, a row index and a column index. This class is used by {@link
	 *  TableScrollPane#getTableAtCell(int, int)}, {@link TableScrollPane#getTableAtRow(int)} and {@link
	 *  TableScrollPane#getTableAtColumn(int)} to convert the row index and column index from the TableScrollPane to its
	 *  child tables.
	 */
	public static class TablePosition {


		public TableScrollPane.TablePosition(javax.swing.JTable table, int row, int column) {
		}

		/**
		 *  Get the table field in the class.
		 * 
		 *  @return the JTable.
		 */
		public javax.swing.JTable getTable() {
		}

		/**
		 *  Get the row in the table.
		 * 
		 *  @return the row index.
		 */
		public int getRow() {
		}

		/**
		 *  Get the column in the table.
		 * 
		 *  @return the column index.
		 */
		public int getColumn() {
		}
	}
}
