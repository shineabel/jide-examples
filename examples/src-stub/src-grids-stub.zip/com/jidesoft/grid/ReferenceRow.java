/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface that references to a row in
 *  the underlying data model. By default, we have {@link IndexReferenceRow} that
 *  refers to a row using row index. If you already have an object that represents a row
 *  in a table model, you can use that object inside this <code>ReferenceRow</code>. Since it is an
 *  interface, it allows you to create your own concrete class and override {@link com.jidesoft.grid.DefaultGroupTableModel#createReferenceRow(javax.swing.table.TableModel,int)}
 *  method to use your own class.
 */
public interface ReferenceRow extends GroupRow {
}
