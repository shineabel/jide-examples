/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This interface is to provide support to {@link GroupTableHeader}.
 * 
 *  @since 3.2.3
 */
public interface GroupModelProvider {

	/**
	 *  Gets the count of group columns.
	 * 
	 *  @return the column count.
	 */
	public int getGroupColumnCount();

	/**
	 *  Gets the corresponding column index in its actual table model for the designated group column.
	 * 
	 *  @param index the group column index
	 *  @return the corresponding column index in its actual table model
	 */
	public int getGroupColumnAt(int index);

	/**
	 *  Gets the corresponding column order in its actual table model for the designated group column.
	 * 
	 *  @param index the group column index
	 *  @return the corresponding column order in its actual table model
	 */
	public int getGroupColumnOrder(int index);

	/**
	 *  Sets the group columns.
	 * 
	 *  @param columns the columns array
	 *  @param orders  the orders array
	 */
	public void setGroupColumns(int[] columns, int[] orders);

	/**
	 *  Groups the table model and refresh.
	 */
	public void groupAndRefresh();

	/**
	 *  Groups the table model and refresh.
	 *  @since 3.6.10
	 */
	public void groupAndRefresh(boolean needSendStructureChange);

	/**
	 *  Checks if the column is groupable or not.
	 * 
	 *  @param columnIndex the column index
	 *  @return true if the column is groupable. Otherwise false.
	 */
	public boolean isColumnGroupable(int columnIndex);

	/**
	 *  Gets the flag indicating if group columns should be displayed.
	 * 
	 *  @return true if the group columns should be displayed in the native table header. Otherwise false.
	 */
	public boolean isDisplayGroupColumns();

	/**
	 *  Gets the flag indicating if group columns should always be displayed at the begging when displayed.
	 * 
	 *  @return true if the group columns should be displayed in the beginning in the native table header. Otherwise false.
	 */
	public boolean groupColumnsFirst();

	/**
	 *  Gets the identifier of the group column index.
	 * 
	 *  @param groupColumnIndex the group column index
	 *  @return the identifier.
	 *  @since 3.3.0
	 */
	public Object getGroupColumnIdentifier(int groupColumnIndex);
}
