/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This interface indicate the table model which implements this interface could fire IndexChangeEvent.
 */
public interface IndexChangeEventGenerator {

	/**
	 *  Add IndexChangelistener.
	 * 
	 *  @param l the listener
	 */
	public void addIndexChangeListener(IndexChangeListener l);

	/**
	 *  Remove IndexChangelistener.
	 * 
	 *  @param l the listener
	 */
	public void removeIndexChangeListener(IndexChangeListener l);

	/**
	 *  Returns an array of all the <code>IndexChangeListener</code>s
	 * 
	 *  @return all of the <code>IndexChangeListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addIndexChangeListener
	 * 
	 *  @since 3.4.4
	 */
	public IndexChangeListener[] getIndexChangeListeners();
}
