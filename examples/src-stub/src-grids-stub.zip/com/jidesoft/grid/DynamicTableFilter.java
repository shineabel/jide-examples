/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>DynamicFilter</code> extends <code>Filter</code> interface to allow you to customize the filter just before it
 *  is used.
 */
public interface DynamicTableFilter extends TableFilter {

	/**
	 *  Initialize the filter. The {@link #isValueFiltered(Object)} should do the filtering after the filter is
	 *  initialized.
	 * 
	 *  @param tableModel
	 *  @param columnIndex
	 *  @param possibleValues
	 *  @return true if a filter is initialized. Otherwise returns false. For example, you can popup a dialog in this
	 *          method to customize a filter. If user cancelled this dialog, you should return false.
	 */
	public boolean initializeFilter(javax.swing.table.TableModel tableModel, int columnIndex, Object[] possibleValues);
}
