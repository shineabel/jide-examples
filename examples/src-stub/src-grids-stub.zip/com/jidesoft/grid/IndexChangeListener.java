/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The listener interface for receiving IndexChangeEvent.
 */
public interface IndexChangeListener extends java.util.EventListener {

	/**
	 *  Called whenever the model wrapper is going to have index changed. So far we have index changing and index changed
	 *  events.
	 * 
	 *  @param event the IndexChangeEvent
	 */
	public void indexChanged(IndexChangeEvent event);
}
