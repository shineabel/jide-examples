/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CsvTableUtils</code> is a class that has methods to export any JTable's content to Character Separated Values
 *  file format.
 *  <p/>
 *  The export feature will not consider the cell contents conversion but you can use ValueConverter to format the value
 *  if you want. It will also optionally consider table header as part of the export. You could also choose any character
 *  including comma as the separator.
 *  <p/>
 *  It does NOT support cell span and will LOSE the collapsed rows in TreeTable scenario because of the CSV format
 *  limitation.
 */
public class CsvTableUtils {

	public CsvTableUtils() {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table    the table to be exported.
	 *  @param fileName the CSV file name. It should be the full path to the file.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName) {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table              the table to be exported.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the table header.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, boolean includeTableHeader) {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table              the table to be exported.
	 *  @param fileName           the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter) {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table               the table to be exported.
	 *  @param fileName            the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table               the table to be exported.
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param fileName            the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table               the table to be exported.
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param fileName            the CSV file name. It should be the full path to the file.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @param separator           the character used to separate the cells. By default, it is a comma.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String fileName, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter, char separator) {
	}

	/**
	 *  Exports the table to an CSV file.
	 * 
	 *  @param table    the table to be exported.
	 *  @param fileName the CSV file name. It should be the full path to the file.
	 *  @param config   a collection of the parameters that could be configured during the export process.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, CsvTableUtils.CsvTableExportConfig config) {
	}

	public static void addCellValue(StringBuffer csvBuffer, String cellValue, char separator) {
	}

	public static void addLineBreak(StringBuffer csvBuffer) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table the table to be exported.
	 *  @param out   the output stream
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table              the table to be exported.
	 *  @param out                the output stream
	 *  @param includeTableHeader whether to include the table header.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, boolean includeTableHeader) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table              the table to be exported.
	 *  @param out                the output stream
	 *  @param includeTableHeader whether to include the table header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to CSV cell.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, boolean includeTableHeader, ValueConverter cellValueConverter) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table               the table to be exported.
	 *  @param out                 the output stream
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table               the table to be exported.
	 *  @param out                 the output stream
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table               the table to be exported.
	 *  @param out                 the output stream
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to CSV cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @param separator           the character used to separate the cells. By default, it is a comma.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, boolean includeTableHeader, ValueConverter cellValueConverter, StringConverter columnNameConverter, char separator) {
	}

	/**
	 *  Exports the table to a CSV file output steam.
	 * 
	 *  @param table  the table to be exported.
	 *  @param out    the output stream
	 *  @param config a collection of the parameters that could be configured during the export process.
	 * 
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException           if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 *  @since 3.3.8
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, CsvTableUtils.CsvTableExportConfig config) {
	}

	/**
	 *  A class that has all the parameters that could be customized when exporting a table or a TableScrollPane to csv file.
	 * 
	 *  @since 3.3.8
	 */
	public static class CsvTableExportConfig {


		/**
		 *  The constructor.
		 */
		public CsvTableUtils.CsvTableExportConfig() {
		}

		/**
		 *  Gets the flag indicating if the table header should be exported.
		 * 
		 *  @return true if the table header should be exported. Otherwise false.
		 */
		public boolean isHeaderIncluded() {
		}

		/**
		 *  Sets the flag indicating if the table header should be exported.
		 * 
		 *  @param headerIncluded the flag
		 */
		public void setHeaderIncluded(boolean headerIncluded) {
		}

		/**
		 *  Gets the cell value converter.
		 * 
		 *  @return the cell value converter.
		 */
		public ValueConverter getCellValueConverter() {
		}

		/**
		 *  Sets the cell value converter.
		 * 
		 *  @param cellValueConverter the cell value converter
		 */
		public void setCellValueConverter(ValueConverter cellValueConverter) {
		}

		/**
		 *  Gets the column name converter.
		 * 
		 *  @return the column name converter.
		 */
		public StringConverter getColumnNameConverter() {
		}

		/**
		 *  Sets the column name converter.
		 * 
		 *  @param columnNameConverter the column name converter
		 */
		public void setColumnNameConverter(StringConverter columnNameConverter) {
		}

		/**
		 *  Gets the first row to be exported.
		 * 
		 *  @return the first row to be exported. -1 to export from the first row.
		 */
		public int getFirstRow() {
		}

		/**
		 *  Sets the first row to be exported.
		 * 
		 *  @param firstRow the first row
		 */
		public void setFirstRow(int firstRow) {
		}

		/**
		 *  Gets the first column to be exported.
		 * 
		 *  @return the first column to be exported. -1 to export from the first column.
		 */
		public int getFirstColumn() {
		}

		/**
		 *  Sets the first column to be exported.
		 * 
		 *  @param firstColumn the first column
		 */
		public void setFirstColumn(int firstColumn) {
		}

		/**
		 *  Gets the number of rows to be exported.
		 * 
		 *  @return the number of rows to be exported. -1 to export all rows from the first row.
		 */
		public int getNumOfRows() {
		}

		/**
		 *  Sets the number of rows to be exported.
		 * 
		 *  @param numOfRows the number of rows to be exported
		 */
		public void setNumOfRows(int numOfRows) {
		}

		/**
		 *  Gets the number of columns to be exported.
		 * 
		 *  @return the number of columns to be exported. -1 to export all columns from the first column.
		 */
		public int getNumOfColumns() {
		}

		/**
		 *  Sets the number of columns to be exported.
		 * 
		 *  @param numOfColumns the number of columns to be exported
		 */
		public void setNumOfColumns(int numOfColumns) {
		}

		/**
		 *  Gets the separator to separate the cells.
		 * 
		 *  @return the separator. By default, it's a comma.
		 */
		public char getSeparator() {
		}

		/**
		 *  Sets the separator to separate the cells.
		 * 
		 *  @param separator the separator
		 */
		public void setSeparator(char separator) {
		}

		/**
		 *  Gets the charset name.
		 * 
		 *  @return the charset name.
		 */
		public String getCharsetName() {
		}

		/**
		 *  Sets the charset name.
		 * 
		 *  @param charsetName the charset name
		 */
		public void setCharsetName(String charsetName) {
		}
	}
}
