/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell editor for text with line breaks. It still display the text in one line but when user clicks on the drop down
 *  button, a dialog will show up to allow user to edit the text with new lines.
 */
public class LegacyMultilineStringCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a LegacyMultilineStringCellEditor.
	 */
	public LegacyMultilineStringCellEditor() {
	}

	/**
	 *  Creates the MultilineStringComboBox used by this cell editor.
	 * 
	 *  @return a MultilineStringComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates the MultilineStringComboBox used by this cell editor.
	 * 
	 *  @return a MultilineStringComboBox.
	 */
	protected com.jidesoft.combobox.MultilineStringComboBox createMultilineStringComboBox() {
	}
}
