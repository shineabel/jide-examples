/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The FilterEditor interface for the JComponents that edits the filters to implement.
 * 
 *  @since 3.4.1
 */
public interface FilterEditor {

	/**
	 *  Gets the filters from the FilterEditor.
	 * 
	 *  @return the filter array.
	 */
	public com.jidesoft.filter.Filter[] getFilters();

	/**
	 *  Sets the filters to the FilterEditor, which will update the JComponent accordingly.
	 * 
	 *  @param filters the filters
	 */
	public void setFilters(com.jidesoft.filter.Filter[] filters);

	/**
	 *  Sets the ObjectGrouper used by the FilterEditor.
	 * 
	 *  @param objectGrouper the ObjectGrouper instance
	 *  @since 3.4.7
	 */
	public void setObjectGrouper(ObjectGrouper objectGrouper);
}
