/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is the interface to provide table interface for the GroupTableHeader.
 * 
 *  @since 3.5.3
 */
public interface GroupHeaderTableProvider {

	public void prepareBeforeGroup();
}
