/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell editor based on ExComboBox. This is an abstract class. You need to implement createExComboBox to
 *  create a subclass of ExComboBox.
 */
public abstract class ExComboBoxCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor, java.awt.event.ActionListener, javax.swing.event.PopupMenuListener {

	protected com.jidesoft.combobox.ExComboBox _comboBox;

	/**
	 *  Creates an ExComboBoxCellEditor.
	 */
	public ExComboBoxCellEditor() {
	}

	/**
	 *  Creates an ExComboBoxCellEditor.
	 * 
	 *  @param model the combobox model.
	 *  @param type  the type of the element in the model.
	 */
	public ExComboBoxCellEditor(javax.swing.ComboBoxModel model, Class type) {
	}

	protected void customizeExComboBox() {
	}

	/**
	 *  Creates an ExComboBox or its subclass used by this cell editor.
	 * 
	 *  @return an ExComboBox.
	 */
	public abstract com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates an ExComboBox or its subclass used by this cell editor. Different from {@link
	 *  #createExComboBox()}, this method takes a ComboBoxModel and type. By default, this method will call
	 *  createExComboBox() but subclass can override it to create an ExComboBox.
	 * 
	 *  @param model the combobox model.
	 *  @param type  the type of the element in the model.
	 *  @return an ExComboBox.
	 */
	public com.jidesoft.combobox.ExComboBox createExComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	/**
	 *  Sets the value to the combobox. By default, it will use setSelectedItem(value, false) to set the value.
	 * 
	 *  @param value the new value.
	 */
	public void setCellEditorValue(Object value) {
	}

	/**
	 *  Gets the value of the cell editor.
	 * 
	 *  @return the value of the cell editor
	 */
	public Object getCellEditorValue() {
	}

	@java.lang.Override
	public void setType(Class valueClass) {
	}

	@java.lang.Override
	public boolean stopCellEditing() {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {
	}

	/**
	 *  Gets the combobox used by this cell editor.
	 * 
	 *  @return the abstract combobox.
	 */
	public com.jidesoft.combobox.ExComboBox getComboBox() {
	}

	@java.lang.Override
	public void setConverter(ObjectConverter converter) {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}
}
