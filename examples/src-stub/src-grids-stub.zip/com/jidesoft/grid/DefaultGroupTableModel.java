/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class DefaultGroupTableModel extends AbstractGroupTableModel implements ColumnIdentifierTableModel, SpanModel, RowTableModelWrapper, ColumnTableModelWrapper, GroupModelProvider, EditorStyleTableModel, ColumnDraggableSupport, SummaryProvider, StyleModel {

	/**
	 *  No sort on the group column, which means the group rows will be displayed in a first-come-first-display order by
	 *  the order it appears in the original table model.
	 */
	public static final int SORT_GROUP_COLUMN_NO_SORT = 0;

	/**
	 *  Ascending order on the group column, which means the groups row will be sorted in an ascending order.
	 */
	public static final int SORT_GROUP_COLUMN_ASCENDING = 1;

	/**
	 *  Descending order on the group column, which means the groups row will be sorted in an descending order.
	 */
	public static final int SORT_GROUP_COLUMN_DESCENDING = -1;

	public static final String PROPERTY_GROUPED_COLUMNS = "groupColumns";

	/**
	 *  The constructor.
	 * 
	 *  @param tableModel the original table model embedded in the DefaultGroupTableModel.
	 */
	public DefaultGroupTableModel(javax.swing.table.TableModel tableModel) {
	}

	@java.lang.Override
	public IndexChangeListener[] getIndexChangeListeners() {
	}

	@java.lang.Override
	public void fireTableRowsDeleted(int firstRow, int lastRow) {
	}

	@java.lang.Override
	public void fireTableRowsInserted(int firstRow, int lastRow) {
	}

	@java.lang.Override
	public void fireTableRowsUpdated(int firstRow, int lastRow) {
	}

	@java.lang.Override
	public void fireTableCellUpdated(int row, int column) {
	}

	/**
	 *  Checks if the specific column is groupable. By default it simply returns true for all columns. You could override
	 *  this method to make some columns non-groupable.
	 * 
	 *  @param columnIndex the column index in the wrapped table model of this DefaultGroupTableModel
	 *  @return true if the column is groupable. Otherwise false.
	 *  @since 3.2.3 changed to public
	 */
	public boolean isColumnGroupable(int columnIndex) {
	}

	/**
	 *  Creates a CompoundTableModelEvent. It is created when a CompoundTableModelEvent is required.
	 * 
	 *  @return the CompoundTableModelEvent instance.
	 */
	protected CompoundTableModelEvent createCompoundTableModelEvent() {
	}

	/**
	 *  Do grouping and fire table structure changed event.
	 */
	public void groupAndRefresh() {
	}

	/**
	 *  Do grouping and you have an option to fire table structure changed event or not.
	 * 
	 *  @param needSendStructureChange true or false.
	 */
	public void groupAndRefresh(boolean needSendStructureChange) {
	}

	/**
	 *  Creates DefaultGroupRow. This is to create a non-leaf row in GroupTable.
	 *  <p/>
	 *  The row created will be expanded if {@link #isAutoExpand()} returns true. Otherwise collapsed.
	 * 
	 *  @return the DefaultGroupRow instance.
	 */
	protected DefaultGroupRow createGroupRow() {
	}

	/**
	 *  Creates ReferenceRow. This is to create a leaf row in GroupTable.
	 * 
	 *  @param tableModel the original table model
	 *  @param row        the row index in the original table model
	 *  @return the  ReferenceRow instance.
	 */
	protected ReferenceRow createReferenceRow(javax.swing.table.TableModel tableModel, int row) {
	}

	/**
	 *  Gets the flag indicating if the original column order in original table model should be kept.
	 * 
	 *  @return true if the original column order should be kept. Otherwise false.
	 *  @see #setKeepColumnOrder(boolean)
	 */
	public boolean isKeepColumnOrder() {
	}

	/**
	 *  Sets the flag indicating if the original column order in original table model should be kept.
	 *  <p/>
	 *  By default, the flag is false.
	 *  <p/>
	 *  If you set the flag to true, the GroupTable will simply use the column order of the original table model. Hence,
	 *  {@link #isDisplayCountColumn()}, {@link #isDisplayGroupColumns()} and {@link #isDisplaySeparateGroupColumn()}
	 *  would not be honored.
	 * 
	 *  @param keepColumnOrder the flag
	 */
	public void setKeepColumnOrder(boolean keepColumnOrder) {
	}

	@java.lang.Override
	public boolean isColumnDraggable(int columnIndex) {
	}

	/**
	 *  Adds GroupRow to a parent row.
	 *  <p/>
	 *  In most scenarios, you don't have to call this method explicitly because {@link #groupAndRefresh()} will invoke
	 *  it automatically.
	 * 
	 *  @param parentRow the parent row, which should also be a group row or a root row
	 *  @param groupRow  the group row to be added to the parent row
	 *  @return the groupRow added.
	 */
	public DefaultGroupRow addGroupRow(Expandable parentRow, DefaultGroupRow groupRow) {
	}

	/**
	 *  Finds a group row based on the ancestor row and the group condition.
	 * 
	 *  @param parent    the ancestor row
	 *  @param condition the group condition
	 *  @return the group row which represents the group condition exactly. Otherwise null.
	 */
	public DefaultGroupRow findParentGroupRow(Expandable parent, GroupCondition condition) {
	}

	/**
	 *  Makes sure internal used fields are created.
	 */
	protected void ensureGroupColumnsCreated() {
	}

	@java.lang.Override
	public boolean isGroupEnabled() {
	}

	/**
	 *  Is the column grouped.
	 * 
	 *  @param columnIndex the column index. It is the column index as in the original table model.
	 *  @return true if the column is grouped. Otherwise false.
	 */
	public boolean isColumnGrouped(int columnIndex) {
	}

	/**
	 *  Checks if it has grouped columns.
	 * 
	 *  @return true if it has grouped columns. Otherwise false.
	 */
	public boolean hasGroupColumns() {
	}

	/**
	 *  Gets the total count of group columns. You can use this method to get the count then use {@link
	 *  #getGroupColumnAt(int)} method to find out each group column index.
	 * 
	 *  @return the total count of group columns.
	 */
	public int getGroupColumnCount() {
	}

	/**
	 *  Gets the group column index.
	 * 
	 *  @param index the column index.
	 *  @return the group column index.
	 */
	public int getGroupColumnAt(int index) {
	}

	/**
	 *  Gets the group column order.
	 *  <p/>
	 *  The return value would be {@link #SORT_GROUP_COLUMN_NO_SORT}, {@link #SORT_GROUP_COLUMN_ASCENDING} or {@link
	 *  #SORT_GROUP_COLUMN_DESCENDING}
	 * 
	 *  @param index the column index
	 *  @return the order.
	 */
	public int getGroupColumnOrder(int index) {
	}

	/**
	 *  Adds a group column with default ascending order.
	 *  <p/>
	 *  This method is just to manage the group columns. To make the group happen in the table, please invoke {@link
	 *  #groupAndRefresh()}.
	 * 
	 *  @param columnIndex the column index in the original table model
	 */
	public void addGroupColumn(int columnIndex) {
	}

	/**
	 *  Adds a group column with designated sort order.
	 *  <p/>
	 *  This method is just to manage the group columns. To make the group happen in the table, please invoke {@link
	 *  #groupAndRefresh()}.
	 * 
	 *  @param columnIndex the column index in the original table model
	 *  @param order       the sort mode, one of {@link #SORT_GROUP_COLUMN_NO_SORT}, {@link #SORT_GROUP_COLUMN_ASCENDING}
	 *                     or {@link #SORT_GROUP_COLUMN_DESCENDING}
	 */
	public void addGroupColumn(int columnIndex, int order) {
	}

	/**
	 *  Removes a group column.
	 *  <p/>
	 *  This method is just to manage the group columns. To make the ungroup happen in the table, please invoke {@link
	 *  #groupAndRefresh()}.
	 * 
	 *  @param columnIndex the column index in the original table model
	 */
	public void removeGroupColumn(int columnIndex) {
	}

	/**
	 *  Sets group columns in a batch mode with default order as ascending.
	 *  <p/>
	 *  This method is just to manage the group columns. To make the group happen in the table, please invoke {@link
	 *  #groupAndRefresh()}.
	 * 
	 *  @param columnIndices the new group column indices in original table model
	 */
	public void setGroupColumns(int[] columnIndices) {
	}

	/**
	 *  Sets group columns in a batch mode.
	 *  <p/>
	 *  This method is just to manage the group columns. To make the group happen in the table, please invoke {@link
	 *  #groupAndRefresh()}.
	 * 
	 *  @param columnIndices the new group column indices in original table model
	 *  @param columnSorting the sort order of each group column
	 */
	public void setGroupColumns(int[] columnIndices, int[] columnSorting) {
	}

	/**
	 *  Clears all group columns.
	 *  <p/>
	 *  This method is just to manage the group columns. To make the ungroup happen in the table, please invoke {@link
	 *  #groupAndRefresh()}.
	 */
	public void clearGroupColumns() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	/**
	 *  Gets the identifier of the group column index.
	 * 
	 *  @param groupColumnIndex the group column index
	 *  @return the identifier.
	 *  @since 3.3.0
	 */
	public Object getGroupColumnIdentifier(int groupColumnIndex) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the flag if the group rows will be created in a single level or multiple levels mode.
	 * 
	 *  @return true if the group rows are created in one single level. Otherwise false.
	 *  @see #setSingleLevelGrouping(boolean)
	 */
	public boolean isSingleLevelGrouping() {
	}

	/**
	 *  Sets the flag if the group rows will be created in a single level or multiple levels mode.
	 *  <p/>
	 *  By default, the value is false, which means multiple level GroupRows will be created. If you want only one level
	 *  group row even if you have multiple group columns, please set this flag to true.
	 * 
	 *  @param singleLevelGrouping the flag
	 */
	public void setSingleLevelGrouping(boolean singleLevelGrouping) {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Finds a group row to hold the row in the original table model.
	 * 
	 *  @param parent     the parent row
	 *  @param tableModel the original table model
	 *  @param rowIndex   the row index
	 *  @return the group row existed. null if not existing.
	 */
	public DefaultGroupRow findGroupRow(Expandable parent, javax.swing.table.TableModel tableModel, int rowIndex) {
	}

	/**
	 *  Finds a group row to hold the row in this group table model.
	 * 
	 *  @param row         the row instance inside the group table model
	 *  @param columnIndex the group column to find
	 *  @return the group row existed. null if not existing.
	 */
	public DefaultGroupRow findGroupRow(Row row, int columnIndex) {
	}

	@java.lang.Override
	public Row getRowAt(int rowIndex) {
	}

	@java.lang.Override
	public int getRowIndex(Row row) {
	}

	public ReferenceRow getReferenceRow(int rowIndex) {
	}

	public boolean isCellSpanOn() {
	}

	@java.lang.Override
	public int getColumnType(int columnIndex) {
	}

	@java.lang.Override
	public int getTableIndex(int columnIndex) {
	}

	/**
	 *  The handler to handle tableRowsInserted event.
	 * 
	 *  @param firstRow the first row inserted
	 *  @param lastRow  the last row inserted
	 */
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	/**
	 *  The handler to handle tableRowsDeleted event.
	 * 
	 *  @param firstRow the first row deleted
	 *  @param lastRow  the last row deleted
	 */
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	/**
	 *  Updates the row index field of IndexReferenceRow. Should be invoked only inside the table model event handlers.
	 * 
	 *  @param index the row index
	 *  @param inc   the gap to be updated
	 */
	protected void updateReference(int index, int inc) {
	}

	/**
	 *  The handler to handle tableRowsUpdated event.
	 * 
	 *  @param firstRow the first row updated
	 *  @param lastRow  the last row updated
	 */
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  The handler to handle tableCellsUpdated event.
	 * 
	 *  @param column   the column updated
	 *  @param firstRow the first row updated
	 *  @param lastRow  the last row updated
	 */
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  The handler to handle tableStructureChanged event.
	 */
	protected void tableStructureChanged() {
	}

	/**
	 *  The handler to handle tableDataChanged event.
	 */
	protected void tableDataChanged() {
	}

	/**
	 *  Gets column mapping.
	 * 
	 *  @return the column mapping array which contains the map from the column index in this DefaultGroupTableModel to
	 *  the original table model.
	 */
	public int[] getColumnMapping() {
	}

	public javax.swing.table.TableModel getActualModel() {
	}

	public int getActualRowAt(int visualRow) {
	}

	public int getVisualRowAt(int actualRow) {
	}

	public int getActualColumnAt(int column) {
	}

	public int getVisualColumnAt(int actualColumn) {
	}

	/**
	 *  Gets the flag indicating if the GroupTable should display group columns.
	 *  <p/>
	 *  By default, the value is false to not show the group columns.
	 *  <p/>
	 *  If {@link #isSummaryMode()} is true, this method will always return true.
	 * 
	 *  @return true if the GroupTable should display group columns. Otherwise false.
	 *  @see #isSummaryMode()
	 */
	public boolean isDisplayGroupColumns() {
	}

	@java.lang.Override
	public boolean groupColumnsFirst() {
	}

	/**
	 *  Sets the flag indicating if the GroupTable should display group columns.
	 * 
	 *  @param displayGroupColumns the flag
	 *  @see #isDisplayGroupColumns()
	 */
	public void setDisplayGroupColumns(boolean displayGroupColumns) {
	}

	/**
	 *  Gets the flag indicating if a separate group column should be created to represent the grouped columns.
	 *  <p/>
	 *  By default, the value is false to not show the separate group column. This flag only takes effect while {@link
	 *  #isDisplayGroupColumns()} returns false and {@link #isKeepColumnOrder()} returns false.
	 * 
	 *  @return true if a separate group column is displayed. Otherwise false.
	 *  @see #setDisplayGroupColumns(boolean)
	 *  @see #setKeepColumnOrder(boolean)
	 */
	public boolean isDisplaySeparateGroupColumn() {
	}

	/**
	 *  Sets the flag indicating if a separate group column should be created to represent the grouped columns.
	 * 
	 *  @param displaySeparateGroupColumn the flag
	 *  @see #isDisplaySeparateGroupColumn()
	 */
	public void setDisplaySeparateGroupColumn(boolean displaySeparateGroupColumn) {
	}

	public boolean isFirstColumn(int columnIndex) {
	}

	/**
	 *  Gets the flag indicating if the grouped value will be shown on the first column when there are no separate
	 *  grouped columns.
	 * 
	 *  @return true or false.
	 *  @see #setDisplayGroupColumns(boolean)
	 *  @see #setDisplaySeparateGroupColumn(boolean)
	 */
	public boolean isDisplayGroupValueOnFirstColumn() {
	}

	/**
	 *  Sets the flag indicating if a separate group column should be created to represent the grouped columns.
	 * 
	 *  @param displayGroupValueOnFirstColumn the flag
	 */
	public void setDisplayGroupValueOnFirstColumn(boolean displayGroupValueOnFirstColumn) {
	}

	/**
	 *  Gets the column name for the count column.
	 * 
	 *  @return the column name. By default "Count".
	 *  @since 3.4.6
	 */
	protected String getCountColumnName() {
	}

	/**
	 *  Gets the column name for the separate group column.
	 * 
	 *  @return the column name. By default "Grouped Columns".
	 */
	protected String getSeparateGroupColumnName() {
	}

	/**
	 *  Gets the flag indicating if a separate count column should be created to represent the count.
	 *  <p/>
	 *  By default, the value is false to not show the separate count column. This flag only takes effect while {@link
	 *  #isDisplayGroupColumns()} returns true.
	 * 
	 *  @return true if a separate count column is displayed. Otherwise false.
	 *  @see #setDisplayGroupColumns(boolean)
	 */
	public boolean isDisplayCountColumn() {
	}

	/**
	 *  Sets the flag indicating if a separate count column should be created to represent the count.
	 * 
	 *  @param displayCountColumn the flag
	 *  @see #isDisplayCountColumn()
	 */
	public void setDisplayCountColumn(boolean displayCountColumn) {
	}

	@java.lang.Override
	public void expandRow(ExpandableRow row, boolean expanded) {
	}

	@java.lang.Override
	public void expandAll() {
	}

	/**
	 *  Expands all rows.
	 * 
	 *  @param fireDataChangedEvent the flag to indicating if a data changed event should be fired after expanding all.
	 */
	protected void expandAll(boolean fireDataChangedEvent) {
	}

	@java.lang.Override
	public void expandFirstLevel() {
	}

	@java.lang.Override
	public void collapseAll() {
	}

	@java.lang.Override
	public void collapseFirstLevel() {
	}

	/**
	 *  Expand all rows that corresponding to the group column.
	 * 
	 *  @param groupColumnIndex the group column index
	 *  @since 3.3.1
	 */
	public void expandGroupColumn(int groupColumnIndex) {
	}

	/**
	 *  Collapse all rows that corresponding to the group column.
	 * 
	 *  @param groupColumnIndex the group column index
	 *  @since 3.3.1
	 */
	public void collapseGroupColumn(int groupColumnIndex) {
	}

	/**
	 *  Sorts the rows.
	 *  <p/>
	 *  Subclass can override this method to implement their own algorithm to sort. When doing comparison in the
	 *  algorithm, use the compare(int, int) method defined in this class.
	 * 
	 *  @param from an int array of row indices to be sorted
	 *  @param to   an int array of row indices to store the result after sorting
	 *  @param low  the start index of the row in the array to be sorted
	 *  @param high the end index of the row in the array to be sorted
	 */
	protected void sort(int[] from, int[] to, int low, int high) {
	}

	/**
	 *  Compares two rows.
	 * 
	 *  @param row1 the first row index
	 *  @param row2 the second row index
	 *  @return 0 if the order of those two rows doesn't matter. -1 to keep current order. 1 to switch those two rows.
	 */
	protected int compare(int row1, int row2) {
	}

	/**
	 *  Compares two objects in a column.
	 * 
	 *  @param o1     the first object
	 *  @param o2     the second object
	 *  @param column the column index
	 *  @return 0 if the order of those two objects doesn't matter. -1 to keep current order. 1 to switch those two
	 *  objects.
	 */
	protected int compare(Object o1, Object o2, int column) {
	}

	/**
	 *  For performance, all comparators for each column should be cached first.
	 */
	protected void cacheComparators() {
	}

	/**
	 *  Gets the column comparator. Subclass can override it to return a comparator for a particular column. By default,
	 *  SortableTableModel will look up for a comparator from ObjectComparatorManager based on getColumnClass return
	 *  value and getColumnComparatorContext return value. Please note, for the performance reason, if both objects are
	 *  Comparable of the same type, we will use Comparable#compareTo method to compare the two objects. Then we will use
	 *  the Comparator. If you want to always use Comparator to compare, you can call {@link
	 *  #setAlwaysUseComparators(boolean)} and set it to true.
	 * 
	 *  @param columnIndex the column index in the actual table model. It's NOT the column index in the group table
	 *                     model.
	 *  @return the comparator for the specified column.
	 */
	public java.util.Comparator getComparator(int columnIndex) {
	}

	/**
	 *  Gets the column comparator context. Subclass can override it to return a comparator context. By default it will
	 *  return null. It should only be used when the column class for two columns are the same but you want to compare
	 *  them differently. First you need to register two different comparators using {@link ObjectComparatorManager}
	 *  using different comparator context in {@link ObjectComparatorManager#registerComparator(Class,
	 *  java.util.Comparator, com.jidesoft.comparator.ComparatorContext)} method. Then return the corresponding context
	 *  when overriding this method.
	 *  <p/>
	 *  We also add a setter for this. You can call {@link #setColumnComparatorContextProvider(com.jidesoft.grid.DefaultGroupTableModel.ColumnComparatorContextProvider)}
	 *  to provide a ColumnComparatorContextProvider. This provider will return a ComparatorContext for each column. This
	 *  will be helpful when it's hard to override SortableTableModel.
	 * 
	 *  @param column the column index in the actual table model. It's NOT the column index in the group table model.
	 *  @return the comparator context for the column.
	 */
	protected ComparatorContext getColumnComparatorContext(int column) {
	}

	/**
	 *  Gets the flag indicating if the row will be moved to upper level if the last grouper values are null.
	 * 
	 *  @return true if the row will be moved to upper level. Otherwise false.
	 *  @see #setRemoveNullGrouper(boolean)
	 */
	public boolean isRemoveNullGrouper() {
	}

	/**
	 *  Sets the flag indicating if the row will be moved to upper level if the last grouper values are null.
	 *  <p/>
	 *  The default value is false to keep original behavior.
	 * 
	 *  @param removeNullGrouper the flag
	 */
	public void setRemoveNullGrouper(boolean removeNullGrouper) {
	}

	/**
	 *  Gets the flag indicating if the group rows will be put ahead of the other reference rows when {@link
	 *  #isRemoveNullGrouper()} returns true.
	 * 
	 *  @return true if the group rows will be laid out first. Otherwise false.
	 *  @see #setDisplayGroupRowsFirst
	 *  @since 3.5.0
	 */
	public boolean isDisplayGroupRowsFirst() {
	}

	/**
	 *  Sets the flag indicating if the group rows will be put ahead of the other reference rows when {@link
	 *  #isRemoveNullGrouper()} returns true.
	 *  <p/>
	 *  The default value is false to keep backward compatibility. This method would only take effect if {@link
	 *  #isRemoveNullGrouper()} returns true.
	 * 
	 *  @param groupRowsFirst the flag
	 *  @see #isRemoveNullGrouper()
	 *  @since 3.5.0
	 */
	public void setDisplayGroupRowsFirst(boolean groupRowsFirst) {
	}

	/**
	 *  Gets the ColumnComparatorContextProvider.
	 * 
	 *  @return the ColumnComparatorContextProvider.
	 */
	public DefaultGroupTableModel.ColumnComparatorContextProvider getColumnComparatorContextProvider() {
	}

	/**
	 *  Sets the <code>ColumnComparatorContextProvider</code>. This provider will provide a
	 *  <code>ComparatorContext</code> for each column. If this table model has several columns that have the same types
	 *  in getColumnClass method but you want to use different comparators to compare and sort them, you would need to
	 *  register several comparators on <code>ObjectComparatorManager</code> using different
	 *  <code>ComparatorContext</code>. Then you can this provider to return different contexts so that
	 *  <code>SortableTableModel</code> can find the correct comparator registered on
	 *  <code>ObjectComparatorManager</code>. If you call this method with a non-null provider, we will automatically
	 *  call {@link #setAlwaysUseComparators(boolean)} and set it to true.
	 * 
	 *  @param columnComparatorContextProvider the columnComparatorContextProvider
	 */
	public void setColumnComparatorContextProvider(DefaultGroupTableModel.ColumnComparatorContextProvider columnComparatorContextProvider) {
	}

	/**
	 *  Checks if the alwaysUseComparators flag value.
	 * 
	 *  @return true if alwaysUseComparators is true. Otherwise false.
	 */
	public boolean isAlwaysUseComparators() {
	}

	/**
	 *  Sets the alwaysUseComparators flag. By default, we will check if the two values are Comparable. If they both are,
	 *  we will use {@link Comparable#compareTo(Object)} to compare. This is the default preferred way because this gives
	 *  developer a finer control of the comparison result. People also sometimes forgot to implement getColumnClass and
	 *  getColumnComparatorContext. If so, a wrong comparator could be used. If this flag is set to true, we will always
	 *  use Comparators to compare which you means you must implement getColumnClass and optionally implement
	 *  getColumnComparatorContext or use {@link #setColumnComparatorContextProvider(com.jidesoft.grid.DefaultGroupTableModel.ColumnComparatorContextProvider)}
	 *  so that the correct comparator will be used for each column.
	 * 
	 *  @param alwaysUseComparators true or false.
	 */
	public void setAlwaysUseComparators(boolean alwaysUseComparators) {
	}

	@java.lang.Override
	public java.util.Map getExpansionState() {
	}

	@java.lang.Override
	public void setExpansionState(java.util.Map state) {
	}

	@java.lang.Override
	public int getEditorStyleAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  While grouping, the rows are sorted first according the grouping columns. You could use this method to get
	 *  current sorting direction.
	 * 
	 *  @return true if the sorting is ascending, false if the sorting is descending.
	 *  @deprecated replaced by {@link #addGroupColumn(int, int)}, sorting is the second parameter.
	 */
	@java.lang.Deprecated
	public boolean isAscendingGroupOrder() {
	}

	/**
	 *  While grouping, the rows are sorted first according the grouping columns. You could use this method to set
	 *  current sorting direction.
	 * 
	 *  @param order true to make later sorting ascending, false to make later sorting descending.
	 *  @deprecated replaced by {@link #addGroupColumn(int, int)}, sorting is the second parameter.
	 */
	@java.lang.Deprecated
	public void setAscendingGroupOrder(boolean order) {
	}

	/**
	 *  Gets the flag indicating if the previous expand status should be kept on data changing, adding/removing group
	 *  columns.
	 * 
	 *  @return true if previous expand status should be kept. Otherwise false.
	 *  @see #setKeepPreviousExpandStatus(boolean)
	 */
	public boolean isKeepPreviousExpandStatus() {
	}

	/**
	 *  Sets the flag indicating if the previous expand status should be kept on data changing, adding/removing group
	 *  columns.
	 *  <p/>
	 *  This flag has higher priority of {@link #setAutoExpand(boolean)}, which means if the new group row could be found
	 *  in previous status, it will take the expand status from auto expanding.
	 *  <p/>
	 *  By default, the flag is true. You could set it to false to return to original behavior.
	 * 
	 *  @param keepPreviousExpandStatus the flag
	 */
	public void setKeepPreviousExpandStatus(boolean keepPreviousExpandStatus) {
	}

	/**
	 *  Gets the flag indicating if previous grouping columns should be kept on receiving table structure changed event.
	 * 
	 *  @return true if previous grouping should be kept. Otherwise false.
	 *  @see #setKeepGroupingOnStructureChange(boolean)
	 */
	public boolean isKeepGroupingOnStructureChange() {
	}

	/**
	 *  Sets the flag indicating if previous grouping columns should be kept on receiving table structure changed event.
	 *  <p/>
	 *  By default, the flag is false. You could set it to true to return to original behavior.
	 * 
	 *  @param keepGroupingOnStructureChange the flag
	 */
	public void setKeepGroupingOnStructureChange(boolean keepGroupingOnStructureChange) {
	}

	/**
	 *  Gets if the GroupTable will work on summary mode.
	 * 
	 *  @return true if the group table will work on summary mode. Otherwise false.
	 *  @since 3.6.0
	 */
	public boolean isSummaryMode() {
	}

	/**
	 *  Sets if the GroupTable will work on summary mode.
	 *  <p/>
	 *  By default, the value is false to be backward compatibility. If this flag is turned on, {@link
	 *  GroupTablePopupMenuCustomizer} will allow you to select summary type for non-grouped columns.
	 * 
	 *  @param summaryMode the summary mode
	 *  @since 3.6.0
	 */
	public void setSummaryMode(boolean summaryMode) {
	}

	@java.lang.Override
	public int getSummaryTypeAt(int columnIndex) {
	}

	/**
	 *  Sets summary type for column index.
	 * 
	 *  @param columnIndex the column index in the underlying table model
	 *  @param summaryType the summary type
	 *  @since 3.6.0
	 */
	public void setSummaryType(int columnIndex, int summaryType) {
	}

	@java.lang.Override
	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellStyleOn() {
	}

	/**
	 *  Gets the flag indicating if the original rows should be hidden when grouped. In the other word, only the grouped
	 *  rows will be shown. If a group row only contains the original rows, the group row will not be expandable.
	 * 
	 *  @return true if these original rows are hidden. Otherwise false. Default is false.
	 *  @see #setOriginalRowsHidden(boolean)
	 *  @since 3.6.0
	 */
	public boolean isOriginalRowsHidden() {
	}

	/**
	 *  Sets the flag indicating if the original rows should be hidden when grouped. In the other word, only the grouped
	 *  rows will be shown. If a group row only contains the original rows, the group row will not be expandable. This
	 *  flag doesn't change the model. The model still has the original rows. We just don't show it on the view when this
	 *  flag is true.
	 * 
	 *  @param originalRowsHidden true or false.
	 *  @since 3.6.0
	 */
	public void setOriginalRowsHidden(boolean originalRowsHidden) {
	}

	/**
	 *  Gets the summary calculator used to calculate the summary when the table is in summary mode (@link
	 *  #setSummaryMode()}.
	 * 
	 *  @return a summary calculator. If the summary calculator is null, a DefaultGroupTableSummaryCalculator will be
	 *  created and returned.
	 */
	public SummaryCalculator getSummaryCalculator() {
	}

	/**
	 *  Sets the summary calculator used to calculate the summary when the table is in summary mode (@link
	 *  #setSummaryMode()}.
	 * 
	 *  @param summaryCalculator a new summary calculator
	 */
	public void setSummaryCalculator(SummaryCalculator summaryCalculator) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @since 3.6.3
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @since 3.6.3
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 3.6.3
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(String)
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @since 3.6.3
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @since 3.6.3
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name.
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @since 3.6.3
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 *  @since 3.6.3
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 *  @since 3.6.3
	 */
	protected synchronized void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 *  @since 3.6.3
	 */
	protected synchronized void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	/**
	 *  An interface used by {@link SortableTableModel#setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}.
	 */
	public static interface class ColumnComparatorContextProvider {


		public ComparatorContext getColumnComparatorContext(javax.swing.table.TableModel tableModel, int column) {
		}
	}
}
