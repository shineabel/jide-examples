/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>Filter</code> that uses filters away all values except the specified value.
 */
public class SingleValueFilter extends AbstractTableFilter implements com.jidesoft.filter.SqlFilterSupport {

	public SingleValueFilter() {
	}

	/**
	 *  Creates SingleValueFilter.
	 * 
	 *  @param value the value that will not be filtered
	 */
	public SingleValueFilter(Object value) {
	}

	/**
	 *  Creates SingleValueFilter.
	 * 
	 *  @param name  name of the filter
	 *  @param value the value that will not be filtered
	 */
	public SingleValueFilter(String name, Object value) {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return true if not allowed and false if allowed. Please note, this could be the opposite of what you thought as
	 *          the method name is if the value is filtered.
	 */
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Gets the only allowed value.
	 * 
	 *  @return the only allowed value.
	 */
	public Object getValue() {
	}

	/**
	 *  Sets the only allowed value.
	 * 
	 *  @param value the value.
	 */
	public void setValue(Object value) {
	}

	@java.lang.Override
	public String getName() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the fields in this filter are exactly the same with those in the input filter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(com.jidesoft.filter.Filter inputFilter) {
	}

	public String getOperator() {
	}

	@java.lang.Override
	public String getPreference(Class clazz, ConverterContext converterContext) {
	}

	@java.lang.Override
	public Object[] setPreference(String prefString, Class clazz, ConverterContext converterContext) {
	}
}
