/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The event object for JideCellEditerListener. The source of
 *  this event is usually the cell editor. It also has row and column information.
 */
public class CellChangeEvent extends javax.swing.event.ChangeEvent {

	public CellChangeEvent(Object source) {
	}

	public int getRow() {
	}

	public void setRow(int row) {
	}

	public int getColumn() {
	}

	public void setColumn(int column) {
	}

	@java.lang.Override
	public String toString() {
	}
}
