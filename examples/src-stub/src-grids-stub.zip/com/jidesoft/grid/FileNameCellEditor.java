/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for FileName.
 */
public class FileNameCellEditor extends ExComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FileNameCellEditor.
	 */
	public FileNameCellEditor() {
	}

	/**
	 *  Creates FileNameChooserExComboBox used by this cell editor.
	 * 
	 *  @return FileNameChooserExComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates FileNameChooserExComboBox used by this cell editor.
	 * 
	 *  @return FileNameChooserExComboBox.
	 */
	protected com.jidesoft.combobox.FileNameChooserExComboBox createFileNameChooserComboBox() {
	}
}
