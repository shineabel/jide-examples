/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>RowModel</code> is a table model interface that supports row based on table model. The row object must
 *  implement {@link Row} interface.
 */
public interface RowModel {

	/**
	 *  /** Returns the Row at the row index specified by <code>rowIndex</code>.
	 * 
	 *  @param rowIndex the row whose row is to be queried
	 *  @return the row at the specified row index
	 */
	public Row getRowAt(int rowIndex);

	/**
	 *  Gets the index of the Row.
	 * 
	 *  @param row the Row
	 *  @return the index of the Row. If the row is displayed in the table, it will return the index. Otherwise, it will
	 *          return -1. So -1 could mean two things - the row is not displayed or the row is not in the tree hierarchy
	 *          at all.
	 */
	public int getRowIndex(Row row);
}
