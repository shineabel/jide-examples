/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Cell style provider for Row. It can be used on TreeTableModel and its subclasses to provide a way to define cell
 *  style based on the Row instance.
 * 
 *  @since 3.6.0
 */
public interface RowCellStyleProvider {

	/**
	 *  Gets the CellStyle for the cell in the row.
	 * 
	 *  @param row         the row instance. The row could be a GroupRow or an IndexReferenceRow.
	 *  @param rowIndex    the rowIndex index.
	 *  @param columnIndex the column index.
	 *  @return the CellStyle for the cell.
	 */
	public CellStyle getRowCellStyleAt(Row row, int rowIndex, int columnIndex);
}
