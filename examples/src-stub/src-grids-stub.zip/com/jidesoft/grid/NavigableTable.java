/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An extension to <code>JTable</code> which can programmatically avoid navigation on certain cells.
 * 
 *  @author Marco De Angelis
 *  @see NavigableModel
 */
public class NavigableTable extends ContextSensitiveTable {

	public NavigableTable() {
	}

	public NavigableTable(int numRows, int numColumns) {
	}

	public NavigableTable(javax.swing.table.TableModel dm) {
	}

	public NavigableTable(Object[][] rowData, Object[] columnNames) {
	}

	public NavigableTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public NavigableTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public NavigableTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public javax.swing.table.TableModel getNavigableModel() {
	}

	/**
	 *  Gets the next style model of the specified model. If the model is not an instance of TableModelWrapper, null will
	 *  be returned as there is no next style model after it. If it is a TableModelWrapper, it will try to find the first
	 *  inner model that is a style model. If there is a style model, it will return it. Otherwise, null will be
	 *  returned.
	 * 
	 *  @param model the model.
	 *  @return the next style model. The return value may or may not be an instance of StyleModel.
	 */
	public javax.swing.table.TableModel getNextNavigableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Checks if the cell is navigable. If there are table model wrappers, it will find the first navigable model that
	 *  isNavigationOn is true and isNavigableAt is false.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return true or false.
	 */
	public boolean isCellNavigable(int row, int column) {
	}

	/**
	 *  Checks if the key stroke and the input event will respect the NavigableModel. By default, this method always
	 *  return true, meaning no matter what navigation key is press or mouse is pressed, the non-navigable cells will be
	 *  not selected. You can override it to customize the behavior.
	 *  <p/>
	 *  For example, if you want the mouse click to select the cell even though cell is not navigable in the model, you
	 *  can do
	 *  <code><pre>
	 *  return ks != null;
	 *  </pre></code>
	 *  It works because if the ks is null, it means the selection change is not triggered by a key stroke. In fact, it
	 *  could be either by a mouse click or by code using Java API.
	 * 
	 *  @param ks the key stroke if any. If KeyStroke is null, it means the selection is changed not because of a key.
	 *  @return true or false.
	 */
	protected boolean isNavigationKey(javax.swing.KeyStroke ks) {
	}

	@java.lang.Override
	public boolean processKeyBinding(javax.swing.KeyStroke ks, java.awt.event.KeyEvent e, int condition, boolean pressed) {
	}

	/**
	 *  Override the default implementation to adjust the selection avoiding the non-navigable cells. This implementation
	 *  works for keyboard events only, assuming the direction from the previous anchor selection. Mouse events on
	 *  non-navigable cells are blocked in the mouse input listener.
	 *  <p/>
	 *  <p> This implementation uses the following conventions: <ul> <li> <code>toggle</code>: <em>false</em>,
	 *  <code>extend</code>: <em>false</em>. Clear the previous selection and ensure the new cell is selected. <li>
	 *  <code>toggle</code>: <em>false</em>, <code>extend</code>: <em>true</em>. Extend the previous selection to include
	 *  the specified cell. <li> <code>toggle</code>: <em>true</em>, <code>extend</code>: <em>false</em>. If the
	 *  specified cell is selected, deselect it. If it is not selected, select it. <li> <code>toggle</code>:
	 *  <em>true</em>, <code>extend</code>: <em>true</em>. Leave the selection state as it is, but move the anchor index
	 *  to the specified location. </ul>
	 * 
	 *  @param row    Affects the selection at <code>row</code>
	 *  @param column Affects the selection at <code>column</code>
	 *  @param toggle See description above
	 *  @param expand If true, extend the current selection
	 */
	@java.lang.Override
	public void changeSelection(int row, int column, boolean toggle, boolean expand) {
	}

	/**
	 *  Finds the next navigable cell from the specified cell.
	 * 
	 *  @param row           row index of the specified cell
	 *  @param column        column index of the specified cell
	 *  @param currentRow    current row index
	 *  @param currentColumn current column index
	 *  @param rowCount      row count
	 *  @param columnCount   column count
	 *  @return the next navigable cell. Null if nothing is found.
	 */
	protected int[] findNextNavigableCell(int row, int column, int currentRow, int currentColumn, int rowCount, int columnCount) {
	}

	/**
	 *  Finds the next navigable cell from the specified cell vertically.
	 * 
	 *  @param row           row index of the specified cell
	 *  @param column        column index of the specified cell
	 *  @param currentRow    current row index
	 *  @param currentColumn current column index
	 *  @param rowCount      row count
	 *  @param columnCount   column count
	 *  @return the next navigable cell. Null if nothing is found.
	 */
	protected int[] findNextNavigableCellVertically(int row, int column, int currentRow, int currentColumn, int rowCount, int columnCount) {
	}

	/**
	 *  Finds the previous navigable cell from the specified cell.
	 * 
	 *  @param row           row index of the specified cell
	 *  @param column        column index of the specified cell
	 *  @param currentRow    current row index
	 *  @param currentColumn current column index
	 *  @param rowCount      row count
	 *  @param columnCount   column count
	 *  @return the previous navigable cell. Null if nothing is found.
	 */
	protected int[] findPreviousNavigableCell(int row, int column, int currentRow, int currentColumn, int rowCount, int columnCount) {
	}

	/**
	 *  Finds the previous navigable cell from the specified cell vertically.
	 * 
	 *  @param row           row index of the specified cell
	 *  @param column        column index of the specified cell
	 *  @param currentRow    current row index
	 *  @param currentColumn current column index
	 *  @param rowCount      row count
	 *  @param columnCount   column count
	 *  @return the previous navigable cell. Null if nothing is found.
	 */
	protected int[] findPreviousNavigableCellVertically(int row, int column, int currentRow, int currentColumn, int rowCount, int columnCount) {
	}

	/**
	 *  Finds the next navigable cell in the same row.
	 * 
	 *  @param row         row index of the specified cell
	 *  @param column      column index of the specified cell
	 *  @param columnCount the column count
	 *  @return the next navigable cell in the same row. Null if nothing is found.
	 */
	protected int[] findNextNavigableCellInRow(int row, int column, int columnCount) {
	}

	/**
	 *  Finds the previous navigable cell in the same row.
	 * 
	 *  @param row    row index of the specified cell
	 *  @param column column index of the specified cell
	 *  @return the previous navigable cell in the same row. Null if nothing is found.
	 */
	protected int[] findPreviousNavigableCellInRow(int row, int column) {
	}

	/**
	 *  Finds the next navigable row in the same column.
	 * 
	 *  @param row      row index of the specified cell
	 *  @param column   column index of the specified cell
	 *  @param rowCount the row count.
	 *  @return the next navigable row in the same column. Null if nothing is found.
	 */
	protected int[] findNextNavigableCellInColumn(int row, int column, int rowCount) {
	}

	/**
	 *  Finds the previous navigable row in the same column.
	 * 
	 *  @param row    row index of the specified cell
	 *  @param column column index of the specified cell
	 *  @return the previous navigable row in the same column. Null if nothing is found.
	 */
	protected int[] findPreviousNavigableCellInColumn(int row, int column) {
	}

	/**
	 *  Finds the nearest navigable cell from the specified cell that is in the same row.
	 * 
	 *  @param row           row index of the specified cell
	 *  @param column        column index of the specified cell
	 *  @param currentRow    current row index
	 *  @param currentColumn current column index
	 *  @param rowCount      row count
	 *  @param columnCount   column count
	 *  @return the previous navigable cell. Null if nothing is found.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected int[] findNearestNavigableCellInRow(int row, int column, int currentRow, int currentColumn, int rowCount, int columnCount) {
	}

	/**
	 *  Finds the nearest navigable cell from the specified cell that is in the same column.
	 * 
	 *  @param row           row index of the specified cell
	 *  @param column        column index of the specified cell
	 *  @param currentRow    current row index
	 *  @param currentColumn current column index
	 *  @param rowCount      row count
	 *  @param columnCount   column count
	 *  @return the previous navigable cell. Null if nothing is found.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected int[] findNearestNavigableCellInColumn(int row, int column, int currentRow, int currentColumn, int rowCount, int columnCount) {
	}
}
