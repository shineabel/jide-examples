/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The TreeTableModel with all expandable interfaces.
 * 
 *  @since 3.5.17
 */
public interface IExpandableTreeTableModel extends ITreeTableModel {

	/**
	 *  Expands or collapses the row.
	 * 
	 *  @param row      the row to be expanded or collapsed
	 *  @param expanded true to expand, false to collapse.
	 */
	public void expandRow(ExpandableRow row, boolean expanded);

	/**
	 *  Rebuilds the displayed rows from the original rows and fire table data changed event.
	 */
	public void refresh();

	/**
	 *  Expands all rows which have children.
	 */
	public void expandAll();

	/**
	 *  Expands all root level rows.
	 */
	public void expandFirstLevel();

	/**
	 *  Expands one more level of rows.
	 */
	public void expandNextLevel();

	/**
	 *  Collapse all rows which have children.
	 */
	public void collapseAll();

	/**
	 *  Collapses all top level rows only. The children level rows are still expanded if they were. But they can't be
	 *  seen anymore as the root rows are collapsed. If you expand the root rows after this call, you will see the
	 *  children rows remain expanded.
	 */
	public void collapseFirstLevel();

	/**
	 *  Collapses all top level rows only. The children level rows are still expanded if they were. But they can't be
	 *  seen anymore as the root rows are collapsed. If you expand the root rows after this call, you will see the
	 *  children rows remain expanded.
	 */
	public void collapseLastLevel();

	/**
	 *  Gets the list of rows used by the table model. The order is as displayed.
	 * 
	 *  @param includeChildren true to include collapsed children as part of the list. Otherwise getRows() will be
	 *                         returned.
	 *  @return the list of rows
	 */
	public java.util.List getRows(boolean includeChildren);

	/**
	 *  Returns the number of children of <code>parent</code>. Returns 0 if it has no children.
	 * 
	 *  @param parent a node in the tree model
	 *  @return the number of children of the node <code>parent</code>
	 */
	public int getChildCount(Object parent);

	/**
	 *  Returns the child of <code>parent</code> at index <code>index</code> in the parent's child array.
	 *  <code>parent</code> must be a node previously obtained from this data source. This should not return
	 *  <code>null</code> if <code>index</code> is a valid index for <code>parent</code> (that is <code>index >= 0 &&
	 *  index < getChildCount(parent</code>)).
	 * 
	 *  @param parent a node in the tree, obtained from this data source
	 *  @param index  the index of the child
	 *  @return the child of <code>parent</code> at index <code>index</code>
	 */
	public Object getChild(Object parent, int index);

	/**
	 *  Gets if the IExpandableTreeTableModel is adjusting. Using this flag could improve the performance by sending less
	 *  table model events.
	 * 
	 *  @return true if the table model is adjust. Otherwise false.
	 */
	public boolean isAdjusting();

	/**
	 *  Removes the row at the row index. No matter which level the row is, it will be removed. If the row has child
	 *  rows, all of them will be removed.
	 * 
	 *  @param rowIndex the row index of the row to be removed
	 */
	public void removeRow(int rowIndex);

	/**
	 *  Adds row to the parentRow. The parentRow has to be an instance of ExpandableRow. Otherwise, there is no effect.
	 * 
	 *  @param parentRow the parent row.
	 *  @param position  the insert position relative to the parent row.
	 *  @param rows      the rows to be added.
	 */
	public void addRows(Row parentRow, int position, java.util.List rows);

	/**
	 *  Gets the expansion state of all expansion state of tree table model. You can use this method along with {@link
	 *  #setExpansionState(java.util.Map)} to restore the tree table expansion state after the IExpandableTreeTableModel is
	 *  recreated.
	 * 
	 *  @return a map contains the expansion state of all rows. To save memory, we only save the expanded tree path so
	 *  far.
	 */
	public java.util.Map getExpansionState();

	/**
	 *  Restores the expansion state of all rows in tree table model. You can use this method to restore the expansion
	 *  state after the TreeTableModel is created but rows remain. For newly added rows, this method will not change
	 *  their expansion state.
	 * 
	 *  @param state a map of the expansion state.
	 */
	public void setExpansionState(java.util.Map state);
}
