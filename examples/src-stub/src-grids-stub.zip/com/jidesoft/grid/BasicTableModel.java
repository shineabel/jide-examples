/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>BasicTableModel</code> provides a quick way to create a table model from a list of objects. It leverages {@link
 *  com.jidesoft.introspector.Introspector} to introspect the object and display the value of the properties as each
 *  column.
 *  <p/>
 *  Assuming you have a list of MyBeanObject which follows the JavaBean pattern, you can create a table model that allow
 *  your user to edit the property of the objects using
 *  <code><pre>
 *  BasicTableModel tableModel = new BasicTableModel(objects, MyBeanObject.class);
 *  </pre></code>
 *  You can also ask Introspector to create such a BasicTableModel using
 *  <code><pre>
 *  new BasicTableModel(objects, IntrospectorManager.getIntrospector(MyBeanObject.class));
 *  </pre></code>
 *  However to make the code above working, you need to register an Introspector first using code like below. Please
 *  note, the string array allows you to decide what properties to be used in the BasicTableModel.
 *  <code><pre>
 *  IntrospectorManager.registerIntrospector(MyBeanObject.class, new IntrospectorFactory() {
 *      public Introspector create() {
 *          try {
 *              return new BeanIntrospector(MyBeanObject.class, new String[]{"name", "Name", "text", "Text", "icon",
 *  "Icon", "opaque", "Opaque", "toolTipText", "ToolTip", "background", "Background", "foreground", "Foreground"}, 2);
 *          }
 *          catch (IntrospectionException e) {
 *              return null;
 *          }
 *      }
 *  });
 *  </pre></code>
 *  In this example, since Introspector is an interface, we used the BeanIntrospector which will introspect the object
 *  using Java bean pattern. If you have other ways to introspect the object, you can implement Introspector to do it.
 */
public class BasicTableModel extends javax.swing.table.AbstractTableModel implements ContextSensitiveTableModel, java.beans.PropertyChangeListener {

	public static final String PROPERTY_EDITABLE = "editable";

	/**
	 *  Creates an empty <code>BasicTableModel</code>.
	 */
	public BasicTableModel() {
	}

	/**
	 *  Creates a <code>BasicTableModel</code> from a list of objects using the default <code>BeanIntrospector</code> for
	 *  the specified type. You need to register the <code>BeanIntrospector</code> on
	 *  <code>BeanIntrospectorManager</code> first.
	 * 
	 *  @param objects the list of objects.
	 *  @param type    the object type
	 */
	public BasicTableModel(java.util.List objects, Class type) {
	}

	/**
	 *  Creates a <code>BasicTableModel</code> from a list of objects using the default <code>BeanIntrospector</code> for
	 *  the specified type and the specified <code>BeanIntrospectorContext</code>. You need to register the
	 *  <code>BeanIntrospector</code> on <code>BeanIntrospectorManager</code> first.
	 * 
	 *  @param objects the list of objects.
	 *  @param type    the object type
	 *  @param context the IntrospectorContext. We will use type and context to locate the Introspector that was
	 *                 registered in {@link com.jidesoft.introspector.IntrospectorManager}.
	 */
	public BasicTableModel(java.util.List objects, Class type, com.jidesoft.introspector.IntrospectorContext context) {
	}

	/**
	 *  Creates a <code>BasicTableModel</code> from a list of objects using the specified property names as the value for
	 *  each column of the table model. You can also use {@link #BasicTableModel(java.util.List, Class,
	 *  com.jidesoft.introspector.IntrospectorContext)} so that you can assign both name and display names using a single
	 *  array.
	 * 
	 *  @param objects       the list of objects.
	 *  @param type          the object type
	 *  @param propertyNames an array of property names. The array is in the format of <code>{ "propertyName1",
	 *                       "displayName11", "propertyName2", "displayName12", ... };</code>
	 *  @throws java.beans.IntrospectionException if java bean introspection failed.
	 */
	public BasicTableModel(java.util.List objects, Class type, String[] propertyNames) {
	}

	/**
	 *  Creates a <code>BasicTableModel</code> from a list of objects using the specified <code>Introspector</code>.
	 * 
	 *  @param objects      the list of objects.
	 *  @param introspector the introspector for the object
	 */
	public BasicTableModel(java.util.List objects, com.jidesoft.introspector.Introspector introspector) {
	}

	/**
	 *  Gets the row count. It is the length of the list of the objects.
	 * 
	 *  @return the row count.
	 */
	public int getRowCount() {
	}

	/**
	 *  Gets the object from the list of the objects.
	 * 
	 *  @param rowIndex the row index.
	 *  @return the object at the specified index.
	 */
	public Object getObject(int rowIndex) {
	}

	/**
	 *  Sets the object at the specified index. A tableRowsUpdated event will be fired.
	 * 
	 *  @param object   the object
	 *  @param rowIndex the row index
	 */
	public void setObject(Object object, int rowIndex) {
	}

	/**
	 *  Gets the index of the object from the list of the objects.
	 * 
	 *  @param object the object.
	 *  @return the index of the object. -1 if the object is not found.
	 */
	public int indexOf(Object object) {
	}

	/**
	 *  Adds an object to the end of the object list. A tableRowsInserted event will be fired.
	 * 
	 *  @param object the object to be added.
	 */
	public void addObject(Object object) {
	}

	/**
	 *  Adds an object to the specified index of the object list. A tableRowsInserted event will be fired.
	 * 
	 *  @param index  the index to be inserted at.
	 *  @param object the object to be added.
	 */
	public void addObject(int index, Object object) {
	}

	/**
	 *  Removes an object from the object list. A tableRowsDeleted event will be fired if the object is indeed removed.
	 * 
	 *  @param object the object to be removed.
	 */
	public void removeObject(Object object) {
	}

	/**
	 *  Removes an object from the object list at the specified index. A tableRowsDeleted event will be fired.
	 * 
	 *  @param index the index of the object to be removed.
	 */
	public void removeObject(int index) {
	}

	/**
	 *  Adds objects to the table model. They will append at the end.
	 * 
	 *  @param objects the objects to be added.
	 */
	public void addObjects(java.util.List objects) {
	}

	/**
	 *  Removes all objects from the table model.
	 */
	public void clear() {
	}

	/**
	 *  Gets the column count. It is the number of properties of each object.
	 * 
	 *  @return the column count.
	 */
	public int getColumnCount() {
	}

	/**
	 *  Gets the Property at the column index. This property doesn't bind to the row yet. If you want to get the value or
	 *  set value to a particular row, you still need to call this first before calling property.setValue or
	 *  property.getValue.
	 *  <code><pre>
	 *  property.setInstance(getObject(rowIndex));
	 *  </pre></code>
	 * 
	 *  @param columnIndex the column index.
	 *  @return the property.
	 */
	public Property getPropertyAt(int columnIndex) {
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int rowIndex, int columnIndex) {
	}

	/**
	 *  This method is called in getValueAt and setValueAt method. In the case of BeanProperty, since we share the
	 *  Property, we need to call setInstance method to set the actual value before we call getValueAt and setValueAt.
	 *  Subclass can override it to do some customized initialization for the property.
	 * 
	 *  @param property    the property for the cell.
	 *  @param rowIndex    the row index of the cell where the Property is used.
	 *  @param columnIndex the column index of the cell where the Property is used.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void prepareProperty(Property property, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public String getColumnName(int columnIndex) {
	}

	@java.lang.Override
	public Class getColumnClass(int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	public Class getCellClassAt(int row, int column) {
	}

	/**
	 *  If the objects follow the JavaBean pattern, it will support property change event. This method will add
	 *  BasicTableModel as a property change listener (BasicTableModel implements PropertyChangeListener) to the object
	 *  so that it will get notification when the property of those objects is changed from outside.
	 * 
	 *  @param objects the list of objects.
	 *  @throws Exception it fails to bind the objects.
	 */
	public void bind(java.util.List objects) {
	}

	/**
	 *  Uninstalled the listeners that were installed in the <code>bind</code> method.
	 * 
	 *  @param objects the list of objects.
	 *  @throws Exception if it fails to unbind the objects.
	 */
	public void unbind(java.util.List objects) {
	}

	protected void installListener(Object t) {
	}

	protected void uninstallListener(Object t) {
	}

	/**
	 *  Updates the corresponding cell if the object's property changed.
	 * 
	 *  @param evt the PropertyChangeEvent
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	@java.lang.Override
	public void fireTableStructureChanged() {
	}

	/**
	 *  Get the flag indicating if the entire table model is editable.
	 *  <p/>
	 *  By default, the value is true. If you want to improve the performance by not registering unnecessary listeners
	 *  while you have this table model with read only purpose, please set it to false.
	 * 
	 *  @return true if the table model is editable. Otherwise false.
	 */
	public boolean isEditable() {
	}

	/**
	 *  Set the flag indicating if the entire table model is editable.
	 * 
	 *  @param editable the flag
	 *  @see #isEditable()
	 */
	public void setEditable(boolean editable) {
	}

	/**
	 *  Support for reporting property changes for boolean properties. This method can be called when a property has
	 *  changed and it will send the appropriate PropertyChangeEvent to any registered PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 *  <p/>
	 *  If <code>listener</code> is <code>null</code>, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the property change listener to be added
	 *  @see #removePropertyChangeListener
	 */
	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}
}
