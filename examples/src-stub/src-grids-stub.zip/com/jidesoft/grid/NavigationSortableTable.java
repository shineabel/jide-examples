/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>NavigationSortableTable</code> is a special SortableTable that is designed for the navigation purpose. It has the
 *  following features.
 *  <pre>
 *  <ul>
 *      <li>It has a special row rollover effect.</li>
 *      <li>The row selection covers the whole row instead of each cell has selection individually
 *  in
 *  the case of
 *  SortableTable.</li>
 *      <li>The selection highlight is different when focused and not focused.</li>
 *  </ul>
 *  </pre>
 *  The selection and rollover effect is painted inside the paintComponent methods of the <code>NavigationSortableTable</code>
 *  after the original table content is painted.
 */
public class NavigationSortableTable extends SortableTable {

	public NavigationSortableTable() {
	}

	public NavigationSortableTable(javax.swing.table.TableModel model) {
	}

	public NavigationSortableTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public NavigationSortableTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public NavigationSortableTable(int numRows, int numColumns) {
	}

	public NavigationSortableTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public NavigationSortableTable(Object[][] rowData, Object[] columnNames) {
	}

	/**
	 *  Creates the <code>NavigationHelper</code> which is a helper class that paints the rollover and the selection
	 *  effect.
	 *  <p/>
	 *  By default, it creates a NavigationSortableTableHelper instance.
	 * 
	 *  @return a new NavigationHelper.
	 */
	protected NavigationComponentHelper createNavigationHelper() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Gets the rollover row that currently has rollover effect.
	 * 
	 *  @return the row that has the rollover effect.
	 */
	public int getNavigationRolloverRow() {
	}

	/**
	 *  Sets the rollover row.
	 * 
	 *  @param navigationRolloverRow the row to show the rollover effect.
	 */
	public void setNavigationRolloverRow(int navigationRolloverRow) {
	}

	/**
	 *  The navigation SortableTable helper class.
	 * 
	 *  @since 3.3.8
	 */
	public class NavigationSortableTableHelper {


		public NavigationSortableTable.NavigationSortableTableHelper() {
		}

		@java.lang.Override
		public java.awt.Rectangle getRowBounds(int row) {
		}

		@java.lang.Override
		public int rowAtPoint(java.awt.Point p) {
		}

		@java.lang.Override
		public int[] getSelectedRows() {
		}
	}
}
