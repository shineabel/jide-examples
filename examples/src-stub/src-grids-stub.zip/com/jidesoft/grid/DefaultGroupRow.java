/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default implementation for <code>GroupRow</code>. This implementation implements both <code>GroupRow</code> and
 *  <code>GroupCondition</code>.
 */
public class DefaultGroupRow extends DefaultExpandableRow implements GroupRow, GroupCondition, Comparable, Cacheable {

	public DefaultGroupRow() {
	}

	public void addCondition(int columnIndex, Object value) {
	}

	public void addCondition(int columnIndex, Object value, ObjectGrouper grouper) {
	}

	public void removeCondition(int columnIndex) {
	}

	public void clearConditions() {
	}

	public Object getConditionValueAsString(int index) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int columnIndex) {
	}

	public Object getConditionValue(int index) {
	}

	public int getConditionColumn(int index) {
	}

	public int getNumberOfConditions() {
	}

	public boolean satisfies(javax.swing.table.TableModel model, int rowIndex) {
	}

	public GroupCondition configureParentCondition(GroupCondition condition) {
	}

	public boolean contains(GroupCondition c) {
	}

	public Object getValueAt(int columnIndex) {
	}

	@java.lang.Override
	public boolean removeChild(Object child) {
	}

	@java.lang.Override
	public IExpandableTreeTableModel getExpandableTreeTableModel() {
	}

	public int compareTo(Object o) {
	}

	public Object getCachedValue() {
	}

	public void setCachedValue(Object value) {
	}

	public boolean isCacheValid() {
	}

	public void invalidateCache() {
	}

	public void invalidateCache(Object key) {
	}

	/**
	 *  Converts the group row to string. Here is the default code. See below for the default code we used.
	 *  <code><pre>
	 *  StringBuffer buf = new StringBuffer();
	 *  DefaultGroupTableModel defaultGroupTableModel = (DefaultGroupTableModel) getTreeTableModel();
	 *  for (int i = 0; i < getNumberOfConditions(); i++) {
	 *      buf.append(" ");
	 *  <p/>
	 *      if (defaultGroupTableModel.isSingleLevelGrouping() || i == getNumberOfConditions() - 1) {
	 *          buf.append(defaultGroupTableModel.getActualModel().getColumnName(getConditionColumn(i)));
	 *          buf.append(": ");
	 *          buf.append(getConditionValue(i));
	 *      }
	 *  }
	 *  return buf.toString();
	 *  </pre></code>
	 *  Please note, you can either override this method or add a converter for DefaultGroupRow to do something like
	 *  this.
	 *  <code><pre>
	 *  ObjectConverterManager.initDefaultConverter();
	 *  ObjectConverterManager.registerConverter(DefaultGroupRow.class, new MyDefaultGroupRowConverter());
	 *  </pre></code>
	 *  If so, MyDefaultGroupRowConverter will have a high priority than this toString method.
	 * 
	 *  @return the String version of the DefaultGroupRow
	 */
	@java.lang.Override
	public String toString() {
	}
}
