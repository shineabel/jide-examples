/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  AutoCellEditingSupport is an interface that can be implemented on cell editor to tell the table to enable the cell
 *  editing when the mouse is over the cell. Different from {@link CellRolloverSupport}
 * 
 *  @see RolloverTableUtils
 *  @since 3.2.0
 */
public interface CellEditingSupport {

	public boolean isEditable(javax.swing.JTable table, java.awt.event.MouseEvent e, int row, int column);
}
