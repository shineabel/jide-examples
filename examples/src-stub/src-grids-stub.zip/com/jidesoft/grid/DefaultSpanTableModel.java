/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>DefaultSpanTableModel</code> adds <code>SpanModel</code> support to <code>DefaultTableModel</code>. You can use
 *  it as replacement for <code>DefaultTableModel</code>. Instead of return a cell span programmatically like in {@link
 *  AbstractSpanTableModel}, you can use {@link #addCellSpan(CellSpan)} or {@link #removeCellSpan(int, int)} to control
 *  the cell span.
 */
public class DefaultSpanTableModel extends javax.swing.table.DefaultTableModel implements SpanTableModel {

	public DefaultSpanTableModel() {
	}

	public DefaultSpanTableModel(int rowCount, int columnCount) {
	}

	public DefaultSpanTableModel(java.util.Vector columnNames, int rowCount) {
	}

	public DefaultSpanTableModel(Object[] columnNames, int rowCount) {
	}

	public DefaultSpanTableModel(java.util.Vector data, java.util.Vector columnNames) {
	}

	public DefaultSpanTableModel(Object[][] data, Object[] columnNames) {
	}

	/**
	 *  Gets the cell span at the specified row and column index.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the cell span at the specified row and column index.
	 */
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Adds a cell span. There is no need to specify the row and column index because the information is in the cell
	 *  span. Once a cell span is added, all cells in the range will return this cell span when
	 *  <code>getCellSpanAt()</code> is called.
	 *  <p/>
	 *  There is only one cell span allowed on the anchor cell. In the other word, if you try to add another cell span on
	 *  the anchor cell, it will remove previous cell span, then add the new one. As long as anchor cells are different,
	 *  two cell span can have overlap, even one cell span contains the other one.
	 * 
	 *  @param cellSpan a CellSpan to be added.
	 */
	public void addCellSpan(CellSpan cellSpan) {
	}

	/**
	 *  Removes the cell span.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 */
	public void removeCellSpan(int rowIndex, int columnIndex) {
	}

	/**
	 *  Removes all cell spans.
	 *  <p/>
	 *  Note: If you want to turn of all cell spans temporarily, you should use <code>setCellSpanOn(false)</code>.
	 */
	public void removeAllCellSpans() {
	}

	public boolean isCellSpanOn() {
	}

	public void setCellSpanOn(boolean cellSpanOn) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the span model occurs.
	 * 
	 *  @param l the SpanModelListener
	 */
	public void addSpanModelListener(SpanModelListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the data model occurs.
	 * 
	 *  @param l the SpanModelListener
	 */
	public void removeSpanModelListener(SpanModelListener l) {
	}

	/**
	 *  Returns an array of all the table model listeners registered on this model.
	 * 
	 *  @return all of this model's <code>SpanModelListener</code>s or an empty array if no table model listeners are
	 *          currently registered
	 *  @see #addSpanModelListener
	 *  @see #removeSpanModelListener
	 *  @since 1.4
	 */
	public SpanModelListener[] getSpanModelListeners() {
	}

	/**
	 *  Notifies all listeners that all span values in the table's rows may have changed. The number of rows may also
	 *  have changed and the <code>JTable</code> should redraw the table from scratch. The structure of the table (as in
	 *  the order of the columns) is assumed to be the same.
	 * 
	 *  @see SpanModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTableSpanChanged() {
	}

	/**
	 *  Notifies all listeners that a cell span is added at cell <code>(row, column)</code>.
	 * 
	 *  @param cellSpan the CellSpan which was just added
	 *  @see SpanModelEvent
	 */
	public void fireTableSpanAdded(CellSpan cellSpan) {
	}

	/**
	 *  Notifies all listeners that a cell span is removed at cell <code>(row, column)</code>.
	 * 
	 *  @param cellSpan the CellSpan which was just removed
	 *  @see SpanModelEvent
	 */
	public void fireTableSpanRemoved(CellSpan cellSpan) {
	}

	/**
	 *  Forwards the given notification event to all <code>SpanModelListeners</code> that registered themselves as
	 *  listeners for this table model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addSpanModelListener
	 *  @see SpanModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTableSpanChanged(SpanModelEvent e) {
	}

	@java.lang.Override
	public void insertRow(int row, Object[] rowData) {
	}

	@java.lang.Override
	public void insertRow(int row, java.util.Vector rowData) {
	}

	@java.lang.Override
	public void moveRow(int start, int end, int to) {
	}

	@java.lang.Override
	public void removeRow(int row) {
	}

	@java.lang.Override
	public void setRowCount(int rowCount) {
	}
}
