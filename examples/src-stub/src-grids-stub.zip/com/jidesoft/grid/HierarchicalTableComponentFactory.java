/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to create a component from the value that returned from HierarchicalTableModel.
 */
public interface HierarchicalTableComponentFactory {

	/**
	 *  Creates the child component for the specified row and using the specified value.
	 * 
	 *  @param table the HierarchicalTable
	 *  @param value the value returned from {@link HierarchicalTableModel#getChildValueAt(int)}.
	 *  @param row   the actual row index as in the HierarchicalTableModel. Please note, it may or may not the visual row
	 *               index as you see from the screen especially if you have sorting and filtering enabled in this
	 *               table.
	 *  @return a child component.
	 */
	public java.awt.Component createChildComponent(HierarchicalTable table, Object value, int row);

	/**
	 *  Destroys the child component.
	 * 
	 *  @param table     the HierarchicalTable
	 *  @param component the component to be destroyed.
	 *  @param row       the actual row index as in the HierarchicalTableModel. Please note, it may or may not the visual
	 *                   row index as you see from the screen especially if you have sorting and filtering enabled in
	 *                   this table.
	 */
	public void destroyChildComponent(HierarchicalTable table, java.awt.Component component, int row);
}
