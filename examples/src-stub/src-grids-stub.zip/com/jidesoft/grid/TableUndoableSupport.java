/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Undoable support for TableModel to implement.
 * 
 *  @since 3.3.4
 */
public interface TableUndoableSupport {

	/**
	 *  Inserts a row at the designated row index.
	 *  <p/>
	 *  Invoking this method will be able to insert a row, then adds an UndoableEdit or fires an event if necessary.
	 * 
	 *  @param rowIndex the row index
	 *  @param rowData  the row data
	 */
	public void undoableInsertRow(int rowIndex, java.util.Vector rowData);

	/**
	 *  Removes a row at the designated row index.
	 *  <p/>
	 *  Invoking this method will be able to remove a row, then adds an UndoableEdit or fires an event if necessary.
	 * 
	 *  @param rowIndex the row index
	 */
	public void undoableRemoveRow(int rowIndex);

	/**
	 *  Updates a row at the designated row index with the new row data .
	 *  <p/>
	 *  Invoking this method will be able to update a row, then adds an UndoableEdit or fires an event if necessary.
	 * 
	 *  @param rowIndex   the row index
	 *  @param newRowData the row data
	 */
	public void undoableUpdateRow(int rowIndex, java.util.Vector newRowData);

	/**
	 *  Updates a cell at the designated cell with the new cell data .
	 *  <p/>
	 *  Invoking this method will be able to update a cell, then adds an UndoableEdit or fires an event if necessary.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the row index
	 *  @param value       the cell value
	 */
	public void undoableUpdateCell(int rowIndex, int columnIndex, Object value);
}
