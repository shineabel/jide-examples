/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is to paint sort icon and sort index.
 * 
 *  @since 3.1.0
 */
public class SortableTableHeaderCellDecorator implements TableHeaderCellDecorator {

	public SortableTableHeaderCellDecorator() {
	}

	protected javax.swing.table.TableCellRenderer getHeaderRenderer(javax.swing.table.JTableHeader header, int columnIndex) {
	}

	public java.awt.Insets getInsets(java.awt.Graphics g, javax.swing.table.JTableHeader header, int columnIndex, java.awt.Rectangle cellRect) {
	}

	public void paint(java.awt.Graphics g, javax.swing.table.JTableHeader header, int columnIndex, java.awt.Rectangle cellRect, boolean mouseOverPaintArea) {
	}

	/**
	 *  Gets the sort information of the specified column.
	 * 
	 *  @param header      the header
	 *  @param columnIndex the column index
	 *  @return SortInfo.
	 */
	protected SortableTableHeaderCellDecorator.SortInfo getSortInfo(javax.swing.table.JTableHeader header, int columnIndex) {
	}

	/**
	 *  Sort information of a particular column.
	 */
	protected class SortInfo {


		public SortableTableHeaderCellDecorator.SortInfo(int sortIndex, boolean ascending) {
		}
	}
}
