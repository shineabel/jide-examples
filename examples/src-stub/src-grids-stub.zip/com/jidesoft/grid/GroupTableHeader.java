/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The GroupTableHeader allows the user to (un)group columns by dragging them with the mouse.
 */
public class GroupTableHeader extends AutoFilterTableHeader {

	public static final String PROPERTY_MARGIN = "margin";

	public static final String PROPERTY_VERTICAL_INDENTION = "verticalIndention";

	public static final String PROPERTY_CONNECTION_LINE_VISIBLE = "connectionLineVisible";

	public static final String PROPERTY_GROUP_HEADER_ENABLED = "groupHeaderEnabled";

	public static final String PROPERTY_GROUP_AREA_BACKGROUND = "groupAreaBackground";

	public static final String PROPERTY_GROUP_AREA_FOREGROUND = "groupAreaForeground";

	public static final String PROPERTY_GROUP_AREA_LABEL_FONT = "groupAreaLabelFont";

	/**
	 *  The constructor.
	 * 
	 *  @param table the group table to install this header.
	 */
	public GroupTableHeader(javax.swing.JTable table) {
	}

	public String getActualUIClassID() {
	}

	/**
	 *  Returns a string that specifies the name of the UIDelegate class that paints this component.
	 * 
	 *  @return the string "TableHeader.groupTableHeaderUIDelegate"
	 * 
	 *  @since 3.1.0
	 */
	public String getUIDelegateClassID() {
	}

	@java.lang.Override
	public void setTable(javax.swing.JTable table) {
	}

	@java.lang.Override
	public void setComponentOrientation(java.awt.ComponentOrientation o) {
	}

	/**
	 *  Gets the background color of the group area.
	 * 
	 *  @return the background color of the group area.
	 *  @see #setGroupAreaBackground(java.awt.Color)
	 *  @since 3.3.0
	 */
	public java.awt.Color getGroupAreaBackground() {
	}

	/**
	 *  Sets the background color of the group area.
	 *  <p/>
	 *  By default, the background color is null, which means using the default color.
	 * 
	 *  @param groupAreaBackground the background
	 *  @since 3.3.0
	 */
	public void setGroupAreaBackground(java.awt.Color groupAreaBackground) {
	}

	/**
	 *  Gets the foreground color of the group area.
	 * 
	 *  @return the foreground color of the group area.
	 *  @see #setGroupAreaForeground(java.awt.Color)
	 *  @since 3.3.0
	 */
	public java.awt.Color getGroupAreaForeground() {
	}

	/**
	 *  Sets the foreground color of the group area.
	 *  <p/>
	 *  By default, the foreground color is Color.gray.
	 * 
	 *  @param groupAreaForeground the foreground
	 *  @since 3.3.0
	 */
	public void setGroupAreaForeground(java.awt.Color groupAreaForeground) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Get the height of the real header.
	 * 
	 *  @return the height.
	 */
	public int getActualHeaderHeight() {
	}

	/**
	 *  Get the start Y of the real header.
	 * 
	 *  @return the start Y.
	 */
	public int getActualHeaderY() {
	}

	@java.lang.Override
	public java.awt.Rectangle getHeaderRect(int column) {
	}

	@java.lang.Override
	public int columnAtPoint(java.awt.Point point) {
	}

	/**
	 *  Returns the grouped column index at the specified point or -1 if no such column.
	 * 
	 *  @param point the point
	 *  @return the grouped column index at the specified point. -1 if no such column.
	 */
	public int groupedColumnAtPoint(java.awt.Point point) {
	}

	/**
	 *  Get the rectangle for the group column
	 * 
	 *  @param groupIndex the index of the group column
	 *  @return the rectangle it occupies.
	 */
	public java.awt.Rectangle getGroupedHeaderRect(int groupIndex) {
	}

	public void setGroupedWidths(int[] widths) {
	}

	/**
	 *  Create the mouse and key listener for DnD feature.
	 * 
	 *  @return the listener.
	 */
	protected GroupTableInputListener createGroupTableInputListener() {
	}

	/**
	 *  Set the group header margin.
	 *  <p/>
	 *  By default, the margin is {3, 0, 3, 0}.
	 * 
	 *  @param margin the margin
	 */
	public void setMargin(java.awt.Insets margin) {
	}

	/**
	 *  Get group header margin.
	 * 
	 *  @return the margin.
	 * 
	 *  @see #setMargin(java.awt.Insets) (java.awt.Insets)
	 */
	public java.awt.Insets getMargin() {
	}

	public int getRollOverGroupColumn() {
	}

	/**
	 *  Toggle between sort orders
	 *  <p/>
	 *  By default cycles through ascending and descending.
	 * 
	 *  @param sorting current sort order
	 *  @return next sort order.
	 */
	protected int toggleSortOrder(int sorting) {
	}

	/**
	 *  Gets the resource string used in GroupTableHeader. Subclass can override it to provide their own strings.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}

	/**
	 *  Get the indent to display next grouped column.
	 * 
	 *  @return the indent.
	 */
	public int getVerticalIndention() {
	}

	/**
	 *  Set the indent to display next grouped column.
	 *  <p/>
	 *  By default, the value is -1 which means half of the original height.
	 * 
	 *  @param verticalIndention the indention
	 */
	public void setVerticalIndention(int verticalIndention) {
	}

	/**
	 *  Get the flag indicating if the connect lines between grouped columns are visible.
	 * 
	 *  @return true if connect lines are visible. Otherwise false.
	 */
	public boolean isConnectionLineVisible() {
	}

	/**
	 *  Set the flag indicating if the connect lines between grouped columns are visible.
	 *  <p/>
	 *  By default, the flag is true.
	 * 
	 *  @param connectionLineVisible the flag
	 */
	public void setConnectionLineVisible(boolean connectionLineVisible) {
	}

	/**
	 *  Get the flag indicating if the group header is enabled.
	 * 
	 *  @return true if the group header is enabled. Otherwise false.
	 */
	public boolean isGroupHeaderEnabled() {
	}

	/**
	 *  Set the flag indicating if the group header is enabled.
	 *  <p/>
	 *  By default the flag is false to keep the same DnD behavior with normal table header. You need set it to true
	 *  explicitly to get the group header behavior.
	 * 
	 *  @param groupHeaderEnabled the flag
	 */
	public void setGroupHeaderEnabled(boolean groupHeaderEnabled) {
	}

	/**
	 *  Gets the default label height if there is no grouped column.
	 * 
	 *  @return the label height.
	 */
	public int getLabelHeight() {
	}

	/**
	 *  Sets the default label height if there is no grouped column.
	 * 
	 *  @param labelHeight the height of the label
	 */
	public void setLabelHeight(int labelHeight) {
	}

	/**
	 *  Gets the font of the label while there is no grouping column.
	 * 
	 *  @return the font.
	 * 
	 *  @see #setLabelFont(java.awt.Font)
	 */
	public java.awt.Font getLabelFont() {
	}

	/**
	 *  Sets the font of the label while there is no grouping column.
	 *  <p/>
	 *  By default, the value is null. In this case, the column will occupy exactly the same height with the actual
	 *  header. If you set this font to a non-null value, the label size will be resized automatically.
	 * 
	 *  @param labelFont the font
	 */
	public void setLabelFont(java.awt.Font labelFont) {
	}
}
