/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is an interface to store column width in the table model so that you don't have to get instance of TableColumnModel
 *  to set each column width. 
 */
public interface ColumnWidthTableModel {

	/**
	 *  Returns the minimum width of the column.
	 * 
	 *  @param  column the column index
	 *  @return the minimum width. -1 means the minimum width is not configured yet.
	 */
	public int getMinimumWidth(int column);

	/**
	 *  Returns the preferred width of the column.
	 * 
	 *  @param  column the column index
	 *  @return the preferred width. -1 means the preferred width is not configured yet.
	 */
	public int getPreferredWidth(int column);

	/**
	 *  Returns the maximum width of the column.
	 * 
	 *  @param  column the column index
	 *  @return the maximum width. -1 means the maximum width is not configured yet.
	 */
	public int getMaximumWidth(int column);
}
