/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Extends CellRendererPane and added an actual renderer and an option to paint or not paint the background.
 */
public class CellRendererPaneEx extends javax.swing.CellRendererPane implements RendererWrapper {

	protected java.awt.Component _actualRenderer;

	/**
	 *  Construct a CellRendererPane object.
	 */
	public CellRendererPaneEx() {
	}

	protected void paintBorder(java.awt.Graphics g) {
	}

	public javax.swing.border.Border getBorder() {
	}

	public String getToolTipText(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Checks the flag whether the background should be painted. Subclass should respect this flag.
	 * 
	 *  @return true or false.
	 */
	public boolean isPaintBackground() {
	}

	/**
	 *  Sets the flag to paint the background. Subclass should respect this flag to paint the background or not.
	 * 
	 *  @param paintBackground true or false.
	 */
	public void setPaintBackground(boolean paintBackground) {
	}

	/**
	 *  Gets the actual renderer. ExpandablePanel can only paint the "+/-" button and let the actual renderer paint other
	 *  part.
	 * 
	 *  @return the actual renderer.
	 */
	public java.awt.Component getActualRenderer() {
	}

	/**
	 *  Sets the actual renderer. By default, ExpandablePanel will paint the +/- button as well as a text. However if you
	 *  call this method, ExpandablePanel will only paint the "+/-" button and let the actual renderer paint other part.
	 * 
	 *  @param actualRenderer the renderer
	 */
	public void setActualRenderer(java.awt.Component actualRenderer) {
	}
}
