/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A String array cell editor.
 */
public class StringArrayCellEditor extends ExComboBoxCellEditor {

	/**
	 *  Creates a StringArrayCellEditor.
	 */
	public StringArrayCellEditor() {
	}

	/**
	 *  Creates StringArrayExComboBox used by this cell editor.
	 * 
	 *  @return a StringArrayExComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates StringArrayExComboBox used by this cell editor.
	 * 
	 *  @return a StringArrayExComboBox.
	 */
	protected com.jidesoft.combobox.StringArrayExComboBox createStringArrayComboBox() {
	}
}
