/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to allow you to implement filtering feature on any table model.
 */
public interface IFilterableTableModel extends javax.swing.table.TableModel, AutoFilterTableModel {

	/**
	 *  Specifies all columns. You can use this to apply a filter to all columns. All columns must satisfy the filter
	 *  condition in order for the row not to be filtered away.
	 */
	public static final int ALL_COLUMNS = -1;

	/**
	 *  Specifies any columns. You can use this to apply a filter to any columns. As long as there is one column
	 *  satisfies the filter condition, the row will not be filtered away.
	 */
	public static final int ANY_COLUMNS = -2;

	public static final String IDENTIFIER_ALL_COLUMNS = "All$$$$$Columns";

	public static final String IDENTIFIER_ANY_COLUMNS = "Any$$$$$Columns";

	/**
	 *  Reapply all filters after they are changed.
	 */
	public void refresh();

	/**
	 *  Checks if the column is filterable for the filters that are added to {@link #ALL_COLUMNS}. The column will be
	 *  excluded if it returns false (same as {@link #isColumnVisible(int)} in this case. There is also {@link
	 *  #isColumnAutoFilterable(int)} which is used for <code>AutoFilterHeader</code> to control if the filter button is
	 *  visible.
	 * 
	 *  @param column the column index.
	 *  @return true if the column can be filtered.
	 */
	public boolean isColumnFilterable(int column);

	/**
	 *  Checks if the column is visible. Since column visible information is on the JTable, FilterableTableModel has no
	 *  idea whether a column is visible. So we added this protected method to give user a chance to tell
	 *  FilterableTableModel whether a column is visible. If it is not visible, it will not be considered when
	 *  filtering.
	 * 
	 *  @param column the column index.
	 *  @return true if the column is visible. Otherwise false.
	 */
	public boolean isColumnVisible(int column);

	/**
	 *  Adds a filter to the specified column.
	 * 
	 *  @param column the column index. It could also be two special values - {@link #ALL_COLUMNS} or {@link
	 *                #ANY_COLUMNS}. If the value is {@link #ANY_COLUMNS}, this method will be the same as {@link
	 *                #addFilter(Filter)}.
	 *  @param filter the filter to be added.
	 */
	public void addFilter(int column, com.jidesoft.filter.Filter filter);

	/**
	 *  Adds a filter to all columns. if one of the columns matches the filter, the row will be not be filtered. <p>You
	 *  can use {@link AbstractFilter} to create new filter. If you need the row index or column index in order to decide
	 *  if the value should be filtered, you can use {@link AbstractTableFilter} and use getRowIndex() and
	 *  getColumnInde() to find out current row or column index.
	 *  <p/>
	 *  Please note, addFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param filter the filter to be added.
	 */
	public void addFilter(com.jidesoft.filter.Filter filter);

	/**
	 *  Adds a FilterItem.
	 * 
	 *  @param filterItem the FilterItem
	 */
	public void addFilter(IFilterableTableModel.FilterItem filterItem);

	/**
	 *  Removes the filter from the specified column. The filter must be added using {@link #addFilter(int, Filter)}.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param column the column index. It could also be two special values - {@link #ALL_COLUMNS} or {@link
	 *                #ANY_COLUMNS}. If the value is {@link #ANY_COLUMNS}, this method will be the same as {@link
	 *                #removeFilter(Filter)}.
	 *  @param filter the filter to be removed.
	 */
	public void removeFilter(int column, com.jidesoft.filter.Filter filter);

	/**
	 *  Removes the filter from all columns. The filter must be added using {@link #addFilter(Filter)}.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param filter the filter to be removed.
	 */
	public void removeFilter(com.jidesoft.filter.Filter filter);

	/**
	 *  Removes the filter item.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param filterItem the FilterItem to be removed.
	 */
	public void removeFilter(IFilterableTableModel.FilterItem filterItem);

	/**
	 *  Removes all filters from the specified column. Those filters are added using {@link #addFilter(int, Filter)}.
	 *  <p/>
	 *  Please note, removeAllFilters will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param column the column index where all filters for that column should be removed.
	 */
	public void removeAllFilters(int column);

	/**
	 *  Removes all filters that are added using {@link #addFilter(Filter)}. If you want to remove all filters that
	 *  either added using {@link #addFilter(int, Filter)} or {@link #addFilter(Filter)}, you should use {@link
	 *  #clearFilters()}.
	 *  <p/>
	 *  Please note, removeAllFilters will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 */
	public void removeAllFilters();

	/**
	 *  Removes all filters from all columns.
	 *  <p/>
	 *  Please note, clearFilters will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 */
	public void clearFilters();

	/**
	 *  Gets the filters for the specified column.
	 * 
	 *  @param column the column index.
	 *  @return the filters for the specified column.
	 */
	public com.jidesoft.filter.Filter[] getFilters(int column);

	/**
	 *  Gets all the FilterItems added to this FilterableTableModel.
	 * 
	 *  @return all the FilterItems added to this FilterableTableModel.
	 */
	public java.util.List getFilterItems();

	/**
	 *  Applies or unapplies the filters. By default, the filters are not applied. So after user adds several filters,
	 *  this method should be called to make filters taking effect. When new filter is added or existing is removed, this
	 *  method should be called as well.
	 * 
	 *  @param apply true to apply the filters.
	 */
	public void setFiltersApplied(boolean apply);

	/**
	 *  Checks if the filters are in effect.
	 * 
	 *  @return true if filters are in effect.
	 */
	public boolean isFiltersApplied();

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters.
	 * 
	 *  @return true if there are any filters. Otherwise false.
	 */
	public boolean hasFilter();

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters on the specified column.
	 * 
	 *  @param columnIndex the column index to check if there is a filter on it.
	 *  @return true if there are any filters on the specified column. Otherwise false.
	 */
	public boolean hasFilter(int columnIndex);

	/**
	 *  Sets the logic of filters on the same column. If true, filters are in AND mode, meaning if one of the filters
	 *  return true in isValueFiltered method, the value will be filtered. If false, filters are in OR mode, meaning if
	 *  one of the filters return false, the value will NOT be filtered.
	 *  <p/>
	 *  The mode only has effect on the filters of the same columns which includes each column of the table model as well
	 *  as the two special column value {@link #ALL_COLUMNS} and {@link #ANY_COLUMNS}.
	 * 
	 *  @return the AND/OR mode. Default is true which means AND mode.
	 */
	public boolean isAndMode();

	/**
	 *  Sets the logic among the filters. If AND is true, Please note, this logic mode will apply for all filters, no
	 *  matter it's for a column or any column or all columns. You won't be able to do complex expression such as AND
	 *  some filters and OR some other filters using one <code>FitlerableTableModel</code>. In order to do more complex
	 *  expression, you would need multiple <code>FilterableTableModel</code>, one wraps the other. You make filters in
	 *  each <code>FilterableTableModel</code> to be OR logic, then the logic among the pipe of
	 *  <code>FilterableTableModel</code>s will always be AND logic.
	 * 
	 *  @param andMode true or false.
	 */
	public void setAndMode(boolean andMode);

	/**
	 *  Checks if the FilterableTableModel is adjusting. If it is adjusting, FilterableTableModel will not apply filter
	 *  when the actual list model changes.
	 * 
	 *  @return true if adjusting. Otherwise false.
	 */
	public boolean isAdjusting();

	/**
	 *  Sets the FilterableTableModel to adjusting mode. If it is adjusting, FilterableTableModel will not apply filter
	 *  when the actual table model changes. After you set adjusting to false, FilterableListModel will re-apply the
	 *  filter.
	 * 
	 *  @param adjusting true or false.
	 */
	public void setAdjusting(boolean adjusting);

	/**
	 *  Gets all possible values of the table model. If there is filter on this column, the possible values are collected
	 *  from the actual table model. If there is no filter on this column, the possible values are collected from this
	 *  filterable table model. After we collected all the values, we will use Arrays.sort method to sort the values.
	 *  <p/>
	 *  The possible values are used by <code>AutoFilterTableHeader</code> to populate the drop down filter list.
	 * 
	 *  @param columnIndex the column index.
	 *  @param comparator  the comparator. It is used to sort the values.
	 *  @return an array of all possible values of certain column in the table model.
	 */
	public Object[] getPossibleValues(int columnIndex, java.util.Comparator comparator);

	public Object[] getPossibleValuesAndConverters(int columnIndex, java.util.Comparator comparator);

	/**
	 *  Gets the filter icon for a particular column.
	 * 
	 *  @param column the column index.
	 *  @return the icon.
	 */
	public javax.swing.Icon getFilterIcon(int column);

	/**
	 *  If filtering is paused, keep rows in same relative positions Inserts/Deletes shift rows without re-ordering
	 * 
	 *  @param pause TRUE = Filtering is Paused;  FALSE = Filtering is Active
	 */
	public void setFilteringPaused(boolean pause);

	/**
	 *  Checks if the filtering is paused.
	 * 
	 *  @return true if paused. Otherwise false.
	 */
	public boolean isFilteringPaused();

	/**
	 *  Adds a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterableTableModelListener
	 */
	public void addFilterableTableModelListener(FilterableTableModelListener l);

	/**
	 *  Removes a listener from the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterableTableModelListener
	 */
	public void removeFilterableTableModelListener(FilterableTableModelListener l);

	/**
	 *  Returns an array of all the FilterableTableModel listeners registered on this filter.
	 * 
	 *  @return all of this filter's <code>FilterableTableModelListener</code>s or an empty array if no filter listeners
	 *          are currently registered
	 *  @see #addFilterableTableModelListener
	 *  @see #removeFilterableTableModelListener
	 */
	public FilterableTableModelListener[] getFilterableTableModelListeners();

	/**
	 *  Check if each converter in this column for each row is the same.
	 * 
	 *  @param columnIndex the column index
	 *  @return true if all converters are the same in every row. Otherwise false.
	 */
	public boolean isSameConverterAt(int columnIndex);
}
