/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AbstractNavigableTableModel</code> adds <code>NavigableModel</code> support to <code>AbstractTableModel</code>.
 *  You can use it as replacement for <code>AbstractTableModel</code>. It implements both methods
 *  in {@link NavigableModel} by returning true in {@link com.jidesoft.grid.NavigableModel#isNavigationOn()} and
 *  {@link com.jidesoft.grid.NavigableModel#isNavigableAt(int,int)}. Subclass can override the default
 *  implementation.
 */
public abstract class AbstractNavigableTableModel extends javax.swing.table.AbstractTableModel implements NavigableTableModel {

	protected AbstractNavigableTableModel() {
	}

	public boolean isNavigableAt(int rowIndex, int columnIndex) {
	}

	public boolean isNavigationOn() {
	}
}
