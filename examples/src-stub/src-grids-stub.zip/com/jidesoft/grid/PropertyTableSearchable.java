/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>PropertyTableSearchable</code> is a special Searchable that implements {@link com.jidesoft.swing.Searchable}
 *  that enables the search function in PropertyTable.
 *  <p/>
 *  The only special attribute of PropertyTableSearchable is one called recursive. Since PropertyTable allows
 *  nested Property. If recursive is true, the search will be performed on all properties include children properties.
 *  If the child property is not visible, it will be made visible. If recursive is false, it will only search on the top level
 *  property and didn't even look at the children property.
 */
public class PropertyTableSearchable extends TreeTableSearchable {

	public PropertyTableSearchable(javax.swing.JTable table) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}

	@java.lang.Override
	protected String convertElementToString(Object item) {
	}
}
