/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellStyle</code> defines the styles of a table cell. Those styles include the background (include the selection
 *  background), the foreground (include the selection foreground), the font, the horizontal alignment, the vertical
 *  alignment, the text, the toolTipText, the icon and the border. <code>CellStyleTable</code> and its subclasses will
 *  use the styles defined in <code>CellStyle</code> and set to cell renderer component. Obviously, not all styles apply
 *  to all types of cell renderer components.
 *  <p/>
 *  <code>CellStyle</code> works with <code>StyleModel</code> which can be used as an interface for TableModel. You can
 *  refer to {@link StyleModel} to see how to use it.
 *  <p/>
 *  In additional to all the styles that you can set to CellStyle, you can assign a priority to it. This is useful where
 *  there are multiple cell styles for the same cell. Please read javadoc of {@link #getPriority()} for more
 *  information.
 */
public class CellStyle implements javax.swing.SwingConstants, Cloneable {

	/**
	 *  An empty icon instance. If you ever setIcon on a cell style, you should set this EMPTY_ICON to those cell styles
	 *  that don't have an icon.
	 */
	public static final javax.swing.Icon EMPTY_ICON;

	public static final java.awt.Color EMPTY_COLOR;

	public static final java.awt.Font EMPTY_FONT;

	public static final javax.swing.border.Border EMPTY_BORDER;

	public static final String EMPTY_STRING = "AN_EMPTY_STRING";

	public static final CellPainter EMPTY_CELL_PAINTER;

	public CellStyle() {
	}

	/**
	 *  Create a copy of the CellStyle;
	 * 
	 *  @param style the existing cell style.
	 */
	public CellStyle(CellStyle style) {
	}

	public javax.swing.border.Border getBorder() {
	}

	/**
	 *  Sets the border style. The border is used to set the border to the cell renderer component. Setting the border
	 *  will make the cell content smaller. You can also use the overlay border if you prefer the border to be painted
	 *  over the cell content instead of setting the border to the component.
	 * 
	 *  @param border the border.
	 */
	public void setBorder(javax.swing.border.Border border) {
	}

	public java.awt.Color getBackground() {
	}

	/**
	 *  Sets the background.
	 * 
	 *  @param background the background color.
	 */
	public void setBackground(java.awt.Color background) {
	}

	public java.awt.Color getForeground() {
	}

	/**
	 *  Sets the foreground color.
	 * 
	 *  @param foreground the foreground color.
	 */
	public void setForeground(java.awt.Color foreground) {
	}

	public java.awt.Color getSelectionBackground() {
	}

	/**
	 *  Sets the selection background.
	 * 
	 *  @param selectionBackground the selection background.
	 */
	public void setSelectionBackground(java.awt.Color selectionBackground) {
	}

	public java.awt.Color getSelectionForeground() {
	}

	/**
	 *  Sets the selection foreground.
	 * 
	 *  @param selectionForeground the selection foreground.
	 */
	public void setSelectionForeground(java.awt.Color selectionForeground) {
	}

	public java.awt.Font getFont() {
	}

	/**
	 *  Sets the font. If you set the font, we will ignore the value in setFontStyle.
	 * 
	 *  @param font the font in the CellStyle.
	 */
	public void setFont(java.awt.Font font) {
	}

	public int getFontStyle() {
	}

	/**
	 *  Sets the font style which could be Font.PLAIN, Font.BOLD or Font.ITALIC. If you set the font, we will ignore the
	 *  value in setFontStyle.
	 * 
	 *  @param fontStyle the font style in the CellStyle.
	 */
	public void setFontStyle(int fontStyle) {
	}

	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Sets the icon. The icon will be used if the cell renderer component is a JLabel or an AbstractButton.
	 * 
	 *  @param icon the icon.
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	public int getVerticalAlignment() {
	}

	/**
	 *  Sets the vertical alignment. It will be applicable for the renderer component that supports the vertical
	 *  alignment, such as JLabel, JButton etc.
	 * 
	 *  @param verticalAlignment One of the following constants defined in <code>SwingConstants</code>: <code>TOP</code>,
	 *                           <code>CENTER</code> (the default), or <code>BOTTOM</code>.
	 */
	public void setVerticalAlignment(int verticalAlignment) {
	}

	public int getHorizontalAlignment() {
	}

	/**
	 *  Sets the horizontal alignment.  It will be applicable for the renderer component that supports the vertical
	 *  alignment, such as JLabel, JButton etc.
	 * 
	 *  @param horizontalAlignment One of the following constants defined in <code>SwingConstants</code>:
	 *                             <code>LEFT</code>, <code>CENTER</code> (the default for image-only labels),
	 *                             <code>RIGHT</code>, <code>LEADING</code> (the default for text-only labels) or
	 *                             <code>TRAILING</code>.
	 */
	public void setHorizontalAlignment(int horizontalAlignment) {
	}

	public int getVerticalTextPosition() {
	}

	/**
	 *  Sets the vertical text position. It will be applicable for the renderer component that supports the vertical text
	 *  position, such as JLabel, JButton etc.
	 * 
	 *  @param verticalTextPosition One of the following constants defined in <code>SwingConstants</code>:
	 *                              <code>TOP</code>, <code>CENTER</code> (the default), or <code>BOTTOM</code>.
	 */
	public void setVerticalTextPosition(int verticalTextPosition) {
	}

	public int getHorizontalTextPosition() {
	}

	/**
	 *  Sets the horizontal text position.  It will be applicable for the renderer component that supports the horizontal
	 *  text position, such as JLabel, JButton etc.
	 * 
	 *  @param horizontalTextPosition One of the following constants defined in <code>SwingConstants</code>:
	 *                                <code>LEFT</code>, <code>CENTER</code> (the default for image-only labels),
	 *                                <code>RIGHT</code>, <code>LEADING</code> (the default for text-only labels) or
	 *                                <code>TRAILING</code>.
	 */
	public void setHorizontalTextPosition(int horizontalTextPosition) {
	}

	public String getText() {
	}

	/**
	 *  Sets the text style. This style can be used when you don't want the value to be visible. By using this text
	 *  style, the text will be displayed instead of the actual cell value.
	 * 
	 *  @param text the text.
	 */
	public void setText(String text) {
	}

	public String getToolTipText() {
	}

	/**
	 *  Sets the tooltip text style. If you want a cell to have a tooltip, you can use this cell style.
	 * 
	 *  @param toolTipText the tooltip text.
	 */
	public void setToolTipText(String toolTipText) {
	}

	public javax.swing.border.Border getOverlayBorder() {
	}

	/**
	 *  Sets the overlay border cell style. The overlay border is painted over the cell content (not set as the border to
	 *  the cell renderer component). This style serves the same purpose as the overlay CellPainter. You can use the
	 *  overlay border if it is easy to make a border to paint the way you prefer. Otherwise you can always the
	 *  CellPainter which is more flexible to paint.
	 *  <p/>
	 *  Please note, if the CellStyle is used in a HeaderStyleModel, the overlay border feature is not supported.
	 * 
	 *  @param overlayBorder the overlay border.
	 */
	public void setOverlayBorder(javax.swing.border.Border overlayBorder) {
	}

	/**
	 *  Gets the overlay CellPainter which is used to paint after the cell content is painted.
	 * 
	 *  @return the overlay CellPainter
	 *  @since 3.3.4
	 */
	public CellPainter getOverlayCellPainter() {
	}

	/**
	 *  Sets the overlay CellPainter. This painter is called after the cell content is painted so it is painted over the
	 *  cell content. This style serves the same purpose as the overlay border. You can use the overlay border if it is
	 *  easy to make a border to paint the way you prefer. Otherwise you can always the CellPainter which is more
	 *  flexible to paint.
	 *  <p/>
	 *  Please note, if the CellStyle is used in a HeaderStyleModel, the overlay CellPainter feature is not supported.
	 * 
	 *  @param overlayCellPainter the overlay CellPainter.
	 *  @since 3.3.4
	 */
	public void setOverlayCellPainter(CellPainter overlayCellPainter) {
	}

	/**
	 *  Gets the underlay CellPainter which is used to paint before the cell content is painted.
	 * 
	 *  @return the underlay CellPainter
	 *  @since 3.3.4
	 */
	public CellPainter getUnderlayCellPainter() {
	}

	/**
	 *  Sets the underlay CellPainter. This painter is called before the cell content is painted.
	 *  <p/>
	 *  Please note, if the CellStyle is used in a HeaderStyleModel, the underlay CellPainter feature is not supported.
	 * 
	 *  @param underlayCellPainter the underlay CellPainter.
	 *  @since 3.3.4
	 */
	public void setUnderlayCellPainter(CellPainter underlayCellPainter) {
	}

	/**
	 *  Gets the priority of the cell style. This has nothing to do with the styles for a cell but the priority of this
	 *  particular cell style when there are multiple cell styles for the same cells.
	 *  <p/>
	 *  In JIDE Grids, we used <code>TableModelWrapper</code> which can wrap another table model. So you can end up with
	 *  a pipe of <code>TableModelWrapper</code>s. Any of the table models can implement <code>StyleModel</code> and each
	 *  one can return a different cell style. <code>CellStyleTable</code> will look at those <code>CellStyle</code>s and
	 *  sort them by the priority. The cell style that has the higher priority will win over any cell styles that have a
	 *  lower priority when there are style conflicts (meaning the same style is used in different cell styles).
	 *  <p/>
	 *  For example, you have one cell style that implements the row stripes and another cell style that implements cell
	 *  update indication. Both use cell background style. Obviously you want the cell update indication has a higher
	 *  priority than row stripes. So you just set a higher priority in cell update indication cell style.
	 *  <p/>
	 *  If the cell styles have the same priority, the one from inner style table model has a higher priority.
	 * 
	 *  @return the priority.
	 */
	public int getPriority() {
	}

	/**
	 *  Sets the priority of the cell style.
	 * 
	 *  @param priority the new priority
	 */
	public void setPriority(int priority) {
	}

	/**
	 *  Checks if this CellStyle instance equals to the obj in terms of exporting to excel.
	 *  <p/>
	 *  Only {@link #getBackground()}, {@link #getForeground()}, {@link #getFont()}, {@link #getFontStyle()}, {@link
	 *  #getHorizontalAlignment()} and {@link #getVerticalAlignment()} are compared in this method.
	 * 
	 *  @param obj the target object
	 *  @return true if it will equal after exporting to excel.
	 *  @since 3.4.8
	 */
	public boolean equalsForExporting(Object obj) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	/**
	 *  Gets the flag indicating if the cell shows the icon only if {@link #getIcon()} is a non-null value.
	 * 
	 *  @return true if the cell shows the icon only without text. Otherwise false.
	 *  @since 3.2.0
	 *  @deprecated replaced by {@link #getText()}. If it returns an empty string, that means only icon will be shown.
	 */
	@java.lang.Deprecated
	public boolean isShowIconOnly() {
	}

	/**
	 *  Sets the flag indicating if the cell shows the icon only if {@link #getIcon()} is a non-null value.
	 * 
	 *  @param showIconOnly the flag
	 *  @since 3.2.0
	 *  @deprecated replaced by {@link #setText(String)}
	 */
	@java.lang.Deprecated
	public void setShowIconOnly(boolean showIconOnly) {
	}

	@java.lang.Override
	public CellStyle clone() {
	}

	/**
	 *  Merges the styles from the originalCellStyle to mergedCellStyle only if the mergedCellStyle doesn't have the
	 *  particular style set before.
	 *  <p/>
	 *  After merge, the priority of the merged cell style would be the higher one of those two CellStyles. If you have
	 *  more than two CellStyles to merge, please sort those CellStyles with priority first.
	 * 
	 *  @param mergedCellStyle  the cell style to merge to
	 *  @param anotherCellStyle the cell style to merge from
	 *  @since 3.3.5
	 */
	public static void mergeCellStyle(CellStyle mergedCellStyle, CellStyle anotherCellStyle) {
	}
}
