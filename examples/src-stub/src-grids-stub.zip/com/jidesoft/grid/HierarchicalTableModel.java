/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>HierarchicalTableModel</code> is an interface used by <code>HierarchicalTable</code> to show any components in
 *  a table in a hierarchical fashion. Each row can be associated with a component. The component can be used to display
 *  detailed or break-down information of that row.
 *  <p/>
 *  This class is part of HierarchicalTable component. If you used the beta version of HierarchicalTable component
 *  before, please note you need to change your code as the interface changed. The main reason for this change is to
 *  break the model from view.
 *  <p/>
 *  Here are the details of interface changes.
 *  <pre><code>
 *  Old method                           ==> New method
 *  boolean hasChildComponent(int row)   ==> boolean hasChild(int row)
 *  boolean isHierarchical(int row) remains
 *  Component getChildComponent(int row) ==> Object getChildValueAt(int row)
 *  </code></pre>
 *  Since HierarchicalTableModel is a model related class, it should only deal with data. The component is now created by
 *  a factory class on HierarchicalTable called {@link HierarchicalTableComponentFactory}. {@link
 *  HierarchicalTableComponentFactory} will create a component from the value that returned from getChildValueAt(int
 *  row). You can set the factory using {@link HierarchicalTable#setComponentFactory(HierarchicalTableComponentFactory)}
 *  method.
 *  <p/>
 *  Sometimes your model is dynamically changing. You may return true or false for hasChild, isHierarchical, isExpandable
 *  and different values for getChildValueAt. If any of them change, you need to call fireTableRowsUpdated event to let
 *  the view about the row change.
 */
public interface HierarchicalTableModel {

	/**
	 *  Checks if the row has child.
	 * 
	 *  @param row the row index
	 *  @return true if the row has child. Otherwise false.
	 */
	public boolean hasChild(int row);

	/**
	 *  Returns true if the child component will be shown in a new row. Returns false is the child component will replace
	 *  the current row.
	 * 
	 *  @param row
	 *  @return true if the child component will be shown in a new row. Otherwise false which means the child component
	 *          will replace the current row when displaying.
	 */
	public boolean isHierarchical(int row);

	/**
	 *  Gets the child object value associated with the row at row index.
	 * 
	 *  @param row
	 *  @return the value. If child components are the same except the displaying is different, it's better to return a
	 *          value using this method. Then the component factory can create the same component and only load a
	 *          different value to that component. You can also return null in this method. If so, the component factory
	 *          can look up in the table model on fly and find out how to create the child component.
	 */
	public Object getChildValueAt(int row);

	/**
	 *  Returns true if the row is expandable. This only makes sense when hasChild() return true. If there is child and
	 *  but not expandable, you will see a gray "+" icon but click on it does nothing.
	 * 
	 *  @param row
	 *  @return true if the row is expandable.
	 */
	public boolean isExpandable(int row);
}
