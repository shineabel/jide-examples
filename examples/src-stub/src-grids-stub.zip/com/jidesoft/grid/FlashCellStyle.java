/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>FlashCellStyle</code> provides an alternative cell style to allow cell flashing.
 *  There are two cell styles defined in this class. The normal style is on the cell style itself since <code>FlashCellStyle</code>
 *  extends <code>CellStyle</code>. This style is used when {@link #isFlashOn()} returns false. The other
 *  cell style is set using {@link #setFlashCellStyle(CellStyle)}. It will be used when {@link #isFlashOn()} returns true.
 *  <p/>
 *  To use this class, you should implement <code>StyleModel</code> in your table model. In the cell you want to flash,
 *  return a predefined <code>FlashCellStyle</code>. You could return a new instance of <code>FlashCellStyle</code> every time.
 *  But  for the performance consideration, it will be way more efficient to reuse the same instance as long as
 *  the flash style (background, foreground, font style etc) is the same for all flashing cells.
 *  <p/>
 *  Once <code>StyleModel</code> is done, you just need to use {@link TableFlashable} to enable the flashing.
 *  <code><pre>
 *  TableFlashable flasher = new TableFlashable(_table, new FlashCellStyle[]{_flashCellStyle}, new int[]{0, 2});
 *  flasher.startFlashing();
 *  </pre></code>
 *  The code above will flash only the cells in the first and the third columns, assuming only those columns have flashing cells.
 */
public class FlashCellStyle extends CellStyle {

	/**
	 *  Creates a <code>FlashCellStyle</code>.
	 */
	public FlashCellStyle() {
	}

	/**
	 *  Checks if the flash style is on. There are two styles defined - normal style and flash style.
	 *  The two styles appear alternatively to create a flashing effect.
	 * 
	 *  @return true if flash style on.
	 */
	public boolean isFlashOn() {
	}

	/**
	 *  Sets the flash style on.
	 * 
	 *  @param on true or false.
	 */
	public void setFlashOn(boolean on) {
	}

	/**
	 *  Toggles from flash style to normal style or other way.
	 */
	public void flash() {
	}

	/**
	 *  Gets the flashCellStyle.
	 * 
	 *  @return the flashCellStyle.
	 */
	public CellStyle getFlashCellStyle() {
	}

	/**
	 *  Sets the flashCellStyle.
	 * 
	 *  @param flashCellStyle the new flashCellStyle.
	 */
	public void setFlashCellStyle(CellStyle flashCellStyle) {
	}

	/**
	 *  Gets the border. If the flash is on, we will return  <code>getFlashCellStyle().getBorder()</code>. Otherwise we will return <code>super.getBorder()</code>.
	 * 
	 *  @return the border.
	 */
	@java.lang.Override
	public javax.swing.border.Border getBorder() {
	}

	/**
	 *  Gets the background. If the flash is on, we will return  <code>getFlashCellStyle().getBackground()</code>. Otherwise we will return <code>super.getBackground()</code>.
	 * 
	 *  @return the background.
	 */
	@java.lang.Override
	public java.awt.Color getBackground() {
	}

	/**
	 *  Gets the foreground. If the flash is on, we will return  <code>getFlashCellStyle().getForeground()</code>. Otherwise we will return <code>super.getForeground()</code>.
	 * 
	 *  @return the foreground.
	 */
	@java.lang.Override
	public java.awt.Color getForeground() {
	}

	/**
	 *  Gets the selection background. If the flash is on, we will return  <code>getFlashCellStyle().getSelectionBackground()</code>. Otherwise we will return <code>super.getSelectionBackground()</code>.
	 * 
	 *  @return the selection background.
	 */
	@java.lang.Override
	public java.awt.Color getSelectionBackground() {
	}

	/**
	 *  Gets the selection foreground. If the flash is on, we will return  <code>getFlashCellStyle().getSelectionForeground()</code>. Otherwise we will return <code>super.getSelectionForeground()</code>.
	 * 
	 *  @return the selection foreground.
	 */
	@java.lang.Override
	public java.awt.Color getSelectionForeground() {
	}

	/**
	 *  Gets the font. If the flash is on, we will return  <code>getFlashCellStyle().getFont()</code>. Otherwise we will return <code>super.getFont()</code>.
	 * 
	 *  @return the font.
	 */
	@java.lang.Override
	public java.awt.Font getFont() {
	}

	/**
	 *  Gets the fontstyle. If the flash is on, we will return  <code>getFlashCellStyle().getFontStyle()</code>. Otherwise we will return <code>super.getFontStyle()</code>.
	 * 
	 *  @return the fontstyle.
	 */
	@java.lang.Override
	public int getFontStyle() {
	}

	/**
	 *  Gets the icon. If the flash is on, we will return  <code>getFlashCellStyle().getIcon()</code>. Otherwise we will return <code>super.getIcon()</code>.
	 * 
	 *  @return the icon.
	 */
	@java.lang.Override
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Gets the vertical alignment. If the flash is on, we will return  <code>getFlashCellStyle().getVerticalAlignment()</code>. Otherwise we will return <code>super.getVerticalAlignment()</code>.
	 * 
	 *  @return the vertical alignment.
	 */
	@java.lang.Override
	public int getVerticalAlignment() {
	}

	/**
	 *  Gets the horizontal alignment. If the flash is on, we will return  <code>getFlashCellStyle().getHorizontalAlignment()</code>. Otherwise we will return <code>super.getHorizontalAlignment()</code>.
	 * 
	 *  @return the horizontal alignment.
	 */
	@java.lang.Override
	public int getHorizontalAlignment() {
	}

	/**
	 *  Gets the priority. If the flash is on, we will return  <code>getFlashCellStyle().getPriority()</code>. Otherwise we will return <code>super.getPriority()</code>.
	 * 
	 *  @return the priority.
	 */
	@java.lang.Override
	public int getPriority() {
	}
}
