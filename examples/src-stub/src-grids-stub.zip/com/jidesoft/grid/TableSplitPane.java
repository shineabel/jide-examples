/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableSplitPane</code> displays a MultiTableModel in several separate tables in a JideSplitPane. However those
 *  tables are synchronized. You can use tab or left key to navigate to all tables just like they are in the same table.
 */
public class TableSplitPane extends JideSplitPane {

	protected MultiTableModel _originalTableModel;

	protected MultiTableModel _originalFooterTableModel;

	protected MultiTableModel _originalHeaderTableModel;

	protected TableScrollPane[] _tableScrollPanes;

	public static final String TABLE_INDEX = "TableSplitPane.index";

	public static final String TABLESPLITPANE_KEY = "TableSplitPane.Parent";

	public TableSplitPane() {
	}

	/**
	 *  Creates a <code>TableSplitPane</code>. The tables will not be sortable.
	 * 
	 *  @param tableModel the MultiTableModel. This is the main table model that will be used to create up to three tables
	 *                    in TableSplitPane.
	 */
	public TableSplitPane(MultiTableModel tableModel) {
	}

	/**
	 *  Creates a <code>TableSplitPane</code>. The tables will not be sortable.
	 * 
	 *  @param tableModel the MultiTableModel. This is the main table model that will be used to create up to three tables
	 *                    in TableSplitPane.
	 *  @param sortable   if the tables will be sortable.
	 */
	public TableSplitPane(MultiTableModel tableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableSplitPane</code> with footer table. The tables will not be sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableSplitPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 */
	public TableSplitPane(MultiTableModel tableModel, MultiTableModel footerTableModel) {
	}

	/**
	 *  Creates a <code>TableSplitPane</code> with footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableSplitPane.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 */
	public TableSplitPane(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Creates a <code>TableSplitPane</code> with footer table. You can specify if the tables are sortable.
	 * 
	 *  @param tableModel       the MultiTableModel. This is the main table model that will be used to create up to three
	 *                          tables in TableSplitPane.
	 *  @param headerTableModel the header table model. It will be used to create a header table above the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param footerTableModel the footer table model. It will be used to create a footer table below the main table. It
	 *                          must have the same column count as the MultiTableModel's non-header and non-footer column
	 *                          count.
	 *  @param sortable         if the tables will be sortable.
	 */
	public TableSplitPane(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Creates a SortableTableModel or SortableTreeTableModel for the MultiTableModel if isSortable() is true.
	 *  Otherwise, tableModel itself will be returned.
	 *  <p/>
	 *  See below for the default code.
	 *  <code><pre>
	 *  TableModel actualTableModel;
	 *  if (tableModel instanceof TreeTableModel && sortable) {
	 *      actualTableModel = new SortableTreeTableModel(tableModel);
	 *  }
	 *  else if (!(tableModel instanceof ISortableTableModel) && sortable) {
	 *      actualTableModel = new SortableTableModel(tableModel);
	 *  }
	 *  else {
	 *      actualTableModel = tableModel;
	 *  }
	 *  return actualTableModel;
	 *  </pre></code>
	 * 
	 *  @param tableModel the MultiTableModel
	 *  @param sortable   true or false. If true, the tableModel should be wrapped into a SortableTableModel or
	 *                    SortableTreeTableModel.
	 *  @return a SortableTableModel or SortableTreeTableModel for the MultiTableModel if isSortable() is true.
	 */
	protected MultiTableModel createSortableTableModel(MultiTableModel tableModel, boolean sortable) {
	}

	/**
	 *  Sets the original table models.
	 * 
	 *  @param tableModel       the main table model
	 *  @param footerTableModel the footer table model. If you don't have any footer, you can pass null.
	 *  @param sortable         if the table need to be sorted
	 */
	public void setTableModels(MultiTableModel tableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Sets the original table models.
	 * 
	 *  @param tableModel       the main table model
	 *  @param headerTableModel the header table model. If you don't have any header, you can pass null.
	 *  @param footerTableModel the footer table model. If you don't have any footer, you can pass null.
	 *  @param sortable         if the table need to be sorted
	 */
	public void setTableModels(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel, boolean sortable) {
	}

	/**
	 *  Gets the original table model.
	 * 
	 *  @return the original table model.
	 */
	public MultiTableModel getOriginalTableModel() {
	}

	/**
	 *  Gets the original footer table model.
	 * 
	 *  @return the original footer table model.
	 */
	public MultiTableModel getOriginalFooterTableModel() {
	}

	/**
	 *  Creates the TableScrollPane used in each pane of the TableSplitPane.
	 * 
	 *  @param tableModel       the main table model
	 *  @param headerTableModel the header table model
	 *  @param footerTableModel the footer table model
	 *  @param tableIndex       the table index
	 *  @param sortable         if the tables need to be sorted
	 *  @return the TableScrollPane.
	 */
	protected TableScrollPane createTableScrollPane(MultiTableModel tableModel, MultiTableModel headerTableModel, MultiTableModel footerTableModel, int tableIndex, boolean sortable) {
	}

	/**
	 *  Gets the array of TableScrollPane.
	 * 
	 *  @return the array of TableScrollPane.
	 */
	public TableScrollPane[] getTableScrollPanes() {
	}

	/**
	 *  Gets the table customizer. It will use when create the tables used by this TableSplitPane.
	 * 
	 *  @return the table customizer.
	 */
	public TableCustomizer getTableCustomizer() {
	}

	/**
	 *  Sets the table customizer. It will use when create the tables used by this TableSplitPane.
	 * 
	 *  @param tableCustomizer the new table customizer.
	 */
	public void setTableCustomizer(TableCustomizer tableCustomizer) {
	}

	/**
	 *  Gets the table customizer for the designated table. It will use when create the tables with the same table
	 *  index.
	 * 
	 *  @param tableIndex the table index
	 *  @return the table customizer.
	 */
	@java.lang.SuppressWarnings("UnusedParameters")
	public TableCustomizer getTableCustomizer(int tableIndex) {
	}

	/**
	 *  Returns the index of the first selected row, -1 if no row is selected.
	 * 
	 *  @return the index of the first selected row
	 *  @since 3.1.1
	 */
	public int getSelectedRow() {
	}

	/**
	 *  Returns the index of the first selected column, -1 if no column is selected.
	 * 
	 *  @return the index of the first selected column
	 *  @since 3.1.1
	 */
	public int getSelectedColumn() {
	}

	/**
	 *  Returns the indices of all selected rows.
	 * 
	 *  @return an array of integers containing the indices of all selected rows, or an empty array if no row is selected
	 *  @see #getSelectedRow
	 *  @since 3.1.1
	 */
	public int[] getSelectedRows() {
	}

	/**
	 *  Returns the indices of all selected columns.
	 * 
	 *  @return an array of integers containing the indices of all selected columns, or an empty array if no column is
	 *  selected
	 *  @see #getSelectedColumn
	 *  @since 3.1.1
	 */
	public int[] getSelectedColumns() {
	}

	/**
	 *  Convert the view column index in the entire TableScrollPane to model index.
	 * 
	 *  @param modelIndex the model column index
	 *  @return the view index
	 *  @since 3.1.1
	 */
	public int convertColumnIndexToView(int modelIndex) {
	}

	/**
	 *  Gets the total column count of TableScrollPane.
	 * 
	 *  @return the total column count of TableScrollPane.
	 *  @since 3.1.1
	 */
	public int getColumnCount() {
	}

	/**
	 *  Convert the view column index in the entire TableScrollPane to model index.
	 * 
	 *  @param viewIndex the view column index counting from 0 including row header table, main table and row footer
	 *                   table
	 *  @return the model index.
	 *  @since 3.1.1
	 */
	public int convertColumnIndexToModel(int viewIndex) {
	}

	/**
	 *  Returns the number of selected rows.
	 * 
	 *  @return the number of selected rows, 0 if no rows are selected
	 *  @since 3.1.1
	 */
	public int getSelectedRowCount() {
	}

	/**
	 *  Returns the number of selected columns.
	 * 
	 *  @return the number of selected columns, 0 if no columns are selected
	 *  @since 3.1.1
	 */
	public int getSelectedColumnCount() {
	}
}
