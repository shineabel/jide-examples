/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Index change event. So far the valid events include INDEX_CHANGING_EVENT and INDEX_CHANGED_EVENT. The event will be
 *  fired from SortableTableModel and FilterableTableModel.
 */
public class IndexChangeEvent extends java.util.EventObject {

	/**
	 *  INDEX_CHANGING_EVENT will be fired before sorting or filtering action is triggered.
	 */
	public static final int INDEX_CHANGING_EVENT = 0;

	/**
	 *  INDEX_CHANGED_EVENT will be fired after sorting or filtering action is finished.
	 */
	public static final int INDEX_CHANGED_EVENT = 1;

	/**
	 *  @param source the table model which fired this event in the very beginning
	 *  @param type   the event type
	 *  @deprecated  Please use {@link #IndexChangeEvent(Object, int, int)} instead.
	 */
	public IndexChangeEvent(Object source, int type) {
	}

	/**
	 *  Constructor of this class.
	 *  <p/>
	 *  You should always use this constructor to construct a new event.
	 *  <p/>
	 *  To improve the performance, you need try your best to make the event serial number unique and paired for
	 *  INDEX_CHANGING_EVENT and INDEX_CHANGED_EVENT. You could assign it to any positive number. Or you can try random()
	 *  like the following code example.
	 *  <code><pre>
	 *  int number = ((Double) (Math.random() * 10000)).intValue();
	 *  IndexChangeEvent e = new IndexChangeEvent(this, INDEX_CHANGING_EVENT, number);
	 *  fireThisEvent(e);
	 *  ....
	 *  IndexChangeEvent e = new IndexChangeEvent(this, INDEX_CHANGED_EVENT, number);
	 *  fireThisEvent(e);
	 *  </pre><code>
	 * 
	 *  @param source the table model which fired this event in the very beginning
	 *  @param type   the event type
	 *  @param eventSerialNumber the event serial number
	 */
	public IndexChangeEvent(Object source, int type, int eventSerialNumber) {
	}

	public IndexChangeEvent(Object source, int type, int eventSerialNumber, boolean forceProcess, boolean actualTableChanged) {
	}

	/**
	 *  Gets the event type.
	 * 
	 *  @return the event type.
	 */
	public int getType() {
	}

	/**
	 *  Gets the event serial number.
	 * 
	 *  @return the event serial number.
	 */
	public int getEventSerialNumber() {
	}

	public boolean isForceProcess() {
	}

	public boolean isActualTableChanged() {
	}

	@java.lang.Override
	public String toString() {
	}
}
