/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellRenderer for password. The default data type for password is char[].class. By default PasswordCellRenderer is
 *  registered on {@link CellRendererManager} with char[].class as data type and  EditorContext("Password") as the editor
 *  context.
 */
public class PasswordCellRenderer extends javax.swing.JPasswordField implements javax.swing.table.TableCellRenderer {

	public static final EditorContext CONTEXT;

	public PasswordCellRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}
}
