/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Interface to customize a JTable.
 */
public interface TableCustomizer {

	public void customize(javax.swing.JTable table);
}
