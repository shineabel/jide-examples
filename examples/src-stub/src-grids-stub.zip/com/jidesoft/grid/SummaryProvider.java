/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to provide summary type for table model.
 * 
 *  @since 3.6.0
 */
public interface SummaryProvider {

	/**
	 *  Returns the summary type of the column.
	 * 
	 *  @param columnIndex the column index
	 *  @return the summary type of the column.
	 */
	public int getSummaryTypeAt(int columnIndex);
}
