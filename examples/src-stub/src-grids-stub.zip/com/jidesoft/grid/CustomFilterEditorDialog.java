/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A dialog for CustomFilterEditor. It contains a CustomFilterEditor, OK and Cancel button.
 */
public class CustomFilterEditorDialog extends StandardDialog implements CustomFilterEditorContainer {

	public CustomFilterEditorDialog(javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Frame owner, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Frame owner, boolean modal, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Frame owner, String title, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Frame owner, String title, boolean modal, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Dialog owner, boolean modal, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Dialog owner, String title, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Dialog owner, String title, boolean modal, javax.swing.JComponent customFilterEditor) {
	}

	public CustomFilterEditorDialog(java.awt.Dialog owner, String title, boolean modal, java.awt.GraphicsConfiguration gc, javax.swing.JComponent customFilterEditor) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}
}
