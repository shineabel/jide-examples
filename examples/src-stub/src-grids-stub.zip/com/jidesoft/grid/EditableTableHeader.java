/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  As the name indicates, <code>EditableTableHeader</code> is an editable <code>JTableHeader</code>.
 *  <p/>
 *  Here is the code to use <code>EditableTableHeader</code>.
 *  <code><pre>
 *  JTable table = new JTable(tableModel);
 *  EditableTableHeader header = new EditableTableHeader(table.getColumnModel());
 *  table.setTableHeader(header);
 *  </pre></code>
 *  Once <code>EditableTableHeader</code> is installed on the table, user can double click on the table header to start
 *  editing. Pressing ENTER will commit editing or pressing ESCAPE to cancel editing.
 *  <p/>
 *  By default, we will use <code>TextFieldCellEditor</code> as the cell editor. You can either override {@link
 *  #createDefaultEditor()} method or call {@link #setDefaultEditor(javax.swing.table.TableCellEditor)} to set your own
 *  cell editor. Please note, if you use your own cell editor, you may need to register ENTER and ESCAPE key to allow
 *  stop or cancel cell editing.
 *  <p/>
 *  By default, all table columns will be editable. The same cell editor will be used for all columns. If you want only
 *  some of the columns editable and each one has its own cell editor, you just need to implement {@link
 *  com.jidesoft.grid.EditableColumnTableModel} interface in your table model. <code>EditableColumnTableModel</code> has
 *  methods to let you decide which column is editable and what cell editor to be used.
 */
public class EditableTableHeader extends SortableTableHeader implements javax.swing.event.CellEditorListener {

	public final int HEADER_ROW = -1;

	protected transient int _editingColumn;

	protected transient javax.swing.table.TableCellEditor _cellEditor;

	protected transient java.awt.Component _editorComp;

	protected javax.swing.table.TableCellEditor _defaultEditor;

	/**
	 *  The constructor that takes JTable
	 * 
	 *  @param table the table
	 *  @since 3.1.0
	 */
	public EditableTableHeader(javax.swing.JTable table) {
	}

	/**
	 *  Creates an <code>EditableTableHeader</code>.
	 * 
	 *  @param columnModel the column model.
	 */
	public EditableTableHeader(javax.swing.table.TableColumnModel columnModel) {
	}

	/**
	 *  Returns a string that specifies the name of the UIDelegate class that paints this component.
	 * 
	 *  @return the string "TableHeader.editableTableHeaderUIDelegate"
	 *  @since 3.1.0
	 */
	public String getUIDelegateClassID() {
	}

	public String getActualUIClassID() {
	}

	/**
	 *  Checks if rollover is enabled. If enabled, it will automatically start cell editing when mouse is moved over the
	 *  table header.
	 * 
	 *  @return true or false.
	 */
	public boolean isRolloverEnabled() {
	}

	/**
	 *  Sets rollover flag. By default, it's false. If enabled, it will automatically start cell editing when mouse is
	 *  moved over the table header.
	 * 
	 *  @param rolloverEnabled true or false.
	 */
	public void setRolloverEnabled(boolean rolloverEnabled) {
	}

	/**
	 *  Sizes the header and marks it as needing display.  Equivalent to <code>revalidate</code> followed by
	 *  <code>repaint</code>. <code>EditableTableHeader</code> overrides this method to stop cell editing first.
	 */
	@java.lang.Override
	public void resizeAndRepaint() {
	}

	/**
	 *  Stops any existing cell editing.
	 */
	public void stopEditing() {
	}

	/**
	 *  Cancels any existing cell editing.
	 */
	public void cancelEditing() {
	}

	/**
	 *  Creates a default header cell editor to be used.
	 * 
	 *  @return the default table column editor.
	 */
	protected javax.swing.table.TableCellEditor createDefaultEditor() {
	}

	/**
	 *  Sets the default editor to be used.
	 * 
	 *  @param defaultEditor the default editor
	 */
	public void setDefaultEditor(javax.swing.table.TableCellEditor defaultEditor) {
	}

	/**
	 *  Returns the default editor.
	 * 
	 *  @return the default editor
	 */
	public javax.swing.table.TableCellEditor getDefaultEditor() {
	}

	/**
	 *  Edits the column at the specified column index.
	 * 
	 *  @param columnIndex the column index to be edited.
	 *  @return true if editing starts. Otherwise false.
	 */
	public boolean editCellAt(int columnIndex) {
	}

	@java.lang.Override
	public void setDraggedColumn(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Edits the column at the specified column index.
	 * 
	 *  @param columnIndex the column index to be edited.
	 *  @param e           the event that triggers the editing.
	 *  @return true if editing starts. Otherwise false.
	 */
	public boolean editCellAt(int columnIndex, java.util.EventObject e) {
	}

	/**
	 *  Customizes the editor component based on the header style.
	 * 
	 *  @param component   the editor component
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @since 3.2.3
	 */
	protected void customizeEditorComponent(java.awt.Component component, int rowIndex, int columnIndex) {
	}

	/**
	 *  Returns true if the header cell at <code>index</code> is editable.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param columnIndex the column whose value is to be queried
	 *  @return true if the cell is editable
	 */
	public boolean isCellEditable(int columnIndex) {
	}

	/**
	 *  Gets the header cell editor for the specified column index. If the table model or any nested table model in case
	 *  of <code>TableModelWrapper</code> implement <code>EditableColumnTableModel</code> interface, it will use that
	 *  interface and call {@link EditableColumnTableModel#getColumnHeaderCellEditor(int)} to get the cell editor. If
	 *  null, we will use {@link #getDefaultEditor()}.
	 * 
	 *  @param columnIndex the column index.
	 *  @return the cell editor.
	 */
	public javax.swing.table.TableCellEditor getCellEditor(int columnIndex) {
	}

	/**
	 *  Sets the currently used cell editor.
	 * 
	 *  @param newEditor the new cell editor that is using.
	 */
	protected void setCellEditor(javax.swing.table.TableCellEditor newEditor) {
	}

	/**
	 *  Prepares the editor by querying the <code>TableColumnModel</code> for the value and selection state of the header
	 *  cell at <code>columnIndex</code>.
	 *  <p/>
	 *  <b>Note:</b> Throughout the table package, the internal implementations always use this method to prepare editors
	 *  so that this default behavior can be safely overridden by a subclass.
	 * 
	 *  @param editor      the <code>TableCellEditor</code> to set up
	 *  @param columnIndex the column of the cell to edit, where 0 is the first column
	 *  @return the <code>Component</code> being edited
	 */
	public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int columnIndex) {
	}

	/**
	 *  Returns the active header cell editor, which is {@code null} if the table header is not currently editing.
	 * 
	 *  @return the {@code TableCellEditor} that does the editing, or {@code null} if the table header is not currently
	 *          editing.
	 *  @see #getCellEditor(int)
	 */
	public javax.swing.table.TableCellEditor getCellEditor() {
	}

	/**
	 *  Returns the component that is handling the editing session. If nothing is being edited, returns null.
	 * 
	 *  @return Component handling editing session
	 */
	public java.awt.Component getEditorComponent() {
	}

	/**
	 *  Sets the <code>editingColumn</code> variable.
	 * 
	 *  @param aColumn the column of the cell to be edited
	 */
	public void setEditingColumn(int aColumn) {
	}

	/**
	 *  Returns the index of the column that contains the cell currently being edited.  If nothing is being edited,
	 *  returns -1.
	 * 
	 *  @return the index of the column that contains the cell currently being edited; returns -1 if nothing being
	 *          edited
	 */
	public int getEditingColumn() {
	}

	/**
	 *  Discards the editor object and frees the real estate it used for cell rendering.
	 */
	public void removeEditor() {
	}

	/**
	 *  Returns true if a header cell is being edited.
	 * 
	 *  @return true if the table header is editing a cell
	 */
	public boolean isEditing() {
	}

	public void editingStopped(javax.swing.event.ChangeEvent e) {
	}

	public void editingCanceled(javax.swing.event.ChangeEvent e) {
	}

	/**
	 *  Calls the <code>unconfigureEnclosingScrollPane</code> method.
	 */
	@java.lang.Override
	public void removeNotify() {
	}

	public boolean isClickToStartEditing() {
	}

	public void setClickToStartEditing(boolean clickToStartEditing) {
	}

	/**
	 *  If the editor requests focus when starts editing. Subclass can override to return false. Default is true.
	 * 
	 *  @return true or false.
	 */
	protected boolean isAutoRequestFocus() {
	}
}
