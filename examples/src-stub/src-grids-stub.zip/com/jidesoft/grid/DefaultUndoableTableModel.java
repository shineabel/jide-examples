/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default undoable TableModel that implements TableUndoableSupport over DefaultTableModel.
 * 
 *  @since 3.3.4
 */
public class DefaultUndoableTableModel extends javax.swing.table.DefaultTableModel implements TableUndoableSupport {

	public DefaultUndoableTableModel() {
	}

	public DefaultUndoableTableModel(int rowCount, int columnCount) {
	}

	public DefaultUndoableTableModel(java.util.Vector columnNames, int rowCount) {
	}

	public DefaultUndoableTableModel(Object[] columnNames, int rowCount) {
	}

	public DefaultUndoableTableModel(java.util.Vector data, java.util.Vector columnNames) {
	}

	public DefaultUndoableTableModel(Object[][] data, Object[] columnNames) {
	}

	@java.lang.Override
	public javax.swing.undo.UndoManager getUndoManager() {
	}

	@java.lang.Override
	public javax.swing.undo.UndoableEditSupport getUndoableEditSupport() {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void insertRow(int row, java.util.Vector rowData) {
	}

	@java.lang.Override
	public void removeRow(int row) {
	}

	@java.lang.Override
	public void fireTableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	public void beginCompoundEdit(boolean isUndoRedo) {
	}

	@java.lang.Override
	public void endCompoundEdit() {
	}

	public void undoableInsertRow(int row, java.util.Vector rowData) {
	}

	@java.lang.Override
	public void undoableUpdateRow(int rowIndex, java.util.Vector rowData) {
	}

	@java.lang.Override
	public void undoableRemoveRow(int row) {
	}

	@java.lang.Override
	public void undoableUpdateCell(int row, int column, Object value) {
	}
}
