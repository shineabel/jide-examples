/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to calculate summary.
 *  <p/>
 *  The SummaryCalculator works like this. Basically, clear() will be called first so that you can clear all saved
 *  information. Then addValue method will be called for each object that we will calculate the statistics, you will
 *  collect them into a List or something like that. Then getSummaryResult(int summaryType) will be called which will
 *  return the statistics of all the values in the List that you saved so far until clear is called again to clear the
 *  List.
 * 
 *  @since 3.6.0
 */
public interface SummaryCalculator {

	public static final int SUMMARY_NONE = -2;

	public static final int SUMMARY_CUSTOM = -1;

	public static final int SUMMARY_SUM = 0;

	public static final int SUMMARY_MAX = 1;

	public static final int SUMMARY_MIN = 2;

	public static final int SUMMARY_MEAN = 3;

	public static final int SUMMARY_VAR = 4;

	public static final int SUMMARY_STDDEV = 5;

	public static final int SUMMARY_COUNT = 6;

	public static final int SUMMARY_CONSTANT = 7;

	public static final int SUMMARY_RESERVED_MAX = 7;

	public static final int[] ALLOWED_SUMMARIES_ALL;

	public static final int[] ALLOWED_SUMMARIES_MAX_MIN_COUNT;

	public static final int[] ALLOWED_SUMMARIES_COUNT;

	/**
	 *  Adds a value for calculation.
	 * 
	 *  @param value the value
	 */
	public void addValue(Object value);

	/**
	 *  Clears all previous added values.
	 */
	public void clear();

	/**
	 *  Gets the number of values that have been added so far.
	 * 
	 *  @return the number of values that have been added so far.
	 */
	public long getCount();

	/**
	 *  Gets the number of summary types.
	 * 
	 *  @return the number of statistic types.
	 */
	public int getNumberOfSummaries();

	/**
	 *  Gets the summary name for the specified type.
	 * 
	 *  @param locale the current locale
	 *  @param type   the summary type
	 *  @return the summary name.
	 */
	public String getSummaryName(java.util.Locale locale, int type);

	/**
	 *  Gets the summary result for the specified type.
	 * 
	 *  @param type the summary type
	 *  @return the summary result for the specified type.
	 */
	public Object getSummaryResult(int type);

	/**
	 *  Gets the allowed summary types for a data type.
	 * 
	 *  @param type the data type.
	 *  @return the allowed summary types.
	 */
	public int[] getAllowedSummaries(Class type);

	/**
	 *  Gets the allowed summary types for a data type.
	 * 
	 *  @param type    the data type.
	 *  @param context the converter context. If the type is the same and you want it to have different summary types,
	 *                 you can use the converter context to make them different.
	 *  @return the allowed summary types.
	 */
	public int[] getAllowedSummaries(Class type, ConverterContext context);
}
