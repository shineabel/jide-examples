/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to allow user to customize for the TableHeaderPopupMenuInstaller.
 */
public interface TableHeaderPopupMenuCustomizer {

	/**
	 *  Customizes the popup menu.
	 * 
	 *  @param header         the table header
	 *  @param popup          the popup menu to be displayed
	 *  @param clickingColumn the column index clicked. -1 means invalid clicking column. However, it might be -2 or less in GroupTableHeader.
	 */
	public void customizePopupMenu(javax.swing.table.JTableHeader header, javax.swing.JPopupMenu popup, int clickingColumn);
}
