/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell editor that based on ListComboBoxCellEditor. It use EnumConverter. For example, in SwingConstants, the
 *  following values are defined.
 *  <code><pre>
 *  public static final int CENTER  = 0;
 *  public static final int TOP     = 1;
 *  public static final int LEFT    = 2;
 *  public static final int BOTTOM  = 3;
 *  public static final int RIGHT   = 4;
 *  </pre></code>
 *  When you want user to choose one of the value above from a table's cell editor, you don't want to use 0, 1, 2, 3, 4
 *  as the value in combobox as it doesn't mean anything from user point of view. You want user to be able to use
 *  meaningful names such as "Center", "Top", "Left", "Bottom", "Right". This is what EnumCellEditor can do it for you.
 *  First, you need to define a EnumConverter, then register it with ObjectConverterManager. Then define a EnumCellEditor
 *  and register with CellEditorManager. See code example below.
 *  <code><pre>
 *  EnumConverter locationConverter = new EnumConverter("Location", int.class,
 *        new Object[]{
 *            new Integer(SwingConstants.CENTER),
 *            new Integer(SwingConstants.TOP),
 *            new Integer(SwingConstants.LEFT),
 *            new Integer(SwingConstants.BOTTOM),
 *            new Integer(SwingConstants.RIGHT)
 *        },
 *        new String[]{
 *            "Center",
 *            "Top",
 *            "Left",
 *            "Bottom",
 *            "Right"
 *        }, new Integer(SwingConstants.HORIZONTAL));
 *  ObjectConverterManager.registerConverter(locationConverter.getType(), locationConverter,
 *  locationConverter.getContext());
 *  LegacyEnumCellRenderer locationCellRenderer = new LegacyEnumCellRenderer(locationConverter);
 *  CellRendererManager.registerRenderer(locationConverter.getType(), locationCellRenderer,
 *  locationCellRenderer.getContext());
 *  EnumCellEditor locationCellEditor = new LegacyEnumCellEditor(locationConverter);
 *  CellEditorManager.registerEditor(locationConverter.getType(), locationCellEditor, locationCellEditor.getContext());
 *  </pre></code>
 */
public class LegacyEnumCellEditor extends LegacyListComboBoxCellEditor {

	public LegacyEnumCellEditor(EnumConverter enumConverter) {
	}

	public EditorContext getContext() {
	}
}
