/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  @deprecated The class is moved to com.jidesoft.filter. Please update your code to use this one under
 *              com.jidesoft.filter instead.
 */
@java.lang.Deprecated
public interface Filter extends com.jidesoft.filter.Filter {
}
