/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>GroupTable</code> is a special <code>TreeTable</code> that can group rows who has the same value in certain
 *  column into a group. It is an implementation that is very similar to the table used in Microsoft Outlook Inbox
 *  table.
 *  <p/>
 *  Please be noted that, {@link #getAutoCreateColumnsFromModel()} has to be true to make the grouping/ungrouping
 *  procedure work correctly.
 */
public class GroupTable extends TreeTable {

	public GroupTable() {
	}

	public GroupTable(int numRows, int numColumns) {
	}

	public GroupTable(javax.swing.table.TableModel dm) {
	}

	public GroupTable(Object[][] rowData, Object[] columnNames) {
	}

	public GroupTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public GroupTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public GroupTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	@java.lang.Override
	public javax.swing.Icon getCollapsedIcon(int row) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	protected void handleMouseEvent(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public String getTableHeaderToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Gets the flag indicating if the special columns like count, group columns are hidable or not by
	 *  TableColumnChooserPopupMenuCustomizer.
	 * 
	 *  @return true if these columns hidable. Otherwise false.
	 *  @see #setSpecialColumnsHidable(boolean)
	 *  @since 3.4.6
	 */
	public boolean isSpecialColumnsHidable() {
	}

	/**
	 *  Sets the flag indicating if the special columns like count, group columns are hidable or not by
	 *  TableColumnChooserPopupMenuCustomizer.
	 *  <p/>
	 *  By default, the flag is true to keep the default behavior no change.
	 * 
	 *  @param specialColumnsHidable the flag
	 *  @since 3.4.6
	 */
	public void setSpecialColumnsHidable(boolean specialColumnsHidable) {
	}
}
