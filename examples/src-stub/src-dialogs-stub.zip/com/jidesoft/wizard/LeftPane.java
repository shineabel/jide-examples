/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  Base class for any pane can be displayed in left pane of wizard.
 */
public class LeftPane extends javax.swing.JPanel {

	public LeftPane() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}
}
