/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  <tt>AbstractWizardPage</tt> is the base class for wizard page. It extends <tt>AbstractDialogPage</tt>. In addition,
 *  it has two more abstract methods. <ul> <li> <tt>abstract public JComponent createWizardContent()</tt> <li>
 *  <tt>abstract public void setupWizardButtons()</tt> </ul> It only has several methods which you can override to get
 *  certain features. <ul> <li> <tt>boolean showBannerPane()</tt> <li> <tt>int getLeftPaneItems()</tt> <li> <tt>Image
 *  getGraphic()</tt> <li> <tt>java.util.List getSteps() </tt> <li> <tt>int getSelectedStepIndex()</tt> </ul>
 */
public abstract class AbstractWizardPage extends AbstractDialogPage {

	/**
	 *  Do not show left pane.
	 */
	public static final int LEFTPANE_NONE = 0;

	/**
	 *  Show left pane but with nothing in it.
	 */
	public static final int LEFTPANE_EMPTY = 1;

	/**
	 *  Show an image on left pane.
	 */
	public static final int LEFTPANE_GRAPHIC = 2;

	/**
	 *  Show steps on left pane.
	 */
	public static final int LEFTPANE_STEPS = 4;

	/**
	 *  Show help on left pane.
	 */
	public static final int LEFTPANE_HELP = 8;

	/**
	 *  Show any customized content on left pane.
	 */
	public static final int LEFTPANE_CUSTOM = 16;

	protected javax.swing.JComponent _wizardContent;

	/**
	 *  Creates a wizard page with title.
	 * 
	 *  @param title the title of the page. It will be displayed in banner (in Wizard 97 standard) or top of the content
	 *               page above the separate line (in Java L&F standard)
	 */
	public AbstractWizardPage(String title) {
	}

	/**
	 *  Creates a wizard page with title and description.
	 * 
	 *  @param title       the title of the page. It will be displayed in banner (in Wizard 97 standard) or top of the
	 *                     content page above the separate line (in Java L&F standard)
	 *  @param description the description of the page. It will be displayed in banner (in Wizard 97 standard) or top of
	 *                     the content page below the separate line (in Java L&F standard)
	 */
	public AbstractWizardPage(String title, String description) {
	}

	/**
	 *  Creates a wizard page with title and icon.
	 * 
	 *  @param title the title of the page. It will be displayed in banner (in Wizard 97 standard) or top of the content
	 *               page above the separate line (in Java L&F standard)
	 *  @param icon  the icon of the page. It will be displayed in banner (in Wizard 97 standard)
	 */
	public AbstractWizardPage(String title, javax.swing.Icon icon) {
	}

	/**
	 *  Creates a wizard page with title, description and icon.
	 * 
	 *  @param title       the title of the page. It will be displayed in banner (in Wizard 97 standard) or top of the
	 *                     content page above the separate line (in Java L&F standard)
	 *  @param description the description of the page. It will be displayed in banner (in Wizard 97 standard) or top of
	 *                     the content page below the separate line (in Java L&F standard)
	 *  @param icon        the icon of the page. It will be displayed in banner (in Wizard 97 standard)
	 */
	public AbstractWizardPage(String title, String description, javax.swing.Icon icon) {
	}

	/**
	 *  Gets the owner of this page. When this page is added to PageList and set to a wizard dialog, getOwner will return
	 *  the wizard dialog. Or it will return null since it hasn't be set.
	 * 
	 *  @return the wizard dialog which this page is added to
	 */
	public WizardDialogPane getOwner() {
	}

	/**
	 *  Subclass should implement this method to creates content of a wizard page.
	 * 
	 *  @return wizard content component
	 */
	public abstract javax.swing.JComponent createWizardContent() {
	}

	/**
	 *  Subclass should implement this method to setup the buttons. All you need to do when implements this method is to
	 *  fireButtonEvent.
	 */
	public abstract void setupWizardButtons() {
	}

	/**
	 *  Retrieves the wizard content. This will return the wizard content created by createWizardContent(). It will
	 *  return null if the wizard page is not visible because of lazy loading.
	 * 
	 *  @return the wizard content.
	 */
	public javax.swing.JComponent getWizardContent() {
	}

	/**
	 *  Subclass can implement this method to decide if the banner panel should be visible when this page is displayed in
	 *  wizard.
	 *  <p/>
	 *  By default, it will return true in Wizard 97 for interior pages and false for Java L&F standard wizard.
	 * 
	 *  @return true if banner panel should be visible. False other wise.
	 */
	public boolean showBannerPane() {
	}

	/**
	 *  Initialize the wizard page. By default, it will create wizard content and put into center of a JPanel. The JPanel
	 *  will have the border read from UIDefaults "Wizard.pageBorder".
	 *  <p/>
	 *  In Java L&F wizard standard, a page header will be added to the north of the JPanel to show the title and
	 *  description of this page.
	 */
	public void lazyInitialize() {
	}

	/**
	 *  Updates the banner panel based on current page. Banner panel is used to display the title, subtitle or icon of
	 *  current page. If you use the default banner panel we provided, all these are done automatically. However if you
	 *  provide your own banner panel and didn't use BannerPanel as the base class, you need to override this method to
	 *  update title, subtitle, or icon by yourself.
	 * 
	 *  @param headerPanel the header panel
	 *  @param page        the dialog page
	 */
	protected void updateHeaderPanel(javax.swing.JComponent headerPanel, AbstractDialogPage page) {
	}

	/**
	 *  Gets the value from UIDefaults with key "Wizard.thinPageBorder". According to Wizard 97 standard, a page can have
	 *  two different margin. One is wider which is can be get using getContentThickBorder(). The other is thinner which
	 *  can be get using this method.
	 * 
	 *  @return the border from UIDefaults with key "Wizard.thinPageBorder".
	 */
	public javax.swing.border.Border getContentThinBorder() {
	}

	/**
	 *  Gets the value from UIDefaults with key "Wizard.thickPageBorder". According to Wizard 97 standard, a page can
	 *  have two different margin. One is thinner which is can be get using getContentThinBorder(). The other is wider
	 *  which can be get using this method.
	 * 
	 *  @return the border from UIDefaults with key "Wizard.thickPageBorder".
	 */
	public javax.swing.border.Border getContentThickBorder() {
	}

	/**
	 *  Gets what items to be shown on left pane. Subclass can override to return the value it wants. It's a bitwise OR
	 *  of LEFTPANE_XXX but not all combinations are valid. Valid combinations are
	 *  <p/>
	 *  <ul> <li>LEFTPANE_NONE: display nothing in left pane. <li>LEFTPANE_GRAPHICS: display a graphic in left pane. You
	 *  can set default graphic for the whole wizard using setDefaultGraphic. Or you can override getGraphic() of each
	 *  page to return whatever graphic you want. <li>LEFTPANE_STEPS: display a list of steps. By default, it will be a
	 *  list of titles of all pages. You can override getSteps() and getSelectedStepIndex() to create your customized
	 *  list of steps. <li>LEFTPANE_HELP: display help information. It should contain the content sensitive help of the
	 *  focused component in the wizard page. Call setHelpText() to set the new help text when focus changes
	 *  <li>LEFTPANE_STEPS | LEFTPANE_HELP: display both steps and help in tabbed pane. </ul>
	 *  <p/>
	 *  <p/>
	 *  By default, it will return LEFTPANE_STEPS in Java L&F standard wizard and LEFTPANE_NONE in Wizard 97 standard.
	 * 
	 *  @return what to show on left pane.
	 */
	public int getLeftPaneItems() {
	}

	/**
	 *  Sets what to show in left pane.
	 * 
	 *  @param leftPaneItems the left pane item bitmap
	 */
	public void setLeftPaneItems(int leftPaneItems) {
	}

	/**
	 *  Gets the steps to be show in step pane. This method will be called by WizardDialog only when leftPaneItem's
	 *  LEFTPANE_STEPS bit is on.
	 *  <p/>
	 *  By default, it will return the pages title as java.util.List.
	 * 
	 *  @return the steps as java.util.List.
	 */
	public java.util.List getSteps() {
	}

	/**
	 *  Gets the selected step index.
	 * 
	 *  @return the selected step index.
	 */
	public int getSelectedStepIndex() {
	}

	/**
	 *  Sets the help text. It will only have effect when getLeftPaneItems() return a value when LEFTPANE_HELP bit is
	 *  on.
	 * 
	 *  @param text new help text
	 */
	public void setHelpText(String text) {
	}

	/**
	 *  Gets the help text.
	 * 
	 *  @return current help text.
	 */
	public String getHelpText() {
	}

	/**
	 *  Gets the graphic that will be displayed on the left pane. It Subclass can override this method to return any
	 *  graphic. It is only used when getLeftPaneItems() == LEFTPANE_GRAPHIC
	 * 
	 *  @return the graphic that will be displayed in left pane.
	 */
	public java.awt.Image getGraphic() {
	}

	/**
	 *  Gets the component that will be displayed on the left pane. It Subclass can override this method to return any
	 *  JComponen t. However it will only have effect when getLeftPaneItems == LEFTPANE_CUSTOM.
	 * 
	 *  @return the left pane.
	 */
	public javax.swing.JComponent getCustomLeftPane() {
	}
}
