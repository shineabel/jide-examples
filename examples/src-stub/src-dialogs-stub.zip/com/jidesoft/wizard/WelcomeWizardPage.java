/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  WelcomeWizardPage is a pre-build wizard page to display welcome information.
 *  It usually has graphic in left pane.
 */
public class WelcomeWizardPage extends GraphicWizardPage {

	/**
	 *  Creates a WelcomeWizardPage with title.
	 * 
	 *  @param title
	 */
	public WelcomeWizardPage(String title) {
	}

	/**
	 *  Creates a WelcomeWizardPage with title and description.
	 * 
	 *  @param title
	 *  @param description
	 */
	public WelcomeWizardPage(String title, String description) {
	}

	@java.lang.Override
	public void setupWizardButtons() {
	}
}
