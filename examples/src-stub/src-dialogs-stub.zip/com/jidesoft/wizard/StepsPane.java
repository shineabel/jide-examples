/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  A base class for steps pane.
 */
public abstract class StepsPane extends GraphicLeftPane {

	protected StepsPane() {
	}

	protected StepsPane(java.awt.Image image) {
	}

	public abstract void setPageList(PageList list) {
	}

	public abstract void setSelectedPage(String title) {
	}

	public abstract void setSelectedPage(String title, boolean fireEvent) {
	}

	public abstract void setSelectedIndex(int index) {
	}

	public abstract void setSelectedIndex(int index, boolean fireEvent) {
	}

	public abstract boolean isNavigable() {
	}

	public abstract void setNavigable(boolean navigable) {
	}

	public abstract void setWizardDialogPane(WizardDialogPane pane) {
	}

	public abstract WizardDialogPane getWizardDialogPane() {
	}
}
