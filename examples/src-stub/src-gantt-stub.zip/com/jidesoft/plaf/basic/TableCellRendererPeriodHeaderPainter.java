package com.jidesoft.plaf.basic;


public class TableCellRendererPeriodHeaderPainter extends AbstractPeriodPainter implements com.jidesoft.plaf.PeriodHeaderPainter, javax.swing.plaf.UIResource {

	public TableCellRendererPeriodHeaderPainter() {
	}

	protected javax.swing.JTable getTable(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	protected javax.swing.table.TableCellRenderer getTableCellRenderer(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	public void paintPeriodHeaders(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics graphics) {
	}

	@java.lang.Override
	protected void paintPeriodInterval(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics2D graphics, com.jidesoft.scale.Period period, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	protected void paintCell(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics2D g, com.jidesoft.scale.Period period, com.jidesoft.scale.PeriodConverter periodConverter, javax.swing.table.TableCellRenderer renderer, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	protected java.awt.Component createRendererComponent(com.jidesoft.scale.ScaleArea scaleArea, javax.swing.table.TableCellRenderer renderer, com.jidesoft.scale.PeriodConverter periodConverter, com.jidesoft.scale.Period period, Object startInstant, Object endInstant) {
	}

	@java.lang.SuppressWarnings("unused")
	protected void releaseRenderer(com.jidesoft.scale.ScaleArea scaleArea, com.jidesoft.scale.PeriodConverter periodConverter, Object startInstant, Object endInstant, java.awt.Component rendererComponent) {
	}

	@java.lang.SuppressWarnings("unused")
	protected void prepareRenderer(com.jidesoft.scale.ScaleArea scaleArea, com.jidesoft.scale.PeriodConverter periodConverter, Object startInstant, Object endInstant, java.awt.Component rendererComponent) {
	}
}
