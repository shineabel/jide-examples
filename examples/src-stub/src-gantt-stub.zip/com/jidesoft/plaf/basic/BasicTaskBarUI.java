package com.jidesoft.plaf.basic;


public class BasicTaskBarUI extends com.jidesoft.plaf.TaskBarUI {

	public BasicTaskBarUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	/**
	 *  @param taskBar The TaskBar to install this UI for.
	 */
	protected void installDefaults(com.jidesoft.gantt.TaskBar taskBar) {
	}

	/**
	 *  @param taskBar The TaskBar to uninstall this UI for.
	 */
	protected void uninstallDefaults(com.jidesoft.gantt.TaskBar taskBar) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
