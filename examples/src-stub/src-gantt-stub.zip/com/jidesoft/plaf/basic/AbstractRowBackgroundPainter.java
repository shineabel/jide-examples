package com.jidesoft.plaf.basic;


/**
 *  The row background painter class for GanttChart.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 *  @since 3.4.2
 */
public abstract class AbstractRowBackgroundPainter implements com.jidesoft.gantt.PeriodBackgroundPainter {

	public AbstractRowBackgroundPainter() {
	}

	@java.lang.Override
	public void paintPeriodBackground(com.jidesoft.gantt.GanttChart ganttChart, java.awt.Graphics2D g, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	public abstract void paintRowBackground(com.jidesoft.gantt.GanttChart ganttChart, java.awt.Graphics2D g, int row) {
	}

	@java.lang.Override
	public com.jidesoft.scale.Period getPeriod() {
	}
}
