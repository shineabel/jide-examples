package com.jidesoft.plaf.basic;


/**
 *  The painter class to paint the relation between entries.
 */
public class BasicGanttEntryRelationPainter implements com.jidesoft.plaf.GanttEntryRelationPainter {

	/**
	 *  The constructor.
	 * 
	 *  @param width the width
	 */
	public BasicGanttEntryRelationPainter(int width) {
	}

	/**
	 *  The constructor.
	 * 
	 *  @param width         the width
	 *  @param startShape    the start shape
	 *  @param endShape      the end shape
	 *  @param entryPadding  the entry padding
	 */
	public BasicGanttEntryRelationPainter(int width, java.awt.Shape startShape, java.awt.Shape endShape, java.awt.Insets entryPadding) {
	}

	public void paintRelation(java.awt.Graphics graphics, com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntryRelation relation, boolean selected, boolean focused) {
	}

	/**
	 *  Paints the line.
	 * 
	 *  @param graphics      the Graphics2D instance
	 *  @param path          the shape
	 *  @param valid         if the line is valid
	 *  @param validStroke   the valid stroke
	 *  @param validPaint    the valid paint
	 *  @param invalidStroke the invalid stroke
	 *  @param invalidPaint  the invalid paint
	 */
	protected void paintLine(java.awt.Graphics2D graphics, java.awt.Shape path, boolean valid, java.awt.Stroke validStroke, java.awt.Paint validPaint, java.awt.Stroke invalidStroke, java.awt.Paint invalidPaint) {
	}

	/**
	 *  Checks if the relation is valid.
	 * 
	 *  @param ganttChart the gantt chart
	 *  @param relation   the relation
	 *  @return true if the relation is valid. Otherwise false.
	 */
	protected boolean isRelationValid(com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntryRelation relation) {
	}

	/**
	 *  Checks if the range is valid.
	 * 
	 *  @param range the range
	 *  @return true if the range is valid. Otherwise false.
	 */
	protected boolean checkValidRange(<any> range) {
	}

	/**
	 *  Gets the index of the entry.
	 * 
	 *  @param ganttChart the gantt chart
	 *  @param entry      the gantt entry
	 *  @return the index.
	 */
	@java.lang.SuppressWarnings("unchecked")
	protected int getIndexOf(com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntry entry) {
	}

	/**
	 *  Paints the shape.
	 * 
	 *  @param graphics           the Graphics2D instance
	 *  @param entry              the gantt entry
	 *  @param attachPoint        the attach point
	 *  @param shape              the shape
	 *  @param shapeOutlineStroke the shape outline stroke
	 *  @param shapeOutlinePaint  the shape outline paint
	 *  @param shapeFillPaint     the shape fill paint
	 */
	@java.lang.SuppressWarnings("unused")
	protected void paintShape(java.awt.Graphics2D graphics, com.jidesoft.gantt.GanttChart entry, java.awt.geom.Point2D attachPoint, java.awt.Shape shape, java.awt.Stroke shapeOutlineStroke, java.awt.Paint shapeOutlinePaint, java.awt.Paint shapeFillPaint) {
	}

	/**
	 *  Transforms shape.
	 * 
	 *  @param g2d      the Graphics2D instance
	 *  @param entry    the gantt entry
	 *  @param shape    the shape
	 *  @param forwards the forward/backward flag
	 *  @return the transformed shape
	 */
	@java.lang.SuppressWarnings("unused")
	protected java.awt.Shape transformShape(java.awt.Graphics2D g2d, com.jidesoft.gantt.GanttChart entry, java.awt.Shape shape, boolean forwards) {
	}

	/**
	 *  Gets the end point.
	 * 
	 *  @param g2d           the Graphics2D instance
	 *  @param ganttChart    the gantt chart
	 *  @param attachPoint   the attach point
	 *  @param fromStart     the from start/end flag
	 *  @param width         the width
	 *  @return the end point.
	 */
	@java.lang.SuppressWarnings("unused")
	protected java.awt.geom.Point2D getEndPoint(java.awt.Graphics2D g2d, com.jidesoft.gantt.GanttChart ganttChart, java.awt.geom.Point2D attachPoint, boolean fromStart, double width) {
	}

	/**
	 *  Gets the boundary point for the row.
	 * 
	 *  @param g2d           the Graphics2D instance
	 *  @param ganttChart    the gantt chart
	 *  @param fromEntryRect the from entry rectangle
	 *  @param fromRow       the from row
	 *  @param fromPoint     the end point of relation line attached to the entry
	 *  @param toEntryRect   the to entry rectangle
	 *  @param toRow         the to row
	 *  @param toPoint       the end point of relation line attached to the opposite entry
	 *  @param type          the relation type
	 *  @param forwards      if the row boundary point is to the right of the from attach point
	 *  @return The point to which the relation line end point and opposite entry boundary point should be connected.
	 */
	@java.lang.SuppressWarnings("unused")
	protected java.awt.geom.Point2D getRowBoundaryPoint(java.awt.Graphics2D g2d, com.jidesoft.gantt.GanttChart ganttChart, java.awt.Rectangle fromEntryRect, int fromRow, java.awt.geom.Point2D fromPoint, java.awt.Rectangle toEntryRect, int toRow, java.awt.geom.Point2D toPoint, int type, boolean forwards) {
	}

	/**
	 *  Gets the attach point.
	 * 
	 *  @param graphics     the Graphics2D instance
	 *  @param ganttChart   the gantt chart
	 *  @param entryRect    the gantt entry
	 *  @param row          the row
	 *  @param start        the from start/end flag
	 *  @return the attach point.
	 */
	@java.lang.SuppressWarnings("unused")
	protected java.awt.geom.Point2D getAttachPoint(java.awt.Graphics2D graphics, com.jidesoft.gantt.GanttChart ganttChart, java.awt.Rectangle entryRect, int row, boolean start) {
	}

	/**
	 *  Sets the flag indicating if the relation should connect to the parent.
	 * 
	 *  @param connectToParent the flag
	 */
	public void setConnectToParent(boolean connectToParent) {
	}

	/**
	 *  Gets the flag indicating if the relation should connect to the parent.
	 * 
	 *  @return true if should connect. Otherwise false.
	 */
	public boolean isConnectToParent() {
	}

	/**
	 *  Gets the invisible stroke.
	 * 
	 *  @return the invisible stroke.
	 */
	public java.awt.Stroke getInvisibleStroke() {
	}

	/**
	 *  Sets the invisible stroke.
	 * 
	 *  @param invisibleStroke the invisible stroke
	 */
	public void setInvisibleStroke(java.awt.Stroke invisibleStroke) {
	}

	/**
	 *  Gets the start shape.
	 * 
	 *  @return the start shape.
	 */
	public java.awt.Shape getStartShape() {
	}

	/**
	 *  Sets the start shape.
	 * 
	 *  @param startShape the start shape
	 *  @since 3.3.7
	 */
	public void setStartShape(java.awt.Shape startShape) {
	}

	/**
	 *  Gets the end shape.
	 * 
	 *  @return the end shape.
	 */
	public java.awt.Shape getEndShape() {
	}

	/**
	 *  Sets the end shape.
	 * 
	 *  @param endShape the end shape
	 *  @since 3.3.7
	 */
	public void setEndShape(java.awt.Shape endShape) {
	}

	/**
	 *  Gets the width.
	 * 
	 *  @return the width.
	 */
	public int getWidth() {
	}

	/**
	 *  Sets the width.
	 * 
	 *  @param width width
	 *  @since 3.3.7
	 */
	public void setWidth(int width) {
	}

	/**
	 *  Gets the line stroke.
	 * 
	 *  @return the line stroke.
	 */
	public java.awt.Stroke getLineStroke() {
	}

	/**
	 *  Sets the line stroke.
	 * 
	 *  @param lineStroke line stroke
	 *  @since 3.3.7
	 */
	public void setLineStroke(java.awt.Stroke lineStroke) {
	}

	/**
	 *  Gets the line paint.
	 * 
	 *  @return the line paint.
	 */
	public java.awt.Paint getLinePaint() {
	}

	/**
	 *  Sets the line paint.
	 * 
	 *  @param linePaint the line paint
	 *  @since 3.3.7
	 */
	public void setLinePaint(java.awt.Paint linePaint) {
	}

	/**
	 *  Gets the invalid line paint.
	 * 
	 *  @return the invalid line paint.
	 */
	public java.awt.Paint getInvalidLinePaint() {
	}

	/**
	 *  Sets the invalid line paint.
	 * 
	 *  @param invalidLinePaint the invalid line paint
	 *  @since 3.3.7
	 */
	public void setInvalidLinePaint(java.awt.Paint invalidLinePaint) {
	}

	/**
	 *  Gets the invalid line stroke.
	 * 
	 *  @return the invalid line stroke.
	 */
	public java.awt.Stroke getInvalidLineStroke() {
	}

	/**
	 *  Sets the invalid line stroke.
	 * 
	 *  @param invalidLineStroke the invalid line stroke
	 *  @since 3.3.7
	 */
	public void setInvalidLineStroke(java.awt.Stroke invalidLineStroke) {
	}

	/**
	 *  Gets the start shape stroke.
	 * 
	 *  @return the start shape stroke.
	 */
	public java.awt.Stroke getStartShapeStroke() {
	}

	/**
	 *  Sets the start shape stroke.
	 * 
	 *  @param startShapeStroke the start shape stroke
	 *  @since 3.3.7
	 */
	public void setStartShapeStroke(java.awt.Stroke startShapeStroke) {
	}

	/**
	 *  Gets the start shape outline paint.
	 * 
	 *  @return the start shape outline paint.
	 */
	public java.awt.Paint getStartShapeOutlinePaint() {
	}

	/**
	 *  Sets the start shape outline paint.
	 * 
	 *  @param startShapeOutlinePaint the start shape outline paint
	 *  @since 3.3.7
	 */
	public void setStartShapeOutlinePaint(java.awt.Paint startShapeOutlinePaint) {
	}

	/**
	 *  Gets the start shape fill paint.
	 * 
	 *  @return the start shape fill paint.
	 */
	public java.awt.Paint getStartShapeFillPaint() {
	}

	/**
	 *  Sets the start shape fill paint.
	 * 
	 *  @param startShapeFillPaint the start shape fill paint
	 *  @since 3.3.7
	 */
	public void setStartShapeFillPaint(java.awt.Paint startShapeFillPaint) {
	}

	/**
	 *  Gets the end shape stroke.
	 * 
	 *  @return the end shape stroke.
	 */
	public java.awt.Stroke getEndShapeStroke() {
	}

	/**
	 *  Sets the end shape stroke.
	 * 
	 *  @param endShapeStroke end shape stroke
	 *  @since 3.3.7
	 */
	public void setEndShapeStroke(java.awt.Stroke endShapeStroke) {
	}

	/**
	 *  Gets the end shape outline paint.
	 * 
	 *  @return the end shape outline paint.
	 */
	public java.awt.Paint getEndShapeOutlinePaint() {
	}

	/**
	 *  Sets the end shape outline paint.
	 * 
	 *  @param endShapeOutlinePaint the end shape outline paint
	 *  @since 3.3.7
	 */
	public void setEndShapeOutlinePaint(java.awt.Paint endShapeOutlinePaint) {
	}

	/**
	 *  Gets the end shape fill paint.
	 * 
	 *  @return the end shape fill paint.
	 */
	public java.awt.Paint getEndShapeFillPaint() {
	}

	/**
	 *  Sets the end shape fill paint.
	 * 
	 *  @param endShapeFillPaint the end shape fill paint
	 *  @since 3.3.7
	 */
	public void setEndShapeFillPaint(java.awt.Paint endShapeFillPaint) {
	}

	/**
	 *  Gets the group offset.
	 * 
	 *  @return the group offset.
	 */
	public java.awt.Insets getGroupOffSet() {
	}

	/**
	 *  Sets the group offset.
	 * 
	 *  @param groupOffset the group offset
	 *  @since 3.3.7
	 */
	public void setGroupOffset(java.awt.Insets groupOffset) {
	}

	/**
	 *  Gets the milestone offset.
	 * 
	 *  @return the milestone offset.
	 */
	public java.awt.Insets getMilestoneOffSet() {
	}

	/**
	 *  Sets the milestone offset.
	 * 
	 *  @param milestoneOffset the milestone offset
	 *  @since 3.3.7
	 */
	public void setMilestoneOffset(java.awt.Insets milestoneOffset) {
	}
}
