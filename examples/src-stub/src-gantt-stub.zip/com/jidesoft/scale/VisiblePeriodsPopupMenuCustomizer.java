/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  <code>VisiblePeriodsPopupMenuCustomizer</code> works with <code>ScaleArea</code> and provides showing/hiding period
 *  related menu items to the ScaleArea's context menu.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public class VisiblePeriodsPopupMenuCustomizer implements ScaleAreaPopupMenuCustomizer, java.awt.event.ActionListener {

	public static final String RESOURCE_PREFIX = "ScaleArea.MenuItem.";

	public static final String PERIOD_TIER_UP = "periodTierUp";

	public static final String PERIOD_TIER_DOWN = "periodTierDown";

	public static final String HIDE_PERIOD_TIER = "hidePeriodTier";

	/**
	 *  This name should be appended with the index of the period in the {@link com.jidesoft.scale.ScaleModel#getPeriods()}.
	 */
	public static final String TOGGLE_PERIOD_VISIBILITY_TIER_X = "togglePeriodTier";

	public VisiblePeriodsPopupMenuCustomizer() {
	}

	public void customizePopup(javax.swing.JPopupMenu menu, ScaleArea scaleArea, Period clickedPeriod, Object clickedInstant) {
	}

	protected String getResourceString(String key) {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}
}
