/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultGanttModel</code> is an implementation of <code>GanttModel</code> that uses a
 *  <code>TreeTableModel</code> to store the gantt entries. For the GanttEntryRelationModel, it uses
 *  <code>DefaultGanttEntryRelationModel</code>. For the <code>ScaleMode</code>, user can set it using setter.
 *  <p/>
 *  The range of the <code>DefaultGanttModel</code> is calculated automatically by default based on its gantt entries.
 *  However user can call {@link #setAutoUpdateRange(boolean)} and set it to false if he/she wants to set the range
 *  manually.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 *  @param <S> The type of the GanttEntry in the model.
 */
public class DefaultGanttModel extends AbstractGanttModel implements java.beans.PropertyChangeListener {

	public DefaultGanttModel() {
	}

	public DefaultGanttModel(<any> treeTableModel) {
	}

	protected DefaultGanttEntryRelationModel createGanttEntryRelationModel() {
	}

	public <any> getTreeTableModel() {
	}

	public void setTreeTableModel(<any> treeTableModel) {
	}

	/**
	 *  Checks if the column index is a range column such as range start or range end or any other column that will
	 *  affect the calculation of the range.
	 * 
	 *  @param columnIndex the column index.
	 *  @return true if the specified column index is related to the range.
	 */
	protected boolean isRangeColumn(int columnIndex) {
	}

	/**
	 *  Updates the Range to the union of all the root child GanttEntries.
	 * 
	 *  @param e the TableModelEvent
	 */
	protected void updateRange(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Whether the GanttModel Range should be automatically updated to fit the GanttEntry Ranges. Defaults to true.
	 * 
	 *  @param autoUpdateRanged true to automatically update the {@link Range}.
	 */
	public void setAutoUpdateRange(boolean autoUpdateRanged) {
	}

	public boolean isAutoUpdateRange() {
	}

	public <any> getRange() {
	}

	public void setRange(<any> range) {
	}

	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	public com.jidesoft.scale.ScaleModel getScaleModel() {
	}

	public void setScaleModel(com.jidesoft.scale.ScaleModel scaleModel) {
	}

	public GanttEntryRelationModel getGanttEntryRelationModel() {
	}

	public void setGanttEntryRelationModel(GanttEntryRelationModel ganttEntryRelationModel) {
	}

	public void addGanttEntry(GanttEntry entry) {
	}

	public void removeGanttEntry(GanttEntry entry) {
	}

	/**
	 *  NOTE: This method will do nothing if the current Range is null!
	 * 
	 *  @param targetRange the target range.
	 *  @param parent      the parent
	 *  @param child       the child
	 *  @param <T>         The type of the bases unit of the scale, for example Date or Integer.
	 */
	public static void union(<any> targetRange, Expandable parent, GanttEntry child) {
	}

	/**
	 *  NOTE: This method will do nothing if the current Range is null!
	 * 
	 *  @param targetRange the target range
	 *  @param parent      the parent
	 *  @param <T>         The type of the bases unit of the scale, for example Date or Integer.
	 */
	@java.lang.SuppressWarnings("unchecked")
	public static void union(<any> targetRange, Expandable parent) {
	}
}
