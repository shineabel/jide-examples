/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttEntryRelationEvent</code> is used to notify listeners that a <code>GanttEntryRelationModel</code> has
 *  changed. The model event describes which relation and the type of the change which could be ADD or REMOVE.
 */
public class GanttEntryRelationEvent extends java.util.EventObject {

	public static final int ADD = 1;

	public static final int REMOVE = 2;

	protected int _type;

	protected GanttEntryRelation _relation;

	public GanttEntryRelationEvent(Object source) {
	}

	/**
	 *  Creates a GanttEntryRelationEvent. The only place this constructor is called is when
	 *  fireGanttEntryRelationChanged method is called in AbstractGanttEntryRelationModel. It means the gantt entry
	 *  relation changed so much that it'd better if the listeners get the relations from the model from scratch. The
	 *  type of the event in this case is undefined.
	 * 
	 *  @param source the source which is GanttEntryRelationModel.
	 */
	public GanttEntryRelationEvent(GanttEntryRelationModel source) {
	}

	/**
	 *  Creates a GanttEntryRelationEvent. The only place this constructor is called is when
	 *  fireGanttEntryRelationCleared method is called in AbstractGanttEntryRelationModel. The type is REMOVE in this
	 *  case.
	 * 
	 *  @param source the source which is GanttEntryRelationModel.
	 *  @param type   the type of the event.
	 */
	public GanttEntryRelationEvent(GanttEntryRelationModel source, int type) {
	}

	/**
	 *  Creates a GanttEntryRelationEvent.
	 * 
	 *  @param source   the source which is GanttEntryRelationModel.
	 *  @param type     the type of the event.
	 *  @param relation the relation that is added or removed.
	 */
	public GanttEntryRelationEvent(GanttEntryRelationModel source, int type, GanttEntryRelation relation) {
	}

	/**
	 *  Gets the relation that is changed in this event. It could be null which means all relations are changed. For
	 *  examples, all relations are cleared from the model.
	 * 
	 *  @return the relation that is changed in this event.
	 */
	public GanttEntryRelation getGanttEntryRelation() {
	}

	/**
	 *  Returns the type of event - one of: ADD, REMOVE.
	 * 
	 *  @return the type of the event.
	 */
	public int getType() {
	}
}
