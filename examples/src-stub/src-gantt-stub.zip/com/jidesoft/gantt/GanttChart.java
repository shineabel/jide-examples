/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 *  @param <S> The type of the GanttEnty in the model.
 */
public class GanttChart extends javax.swing.JComponent implements javax.swing.Scrollable, GanttModelListener, GanttEntryRelationListener, javax.swing.event.ListSelectionListener, java.beans.PropertyChangeListener {

	public static final String PROPERTY_SCALE_AREA = "scaleArea";

	public static final String PROPERTY_GANTT_MODEL = "ganttModel";

	public static final String PROPERTY_EDITABLE = "editable";

	public static final String PROPERTY_VIEW_MODE = "viewMode";

	public static final String PROPERTY_ROW_HEIGHT = "rowHeight";

	public static final String PROPERTY_ROW_MARGIN = "rowMargin";

	public static final String PROPERTY_GRID_COLOR = "gridColor";

	public static final String PROPERTY_SHOW_GRID = "showGrid";

	public static final String PROPERTY_LABEL_POSITION = "labelPosition";

	public static final String PROPERTY_LABEL_ENTRY_GAP = "labelEntryGap";

	public static final int VIEW_MODE_EDITING = 0;

	public static final int VIEW_MODE_PANNING = 1;

	public GanttChart() {
	}

	public GanttChart(GanttModel model) {
	}

	public GanttChart(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	public GanttChart(GanttModel model, com.jidesoft.scale.ScaleArea scaleArea) {
	}

	public void setScaleArea(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	public com.jidesoft.scale.ScaleArea getScaleArea() {
	}

	public GanttModel getModel() {
	}

	public boolean isEditable() {
	}

	public void setEditable(boolean editable) {
	}

	public void ganttEntryRelationChanged(GanttEntryRelationEvent e) {
	}

	public void ganttChartChanged(GanttModelEvent e) {
	}

	public void setModel(GanttModel model) {
	}

	public java.awt.Dimension getPreferredScrollableViewportSize() {
	}

	public int getScrollableBlockIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	public boolean getScrollableTracksViewportHeight() {
	}

	public boolean getScrollableTracksViewportWidth() {
	}

	public int getScrollableUnitIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	protected void setUI(com.jidesoft.plaf.GanttChartUI newUI) {
	}

	@java.lang.Override
	public String getUIClassID() {
	}

	public com.jidesoft.plaf.GanttChartUI getUI() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Calls the <code>configureEnclosingScrollPane</code> method.
	 * 
	 *  @see #configureEnclosingScrollPane
	 */
	@java.lang.Override
	public void addNotify() {
	}

	/**
	 *  If this <code>GanttChart</code> is the <code>viewportView</code> of an enclosing <code>JScrollPane</code> (the
	 *  usual situation), configure this <code>ScrollPane</code> by, amongst other things, installing the table's
	 *  <code>scaleArea</code> as the <code>columnHeaderView</code> of the scroll pane. When a <code>GanttChart</code> is
	 *  added to a <code>JScrollPane</code> in the usual way, using <code>new JScrollPane(myGanttChart)</code>,
	 *  <code>addNotify</code> is called in the <code>GanttChart</code> (when the table is added to the viewport).
	 *  <code>GanttChart</code>'s <code>addNotify</code> method in turn calls this method, which is protected so that
	 *  this default installation procedure can be overridden by a subclass.
	 * 
	 *  @see #addNotify
	 */
	protected void configureEnclosingScrollPane() {
	}

	/**
	 *  Gets the count of entries inside the gantt model.
	 * 
	 *  @return the entry count.
	 */
	public int getEntryCount() {
	}

	/**
	 *  Gets the gantt entry at the point.
	 * 
	 *  @param point the mouse point
	 * 
	 *  @return the gantt entry.
	 */
	public GanttEntry getEntryAt(java.awt.Point point) {
	}

	/**
	 *  Gets the gantt entry by index.
	 * 
	 *  @param index the index
	 * 
	 *  @return the gantt entry.
	 */
	public GanttEntry getEntryAt(int index) {
	}

	/**
	 *  Gets the gantt entry by index and sub entry index.
	 * 
	 *  @param index         the index
	 *  @param subEntryIndex the sub entry index
	 * 
	 *  @return the gantt entry.
	 */
	public GanttEntry getEntryAt(int index, int subEntryIndex) {
	}

	/**
	 *  Gets the index of gantt entry.
	 * 
	 *  @param entry the gantt entry
	 * 
	 *  @return the index of the entry inside the model. -1 if not found.
	 */
	public int getIndexOf(GanttEntry entry) {
	}

	/**
	 *  Equivalent to <code>revalidate</code> followed by <code>repaint</code>.
	 */
	protected void resizeAndRepaint() {
	}

	/**
	 *  Sets the height, in pixels, of all cells to <code>rowHeight</code>, revalidates, and repaints. The height of the
	 *  cells will be equal to the row height minus the row margin.
	 * 
	 *  @param rowHeight new row height
	 * 
	 *  @throws IllegalArgumentException if <code>rowHeight</code> is less than 1
	 */
	public void setRowHeight(int rowHeight) {
	}

	public boolean isRowHeightSet() {
	}

	/**
	 *  Returns the height of a table row, in pixels. The default row height is 16.0.
	 * 
	 *  @return the height in pixels of a table row
	 * 
	 *  @see #setRowHeight
	 */
	public int getRowHeight() {
	}

	public int getTotalRowHeight() {
	}

	/**
	 *  Sets the height for <code>row</code> to <code>rowHeight</code>, revalidates, and repaints. The height of the
	 *  cells in this row will be equal to the row height minus the row margin.
	 * 
	 *  @param row       the row whose height is being changed
	 *  @param rowHeight new row height, in pixels
	 * 
	 *  @throws IllegalArgumentException if <code>rowHeight</code> is less than 1
	 */
	public void setRowHeight(int row, int rowHeight) {
	}

	/**
	 *  Returns the height, in pixels, of the cells in <code>row</code>.
	 * 
	 *  @param row the row whose height is to be returned
	 * 
	 *  @return the height, in pixels, of the cells in the row
	 */
	public int getRowHeight(int row) {
	}

	/**
	 *  Sets the amount of empty space between cells in adjacent rows.
	 * 
	 *  @param rowMargin the number of pixels between cells in a row
	 * 
	 *  @see #getRowMargin
	 */
	public void setRowMargin(int rowMargin) {
	}

	/**
	 *  Gets the amount of empty space, in pixels, between cells. Equivalent to: <code>getIntercellSpacing().height</code>.
	 * 
	 *  @return the number of pixels between cells in a row
	 * 
	 *  @see #setRowMargin
	 */
	public int getRowMargin() {
	}

	/**
	 *  Sets the color used to draw grid lines to <code>gridColor</code> and redisplays. The default color is look and
	 *  feel dependent.
	 * 
	 *  @param gridColor the new color of the grid lines
	 * 
	 *  @throws IllegalArgumentException if <code>gridColor</code> is <code>null</code>
	 */
	public void setGridColor(java.awt.Color gridColor) {
	}

	/**
	 *  Returns the color used to draw grid lines. The default color is look and feel dependent.
	 * 
	 *  @return the color used to draw grid lines
	 * 
	 *  @see #setGridColor
	 */
	public java.awt.Color getGridColor() {
	}

	/**
	 *  Sets whether the table draws grid lines around cells. If <code>showGrid</code> is true it does; if it is false it
	 *  doesn't.
	 * 
	 *  @param showGrid true if table view should draw grid lines
	 */
	public void setShowGrid(boolean showGrid) {
	}

	public boolean isShowGrid() {
	}

	/**
	 *  If enabled, mouse editing and mouse drag selection is disabled. Instead mouse double clicks center the chart and
	 *  mouse drag pans the chart.
	 *  <p/>
	 *  Selection is still possible by clicked exactly on a GanttEntry or by holding down CTRL or SHIFT.
	 * 
	 *  @param viewMode the new view mode.
	 */
	public void setViewMode(int viewMode) {
	}

	public int getViewMode() {
	}

	/**
	 *  Returns the index of the row that <code>point</code> lies in, or -1 if the result is not in the range [0,
	 *  <code>getRowCount()</code>-1].
	 * 
	 *  @param point the location of interest
	 * 
	 *  @return the index of the row that <code>point</code> lies in, or -1 if the result is not in the range [0,
	 *          <code>getRowCount()</code>-1]
	 */
	public int rowAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Returns a rectangle for the row, clipped by the {@link Range} of the {@link GanttEntry} at that row. If there is
	 *  no entry at the row or the range of the entry is <code>null</code> or has a <code>null</code> lower or upper
	 *  boundary, <code>null</code> is returned.
	 * 
	 *  @param row the row index.
	 * 
	 *  @return Returns the entry rectangle at the row or null if there is no entry or the entry has no valid Range
	 */
	public java.awt.Rectangle getEntryRect(int row) {
	}

	public java.awt.Rectangle getEntryRect(GanttEntry entry, int row) {
	}

	public java.awt.Rectangle getRowRect(int row, boolean includingSpacing) {
	}

	/**
	 *  Automatically resizes the periods width and changes the visible periods to fit the range of the GanttModel. If
	 *  visibleRowsOnly is <code>true</code> the periods are resized to fit the union of the range of the GanttEntries of
	 *  the currently visible rows.
	 *  <p/>
	 *  If no valid range can be found (either <code>null</code> or the start or end is <code>null</code>) the periods
	 *  are changed to fit the default range of the ScaleModel.
	 * 
	 *  @param visibleRowsOnly <code>true</code> if the periods should be resized to combined range of the GanttEntries
	 *                         of the visible rows.
	 * 
	 *  @see GanttChart#zoomPeriods
	 *  @see GanttModel#getRange
	 */
	public void autoResizePeriods(boolean visibleRowsOnly) {
	}

	/**
	 *  Automatically resizes the periods width and changes the visible periods to fit the specified range.
	 * 
	 *  @param start The start of the range (not null).
	 *  @param end   The end of the range (not null).
	 */
	public void zoomPeriods(Object start, Object end) {
	}

	public void zoomInPeriods() {
	}

	public void zoomOutPeriods() {
	}

	public void zoomPeriods(double factor) {
	}

	public void scrollSpanToVisible(<any> span) {
	}

	public void scrollSpanToVisible(Object start, Object end) {
	}

	public void scrollRowToVisible(int rowIndex) {
	}

	/**
	 *  Returns an appropriate renderer for the row specified by the row index. Subclass can override this method to
	 *  return different renderer for different rows.
	 * 
	 *  @param row the row of the cell to render, where 0 is the first row
	 * 
	 *  @return the assigned renderer.
	 */
	public GanttEntryRenderer getEntryRenderer(int row) {
	}

	/**
	 *  Returns an appropriate renderer for the row specified by the row index. Subclass can override this method to
	 *  return different renderer for different rows.
	 * 
	 *  @param row    the row of the cell to render, where 0 is the first row
	 *  @param column the column index of the sub entry. -1 if there is no sub entry
	 * 
	 *  @return the assigned renderer.
	 */
	public GanttEntryRenderer getEntryRenderer(int row, int column) {
	}

	/**
	 *  Gets the default GanttEntryRenderer.
	 * 
	 *  @return the default GanttEntryRenderer.
	 */
	public GanttEntryRenderer getDefaultEntryRenderer() {
	}

	/**
	 *  Sets the default GanttEntryRenderer. Please remember to call repaint() after you change the default
	 *  GanttEntryRenderer.
	 * 
	 *  @param defaultEntryRenderer the new default GanttEntryRenderer.
	 */
	public void setDefaultEntryRenderer(GanttEntryRenderer defaultEntryRenderer) {
	}

	/**
	 *  Returns an appropriate renderer for the row specified by the row index. Subclass can override this method to
	 *  return different renderer for different rows.
	 * 
	 *  @param row the row of the cell to render, where 0 is the first row
	 * 
	 *  @return the assigned renderer.
	 */
	public GanttLabelRenderer getLabelRenderer(int row) {
	}

	/**
	 *  Returns an appropriate renderer for the row specified by the row index. Subclass can override this method to
	 *  return different renderer for different rows.
	 * 
	 *  @param row    the row of the cell to render, where 0 is the first row
	 *  @param column the column index of the sub entry. -1 if there is no sub entry
	 * 
	 *  @return the assigned renderer.
	 */
	public GanttLabelRenderer getLabelRenderer(int row, int column) {
	}

	/**
	 *  Gets the default GanttLabelRenderer.
	 * 
	 *  @return the default GanttLabelRenderer.
	 */
	public GanttLabelRenderer getDefaultLabelRenderer() {
	}

	/**
	 *  Sets the default GanttLabelRenderer. Please remember to call repaint() after you change the default
	 *  GanttLabelRenderer.
	 * 
	 *  @param defaultLabelRenderer the new default GanttLabelRenderer.
	 */
	public void setDefaultLabelRenderer(GanttLabelRenderer defaultLabelRenderer) {
	}

	/**
	 *  Gets the label position relative to the entry. It could be either SwingConstants.LEADING or
	 *  SwingConstants.TRAILING.
	 * 
	 *  @return the label position
	 */
	public int getLabelPosition() {
	}

	/**
	 *  Sets the label position. The valid values are SwingConstants.LEADING or SwingConstants.TRAILING. Please remember
	 *  to call repaint() after you change the label position.
	 * 
	 *  @param labelPosition the label position.
	 */
	public void setLabelPosition(int labelPosition) {
	}

	/**
	 *  Gets the gap between the label and the entry.
	 * 
	 *  @return the gap between the label and the entry.
	 */
	public int getLabelEntryGap() {
	}

	/**
	 *  Sets the label and the entry gap. Please remember to call repaint() after you change the gap.
	 * 
	 *  @param labelEntryGap the gap between the label and the entry.
	 */
	public void setLabelEntryGap(int labelEntryGap) {
	}

	/**
	 *  Prepares the renderer by querying the data model for the value and selection state of the cell at
	 *  <code>row</code>, <code>column</code>. Returns the component (may be a <code>Component</code> or a
	 *  <code>JComponent</code>) under the event location.
	 *  <p/>
	 *  During a printing operation, this method will configure the renderer without indicating selection or focus, to
	 *  prevent them from appearing in the printed output. To do other customizations based on whether or not the table
	 *  is being printed, you can check the value of JComponent#isPaintingForPrint(), either here or within custom
	 *  renderers.
	 * 
	 *  @param renderer the <code>TableCellRenderer</code> to prepare
	 *  @param row      the row of the cell to render, where 0 is the first row
	 *  @param insets   the insets of the component
	 * 
	 *  @return the <code>Component</code> under the event location
	 * 
	 *  @deprecated replaced by {@link #prepareRenderer(GanttEntryRenderer, int, int, java.awt.Insets)}
	 */
	@java.lang.Deprecated
	public java.awt.Component prepareRenderer(GanttEntryRenderer renderer, int row, java.awt.Insets insets) {
	}

	/**
	 *  Prepares the renderer by querying the data model for the value and selection state of the cell at
	 *  <code>row</code>, <code>column</code>. Returns the component (may be a <code>Component</code> or a
	 *  <code>JComponent</code>) under the event location.
	 *  <p/>
	 *  During a printing operation, this method will configure the renderer without indicating selection or focus, to
	 *  prevent them from appearing in the printed output. To do other customizations based on whether or not the table
	 *  is being printed, you can check the value of JComponent#isPaintingForPrint(), either here or within custom
	 *  renderers.
	 * 
	 *  @param renderer the <code>TableCellRenderer</code> to prepare
	 *  @param row      the row of the cell to render, where 0 is the first row
	 *  @param column   the column index of the sub entry. -1 if there is no sub entry
	 *  @param insets   the insets of the component
	 * 
	 *  @return the <code>Component</code> under the event location
	 */
	public java.awt.Component prepareRenderer(GanttEntryRenderer renderer, int row, int column, java.awt.Insets insets) {
	}

	/**
	 *  Prepares the renderer by querying the data model for the value and selection state of the cell at
	 *  <code>row</code>, <code>column</code>. Returns the component (may be a <code>Component</code> or a
	 *  <code>JComponent</code>) under the event location.
	 *  <p/>
	 *  During a printing operation, this method will configure the renderer without indicating selection or focus, to
	 *  prevent them from appearing in the printed output. To do other customizations based on whether or not the table
	 *  is being printed, you can check the value of JComponent#isPaintingForPrint(), either here or within custom
	 *  renderers.
	 * 
	 *  @param renderer the <code>TableCellRenderer</code> to prepare
	 *  @param row      the row of the cell to render, where 0 is the first row
	 * 
	 *  @return the <code>Component</code> under the event location
	 */
	public java.awt.Component prepareLabelRenderer(GanttLabelRenderer renderer, int row) {
	}

	/**
	 *  Prepares the renderer by querying the data model for the value and selection state of the cell at
	 *  <code>row</code>, <code>column</code>. Returns the component (may be a <code>Component</code> or a
	 *  <code>JComponent</code>) under the event location.
	 *  <p/>
	 *  During a printing operation, this method will configure the renderer without indicating selection or focus, to
	 *  prevent them from appearing in the printed output. To do other customizations based on whether or not the table
	 *  is being printed, you can check the value of JComponent#isPaintingForPrint(), either here or within custom
	 *  renderers.
	 * 
	 *  @param renderer the <code>TableCellRenderer</code> to prepare
	 *  @param row      the row of the cell to render, where 0 is the first row
	 *  @param column   the column index of the sub entry. -1 if there is no sub entry
	 * 
	 *  @return the <code>Component</code> under the event location
	 */
	public java.awt.Component prepareLabelRenderer(GanttLabelRenderer renderer, int row, int column) {
	}

	public com.jidesoft.plaf.GanttEntryRelationPainter getRelationPainter(int relationType) {
	}

	public void setRelationPainter(int relationType, com.jidesoft.plaf.GanttEntryRelationPainter painter) {
	}

	public java.util.List getPeriodBackgroundPainters() {
	}

	public void addPeriodBackgroundPainter(PeriodBackgroundPainter painter) {
	}

	/**
	 *  Adds a painter to chart to paint behind the Gantt entries.
	 *  <p>Painters paint in order of index with later painters overwriting the previous ones
	 *  if they paint in the same location (unless painting with transparent colors).
	 * 
	 *  @param index the location in the painter list
	 *  @param painter the PeriodBackgroundPainter which paints the background
	 *  @since 3.4.2
	 */
	public void addPeriodBackgroundPainter(int index, PeriodBackgroundPainter painter) {
	}

	public void removePeriodBackgroundPainter(PeriodBackgroundPainter painter) {
	}

	/**
	 *  Returns the current selection mode for the list. This is a cover method that delegates to the method of the same
	 *  name on the list's selection model.
	 * 
	 *  @return the current selection mode
	 * 
	 *  @see #setSelectionMode
	 */
	public int getSelectionMode() {
	}

	public javax.swing.ListSelectionModel getSelectionModel() {
	}

	public void setSelectionModel(javax.swing.ListSelectionModel selectionModel) {
	}

	/**
	 *  Sets the gantt chart's selection mode to allow only single selections, a single contiguous interval, or multiple
	 *  intervals.
	 *  <p/>
	 * 
	 *  @param selectionMode the new selection mode
	 */
	public void setSelectionMode(int selectionMode) {
	}

	/**
	 *  Deselects all selected entries.
	 */
	public void clearSelection() {
	}

	public void selectAll() {
	}

	/**
	 *  Selects a single cell. Does nothing if the given index is greater than or equal to the model size. This is a
	 *  convenience method that uses {@code setSelectionInterval} on the selection model. Refer to the documentation for
	 *  the selection model class being used for details on how values less than {@code 0} are handled.
	 * 
	 *  @param index the index of the cell to select
	 * 
	 *  @see ListSelectionModel#setSelectionInterval
	 */
	public void setSelectedIndex(int index) {
	}

	/**
	 *  Selects the rows from <code>index0</code> to <code>index1</code>, inclusive.
	 * 
	 *  @param index0 one end of the interval
	 *  @param index1 the other end of the interval
	 * 
	 *  @throws IllegalArgumentException if <code>index0</code> or <code>index1</code> lie outside [0,
	 *                                   <code>getRowCount()</code>-1]
	 */
	public void setSelectionInterval(int index0, int index1) {
	}

	/**
	 *  Adds the rows from <code>index0</code> to <code>index1</code>, inclusive, to the current selection.
	 * 
	 *  @param index0 one end of the interval
	 *  @param index1 the other end of the interval
	 * 
	 *  @throws IllegalArgumentException if <code>index0</code> or <code>index1</code> lie outside [0,
	 *                                   <code>getRowCount()</code>-1]
	 */
	public void addSelectionInterval(int index0, int index1) {
	}

	/**
	 *  Deselects the rows from <code>index0</code> to <code>index1</code>, inclusive.
	 * 
	 *  @param index0 one end of the interval
	 *  @param index1 the other end of the interval
	 * 
	 *  @throws IllegalArgumentException if <code>index0</code> or <code>index1</code> lie outside [0,
	 *                                   <code>getRowCount()</code>-1]
	 */
	public void removeSelectionInterval(int index0, int index1) {
	}

	/**
	 *  Returns the index of the first selected entry, -1 if no entry is selected.
	 * 
	 *  @return the index of the first selected entry
	 */
	public int getSelectedRow() {
	}

	/**
	 *  Returns the indices of all selected entries.
	 * 
	 *  @return an array of integers containing the indices of all selected entries, or an empty array if no entries is
	 *          selected
	 * 
	 *  @see #getSelectedRow
	 */
	public int[] getSelectedRows() {
	}

	/**
	 *  Returns the number of selected entries.
	 * 
	 *  @return the number of selected entries, 0 if no entries are selected
	 */
	public int getSelectedRowCount() {
	}

	/**
	 *  Returns the anchor selection index. This is a cover method that delegates to the method of the same name on the
	 *  list's selection model.
	 * 
	 *  @return the anchor selection index
	 * 
	 *  @see ListSelectionModel#getAnchorSelectionIndex
	 */
	public int getAnchorSelectionIndex() {
	}

	/**
	 *  Returns the lead selection index. This is a cover method that delegates to the method of the same name on the
	 *  list's selection model.
	 * 
	 *  @return the lead selection index
	 * 
	 *  @see ListSelectionModel#getLeadSelectionIndex
	 */
	public int getLeadSelectionIndex() {
	}

	/**
	 *  Returns the smallest selected cell index, or {@code -1} if the selection is empty. This is a cover method that
	 *  delegates to the method of the same name on the list's selection model.
	 * 
	 *  @return the smallest selected cell index, or {@code -1}
	 * 
	 *  @see ListSelectionModel#getMinSelectionIndex
	 */
	public int getMinSelectionIndex() {
	}

	/**
	 *  Returns the largest selected cell index, or {@code -1} if the selection is empty. This is a cover method that
	 *  delegates to the method of the same name on the list's selection model.
	 * 
	 *  @return the largest selected cell index
	 * 
	 *  @see ListSelectionModel#getMaxSelectionIndex
	 */
	public int getMaxSelectionIndex() {
	}

	/**
	 *  Sets the selection model's {@code valueIsAdjusting} property. When {@code true}, upcoming changes to selection
	 *  should be considered part of a single change. This property is used internally and developers typically need not
	 *  call this method. For example, when the model is being updated in response to a user drag, the value of the
	 *  property is set to {@code true} when the drag is initiated and set to {@code false} when the drag is finished.
	 *  This allows listeners to update only when a change has been finalized, rather than handling all of the
	 *  intermediate values.
	 *  <p/>
	 *  You may want to use this directly if making a series of changes that should be considered part of a single
	 *  change.
	 *  <p/>
	 *  This is a cover method that delegates to the method of the same name on the list's selection model. See the
	 *  documentation for {@link javax.swing.ListSelectionModel#setValueIsAdjusting} for more details.
	 * 
	 *  @param b the new value for the property
	 * 
	 *  @see ListSelectionModel#setValueIsAdjusting
	 *  @see javax.swing.event.ListSelectionEvent#getValueIsAdjusting
	 *  @see #getValueIsAdjusting
	 */
	public void setValueIsAdjusting(boolean b) {
	}

	/**
	 *  Returns the value of the selection model's {@code isAdjusting} property.
	 *  <p/>
	 *  This is a cover method that delegates to the method of the same name on the list's selection model.
	 * 
	 *  @return the value of the selection model's {@code isAdjusting} property.
	 * 
	 *  @see #setValueIsAdjusting
	 *  @see ListSelectionModel#getValueIsAdjusting
	 */
	public boolean getValueIsAdjusting() {
	}

	/**
	 *  Returns true if the specified index is in the valid range of entries, and the entry at that index is selected.
	 * 
	 *  @param index the entry index
	 * 
	 *  @return true if <code>row</code> is a valid index and the entry at that index is selected (where 0 is the first
	 *          entry)
	 */
	public boolean isRowSelected(int index) {
	}

	/**
	 *  Updates the selection models of the table, depending on the state of the two flags: <code>toggle</code> and
	 *  <code>extend</code>. Most changes to the selection that are the result of keyboard or mouse events received by
	 *  the UI are channeled through this method so that the behavior may be overridden by a subclass. Some UIs may need
	 *  more functionality than this method provides, such as when manipulating the lead for discontiguous selection, and
	 *  may not call into this method for some selection changes.
	 *  <p/>
	 *  This implementation uses the following conventions: <ul> <li> <code>toggle</code>: <em>false</em>,
	 *  <code>extend</code>: <em>false</em>. Clear the previous selection and ensure the new cell is selected. <li>
	 *  <code>toggle</code>: <em>false</em>, <code>extend</code>: <em>true</em>. Extend the previous selection from the
	 *  anchor to the specified cell, clearing all other selections. <li> <code>toggle</code>: <em>true</em>,
	 *  <code>extend</code>: <em>false</em>. If the specified cell is selected, deselect it. If it is not selected,
	 *  select it. <li> <code>toggle</code>: <em>true</em>, <code>extend</code>: <em>true</em>. Apply the selection state
	 *  of the anchor to all cells between it and the specified cell. </ul>
	 * 
	 *  @param rowIndex affects the selection at <code>row</code>
	 *  @param toggle   see description above
	 *  @param extend   if true, extend the current selection
	 */
	public void changeSelection(int rowIndex, boolean toggle, boolean extend) {
	}

	/**
	 *  Returns the foreground color for the rows of the selected entries.
	 * 
	 *  @return the <code>Color</code> object for the foreground property
	 * 
	 *  @see #setSelectionForeground
	 *  @see #setSelectionBackground
	 */
	public java.awt.Color getSelectionForeground() {
	}

	/**
	 *  Sets the foreground color for the rows of the selected entries.
	 *  <p/>
	 *  The default value of this property is defined by the look and feel implementation.
	 *  <p/>
	 *  This is a <a href="http://java.sun.com/docs/books/tutorial/javabeans/whatis/beanDefinition.html">JavaBeans</a>
	 *  bound property.
	 * 
	 *  @param selectionForeground the <code>Color</code> to use in the foreground for selected list items
	 * 
	 *  @see #getSelectionForeground
	 *  @see #setSelectionBackground
	 *  @see #setForeground
	 *  @see #setBackground
	 *  @see #setFont
	 */
	public void setSelectionForeground(java.awt.Color selectionForeground) {
	}

	/**
	 *  Returns the background color for selected cells.
	 * 
	 *  @return the <code>Color</code> used for the background of selected list items
	 * 
	 *  @see #setSelectionBackground
	 *  @see #setSelectionForeground
	 */
	public java.awt.Color getSelectionBackground() {
	}

	/**
	 *  Sets the background color for selected cells.  Cell renderers can use this color to the fill selected cells.
	 *  <p/>
	 *  The default value of this property is defined by the look and feel implementation.
	 *  <p/>
	 *  This is a <a href="http://java.sun.com/docs/books/tutorial/javabeans/whatis/beanDefinition.html">JavaBeans</a>
	 *  bound property.
	 * 
	 *  @param selectionBackground the <code>Color</code> to use for the background of selected cells
	 * 
	 *  @see #getSelectionBackground
	 *  @see #setSelectionForeground
	 *  @see #setForeground
	 *  @see #setBackground
	 *  @see #setFont
	 */
	public void setSelectionBackground(java.awt.Color selectionBackground) {
	}

	/**
	 *  Returns the default selection model object, which is a <code>DefaultListSelectionModel</code>.  A subclass can
	 *  override this method to return a different selection model object.
	 * 
	 *  @return the default selection model object
	 * 
	 *  @see javax.swing.DefaultListSelectionModel
	 */
	protected javax.swing.ListSelectionModel createDefaultSelectionModel() {
	}

	/**
	 *  Scrolls the list within an enclosing viewport to make the specified cell completely visible. This calls {@code
	 *  scrollRectToVisible} with the bounds of the specified cell. For this method to work, the {@code JList} must be
	 *  within a <code>JViewport</code>.
	 *  <p/>
	 *  If the given index is outside the list's range of cells, this method results in nothing.
	 * 
	 *  @param index the index of the cell to make visible
	 * 
	 *  @see JComponent#scrollRectToVisible
	 *  @see #getVisibleRect
	 */
	public void ensureRowIsVisible(int index) {
	}

	@java.lang.Override
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in gantt.properties.
	 * 
	 *  @param key the resource string key
	 * 
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}

	/**
	 *  Gets the flag indicating if drag and move gantt entry is allowed.
	 * 
	 *  @return true if drag and move gantt entry is allowed. Otherwise false.
	 * 
	 *  @see #setAllowMoveEntry(boolean)
	 */
	public boolean isAllowMoveEntry() {
	}

	/**
	 *  Sets the flag indicating if drag and move gantt entry is allowed.
	 *  <p/>
	 *  By default, the flag is true. If you want only resize but would like to avoid drag to move entire entry, please
	 *  set this flag to false.
	 * 
	 *  @param allowMoveEntry the flag
	 */
	public void setAllowMoveEntry(boolean allowMoveEntry) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Gets the pixels for the width of the resize area.
	 * 
	 *  @return the pixels for the width of the resize area.
	 */
	public int getResizeAreaWidth() {
	}

	/**
	 *  Sets the pixels for the width of the resize area.
	 * 
	 *  @param resizeAreaWidth the pixels for the width of the resize area
	 */
	public void setResizeAreaWidth(int resizeAreaWidth) {
	}

	/**
	 *  Checks if the point is in the resize west area.
	 *  <p/>
	 *  By default, it simply returns true if point.x < entryRect.x. You could override this method to let the condition
	 *  be point.x < entryRect.x + getResizeAreaWidth() / 2 to enlarge the resize west area.
	 * 
	 *  @param point     the mouse point
	 *  @param entryRect the rectangle of the entry area
	 * 
	 *  @return true if the point is in the resize west area. Otherwise false.
	 */
	public boolean isResizeWestArea(java.awt.Point point, java.awt.Rectangle entryRect) {
	}

	/**
	 *  Checks if the point is in the resize east area.
	 *  <p/>
	 *  By default, it simply returns true if point.x < entryRect.x + entryRect.width. You could override this method to
	 *  let the condition be point.x < entryRect.x + entryRect.width + getResizeAreaWidth() / 2 to enlarge the resize
	 *  east area.
	 * 
	 *  @param point     the mouse point
	 *  @param entryRect the rectangle of the entry area
	 * 
	 *  @return true if the point is in the resize east area. Otherwise false.
	 */
	public boolean isResizeEastArea(java.awt.Point point, java.awt.Rectangle entryRect) {
	}

	/**
	 *  Checks if the entry is allowed to be resized as designated start & end.
	 * 
	 *  @param entry the gantt entry
	 *  @param start the new start of the range
	 *  @param end   the new end of the range
	 *  @return true by default. You could override this method to restrict the dragging to resize behavior.
	 *  @since 3.4.5
	 */
	public boolean isAllowResizeEntry(GanttEntry entry, Object start, Object end) {
	}
}
