/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultGanttLabelRenderer</code> is a default implementation of <code>GanttLabelRenderer</code> using
 *  <code>JLabel</code>. By default, we simply use the name of the entry as the label. Subclass can override {@link
 *  #convertEntryToString(GanttEntry)} to provide a different string as the label.
 */
public class DefaultGanttLabelRenderer extends javax.swing.JLabel implements GanttLabelRenderer {

	public DefaultGanttLabelRenderer() {
	}

	@java.lang.Deprecated
	public java.awt.Component getGanttLabelRendererComponent(GanttChart chart, GanttEntry entry, boolean isSelected, boolean hasFocus, int row) {
	}

	public java.awt.Component getGanttLabelRendererComponent(GanttChart chart, GanttEntry entry, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Converts the GanttEntry to String and set it to the JLabel.
	 * 
	 *  @param entry the GanttEntry
	 *  @return the String converted from the GanttEntry.
	 */
	protected String convertEntryToString(GanttEntry entry) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public boolean isOpaque() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 * 
	 *  @since 1.5
	 */
	@java.lang.Override
	public void invalidate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void validate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void revalidate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint(java.awt.Rectangle r) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}
}
