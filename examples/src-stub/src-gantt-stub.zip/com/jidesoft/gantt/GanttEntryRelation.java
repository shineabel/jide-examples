/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttEntryRelation</code> defines a relation between two entries.
 * 
 *  @param <S> The type of the GanttEntries in the model.
 */
public interface GanttEntryRelation {

	/**
	 *  The successor entry cannot begin until the task that it depends (the predecessor entry) on is complete.
	 */
	public static final int ENTRY_RELATION_FINISH_TO_START = 1;

	/**
	 *  The successor entry cannot begin until the task that it depends (the predecessor entry) has begun.
	 */
	public static final int ENTRY_RELATION_START_TO_START = 2;

	/**
	 *  The successor entry cannot be completed until the task that it depends on (the predecessor entry) is completed.
	 */
	public static final int ENTRY_RELATION_FINISH_TO_FINISH = 3;

	/**
	 *  The successor entry cannot be completed until the task that it depends on (the predecessor entry) begins.
	 */
	public static final int ENTRY_RELATION_START_TO_FINISH = 4;

	/**
	 *  Gets the predecessor entry of the relation.
	 * 
	 *  @return the predecessor entry.
	 */
	public GanttEntry getPredecessorEntry();

	/**
	 *  Gets the successor entry of the relation.
	 * 
	 *  @return the successor entry.
	 */
	public GanttEntry getSuccessorEntry();

	/**
	 *  Gets the relation type between the predecessor and successor entries.
	 * 
	 *  @return the relation type.
	 */
	public int getRelationType();
}
