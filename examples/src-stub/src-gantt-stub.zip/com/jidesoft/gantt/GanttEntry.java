/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttEntry</code> represents an entry in a gantt chart. It has an unique ID within the same gantt chart. It has
 *  a start and end value. The value could be a date, time or an int value, depending on the use case. It also has a
 *  completion value which is the percentage of the completion.
 * 
 *  @param <T> The type of the bases unit of the range, for example Date or Integer.
 *  @see MutableGanttEntry
 *  @see DefaultGanttEntry
 */
public interface GanttEntry {

	public static final String PROPERTY_ADJUSTING = "adjusting";

	/**
	 *  Gets the name of the entry. The name will be displayed on the gantt table.
	 * 
	 *  @return the name of the entry
	 */
	public String getName();

	/**
	 *  Gets the range for this entry.
	 *  <p/>
	 *  NOTE: the range can be null and the range's upper and/or lower boundary can be null!
	 * 
	 *  @return the range.
	 */
	public <any> getRange();

	/**
	 *  Gets the percentage of completion as a double value between 0.0 and 1.0.
	 * 
	 *  @return the percentage of completion.
	 */
	public double getCompletion();

	/**
	 *  Checks if the entry is adjusting.
	 * 
	 *  @return true or false.
	 */
	public boolean isAdjusting();
}
