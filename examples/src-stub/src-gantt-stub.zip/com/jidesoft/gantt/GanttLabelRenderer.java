/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  This interface defines the method required by any object that would like to be a label renderer for
 *  <code>GanttEntry</code> in a <code>GanttCart</code>.
 */
public interface GanttLabelRenderer {

	/**
	 *  Creates the component used for painting the label for the gantt entry.  This method is used to configure the
	 *  renderer appropriately before drawing.
	 *  <p/>
	 * 
	 *  @param chart      the <code>GanttChart</code> that is asking the renderer to draw; can be <code>null</code>
	 *  @param entry      the GanttEntry of the cell to be rendered.  It is up to the specific renderer to interpret and
	 *                    draw the value.
	 *  @param isSelected true if the gantt entry is to be rendered with the selection highlighted; otherwise false
	 *  @param hasFocus   if true, render gantt entry appropriately.  For example, put a special border on the cell, if
	 *                    the cell can be edited, render in the color used to indicate editing
	 *  @param row        the row index of the GanttEntry being drawn.
	 *  @return the component that will be used to render the gantt entry.
	 *  @deprecated replaced by {@link #getGanttLabelRendererComponent(GanttChart, GanttEntry, boolean, boolean, int, int)}
	 */
	@java.lang.Deprecated
	public java.awt.Component getGanttLabelRendererComponent(GanttChart chart, GanttEntry entry, boolean isSelected, boolean hasFocus, int row);

	/**
	 *  Creates the component used for painting the label for the gantt entry.  This method is used to configure the
	 *  renderer appropriately before drawing.
	 *  <p/>
	 * 
	 *  @param chart      the <code>GanttChart</code> that is asking the renderer to draw; can be <code>null</code>
	 *  @param entry      the GanttEntry of the cell to be rendered.  It is up to the specific renderer to interpret and
	 *                    draw the value.
	 *  @param isSelected true if the gantt entry is to be rendered with the selection highlighted; otherwise false
	 *  @param hasFocus   if true, render gantt entry appropriately.  For example, put a special border on the cell, if
	 *                    the cell can be edited, render in the color used to indicate editing
	 *  @param row        the row index of the GanttEntry being drawn.
	 *  @param column     the column index of the sub entry. -1 if there is no sub entry
	 *  @return the component that will be used to render the gantt entry.
	 */
	public java.awt.Component getGanttLabelRendererComponent(GanttChart chart, GanttEntry entry, boolean isSelected, boolean hasFocus, int row, int column);
}
