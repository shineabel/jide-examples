/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DateGanttChart</code> is a GanttChart that uses the Date.class as the unit for the scale.
 * 
 *  @param <S> The type of the GanttEntry in the model.
 */
public class DateGanttChart extends GanttChart {

	public DateGanttChart() {
	}

	public DateGanttChart(GanttModel ganttModel) {
	}

	public DateGanttChart(com.jidesoft.scale.ScaleArea scaleArea) {
	}

	public DateGanttChart(GanttModel ganttModel, com.jidesoft.scale.ScaleArea scaleArea) {
	}
}
