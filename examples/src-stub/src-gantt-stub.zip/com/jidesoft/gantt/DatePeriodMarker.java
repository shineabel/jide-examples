/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DatePeriodMarker</code> can be used to mark special period, for example the first day of every month, every
 *  weekends, etc.
 */
public class DatePeriodMarker extends AbstractPeriodMarker {

	/**
	 *  @param calendarValuesToMark One or more of the {@link DatePeriod#getCalendarField()} values to mark.
	 */
	public DatePeriodMarker(java.awt.Paint backgroundPaint, java.awt.Paint outlinePaint, java.awt.Stroke outlineStroke, com.jidesoft.scale.DatePeriod period, int[] calendarValuesToMark) {
	}

	@java.lang.Override
	public boolean isNextPeriodMarked(java.util.Date startInstant, java.util.Date endInstant) {
	}

	@java.lang.Override
	public boolean isPeriodMarked(java.util.Date startInstant, java.util.Date endInstant) {
	}

	@java.lang.Override
	public boolean isPreviousPeriodMarked(java.util.Date startInstant, java.util.Date endInstant) {
	}
}
