/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttChartPopupMenuInstaller</code> allows you to add a popup menu to GanttChart and customize it. To use it,
 *  you just need to call
 *  <pre><code>
 *  GanttChartPopupMenuInstaller installer = new GanttChartPopupMenuInstaller(ganttChart);
 *  </code></pre>
 *  Or if you want to uninstall it, call
 *  <pre><code>
 *  GanttChartPopupMenuInstaller.getGanttChartPopupMenuInstaller(ganttChart).uninstallListeners();
 *  </code></pre>
 *  However <code>GanttchartPopupMenuInstaller</code> has no menu items. You can use one of the existing
 *  <code>GanttChartPopupMenuCustomizer</code>s to add more menu items or create your own
 *  <code>GanttChartPopupMenuCustomizer</code> to do it.
 */
public class GanttChartPopupMenuInstaller extends java.awt.event.MouseAdapter {

	/**
	 *  Client property used by GanttChart to provide its own GanttChartColumnPopupMenuCustomizer.
	 */
	public static final String CLIENT_PROPERTY_POPUP_MENU_INSTALLER = "GanttChartPopupMenuInstaller";

	/**
	 *  Creates a GanttChartColumnPopupMenuCustomizer.
	 * 
	 *  @param ganttChart the table.
	 */
	public GanttChartPopupMenuInstaller(GanttChart ganttChart) {
	}

	public void addGanttChartPopupMenuCustomizer(GanttChartPopupMenuCustomizer customizer) {
	}

	public void removeTablePopupMenuCustomizer(GanttChartPopupMenuCustomizer customizer) {
	}

	public GanttChartPopupMenuCustomizer[] getGanttChartPopupMenuCustomizers() {
	}

	@java.lang.Override
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	protected javax.swing.JPopupMenu createPopupMenu() {
	}

	/**
	 *  Customizes the menu items for the popup menu.
	 * 
	 *  @param ganttChart  the ganttChart.
	 *  @param popup       the popup menu.
	 *  @param clickingRow the row that user right clicks.
	 *  @param p           the point that user right clicks.
	 */
	protected void customizeMenuItems(GanttChart ganttChart, javax.swing.JPopupMenu popup, int clickingRow, java.awt.Point p) {
	}

	/**
	 *  Adds a separator to the popup menu if there are menu items on it already.
	 * 
	 *  @param popup the popup menu.
	 */
	public static void addSeparatorIfNecessary(javax.swing.JPopupMenu popup) {
	}

	/**
	 *  Installs the listeners needed in order to show the popup menu for the GanttChart.
	 */
	public void installListeners() {
	}

	/**
	 *  Uninstalls the listeners needed in order to show the popup menu for the GanttChart.
	 */
	public void uninstallListeners() {
	}

	/**
	 *  Gets the Searchable installed on the component. Null is no Searchable was installed.
	 * 
	 *  @param ganttChart the GanttChart
	 *  @return the Searchable installed. Null is no Searchable was installed.
	 */
	public static GanttChartPopupMenuInstaller getGanttChartPopupMenuInstaller(GanttChart ganttChart) {
	}
}
