/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>RelationGanttChartPopupMenuCustomizer</code> works with <code>GanttChartPopupMenuInstaller</code> to add
 *  relation related menu items to GanttChart's context menu.
 */
public class RelationGanttChartPopupMenuCustomizer implements GanttChartPopupMenuCustomizer {

	public RelationGanttChartPopupMenuCustomizer() {
	}

	public void customizePopupMenu(GanttChart ganttChart, javax.swing.JPopupMenu popup, int clickingRow, java.awt.Point p) {
	}

	protected String getRelationString(GanttChart chart, int relationType) {
	}
}
