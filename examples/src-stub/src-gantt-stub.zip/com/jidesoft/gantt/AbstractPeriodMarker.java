/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public abstract class AbstractPeriodMarker extends AbstractPeriodBackgroundPainter {

	public AbstractPeriodMarker(com.jidesoft.scale.Period forPeriod, java.awt.Paint backgroundPaint, java.awt.Paint outlinePaint, java.awt.Stroke outlineStroke) {
	}

	public abstract boolean isPeriodMarked(Object startInstant, Object endInstant) {
	}

	public abstract boolean isPreviousPeriodMarked(Object startInstant, Object endInstant) {
	}

	public abstract boolean isNextPeriodMarked(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public java.awt.Paint getBackgroundPaint(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public java.awt.Paint getOutlinePaint(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public java.awt.Stroke getOutlineStroke(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public int getOutlineSides(Object startInstant, Object endInstant) {
	}
}
