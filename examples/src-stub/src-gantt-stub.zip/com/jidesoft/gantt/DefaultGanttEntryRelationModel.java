/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultGanttEntryRelationModel</code> is a default implementation of <code>GanttEntryRelationModel</code>.
 * 
 *  @param <S> The type of the GanttEntry in the model.
 */
public class DefaultGanttEntryRelationModel extends AbstractGanttEntryRelationModel {

	/**
	 *  The map from GanttEntry to a set of GanttEntryRelation.
	 * 
	 *  @since 3.4.2
	 */
	protected final java.util.Map _relations;

	public DefaultGanttEntryRelationModel() {
	}

	public void addEntryRelation(GanttEntryRelation relation) {
	}

	public java.util.Set getEntryRelations(GanttEntry entry) {
	}

	public GanttEntryRelation getEntryRelation(GanttEntry start, GanttEntry end) {
	}

	public void removeEntryRelation(GanttEntryRelation relation) {
	}

	@java.lang.SuppressWarnings("unchecked")
	public void removeEntryRelations(GanttEntry entry) {
	}

	public void removeAllEntryRelations() {
	}
}
