/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultPeriodBackgroundPainter</code> provides a default implementation for
 *  <code>PeriodBackgroundPainter</code>.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public class DefaultPeriodBackgroundPainter extends AbstractPeriodBackgroundPainter {

	/**
	 *  Marks the start of each period with a dashed line.
	 */
	public DefaultPeriodBackgroundPainter(com.jidesoft.scale.Period forPeriod) {
	}

	public DefaultPeriodBackgroundPainter(com.jidesoft.scale.Period forPeriod, java.awt.Paint backgroundPaint, java.awt.Paint outlinePaint, java.awt.Stroke outlineStroke, int outlineSides) {
	}

	public void setBackgroundPaint(java.awt.Paint fillPaint) {
	}

	@java.lang.Override
	public java.awt.Paint getBackgroundPaint(Object startInstant, Object endInstant) {
	}

	public void setOutlinePaint(java.awt.Paint paint) {
	}

	@java.lang.Override
	protected java.awt.Paint getOutlinePaint(Object startInstant, Object endInstant) {
	}

	public void setOutlineStroke(java.awt.Stroke stroke) {
	}

	@java.lang.Override
	public java.awt.Stroke getOutlineStroke(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public int getOutlineSides(Object startInstant, Object endInstant) {
	}

	public void setOutlineSides(int defaultOutlineSides) {
	}
}
