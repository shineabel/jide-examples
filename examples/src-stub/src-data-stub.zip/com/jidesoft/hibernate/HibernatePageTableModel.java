/**
 *  The package contains classes related for Hibernate support for JIDE Data Grids product.
 */
package com.jidesoft.hibernate;


/**
 *  <code>HibernatePageTableModel</code> extends <code>AdvancePageTableModel</code> by providing support for Hibernate.
 */
public class HibernatePageTableModel extends com.jidesoft.grid.AdvancePageTableModel {

	protected Session _session;

	protected Class _type;

	/**
	 *  Creates a <code>HibernatePageTableModel</code>. The page size is defaulted to 10 in this case.
	 * 
	 *  @param session the session object from Hibernate.
	 *  @param type    the data type which is referred as the persistent class in Hibernate.
	 */
	public HibernatePageTableModel(Session session, Class type) {
	}

	/**
	 *  Creates a <code>HibernatePageTableModel</code>.
	 * 
	 *  @param session  the session object from Hibernate.
	 *  @param type     the data type which is referred as the persistent class in Hibernate.
	 *  @param pageSize the page size.
	 */
	public HibernatePageTableModel(Session session, Class type, int pageSize) {
	}

	protected java.util.List createOrders(SortItemSupport sortItemSupport) {
	}

	protected Criterion prepareCriterion(FilterItem filterItem) {
	}

	protected java.util.List createCriterions(FilterItemSupport filterItemSupport) {
	}

	/**
	 *  Submits the query.
	 * 
	 *  @param sortItemSupport   the information for sort items.
	 *  @param filterItemSupport the information for filter items.
	 *  @param currentPage       the current page.
	 *  @param pageSize          the page size.
	 */
	@java.lang.Override
	public void refreshData(SortItemSupport sortItemSupport, FilterItemSupport filterItemSupport, int currentPage, int pageSize) {
	}

	/**
	 *  Override this method to provide to pass in a list of properties to the HibernateTableModel if needed.
	 * 
	 *  @param rows the objects.
	 *  @return an HibernateTableModel.
	 *  @see com.jidesoft.hibernate.HibernateTableModel
	 */
	protected javax.swing.table.TableModel createCurrentPageTableModel(java.util.List rows) {
	}
}
