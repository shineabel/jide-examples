/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public class DefaultRecord implements java.io.Serializable, java.util.Map, Record {

	protected final java.util.HashMap values;

	public DefaultRecord() {
	}

	public DefaultRecord(DefaultRecord record) {
	}

	public DefaultRecord(java.util.Map map) {
	}

	public int getSize() {
	}

	public boolean isEmpty() {
	}

	public boolean contains(String field) {
	}

	public Object remove(String field) {
	}

	public java.util.HashMap getValues() {
	}

	public void putAll(java.util.Map data) {
	}

	public void putAll(java.util.Map data, boolean overwrite) {
	}

	public Object getValue(String field) {
	}

	public String getString(String field) {
	}

	public int getInt(String field) {
	}

	public double getDouble(String field) {
	}

	public java.sql.Date getDate(String field) {
	}

	public void setValue(String field, Object value) {
	}

	public boolean isNull(String field) {
	}

	/**
	 *  Devuelve si existe el valor en el hash independientemente
	 *  de si es nulo o no.
	 *  @param field     Nombre del campo
	 *  @return  si existe la clave en el map.
	 */
	public boolean isEmpty(String field) {
	}

	public String toString(String separador) {
	}

	public String toString(String separador, boolean showInstance) {
	}

	public String toString() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public void clear() {
	}

	@java.lang.Override
	public int size() {
	}

	@java.lang.Override
	public boolean containsKey(Object key) {
	}

	@java.lang.Override
	public boolean containsValue(Object value) {
	}

	@java.lang.Override
	public Object get(Object key) {
	}

	@java.lang.Override
	public Object put(String key, Object value) {
	}

	@java.lang.Override
	public Object remove(Object key) {
	}

	@java.lang.Override
	public java.util.Set keySet() {
	}

	@java.lang.Override
	public java.util.Collection values() {
	}

	@java.lang.Override
	public java.util.Set entrySet() {
	}
}
