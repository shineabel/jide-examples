/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


/**
 *  Created by IntelliJ IDEA.
 *  User: programacion
 *  Date: 13-nov-2009
 *  Time: 13:17:55
 *  To change this template use File | Settings | File Templates.
 */
public interface BatchedOperations {

	/**
	 *  Establish if the changes are immediate or belong to a transaction
	 *  @param autoCommit
	 */
	public void setAutoCommit(boolean autoCommit);

	/**
	 *  Return the commit mode
	 *  @return
	 */
	public boolean isAutoCommit();

	/**
	 *  Push changes
	 *  @throws Exception
	 */
	public void commit();

	/**
	 *  Go back to the initial state
	 *  @throws Exception
	 */
	public void rollback();
}
