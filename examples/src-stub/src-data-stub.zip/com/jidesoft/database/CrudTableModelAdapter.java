/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


/**
 *  An adapter class for the interface {@link com.jidesoft.database.CrudTableModel} for easy implementation.
 */
public class CrudTableModelAdapter extends TableModelWrapperImpl implements CrudTableModel {

	public CrudTableModelAdapter(javax.swing.table.TableModel tableModel) {
	}

	public CrudTableModelAdapter(javax.swing.table.TableModel tableModel, CrudRowOperations crudOperations) {
	}

	public void insertRow(Record record) {
	}

	public Record readRow(int rowIndex) {
	}

	public void updateRow(int rowIndex, Record record) {
	}

	public void deleteRow(int rowIndex) {
	}
}
