/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public interface CrudTableModel extends javax.swing.table.TableModel, CrudRowOperations {
}
