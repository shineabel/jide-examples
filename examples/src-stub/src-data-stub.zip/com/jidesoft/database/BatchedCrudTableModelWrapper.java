/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public class BatchedCrudTableModelWrapper extends TableModelWrapperImpl implements CrudTableModel, BatchedOperations {

	protected TableModelCache _cache;

	public BatchedCrudTableModelWrapper(javax.swing.table.TableModel model) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void rollback() {
	}

	protected int getActualIndexAt(int row) {
	}

	protected void resetState() {
	}

	@java.lang.Override
	public void commit() {
	}

	/**
	 *  CrudTableModel interface implementation
	 */
	@java.lang.Override
	public void insertRow(Record record) {
	}

	@java.lang.Override
	public Record readRow(int rowIndex) {
	}

	protected Record createRowRecord() {
	}

	@java.lang.Override
	public void updateRow(int rowIndex, Record record) {
	}

	@java.lang.Override
	public void deleteRow(int rowIndex) {
	}

	@java.lang.Override
	public void setAutoCommit(boolean autoCommit) {
	}

	@java.lang.Override
	public boolean isAutoCommit() {
	}
}
