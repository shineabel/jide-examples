package com.jidesoft.grid;


/**
 *  <code>PagedTablePaneNavigationBar</code> is a PageNavigationBar for PagedTablePane.
 */
public class PagedTablePaneNavigationBar extends com.jidesoft.paging.PageNavigationBar {

	public PagedTablePaneNavigationBar(PagedTablePane pane) {
	}

	@java.lang.Override
	public void lastPage() {
	}

	@java.lang.Override
	protected int getPageSize() {
	}

	@java.lang.Override
	protected int getSelectedRecordIndex() {
	}

	@java.lang.Override
	protected void setSelectedRecordIndex(int row) {
	}

	@java.lang.Override
	protected void changeCurrentPage(int newPageIndex) {
	}
}
