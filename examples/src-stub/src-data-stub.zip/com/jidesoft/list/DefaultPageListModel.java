package com.jidesoft.list;


public class DefaultPageListModel extends AbstractPageListModel {

	public DefaultPageListModel(javax.swing.ListModel model) {
	}

	public DefaultPageListModel(javax.swing.ListModel model, int pageSize) {
	}

	public int getActualIndexAt(int visualRow) {
	}

	public int getIndexAt(int actualRow) {
	}

	public javax.swing.ListModel getActualModel() {
	}

	public void setActualModel(javax.swing.ListModel model) {
	}

	public int[] getIndexes() {
	}

	public void setIndexes(int[] indexes) {
	}

	public Object getElementAt(int rowIndex) {
	}

	public int getTotalRecordCount() {
	}

	public void setTotalRecordCount(int totalRecordCount) {
	}

	protected void reallocateIndexes() {
	}

	protected CompoundListDataEvent createCompoundListDataEvent() {
	}

	@java.lang.Override
	public void fireListDataEvent(javax.swing.event.ListDataEvent event) {
	}
}
