package com.jidesoft.plaf.synth;


public class SynthCustomizer {

	public SynthCustomizer() {
	}

	public void customize(javax.swing.UIDefaults defaults) {
	}
}
