package com.jidesoft.plaf.motif;


public class MotifCustomizer {

	public MotifCustomizer() {
	}

	public void customize(javax.swing.UIDefaults defaults) {
	}
}
