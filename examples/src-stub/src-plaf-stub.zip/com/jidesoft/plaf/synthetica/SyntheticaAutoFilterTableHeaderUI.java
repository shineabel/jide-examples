package com.jidesoft.plaf.synthetica;


/**
 *  UI class for AutoFilterTableHeader in Synthetica L&F.
 * 
 *  @since 3.1.0
 */
public class SyntheticaAutoFilterTableHeaderUI extends SyntheticaEditableTableHeaderUI {

	public SyntheticaAutoFilterTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
