package com.jidesoft.plaf.synthetica;


public class SyntheticaCustomizer {

	public SyntheticaCustomizer() {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	public void customize(javax.swing.UIDefaults defaults) {
	}
}
