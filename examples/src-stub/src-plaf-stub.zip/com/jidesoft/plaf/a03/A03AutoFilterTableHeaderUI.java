package com.jidesoft.plaf.a03;


/**
 *  UI class for AutoFilterTableHeader for Synth L&F.
 * 
 *  @since 3.1.0
 */
public class A03AutoFilterTableHeaderUI extends A03EditableTableHeaderUI {

	public A03AutoFilterTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
