package com.jidesoft.plaf.a03;


public class A03Initializer {

	public A03Initializer() {
	}

	public void initialize(javax.swing.UIDefaults defaults) {
	}
}
