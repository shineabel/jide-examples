package com.jidesoft.plaf.a03;


public class A03TreeTableUI extends A03CellSpanTableUI {

	public A03TreeTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}
}
