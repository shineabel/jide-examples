package com.jidesoft.plaf.a03;


/**
 *  UI class for NestedTableHeader for Synth L&F.
 */
public class A03NestedTableHeaderUI extends A03AutoFilterTableHeaderUI {

	public A03NestedTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
