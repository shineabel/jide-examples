package com.jidesoft.plaf.gtk;


public class GTKInitializer {

	public GTKInitializer() {
	}

	public void initialize(javax.swing.UIDefaults defaults) {
	}
}
