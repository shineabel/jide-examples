package com.jidesoft.plaf.substance.v4;


public class SubstanceNavigableTableUI extends SubstanceJideTableUI {

	public SubstanceNavigableTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}
}
