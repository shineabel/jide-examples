package com.jidesoft.plaf.substance.v4;


public class SubstanceCellSpanTableUI extends SubstanceNavigableTableUI {

	public SubstanceCellSpanTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
