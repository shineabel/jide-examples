package com.jidesoft.plaf.substance;


public class SubstanceCustomizer {

	public SubstanceCustomizer() {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	public void customize(javax.swing.UIDefaults defaults) {
	}

	public void customizeFor5x(javax.swing.UIDefaults defaults) {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	public void customizeFor4x(javax.swing.UIDefaults defaults) {
	}
}
