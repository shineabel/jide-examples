package com.jidesoft.plaf.substance;


public class SubstanceTreeTableUI extends SubstanceCellSpanTableUI {

	public SubstanceTreeTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}
}
