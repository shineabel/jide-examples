package com.jidesoft.plaf.tonic;


/**
 *  BasicRangeSliderUI implementation
 */
public class TonicRangeSliderUI extends SliderUI {

	protected static final int MOUSE_HANDLE_NONE = 0;

	protected static final int MOUSE_HANDLE_MIN = 1;

	protected static final int MOUSE_HANDLE_MAX = 2;

	protected static final int MOUSE_HANDLE_MIDDLE = 4;

	protected static final int MOUSE_HANDLE_LOWER = 5;

	protected static final int MOUSE_HANDLE_UPPER = 6;

	protected boolean hover;

	protected boolean second;

	protected boolean rollover1;

	protected boolean pressed1;

	protected boolean rollover2;

	protected boolean pressed2;

	public TonicRangeSliderUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent slider) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void restoreThumbForLowValue(java.awt.Point p) {
	}

	protected java.awt.Point adjustThumbForHighValue() {
	}

	protected void adjustSnapHighValue() {
	}

	@java.lang.Override
	protected void calculateThumbLocation() {
	}

	@java.lang.Override
	protected TrackListener createTrackListener(javax.swing.JSlider slider) {
	}

	protected int getMouseHandle(int x, int y) {
	}

	@java.lang.Override
	public void paintThumb(java.awt.Graphics g) {
	}

	protected void setMouseRollover(int handle) {
	}

	protected void setMousePressed(int handle) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void setMouseReleased(int handle) {
	}

	@java.lang.Override
	public void scrollByBlock(int direction) {
	}

	@java.lang.Override
	public void scrollByUnit(int direction) {
	}

	protected class RangeTrackListener {


		public TonicRangeSliderUI.RangeTrackListener(TrackListener listener) {
		}

		/**
		 *  @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		/**
		 *  @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		/**
		 *  @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		/**
		 *  @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		/**
		 *  @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		/**
		 *  @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		/**
		 *  @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
		 */
		@java.lang.Override
		public void mouseExited(java.awt.event.MouseEvent e) {
		}
	}
}
