/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The implementation of SummaryCalculator for BigDecimal. In this implementation, we calculate seven statistics - Sum,
 *  Min, Max, Mean, Var, StdDev, Count.
 *  <p/>
 *  Different from what is already in DefaultSummaryCalculator, some statistics calculations need a MathContext to
 *  control the precision. You can set it using {@link #setMathContext(java.math.MathContext)}. This context is used in
 *  Mean, Var, StdDev calculation.
 * 
 *  @deprecated Please use DefaultSummaryCalculator instead as DefaultSummaryCalculator supports BigDecimal as well.
 */
@java.lang.Deprecated
public class BigDecimalSummaryCalculator implements PivotSummaryCalculator {

	public BigDecimalSummaryCalculator() {
	}

	public BigDecimalSummaryCalculator(java.math.MathContext mathContext) {
	}

	/**
	 *  Gets the math context. This is used when calculating mean, var and stddev.
	 * 
	 *  @return the MathContext.
	 */
	public java.math.MathContext getMathContext() {
	}

	/**
	 *  Sets the math context. This is used when calculating mean, var and stddev.
	 * 
	 *  @param mathContext a new MathContext.
	 */
	public void setMathContext(java.math.MathContext mathContext) {
	}

	public void addValue(Object object) {
	}

	public void addValue(IPivotDataModel pivotDataModel, PivotField pivotField, int row, int column, Object object) {
	}

	@java.lang.Override
	public void addValue(PivotValueProvider valueProvider, PivotField field, Object object) {
	}

	@java.lang.Override
	public void addValue(PivotValueProvider dataModel, PivotField field, Values rowValues, Values columnValues, Object object) {
	}

	public void clear() {
	}

	public long getCount() {
	}

	public int getNumberOfSummaries() {
	}

	public String getSummaryName(java.util.Locale locale, int summarySort) {
	}

	public Object getSummaryResult(int summarySort) {
	}

	/**
	 *  Checks if the biasCorrect is set.
	 * 
	 *  @return true or false.
	 */
	public boolean isBiasCorrected() {
	}

	/**
	 *  Sets the biasCorrected flag. If true, variance will be calculated dividing by n - 1. Otherwise, it willdividee by
	 *  n. Default is true.
	 * 
	 *  @param biasCorrected true or false.
	 */
	public void setBiasCorrected(boolean biasCorrected) {
	}

	public int[] getAllowedSummaries(Class type) {
	}

	/**
	 *  Gets the allowed summary types.
	 * 
	 *  @param type the data type.
	 *  @return the allowed summary types.
	 */
	public int[] getAllowedSummaries(Class type, ConverterContext context) {
	}
}
