/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The AggregateTableHeader allows the user to (un)aggregate columns by dragging them with the mouse.
 * 
 *  @since 3.2.3
 */
public class AggregateTableHeader extends GroupTableHeader {

	public AggregateTableHeader(javax.swing.JTable table) {
	}
}
