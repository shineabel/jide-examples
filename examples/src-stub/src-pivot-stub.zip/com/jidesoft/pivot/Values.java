/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  An interface to represent several <code>Value</code>s.
 */
public interface Values {

	/**
	 *  Gets the number of <code>Value</code>s.
	 * 
	 *  @return the number of <code>Value</code>s.
	 */
	public int getCount();

	/**
	 *  Gets the <code>Value</code> at the specified index.
	 * 
	 *  @param index the index.
	 *  @return the <code>Value</code> at the specified index.
	 */
	public Value getValueAt(int index);
}
