/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  Running summary class to store running summary information.
 */
public class RunningSummary {

	/**
	 *  Default constructor. RunningType will be 0 and other fields are null.
	 */
	public RunningSummary() {
	}

	/**
	 *  Get running type.
	 * 
	 *  @return running type.
	 */
	public int getRunningType() {
	}

	/**
	 *  Set running type.
	 * 
	 *  @param runningType running type.
	 */
	public void setRunningType(int runningType) {
	}

	/**
	 *  Get base on field.
	 * 
	 *  @return base on field.
	 */
	public PivotField getBaseOnField() {
	}

	/**
	 *  Set base on field.
	 * 
	 *  @param baseOnField base on field
	 */
	public void setBaseOnField(PivotField baseOnField) {
	}

	/**
	 *  Get range in field.
	 * 
	 *  @return range in field.
	 */
	public PivotField getRangeInField() {
	}

	/**
	 *  Set range in field.
	 * 
	 *  @param rangeInField range in field
	 */
	public void setRangeInField(PivotField rangeInField) {
	}

	/**
	 *  Get compare to object.
	 * 
	 *  @return compare to object.
	 */
	public Object getCompareTo() {
	}

	/**
	 *  Set compare to object.
	 * 
	 *  @param compareTo compare to object
	 */
	public void setCompareTo(Object compareTo) {
	}
}
