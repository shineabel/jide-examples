/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class CompareToConverter {

	public CompareToConverter(PivotTablePane pivotTablePane) {
	}

	@java.lang.Override
	public String toString(Object object, ConverterContext context) {
	}

	@java.lang.Override
	public boolean supportToString(Object object, ConverterContext context) {
	}

	@java.lang.Override
	public Object fromString(String string, ConverterContext context) {
	}

	@java.lang.Override
	public boolean supportFromString(String string, ConverterContext context) {
	}
}
