/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The field settings panel which is used by the field settings dialog when user right clicks on the field box to customize the settings.
 */
public class FieldSettingsPanel extends javax.swing.JPanel {

	protected javax.swing.JTextField _nameField;

	protected javax.swing.JCheckBox _separateSubtotalSettingCheckBox;

	protected SubtotalSettingPanel _subtotalSettingPanel;

	protected SubtotalSettingPanel _subtotalSettingPanelForRow;

	protected SubtotalSettingPanel _subtotalSettingPanelForColumn;

	protected javax.swing.JComboBox _summaryComboBox;

	protected javax.swing.JCheckBox _runningSettingCheckBox;

	protected javax.swing.JPanel _runningSettingPanel;

	protected ButtonPanel _runningSettingButtonPanel;

	protected javax.swing.JButton _addRowButton;

	protected javax.swing.JButton _removeRowButton;

	protected javax.swing.JButton _clearRowButton;

	protected javax.swing.JCheckBox _hideOriginalCheckBox;

	protected javax.swing.JTable _runningSettingTable;

	protected javax.swing.JComboBox _subtotalComboBox;

	protected javax.swing.JComboBox _grandTotalComboBox;

	protected javax.swing.JCheckBox _enableFilterCheckBox;

	protected javax.swing.JComboBox _filterFieldComboBox;

	protected javax.swing.JComboBox _filterBaseValuesComboBox;

	protected CustomFilterEditor _filterEditor;

	protected javax.swing.JRadioButton _farRadio;

	protected javax.swing.JRadioButton _nearRadio;

	public FieldSettingsPanel(PivotTablePane pivotTablePane) {
	}

	/**
	 *  Installs all the components on the field settings panel. Subclass can override this methods to add more components or customize existing components.
	 */
	protected void installComponents() {
	}

	protected void installListeners() {
	}

	public PivotField getField() {
	}

	public void setField(PivotField field) {
	}

	/**
	 *  Loads the data from the PivotField.
	 */
	public void loadData() {
	}

	/**
	 *  Saves the data to the PivotField.
	 */
	public void saveData() {
	}

	public java.awt.Component getInitFocusedComponent() {
	}
}
