/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  A value represents grand total data in pivot data model. In this case, the actual value is null.
 */
public class GrandTotalValue extends DefaultExpandable implements ExpandableValue {

	public GrandTotalValue() {
	}

	public Object getValue() {
	}

	public void setValue(Object value) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}
}
