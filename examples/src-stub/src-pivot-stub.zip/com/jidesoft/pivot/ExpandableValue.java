/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  An interface extending both {@link Expandable} and {@link Value}.
 */
public interface ExpandableValue extends Value {
}
