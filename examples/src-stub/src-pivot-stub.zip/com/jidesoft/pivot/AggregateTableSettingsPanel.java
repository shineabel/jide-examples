/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  This class is not ready for public usage yet.
 */
public class AggregateTableSettingsPanel extends StandardDialogPane {

	public AggregateTableSettingsPanel(AggregateTable aggregateTable) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	/**
	 *  Changes the default cancel action.
	 * 
	 *  @param cancelAction the cancel action
	 */
	public void setCancelAction(javax.swing.AbstractAction cancelAction) {
	}

	/**
	 *  Gets the cancel action.
	 * 
	 *  @return the cancel action.
	 */
	public javax.swing.AbstractAction getCancelAction() {
	}

	/**
	 *  Changes the default OK action.
	 * 
	 *  @param okAction the ok action
	 */
	public void setOKAction(javax.swing.AbstractAction okAction) {
	}

	/**
	 *  Gets the OK action.
	 * 
	 *  @return the OK action.
	 */
	public javax.swing.AbstractAction getOKAction() {
	}

	@java.lang.Override
	public void initComponents() {
	}

	public ISortableTableModel.SortItem[] getSortItems() {
	}

	public IFilterableTableModel.FilterItem[] getFilterItems() {
	}

	public IPivotDataModel getPivotDataModel() {
	}

	public javax.swing.table.TableModel getTableModel() {
	}
}
