/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The component used by HeaderTable which has a "+/-" button.
 */
public class HeaderExpandablePanel extends ExpandablePanel {

	public HeaderExpandablePanel(javax.swing.JTable table, javax.swing.Icon expandedIcon, javax.swing.Icon collapsedIcon, java.awt.Color disabledBackground, java.awt.Color disabledForeground) {
	}

	public HeaderExpandablePanel(javax.swing.JTable table, java.awt.Component actualRenderer, javax.swing.Icon expandedIcon, javax.swing.Icon collapsedIcon, java.awt.Color disabledBackground, java.awt.Color disabledForeground) {
	}

	@java.lang.Override
	protected void paintBorder(java.awt.Graphics g) {
	}

	@java.lang.Override
	protected int paintIcon(java.awt.Graphics g, int start) {
	}

	@java.lang.Override
	public boolean isExpandIconVisible(javax.swing.JTable table) {
	}

	@java.lang.Override
	protected void paintBackground(java.awt.Graphics g) {
	}
}
