/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The table model for the table in the data area in pivot table.
 */
public class DataTableModel extends javax.swing.table.AbstractTableModel implements PivotConstants {

	public DataTableModel(PivotDataModel pivotDataModel) {
	}

	public IPivotDataModel getPivotDataModel() {
	}

	public int getRowCount() {
	}

	/**
	 *  Gets the column name. It will be the field's title.
	 * 
	 *  @param column the column index.
	 *  @return the column name.
	 */
	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int columnIndex) {
	}

	public int getColumnCount() {
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	protected boolean needDisplayPercentageForGrandTotal(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the running type of the cell. If the cell displays a running summary, the returned value will be the running
	 *  type. Otherwise, it will return -1.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the running type of the cell.
	 */
	public int getRunningTypeAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the summary type of the cell. If the cell displays a subtotal, the returned value will be the subtotal type.
	 *  Otherwise, it will return the PivotField's getSummaryType() value.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the summary type of the cell.
	 */
	public int getSummaryTypeAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the ConverterContext of the cell. In most cases, it will return the ConverterContext of the fields. But if
	 *  the cell displays a summary information, it will use {@link PivotField#getSummaryClass(int)} to find out the
	 *  actual ConverterContext. If getSummaryClass return null, it will use the same ConverterContext as the pivot
	 *  field. But if getSummaryClass return another type (such as SUMMARY_COUNT will return Long.class), the
	 *  ConverterContext will be null so that the default cell renderer for that particular type will be used.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the ConverterContext of the cell.
	 */
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the EditorContext of the cell. In most cases, it will return the EditorContext of the fields. But if the
	 *  cell displays a summary information, it will use {@link PivotField#getSummaryClass(int)} to find out the actual
	 *  EditorContext. If getSummaryClass return null, it will use the same EditorContext as the pivot field. But if
	 *  getSummaryClass return another type (such as SUMMARY_COUNT will return Long.class), the EditorContext will be
	 *  null so that the default cell renderer for that particular type will be used.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the ConverterContext of the cell.
	 */
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the cell type at the cell.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the cell type at the cell.
	 */
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the field at the cell.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the field at the cell.
	 */
	public PivotField getDataFieldAt(int rowIndex, int columnIndex) {
	}

	public final CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	public final boolean isCellStyleOn() {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}
}
