/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class RunningSummaryValues extends DefaultValues {

	public RunningSummaryValues(Value[] values) {
	}

	public RunningSummaryValues(java.util.List values) {
	}

	public RunningSummaryValues(Object[] values) {
	}

	public RunningSummaryValues(ExpandableValue value) {
	}

	public RunningSummary getRunningSummary() {
	}

	@java.lang.Override
	public String toString() {
	}

	public int getRunningType() {
	}

	public PivotField getBaseOnField() {
	}

	public PivotField getRangeInField() {
	}

	public Object getCompareTo() {
	}
}
