/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  A value represents dummy value when there is no row field (or column fields) but there are data
 *  fields in that area.
 */
public class DummyValue extends DefaultExpandable implements ExpandableValue {

	public DummyValue() {
	}

	public Object getValue() {
	}

	public void setValue(Object value) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}
}
