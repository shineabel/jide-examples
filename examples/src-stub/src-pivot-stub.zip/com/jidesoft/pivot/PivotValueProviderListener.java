/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The listener interface for receiving PivotDataModelEvent.
 */
public interface PivotValueProviderListener extends java.util.EventListener {

	public void pivotValueProviderEventHandler(PivotValueProviderEvent event);
}
