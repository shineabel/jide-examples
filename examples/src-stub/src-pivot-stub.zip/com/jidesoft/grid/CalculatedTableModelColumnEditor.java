package com.jidesoft.grid;


/**
 *  This class is not ready for public usage yet.
 */
public class CalculatedTableModelColumnEditor extends AbstractDialogPage {

	public javax.swing.JButton _removeColumnButton;

	public CalculatedTableModelColumnEditor(javax.swing.table.TableModel originalTableModel) {
	}

	public void lazyInitialize() {
	}

	protected void initComponents() {
	}

	/**
	 *  Gets the CalculatedTableModel created by this CalculatedTableModelColumnEditor. Please note, if no calculated
	 *  table columns are created in this editor, this method will return the original table model.
	 * 
	 *  @return the table model. If the calculated table columns are added, this method will return the
	 *          CalculatedTableModel instance. Otherwise, the original table model will be returned.
	 */
	public javax.swing.table.TableModel getCalculatedTableModel() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in dashboard.properties.
	 * 
	 *  @param key the resource key.
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Gets the resource bundle used by this component.
	 * 
	 *  @return the resource bundle.
	 */
	public java.util.ResourceBundle getResourceBundle() {
	}
}
