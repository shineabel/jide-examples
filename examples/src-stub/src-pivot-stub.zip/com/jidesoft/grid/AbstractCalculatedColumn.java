package com.jidesoft.grid;


/**
 *  This is an abstract implementation of CalculatedColumn interface. It implements most methods except getValueAt and
 *  getDependingColumns.
 *  <p/>
 *  It also provides support for ObjectGrouper to group different values into the same group so that the column has less
 *  possible values.
 */
public abstract class AbstractCalculatedColumn extends javax.swing.table.TableColumn implements CalculatedColumn {

	public AbstractCalculatedColumn(javax.swing.table.TableModel model) {
	}

	protected AbstractCalculatedColumn(javax.swing.table.TableModel model, String newColumnName) {
	}

	protected AbstractCalculatedColumn(javax.swing.table.TableModel model, String newColumnName, Class newColumnClass) {
	}

	protected AbstractCalculatedColumn(javax.swing.table.TableModel model, ObjectGrouper objectGrouper) {
	}

	protected AbstractCalculatedColumn(javax.swing.table.TableModel model, String columnName, ObjectGrouper objectGrouper) {
	}

	public javax.swing.table.TableModel getActualModel() {
	}

	public String getColumnName() {
	}

	@java.lang.Override
	public Object getColumnIdentifier() {
	}

	public void setColumnName(String columnName) {
	}

	public Class getColumnClass() {
	}

	public void setColumnClass(Class columnClass) {
	}

	public ObjectGrouper getObjectGrouper() {
	}

	public void setObjectGrouper(ObjectGrouper objectGrouper) {
	}

	public Class getCellClass(int rowIndex) {
	}

	public EditorContext getEditorContext(int rowIndex) {
	}

	public void setEditorContext(EditorContext editorContext) {
	}

	public ConverterContext getConverterContext(int rowIndex) {
	}

	public void setConverterContext(ConverterContext converterContext) {
	}

	public static Object getGroupValue(ObjectGrouper grouper, Object value) {
	}
}
