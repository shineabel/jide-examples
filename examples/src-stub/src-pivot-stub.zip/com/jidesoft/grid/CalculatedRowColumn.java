package com.jidesoft.grid;


/**
 *  CalculatedColumn for Row based TreeTableModel.
 * 
 *  @since 3.4.1
 */
public interface CalculatedRowColumn {

	/**
	 *  Gets the value at the cell of the Row instance.
	 * 
	 *  @param row the row instance
	 *  @return the cell value.
	 */
	public Object getValueAt(Row row);
}
