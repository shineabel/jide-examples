/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  List cell renderer used in ShortcutEditor's command list.
 * 
 *  @since 3.3.7
 */
public class CommandListCellRenderer extends javax.swing.JPanel implements javax.swing.ListCellRenderer {

	protected static java.awt.Color COLOR_MODIFIED;

	protected static java.awt.Color COLOR_MODIFIED_SELECTED;

	protected static java.awt.Color COLOR_DEFAULT;

	protected static java.awt.Color COLOR_DEFAULT_SELECTED;

	protected static java.awt.Color COLOR_DISABLE;

	protected StyledLabel _commandLabel;

	protected StyledLabel _shortcutLabel;

	protected ShortcutEditor _shortcutEditor;

	/**
	 *  The constructor.
	 * 
	 *  @param editor the shortcut editor
	 */
	public CommandListCellRenderer(ShortcutEditor editor) {
	}

	@java.lang.Override
	public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	}
}
