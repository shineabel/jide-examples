/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  <code>KeyboardShortcut</code> represents a kind of shortcuts that triggered by keyboard. It can be one keystroke such
 *  as ctrl+c or several keystrokes such ctrl+x followed ctrl+c (to exit Emacs).
 */
public class KeyboardShortcut extends Shortcut {

	public KeyboardShortcut() {
	}

	public KeyboardShortcut(javax.swing.KeyStroke keyStroke) {
	}

	public KeyboardShortcut(javax.swing.KeyStroke keyStroke, String context) {
	}

	public KeyboardShortcut(javax.swing.KeyStroke[] keyStrokes) {
	}

	public KeyboardShortcut(javax.swing.KeyStroke[] keyStrokes, String context) {
	}

	public KeyboardShortcut(java.awt.event.KeyEvent e) {
	}

	public javax.swing.KeyStroke[] getKeyStrokes() {
	}

	public void addKeyStroke(javax.swing.KeyStroke keyStroke) {
	}

	public void removeLastKeyStroke() {
	}

	public void clear() {
	}

	public int getCount() {
	}

	@java.lang.Override
	public String toString() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	public static javax.swing.KeyStroke parseKeyStroke(String s) {
	}

	public static String getKeyStrokeString(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Converts the shortcut for Mac OS X.
	 * 
	 *  @return a shortcut for Mac OS X.
	 */
	public Shortcut convertToMacOSX() {
	}

	/**
	 *  Converts the shortcut string to MacOSX type of shortcut. The different is Mac OS X uses "meta" to replace
	 *  "control" key as on other operating systems.
	 * 
	 *  @param shortcut the shortcut string.
	 *  @return the shortcut string for Mac OS X.
	 */
	public static String convertToMacOSX(String shortcut) {
	}

	/**
	 *  Converts the shortcut string from MacOSX type of shortcut. The different is Mac OS X uses "meta" to replace
	 *  "control" key as on other operating systems.
	 * 
	 *  @param shortcut the shortcut string for Mac OS X.
	 *  @return the shortcut string for non-Mac OS X.
	 */
	public static String convertFromMacOSX(String shortcut) {
	}
}
