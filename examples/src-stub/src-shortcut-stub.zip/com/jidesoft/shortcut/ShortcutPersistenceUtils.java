/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  A helper class that can support persist ShortcutSchema to/from xml file.
 */
public class ShortcutPersistenceUtils {

	public ShortcutPersistenceUtils() {
	}

	/**
	 *  Saves the shortcut schema to a file.
	 * 
	 *  @param manager  the shortcut schema manager
	 *  @param fileName the file name
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(ShortcutSchemaManager manager, String fileName) {
	}

	/**
	 *  Saves the shortcut schema to a file.
	 * 
	 *  @param manager  the shortcut schema manager
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(ShortcutSchemaManager manager, String fileName, String encoding) {
	}

	/**
	 *  Saves the shortcut schema to a file.
	 * 
	 *  @param manager the shortcut schema manager
	 *  @param out     the output stream
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(ShortcutSchemaManager manager, java.io.OutputStream out) {
	}

	/**
	 *  Saves the shortcut schema to a file.
	 * 
	 *  @param manager  the shortcut schema manager
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(ShortcutSchemaManager manager, java.io.OutputStream out, String encoding) {
	}

	public static org.w3c.dom.Document save(ShortcutSchemaManager manager) {
	}

	public static void load(ShortcutSchemaManager manager, java.io.InputStream in) {
	}

	public static void load(ShortcutSchemaManager manager, String fileName) {
	}

	public static void load(ShortcutSchemaManager manager, java.io.InputStream in, boolean append) {
	}

	public static void load(ShortcutSchemaManager manager, String fileName, boolean append) {
	}

	public static void load(ShortcutSchemaManager manager, org.w3c.dom.Document document) {
	}

	public static void load(ShortcutSchemaManager manager, org.w3c.dom.Document document, boolean append) {
	}

	public static String getVersion(java.io.InputStream in) {
	}

	public static String getVersion(String fileName) {
	}

	public static String getVersion(org.w3c.dom.Document document) {
	}
}
